// TBC Assistant 3.1.0 — Chrome extension build of the tool. Built from IansAssistant.user.js.
window.__tbcxMeta = {"name": "TBC Assistant", "version": "3.1.0", "namespace": "ians-assistant", "description": "TBC Assistant \u2014 Sabre *IA/VI* GDS toolkit for agents: copy button for flight sites, CRM Sort Me / Merge / quick Sell edit / search panel, Send to lead, power dialer + RingCentral texting. Dark dashboard design."};
window.__tbcxRun = function (GM_getValue, GM_setValue, GM_deleteValue, GM_listValues, GM_addValueChangeListener, GM_removeValueChangeListener, GM_addStyle, GM_setClipboard, GM_openInTab, GM_xmlhttpRequest, GM_registerMenuCommand, GM_unregisterMenuCommand, GM_info, unsafeWindow) {
// ==UserScript==
// @name         TBC Assistant
// @namespace    ians-assistant
// @version      3.1.0
// @updateURL    https://raw.githubusercontent.com/IanTBC/ians-assistant/main/IansAssistant.user.js
// @downloadURL  https://raw.githubusercontent.com/IanTBC/ians-assistant/main/IansAssistant.user.js
// @description  TBC Assistant — Sabre *IA/VI* GDS toolkit for agents: copy button for flight sites, CRM Sort Me / Merge / quick Sell edit / search panel, Send to lead, power dialer + RingCentral texting. Dark dashboard design.
// @match        *://*.flybasis.com/*
// @match        *://agentsearch.vercel.app/*
// @match        *://*.awardlogic.com/*
// @match        *://*.pointsyeah.com/*
// @match        *://matrix.itasoftware.com/*
// @match        *://*.kayak.com/*
// @match        *://*.cheapoair.com/*
// @match        https://www.google.com/travel/flights*
// @match        https://bo.travelbusinessclass.com/*
// @match        https://bo.tmgbo.com/*
// @match        *://*.tmgbo.com/*
// @match        https://apps.ringcentral.com/integration/ringcentral-embeddable/*
// @match        https://app.ringcentral.com/*
// @match        https://iantbc.github.io/ians-assistant/*
// @grant        GM_addStyle
// @grant        GM_setClipboard
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addValueChangeListener
// @grant        unsafeWindow
// @grant        GM_openInTab
// @grant        GM_removeValueChangeListener
// @grant        GM_xmlhttpRequest
// @connect      raw.githubusercontent.com
// @author       Ian Brown
// @run-at       document-idle
// ==/UserScript==

/*
 * ┌──────────────────────────────────────────────────────────────────┐
 * │  TBC Assistant                                    © Ian Brown     │
 * │  Sabre GDS, BO and calling toolkit for Travel Business Class     │
 * │  agents. Guide and install: https://iantbc.github.io/ians-assistant/ │
 * └──────────────────────────────────────────────────────────────────┘
 *
 *  How this file is laid out
 *    SHARED LOOK ............ colours for Dark / Light / Navy, and Pip
 *    UPDATE NOTICE .......... "new version available" banner
 *    SECTION 1 .............. flight sites: GDS copy, Lead ID, Sell box
 *    SECTIONS 2-3 ........... the BO: Add option tools, search panel, flags
 *    SECTION 4 .............. the assistant panel: dialer, texting, Pip
 *    SECTIONS 6-11 .......... RingCentral helpers, checks, quote card,
 *                             terminal helper, lead tool pages
 *
 *  Saved settings keep their original key names on purpose, so agents
 *  never lose their templates, theme or progress when they update.
 */


// ====================================================================
// SHARED LOOK — mode (nova / nova night / dark / light / navy) + accent colour, used by every
// part of the script (panel, flight-site pop-up, banners). The panel's
// CSS below mirrors these same values.
// ====================================================================
var IA_MODES = {"dark": {"bg": "#14161f", "card": "rgba(255,255,255,.06)", "cardbd": "transparent", "field": "#1d2030", "line": "#262a3a", "line2": "#303548", "text": "#e3e5f0", "title": "#ffffff", "muted": "#9a9fb8", "sec": "#c9cbe0", "head": "#e3e5f0", "eye": "#0e0f13", "onacc": "#0e0f13", "ok": "#4ade80", "bad": "#ff7b7b", "stop": "#e5484d", "foot": "#6b7089", "shadow": "0 22px 50px rgba(0,0,0,.55)", "glass": "rgba(24,26,40,.80)", "edge": "rgba(255,255,255,.10)", "inner": "rgba(255,255,255,.06)", "chip": "rgba(255,255,255,.08)", "chipshadow": "none", "sky": "radial-gradient(circle at 18% 0%, rgba(124,124,248,.22) 0, transparent 55%), radial-gradient(circle at 100% 100%, rgba(56,189,248,.10) 0, transparent 50%)"}, "light": {"bg": "#f7faff", "card": "rgba(255,255,255,.80)", "cardbd": "transparent", "field": "#ffffff", "line": "#dfe6f3", "line2": "#d3dcee", "text": "#0d1b3e", "title": "#0d1b3e", "muted": "#5a6888", "sec": "#2c3a5c", "head": "#0d1b3e", "eye": "#ffffff", "onacc": "#ffffff", "ok": "#16a34a", "bad": "#dc3e42", "stop": "#e0342b", "foot": "#8a96b2", "shadow": "0 20px 44px rgba(31,92,255,.20)", "glass": "rgba(240,246,255,.82)", "edge": "rgba(255,255,255,.95)", "inner": "rgba(255,255,255,.80)", "chip": "rgba(255,255,255,.92)", "chipshadow": "0 2px 6px rgba(13,27,62,.07)", "sky": "radial-gradient(circle at 12% 0%, rgba(255,255,255,.9) 0, transparent 45%), linear-gradient(160deg, rgba(158,197,255,.55), rgba(230,240,255,.35))"}, "navy": {"bg": "#0f2142", "card": "rgba(160,190,255,.08)", "cardbd": "transparent", "field": "#142a50", "line": "#1f3560", "line2": "#284273", "text": "#e6edf7", "title": "#ffffff", "muted": "#9db2d3", "sec": "#c4d2e6", "head": "#e6edf7", "eye": "#071226", "onacc": "#071226", "ok": "#4ade80", "bad": "#ff8a8a", "stop": "#e5484d", "foot": "#6a80a6", "shadow": "0 22px 50px rgba(2,8,20,.6)", "glass": "rgba(18,38,72,.82)", "edge": "rgba(160,190,255,.16)", "inner": "rgba(160,190,255,.08)", "chip": "rgba(160,190,255,.11)", "chipshadow": "none", "sky": "radial-gradient(circle at 18% 0%, rgba(124,156,255,.24) 0, transparent 55%), radial-gradient(circle at 100% 100%, rgba(45,212,191,.10) 0, transparent 50%)"}};
var IA_ACCENTS = {"midnight": ["#7c7cf8", "#1f5cff", "#7c9cff"], "teal": ["#2dd4bf", "#0f766e", "#5eead4"], "pink": ["#f472b6", "#db2777", "#f9a8d4"], "black": ["#e4e4e7", "#27272a", "#e6edf7"], "gold": ["#f5b544", "#b45309", "#fcd34d"], "rainbow": ["#a78bfa", "#7c3aed", "#c4b5fd"]};
// Nova and Nova Night (2.15.0): the website's look. They bring their own
// orange (acc) for Pip and highlights, and ink pill buttons (pri / onpri).
// In Dark, Light and Navy, pri is simply the accent colour.
IA_MODES.nova = {"bg": "#EEF1F7", "card": "rgba(255,255,255,.92)", "cardbd": "transparent", "field": "#FFFFFF", "line": "rgba(18,22,40,.10)", "line2": "rgba(18,22,40,.16)", "text": "#121628", "title": "#121628", "muted": "#565E77", "sec": "#2E3550", "head": "#121628", "eye": "#121628", "onacc": "#121628", "ok": "#0F9C83", "bad": "#C2283A", "stop": "#C2283A", "foot": "#8A90A6", "shadow": "0 1px 2px rgba(18,22,40,.05), 0 18px 40px -18px rgba(18,22,40,.30)", "glass": "rgba(255,255,255,.74)", "edge": "rgba(18,22,40,.10)", "inner": "#FFFFFF", "chip": "#FFFFFF", "chipshadow": "0 1px 2px rgba(18,22,40,.06), 0 6px 14px -8px rgba(18,22,40,.22)", "sky": "radial-gradient(circle at 100% 0%, rgba(255,120,80,.24) 0, transparent 55%), radial-gradient(circle at 0% 100%, rgba(80,130,255,.18) 0, transparent 55%)", "acc": "#FF5B2E", "pri": "#121628", "onpri": "#F5F7FC"};
IA_MODES.novanight = {"bg": "#0A0D19", "card": "rgba(255,255,255,.04)", "cardbd": "transparent", "field": "#1B2036", "line": "rgba(238,240,250,.10)", "line2": "rgba(238,240,250,.16)", "text": "#EEF0FA", "title": "#FFFFFF", "muted": "#9CA3BF", "sec": "#C9CDE0", "head": "#EEF0FA", "eye": "#0A0D19", "onacc": "#0A0D19", "ok": "#3FE0C5", "bad": "#FF6B7D", "stop": "#E5484D", "foot": "#6B7189", "shadow": "0 1px 2px rgba(0,0,0,.4), 0 18px 40px -18px rgba(0,0,0,.75)", "glass": "rgba(14,18,33,.93)", "edge": "rgba(238,240,250,.10)", "inner": "#131729", "chip": "#1B2036", "chipshadow": "none", "sky": "radial-gradient(circle at 100% 0%, rgba(255,110,70,.20) 0, transparent 55%), radial-gradient(circle at 0% 100%, rgba(70,110,255,.20) 0, transparent 55%)", "acc": "#FF7048", "pri": "#EEF0FA", "onpri": "#0A0D19"};
// Calm and Calm Light (3.0.0): the new main look. Flat surfaces, one blue
// for actions, green / amber / red only for meaning, Plus Jakarta Sans.
// Calm (dark) is the default. They reuse the Nova shapes (iaIsNova) and the
// CALM LAYER below adjusts corners, labels and fonts.
IA_MODES.calm = {"bg": "#0D1117", "card": "#161B24", "cardbd": "transparent", "field": "#1D2330", "line": "#262D3B", "line2": "#323A4B", "text": "#CDD3DF", "title": "#EEF1F7", "muted": "#97A0B3", "sec": "#B7BFCF", "head": "#EEF1F7", "eye": "#0D1117", "onacc": "#FFFFFF", "ok": "#3CCB92", "bad": "#FF6B63", "stop": "#E5484D", "foot": "#6F788C", "shadow": "0 0 0 1px #262D3B, 0 16px 36px -16px rgba(0,0,0,.7)", "glass": "#161B24", "edge": "#262D3B", "inner": "#1D2330", "chip": "#1D2330", "chipshadow": "none", "sky": "none", "acc": "#5B83FF", "pri": "#5B83FF", "onpri": "#FFFFFF"};
IA_MODES.calmlight = {"bg": "#F4F6F9", "card": "#FFFFFF", "cardbd": "transparent", "field": "#FFFFFF", "line": "#E4E8EF", "line2": "#D3D9E3", "text": "#2B3346", "title": "#0E1525", "muted": "#5F687C", "sec": "#3B4458", "head": "#0E1525", "eye": "#FFFFFF", "onacc": "#FFFFFF", "ok": "#0E9F6A", "bad": "#D93A33", "stop": "#D93A33", "foot": "#8A92A4", "shadow": "0 1px 2px rgba(14,21,37,.06), 0 12px 32px -14px rgba(14,21,37,.28)", "glass": "#FFFFFF", "edge": "#E4E8EF", "inner": "#F1F3F7", "chip": "#FFFFFF", "chipshadow": "inset 0 0 0 1px #D3D9E3", "sky": "none", "acc": "#2556F5", "pri": "#2556F5", "onpri": "#FFFFFF"};
var IA_LOOKS = [['calm', 'Calm'], ['calmlight', 'Calm Light'], ['nova', 'Nova'], ['novanight', 'Nova Night'], ['dark', 'Dark'], ['light', 'Light'], ['navy', 'Navy']];
function iaIsCalm(m) { return m === 'calm' || m === 'calmlight'; }
function iaIsNova(m) { return m === 'nova' || m === 'novanight' || iaIsCalm(m); }
function iaIsLight(m) { return m === 'light' || m === 'nova' || m === 'calmlight'; }
// Everyone moves to Calm (dark) once when 3.0.0 arrives; after that the
// agent's own pick stays (Nova and the older looks are still in the menu).
try {
  if (!GM_getValue('ia-calm-start', false)) { GM_setValue('ia-mode', 'calm'); GM_setValue('ia-calm-start', true); GM_setValue('ia-nova-start', true); }
} catch (e) { /* ignore */ }
function iaMode() {
  let m = 'calm';
  try { m = GM_getValue('ia-mode', 'calm'); } catch (e) { /* ignore */ }
  return IA_MODES[m] ? m : 'calm';
}
function iaPalette() {
  const mode = iaMode();
  let t = 'midnight';
  try { t = GM_getValue('bmo-theme', 'midnight'); } catch (e) { /* ignore */ }
  const acc = (IA_ACCENTS[t] || IA_ACCENTS.midnight)[Math.max(0, ['dark', 'light', 'navy'].indexOf(mode))];
  return Object.assign({ mode, acc, pri: acc, onpri: IA_MODES[mode].onacc }, IA_MODES[mode]);
}
// Nova fonts (Unbounded titles, Manrope text, JetBrains Mono labels). If a
// site blocks them, the system fonts are used instead.
try { GM_addStyle("@import url('https://fonts.googleapis.com/css2?family=Unbounded:wght@600;700&family=Manrope:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@500;600;700;800&family=JetBrains+Mono:wght@500&display=swap');"); } catch (e) { /* ignore */ }
// In Calm the same slots use Plus Jakarta Sans (a look change from Calm to
// Nova or back picks up its fonts after the page reloads).
var IA_CALM_FONT = "'Plus Jakarta Sans', 'Segoe UI', system-ui, -apple-system, sans-serif";
var IA_NOVA_FONT = iaIsCalm(iaMode()) ? IA_CALM_FONT : "Manrope, 'Segoe UI', system-ui, -apple-system, sans-serif";
var IA_NOVA_DISPLAY = iaIsCalm(iaMode()) ? IA_CALM_FONT : "Unbounded, 'Segoe UI', system-ui, sans-serif";
var IA_NOVA_MONO = "'JetBrains Mono', ui-monospace, Consolas, monospace";
// Windows or Mac: one script for both. Shortcuts use Ctrl on Windows and
// Control on a Mac (Command works too); labels use the Mac names on a Mac.
var IA_MAC = /Mac/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || navigator.userAgent);
var IA_MOD = IA_MAC ? 'Control' : 'Ctrl';

// ====================================================================
// CALM LAYER (3.0.0) — corners, labels and weights for the Calm looks.
// Works by a class on <html> (ia-calm), so every part of the tool picks it
// up without its own wiring. Flat: no blur behind panels (also cheaper to
// draw, so animations stay smooth).
// ====================================================================
function iaCalmClass() {
  try { document.documentElement.classList.toggle('ia-calm', iaIsCalm(iaMode())); } catch (e) { /* ignore */ }
}
iaCalmClass();
try { GM_addValueChangeListener('ia-mode', () => iaCalmClass()); } catch (e) { /* ignore */ }
try {
  GM_addStyle(`
  html.ia-calm .ia-widget.ia-mode-calm { --acc: #5B83FF; } html.ia-calm .ia-widget.ia-mode-calmlight { --acc: #2556F5; }
  .ia-mode-calm .ia-ico-dark, .ia-mode-calmlight .ia-ico-light { display: block; }
  html.ia-calm .ia-widget.ia-nova .ia-panel, html.ia-calm .ia-widget.ia-nova .ia-bubble { border-radius: 18px; -webkit-backdrop-filter: none; backdrop-filter: none; }
  html.ia-calm .ia-widget.ia-nova .ia-card { border-radius: 14px; }
  html.ia-calm button[class*="ia-"], html.ia-calm [class*="ia-"] button { border-radius: 10px !important; }
  html.ia-calm button[class*="chip"], html.ia-calm [class*="chip"] > button, html.ia-calm .ia-cb-card { border-radius: 999px !important; }
  html.ia-calm .ia-widget.ia-nova .ia-iconbtn, html.ia-calm .ia-widget.ia-nova .ia-mode-btn, html.ia-calm .ia-widget.ia-nova .ia-cb-btn { border-radius: 9px !important; }
  html.ia-calm .ia-widget.ia-nova .ia-call, html.ia-calm .ia-widget.ia-nova .ia-sec, html.ia-calm .ia-widget.ia-nova .ia-stop { box-shadow: none; border-radius: 12px !important; }
  html.ia-calm .ia-widget.ia-nova .ia-sec, html.ia-calm .ia-widget.ia-nova .ia-stop { background: var(--ia-inner); }
  html.ia-calm .ia-widget.ia-nova .ia-cb-badge { color: #fff; font-family: inherit; font-weight: 800; }
  html.ia-calm .ia-widget.ia-nova .ia-head__title, html.ia-calm .ia-widget.ia-nova .ia-panel .ia-screen-info__client, html.ia-calm .ia-widget.ia-nova .ia-idle__t,
  html.ia-calm .ia-widget.ia-nova .ia-stats b, html.ia-calm .ia-widget.ia-nova .ia-cbdue__who, html.ia-calm .ia-sq--nova .ia-sq__head b, html.ia-calm .ia-sb--nova .ia-sb-t {
    font-weight: 800; letter-spacing: -.01em; }
  html.ia-calm .ia-widget.ia-nova .ia-panel .ia-screen-info__label, html.ia-calm .ia-widget.ia-nova .ia-stats > span, html.ia-calm .ia-widget.ia-nova .ia-foot,
  html.ia-calm .ia-widget.ia-nova .ia-cbdue__k { font-family: ${IA_CALM_FONT}; text-transform: none; letter-spacing: 0; font-weight: 600; }
  html.ia-calm .ia-widget.ia-nova .ia-stats > span { font-size: 10.5px; }
  html.ia-calm .ia-widget.ia-nova .ia-cbdue, html.ia-calm .ia-cbpop.ia-nova, html.ia-calm .ia-sb--nova, html.ia-calm .ia-sq--nova .ia-sq__card { border-radius: 16px; }
  html.ia-calm .ia-widget.ia-nova .ia-reminder, html.ia-calm .ia-widget.ia-nova .ia-levelup__text { border-radius: 14px; }
  /* flight sites: the GDS copy button and the big COPIED sign */
  html.ia-calm .gds-btn-base.gds-btn-base { background: #161B24 !important; color: #EEF1F7 !important; border: 1px solid #323A4B !important; border-radius: 10px !important;
    font-family: ${IA_CALM_FONT} !important; box-shadow: none !important; }
  html.ia-calm .gds-btn-base.gds-btn-base:hover { background: #1D2330 !important; color: #fff !important; }
  html.ia-calm .gds-btn-base.copied { background: #0E9F6A !important; border-color: #0E9F6A !important; color: #fff !important; }
  html.ia-calm .gds-big-copied { font-family: ${IA_CALM_FONT}; font-size: 40px; letter-spacing: 2px; color: #fff; background: #161B24; border: 1px solid #323A4B; border-radius: 18px; padding: 20px 40px; }
  `);
} catch (e) { /* ignore */ }
// Small Pip (body + eyes) built with DOM calls, so it works on sites that
// block innerHTML (Google's Trusted Types).
function iaPipNode(size, p) {
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '10 10 76 80');
  svg.setAttribute('width', String(size));
  svg.setAttribute('height', String(Math.round(size * 80 / 76)));
  svg.setAttribute('aria-hidden', 'true');
  const body = document.createElementNS(NS, 'path');
  body.setAttribute('d', 'M22 70 L22 38 Q22 26 34 26 L62 26 Q74 26 74 38 L74 62 Q74 74 62 74 L40 74 L30 84 L31 74 Q22 73 22 70 Z');
  body.setAttribute('fill', p.acc);
  svg.appendChild(body);
  [40, 56].forEach((cx) => {
    const c = document.createElementNS(NS, 'circle');
    c.setAttribute('cx', String(cx)); c.setAttribute('cy', '47'); c.setAttribute('r', '4.5'); c.setAttribute('fill', p.eye);
    svg.appendChild(c);
  });
  return svg;
}


// ====================================================================
// UPDATE NOTICE — tells agents when a newer version is published.
// Set UPDATE_URL to the gist's raw link (the same one used for
// @updateURL / @downloadURL). Every 30 minutes it reads the published
// @version; if it's newer than the installed one, a small banner offers
// a one-click "Update" (opens Tampermonkey's install screen). While
// UPDATE_URL is empty this does nothing.
// ====================================================================
// ====================================================================
// WEBSITE CHECK — on the TBC Assistant website only, tells the page that
// the tool is installed (and which version), so its install guide can say
// "You're all set". Nothing else runs there.
// ====================================================================
(function websiteCheck() {
  if (location.hostname !== 'iantbc.github.io') return;
  const v = (typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || '';
  const mark = () => {
    document.documentElement.setAttribute('data-tbc-assistant', v);
    document.dispatchEvent(new CustomEvent('tbc-assistant-ready', { detail: { version: v } }));
  };
  mark();
  setTimeout(mark, 1500);
})();

(function updateNotice() {
  const UPDATE_URL = 'https://raw.githubusercontent.com/IanTBC/ians-assistant/main/extension/manifest.json'; // extension: newer version check
  if (!UPDATE_URL || window.top !== window) return;
  if (/ringcentral\.com$/.test(location.hostname)) return;
  if (location.hostname === 'iantbc.github.io') return; // the website shows updates itself
  const CHECK_KEY = 'ia-update-checked';
  const SNOOZE_KEY = 'ia-update-snooze';
  const installed = (typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || '0';
  const newer = (a, b) => {
    const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0; }
    return false;
  };
  function showBanner(version) {
    if (!document.body || document.getElementById('ia-update-banner')) return;
    try { if (Date.now() < Number(GM_getValue(SNOOZE_KEY + version, 0))) return; } catch (e) { /* ignore */ }
    const p = iaPalette();
    const box = document.createElement('div');
    box.id = 'ia-update-banner';
    box.style.cssText = "position:fixed;left:16px;bottom:16px;z-index:2147483647;display:flex;align-items:center;gap:10px;background:" + p.sky + "," + p.glass + ";-webkit-backdrop-filter:blur(18px) saturate(1.4);backdrop-filter:blur(18px) saturate(1.4);color:" + p.text + ";border:1px solid " + p.edge + ";border-radius:16px;padding:9px 11px;font:700 12.5px Inter,'Segoe UI',system-ui,sans-serif;box-shadow:" + p.shadow + ";" + (iaIsNova(p.mode) ? 'border-radius:999px;padding:7px 8px 7px 16px;font-family:' + IA_NOVA_FONT + ';' : '');
    const txt = document.createElement('span');
    txt.textContent = "TBC Assistant " + version + ' is available';
    const go = document.createElement('button');
    go.textContent = 'Update';
    go.style.cssText = 'border:0;border-radius:' + (iaIsNova(p.mode) ? '999px' : '10px') + ';padding:7px 13px;background:' + p.pri + ';color:' + p.onpri + ';font:800 12px Inter,\'Segoe UI\',system-ui,sans-serif;cursor:pointer;';
    const later = document.createElement('button');
    later.textContent = 'Later';
    later.style.cssText = 'border:0;border-radius:' + (iaIsNova(p.mode) ? '999px' : '10px') + ';padding:7px 11px;background:' + p.chip + ';color:' + p.title + ';font:800 12px Inter,\'Segoe UI\',system-ui,sans-serif;cursor:pointer;';
    go.addEventListener('click', () => {
      try { GM_openInTab('https://iantbc.github.io/ians-assistant/#update', { active: true }); } catch (e) { window.open('https://iantbc.github.io/ians-assistant/#update', '_blank'); }
      box.remove();
    });
    later.addEventListener('click', () => {
      try { GM_setValue(SNOOZE_KEY + version, Date.now() + 3600e3); } catch (e) { /* ignore */ }
      box.remove();
    });
    box.append(iaPipNode(18, p), txt, go, later);
    document.body.appendChild(box);
  }
  function check() {
    let last = 0;
    try { last = Number(GM_getValue(CHECK_KEY, 0)) || 0; } catch (e) { /* ignore */ }
    let known = '';
    try { known = GM_getValue('ia-update-latest', ''); } catch (e) { /* ignore */ }
    if (known && newer(known, installed)) showBanner(known);
    if (Date.now() - last < 2 * 60e3) return; // one check every 2 minutes, shared by all tabs
    try { GM_setValue(CHECK_KEY, Date.now()); } catch (e) { /* ignore */ }
    try {
      GM_xmlhttpRequest({
        method: 'GET', url: UPDATE_URL + '?t=' + Date.now(), nocache: true,
        onload: (r) => {
          if (r.status !== 200) return;
          const m = String(r.responseText).match(/"version"\s*:\s*"([\d.]+)"/);
          if (!m) return;
          try { GM_setValue('ia-update-latest', m[1]); } catch (e) { /* ignore */ }
          if (newer(m[1], installed)) showBanner(m[1]);
        },
      });
    } catch (e) { /* ignore */ }
  }
  setTimeout(check, 3000);
  setInterval(check, 60e3);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
})();


// ====================================================================
// SECTION 1 · Flight-search-site GDS *IA/VI* copy button
// (ITA Matrix, FlyBasis/agentsearch, PointsYeah, AwardLogic, Kayak,
// CheapOair, Google Flights)
// ====================================================================
// ------------------------------------------------------------------
// SHARED *IA/VI* BUILD ENGINE (data + pure helpers only) — used by both
// the flight-search-site adapters below and the CRM's own terminal
// flight-list builder further down. Declared once here, at true
// top-level scope (outside every IIFE below), rather than as two full
// copies inside each one — those two copies used to be byte-for-byte
// identical, so this removes one of them without changing behavior
// anywhere. Two things intentionally stay OUT of this shared block,
// each still duplicated in its own IIFE: CONFIG (its STATUS_CODE
// genuinely differs between the two — GK for award sites, SS
// otherwise, vs. always GK), and buildIALine/buildVILines/buildBoth/
// bookingClass (they read that CONFIG, so hoisting them here would
// mean they could no longer see either copy of it).
// ------------------------------------------------------------------
const EQUIP_MAP = {
    'airbus a319': '319', 'airbus a320-100/200': '320', 'airbus a320neo': '32N', 'airbus a321': '321',
    'airbus a321neo': '32Q', 'airbus a330': '333', 'airbus a330-200': '332', 'airbus a330-300': '333', 'airbus a330-900neo': '339',
    'airbus a350-900': '359', 'airbus a350-1000': '351', 'boeing 737-800': '738', 'boeing 737 max 8': '7M8',
    'boeing 737 max 9': '7M9', 'boeing 767-300': '763', 'boeing 767-300 (winglets)': '763',
    'boeing 777': '777', 'boeing 777-200er': '772', 'boeing 777-300er': '77W', 'boeing 777-300 er': '77W',
    'boeing 777-200 er': '772', 'boeing 787': '788', 'boeing 787-8': '788', 'boeing 787-9': '789', 'boeing 787-10': '781',
    'airbus a321neolr': '32S', 'airbus a321lr': '32S'
  };

const ALLIANCE_MAP = {
    AA: 'ONEWORLD', BA: 'ONEWORLD', IB: 'ONEWORLD', QF: 'ONEWORLD', CX: 'ONEWORLD', JL: 'ONEWORLD', QR: 'ONEWORLD', AY: 'ONEWORLD', MH: 'ONEWORLD',
    UA: 'STAR ALLIANCE', LH: 'STAR ALLIANCE', NH: 'STAR ALLIANCE', SQ: 'STAR ALLIANCE', AC: 'STAR ALLIANCE', TG: 'STAR ALLIANCE', OS: 'STAR ALLIANCE', LX: 'STAR ALLIANCE',
    DL: 'SKYTEAM', AF: 'SKYTEAM', KL: 'SKYTEAM', KE: 'SKYTEAM', SV: 'SKYTEAM', AZ: 'SKYTEAM', VN: 'SKYTEAM', AT: 'ONEWORLD'
  };

const AIRPORT_COORDS = {
    JFK:[40.6413,-73.7781], EWR:[40.6895,-74.1745], LGA:[40.7769,-73.8740], BOS:[42.3656,-71.0096],
    IAD:[38.9531,-77.4565], DCA:[38.8512,-77.0402], BWI:[39.1774,-76.6684], PHL:[39.8744,-75.2424],
    ORD:[41.9742,-87.9073], ATL:[33.6407,-84.4277], MIA:[25.7959,-80.2870], MCO:[28.4312,-81.3081],
    FLL:[26.0726,-80.1527], TPA:[27.9772,-82.5311], DFW:[32.8998,-97.0403], IAH:[29.9902,-95.3368],
    AUS:[30.1975,-97.6664], DEN:[39.8561,-104.6737], LAX:[33.9416,-118.4085], SFO:[37.6213,-122.3790],
    SAN:[32.7338,-117.1933], SEA:[47.4502,-122.3088], PDX:[45.5898,-122.5951], LAS:[36.0840,-115.1537],
    PHX:[33.4342,-112.0116], SLC:[40.7899,-111.9791], MSP:[44.8848,-93.2223], DTW:[42.2124,-83.3534],
    CLT:[35.2140,-80.9431], MSY:[29.9934,-90.2580], STL:[38.7487,-90.3700], MCI:[39.2976,-94.7139],
    PIT:[40.4915,-80.2329], CLE:[41.4117,-81.8498], IND:[39.7173,-86.2944], CMH:[39.9980,-82.8919],
    BNA:[36.1245,-86.6782], MEM:[35.0424,-89.9767], JAX:[30.4941,-81.6879], RDU:[35.8776,-78.7875],
    SAT:[29.5337,-98.4698], ELP:[31.8072,-106.3781], SJC:[37.3626,-121.9291], OAK:[37.7126,-122.2197],
    SNA:[33.6757,-117.8682], ONT:[34.0560,-117.6012], BUR:[34.2007,-118.3587], HNL:[21.3245,-157.9251],
    YVR:[49.1947,-123.1792], YYZ:[43.6777,-79.6248], YUL:[45.4706,-73.7408], YYC:[51.1215,-114.0076],
    MEX:[19.4363,-99.0721], CUN:[21.0365,-86.8771], PTY:[9.0714,-79.3835], BOG:[4.7016,-74.1469],
    LIM:[-12.0219,-77.1143], GRU:[-23.4356,-46.4731], GIG:[-22.8100,-43.2506], EZE:[-34.8222,-58.5358],
    SCL:[-33.3930,-70.7858], BKO:[12.5335,-7.9498],
    LHR:[51.4700,-0.4543], LGW:[51.1481,-0.1903], MAN:[53.3537,-2.2750], CDG:[49.0097,2.5479],
    ORY:[48.7262,2.3652], AMS:[52.3105,4.7683], FRA:[50.0379,8.5622], MUC:[48.3538,11.7861],
    DUS:[51.2895,6.7668], BER:[52.3667,13.5033], ZRH:[47.4647,8.5492], GVA:[46.2381,6.1090],
    VIE:[48.1103,16.5697], MAD:[40.4983,-3.5676], BCN:[41.2971,2.0785], LIS:[38.7813,-9.1359],
    FCO:[41.8003,12.2389], MXP:[45.6306,8.7281], VCE:[45.5053,12.3519], ATH:[37.9364,23.9445],
    IST:[41.2753,28.7519], SAW:[40.8986,29.3092], CPH:[55.6180,12.6560], ARN:[59.6519,17.9186],
    OSL:[60.1976,11.1004], HEL:[60.3172,24.9633], DUB:[53.4213,-6.2701], BRU:[50.9014,4.4844],
    WAW:[52.1657,20.9671], PRG:[50.1008,14.2600], BUD:[47.4298,19.2611], KEF:[63.9850,-22.6056],
    DXB:[25.2532,55.3657], AUH:[24.4330,54.6511], DOH:[25.2731,51.6081], RUH:[24.9576,46.6988],
    JED:[21.6796,39.1565], CAI:[30.1219,31.4056], JNB:[-26.1392,28.2460], CPT:[-33.9648,18.6017],
    NBO:[-1.3192,36.9278], LOS:[6.5774,3.3212], ADD:[8.9779,38.7993],
    HND:[35.5494,139.7798], NRT:[35.7720,140.3929], KIX:[34.4347,135.2440], ICN:[37.4602,126.4407],
    PVG:[31.1443,121.8083], PEK:[40.0799,116.6031], PKX:[39.5098,116.4109], HKG:[22.3080,113.9185],
    TPE:[25.0777,121.2328], SIN:[1.3644,103.9915], BKK:[13.6900,100.7501], KUL:[2.7456,101.7099],
    CGK:[-6.1256,106.6559], MNL:[14.5086,121.0198], DEL:[28.5562,77.1000], BOM:[19.0887,72.8679],
    BLR:[13.1986,77.7066], MAA:[12.9941,80.1709], HYD:[17.2403,78.4294], CCU:[22.6547,88.4467],
    SYD:[-33.9399,151.1753], MEL:[-37.6690,144.8410], BNE:[-27.3842,153.1175], PER:[-31.9403,115.9669],
    AKL:[-37.0082,174.7850],
    CMB:[7.1808,79.8841], MLE:[4.1918,73.5290], KTM:[27.6966,85.3591], DAC:[23.8433,90.3978],
    ISB:[33.5491,72.8256], KHI:[24.9065,67.1608], LHE:[31.5216,74.4036], AMM:[31.7226,35.9932],
    BEY:[33.8209,35.4884], TLV:[32.0114,34.8867], ALG:[36.6910,3.2154], TUN:[36.8510,10.2272],
    CMN:[33.3675,-7.5900], ACC:[5.6052,-0.1668], DKR:[14.7397,-17.4902], DAR:[-6.8781,39.2026],
    EBB:[0.0424,32.4436], HRE:[-17.9318,31.0928], MRU:[-20.4302,57.6836], SDQ:[18.4297,-69.6689],
    PUJ:[18.5674,-68.3634], SJO:[9.9981,-84.2041], GUA:[14.5833,-90.5275],
    UIO:[-0.1292,-78.3575], CCS:[10.6031,-66.9906], ASU:[-25.2400,-57.5200], MVD:[-34.8384,-56.0308],
    NAN:[-17.7554,177.4434], PPT:[-17.5537,-149.6069], GUM:[13.4834,144.7960], HKT:[8.1132,98.3169],
    RGN:[16.9073,96.1332], VTE:[17.9883,102.5633], PNH:[11.5466,104.8441],
    DPS:[-8.7482,115.1672], CNX:[18.7669,98.9626],
  };

function haversineMiles(lat1, lon1, lat2, lon2) {
    const R = 3958.8; // Earth radius, miles
    const toRad = (deg) => (deg * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
    return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
  }

const CONTINENT_OF = {
    JFK:'NA',EWR:'NA',LGA:'NA',BOS:'NA',IAD:'NA',DCA:'NA',BWI:'NA',PHL:'NA',ORD:'NA',ATL:'NA',
    MIA:'NA',MCO:'NA',FLL:'NA',TPA:'NA',DFW:'NA',IAH:'NA',AUS:'NA',DEN:'NA',LAX:'NA',SFO:'NA',
    SAN:'NA',SEA:'NA',PDX:'NA',LAS:'NA',PHX:'NA',SLC:'NA',MSP:'NA',DTW:'NA',CLT:'NA',MSY:'NA',
    STL:'NA',MCI:'NA',PIT:'NA',CLE:'NA',IND:'NA',CMH:'NA',BNA:'NA',MEM:'NA',JAX:'NA',RDU:'NA',
    SAT:'NA',ELP:'NA',SJC:'NA',OAK:'NA',SNA:'NA',ONT:'NA',BUR:'NA',HNL:'NA',YVR:'NA',YYZ:'NA',
    YUL:'NA',YYC:'NA',MEX:'NA',CUN:'NA',SDQ:'NA',PUJ:'NA',SJO:'NA',GUA:'NA',
    PTY:'SA',BOG:'SA',LIM:'SA',GRU:'SA',GIG:'SA',EZE:'SA',SCL:'SA',UIO:'SA',CCS:'SA',ASU:'SA',MVD:'SA',
    LHR:'EU',LGW:'EU',MAN:'EU',CDG:'EU',ORY:'EU',AMS:'EU',FRA:'EU',MUC:'EU',DUS:'EU',BER:'EU',
    ZRH:'EU',GVA:'EU',VIE:'EU',MAD:'EU',BCN:'EU',LIS:'EU',FCO:'EU',MXP:'EU',VCE:'EU',ATH:'EU',
    IST:'EU',SAW:'EU',CPH:'EU',ARN:'EU',OSL:'EU',HEL:'EU',DUB:'EU',BRU:'EU',WAW:'EU',PRG:'EU',
    BUD:'EU',KEF:'EU',
    CAI:'AF',JNB:'AF',CPT:'AF',NBO:'AF',LOS:'AF',ADD:'AF',ALG:'AF',TUN:'AF',CMN:'AF',ACC:'AF',
    DKR:'AF',DAR:'AF',EBB:'AF',HRE:'AF',MRU:'AF',
    DXB:'AS',AUH:'AS',DOH:'AS',RUH:'AS',JED:'AS',AMM:'AS',BEY:'AS',TLV:'AS',HND:'AS',NRT:'AS',
    KIX:'AS',ICN:'AS',PVG:'AS',PEK:'AS',PKX:'AS',HKG:'AS',TPE:'AS',SIN:'AS',BKK:'AS',KUL:'AS',
    CGK:'AS',MNL:'AS',DEL:'AS',BOM:'AS',BLR:'AS',MAA:'AS',HYD:'AS',CCU:'AS',CMB:'AS',MLE:'AS',
    KTM:'AS',DAC:'AS',ISB:'AS',KHI:'AS',LHE:'AS',RGN:'AS',VTE:'AS',PNH:'AS',DPS:'AS',CNX:'AS',HKT:'AS',
    SYD:'OC',MEL:'OC',BNE:'OC',PER:'OC',AKL:'OC',NAN:'OC',PPT:'OC',GUM:'OC',
    // Continent-only tags below — not in AIRPORT_COORDS (no precise coords
    // kept for these), but classified so they still hit the continent-pair
    // fallback instead of falling all the way through to the flat global
    // guess. This is where this tier actually earns its keep — the codes
    // above are already covered exactly, so this list is what makes the
    // fallback tier do anything at all rather than being dead weight.
    YOW:'NA',YEG:'NA',YWG:'NA',ANC:'NA',OGG:'NA',KOA:'NA',SJU:'NA',MSN:'NA',GRR:'NA',OMA:'NA',
    TUL:'NA',OKC:'NA',BHM:'NA',RSW:'NA',PBI:'NA',ABQ:'NA',TUS:'NA',BOI:'NA',GEG:'NA',SMF:'NA',RNO:'NA',
    BSB:'SA',REC:'SA',FOR:'SA',CNF:'SA',POA:'SA',VVI:'SA',LPB:'SA',CUZ:'SA',MDE:'SA',CLO:'SA',GYE:'SA',
    NCE:'EU',LYS:'EU',TLS:'EU',MRS:'EU',BLQ:'EU',NAP:'EU',PMI:'EU',AGP:'EU',SVQ:'EU',BIO:'EU',
    PSA:'EU',TRN:'EU',STR:'EU',HAM:'EU',HAJ:'EU',NUE:'EU',KRK:'EU',GDN:'EU',LJU:'EU',ZAG:'EU',
    SOF:'EU',OTP:'EU',BEG:'EU',SKG:'EU',LCA:'EU',PFO:'EU',
    LAD:'AF',MPM:'AF',WDH:'AF',GBE:'AF',LUN:'AF',RUN:'AF',SEZ:'AF',
    SGN:'AS',HAN:'AS',URC:'AS',CAN:'AS',SZX:'AS',CTU:'AS',XIY:'AS',WUH:'AS',NKG:'AS',TAO:'AS',
    DLC:'AS',SHE:'AS',HRB:'AS',KMG:'AS',CSX:'AS',FUK:'AS',CTS:'AS',OKA:'AS',NGO:'AS',KMQ:'AS',
    CJU:'AS',PUS:'AS',GMP:'AS',TAS:'AS',ALA:'AS',BAK:'AS',GYD:'AS',TBS:'AS',EVN:'AS',
    CHC:'OC',WLG:'OC',ZQN:'OC',CNS:'OC',OOL:'OC',ADL:'OC',CBR:'OC',HBA:'OC',DRW:'OC',
  };

const CONTINENT_AVG_MILES = {
    'NA-NA': 1400, 'SA-SA': 1600, 'EU-EU': 900, 'AF-AF': 1800, 'AS-AS': 2200, 'OC-OC': 1600,
    'NA-SA': 3300, 'EU-NA': 4300, 'AF-NA': 6500, 'AS-NA': 7200, 'NA-OC': 7600,
    'EU-SA': 5500, 'AF-SA': 4500, 'AS-SA': 10500, 'OC-SA': 8200,
    'AF-EU': 3000, 'AS-EU': 4800, 'EU-OC': 10500,
    'AF-AS': 4200, 'AF-OC': 7600,
    'AS-OC': 4200,
  };

const GLOBAL_AVG_MILES = 4000;

function lookupDistance(origin, dest) {
    const a = AIRPORT_COORDS[origin];
    const b = AIRPORT_COORDS[dest];
    if (a && b) return haversineMiles(a[0], a[1], b[0], b[1]);

    const c1 = CONTINENT_OF[origin];
    const c2 = CONTINENT_OF[dest];
    if (c1 && c2) {
      const key = [c1, c2].sort().join('-');
      if (CONTINENT_AVG_MILES[key] != null) return CONTINENT_AVG_MILES[key];
    }

    return GLOBAL_AVG_MILES;
  }

const DOW_LETTERS = ['S', 'M', 'T', 'W', 'Q', 'F', 'J'];

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

function formatDate(isoStr) {
    const d = new Date(isoStr);
    return `${String(d.getDate()).padStart(2, '0')}${MONTHS[d.getMonth()]}`;
  }

function formatTime(isoStr) {
    const d = new Date(isoStr);
    let h = d.getHours();
    const m = String(d.getMinutes()).padStart(2, '0');
    const ampm = h < 12 ? 'A' : 'P';
    h = h % 12 || 12;
    return `${h}${m}${ampm}`;
  }

function elapsed(durationMin) {
    const h = Math.floor(durationMin / 60);
    const m = String(durationMin % 60).padStart(2, '0');
    return `${h}.${m}`;
  }

function parseLocal(value) {
    if (value instanceof Date) return value;
    const s = String(value);
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?/);
    if (m) {
      return new Date(
        parseInt(m[1], 10), parseInt(m[2], 10) - 1, parseInt(m[3], 10),
        parseInt(m[4], 10), parseInt(m[5], 10), m[6] ? parseInt(m[6], 10) : 0
      );
    }
    return new Date(s);
  }

function dowLetter(d) {
    return DOW_LETTERS[d.getDay()];
  }

function sameCalendarDate(a, b) {
    return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  }

function daysBetween(a, b) {
    const msPerDay = 24 * 60 * 60 * 1000;
    const utcA = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const utcB = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.round((utcB - utcA) / msPerDay);
  }

const EQUIP_FAMILY_DEFAULTS = [
    { test: /a?350/, variants: [[/-?\s?1000/, '351'], [/-?\s?900/, '359']], fallback: '359' },
    { test: /a?330/, variants: [[/neo|-?\s?900/, '339'], [/-?\s?200/, '332'], [/-?\s?300/, '333']], fallback: '333' },
    { test: /787/, variants: [[/-?\s?8\b|800/, '788'], [/-?\s?9\b|900/, '789'], [/-?\s?10\b|1000/, '781']], fallback: '788' },
    { test: /737/, variants: [[/max\s?8/, '7M8'], [/max\s?9/, '7M9'], [/-?\s?800/, '738']], fallback: '738' },
    { test: /a?321/, variants: [[/neo\s?lr|lr\b/, '32S'], [/neo/, '32Q']], fallback: '321' },
    { test: /a?320/, variants: [[/neo/, '32N']], fallback: '320' },
    { test: /a?319/, variants: [], fallback: '319' },
    { test: /777/, variants: [[/-?\s?300\s?er|300er/, '77W'], [/-?\s?200\s?er|200er/, '772']], fallback: '777' },
    { test: /767/, variants: [[/-?\s?300/, '763']], fallback: '763' },
  ];

const CARRIER_WIDEBODY_DEFAULT = {
    AA: '772', DL: '359', UA: '789', BA: '789', LH: '359', AF: '772', KL: '772',
    EK: '77W', QR: '359', SQ: '359', CX: '359', JL: '789', NH: '789',
    AC: '789', QF: '789', VS: '789', EY: '789', TK: '359', PR: '333',
  };

function guessEquipCode(leg) {
    const dist = leg.distance != null ? leg.distance : lookupDistance(leg.origin?.iata, leg.destination?.iata);
    if (dist != null && dist > 3000) {
      return CARRIER_WIDEBODY_DEFAULT[leg.airline?.code] || '789';
    }
    if (dist != null && dist > 1200) return '321';
    return '738';
  }

function equipCode(leg) {
    if (leg.equipmentCode) return leg.equipmentCode;
    const aircraftName = leg.aircraft;
    if (!aircraftName) return guessEquipCode(leg);
    const key = aircraftName.trim().toLowerCase().replace(/\s+passenger\b/, '').replace(/\s+/g, ' ');
    if (EQUIP_MAP[key]) return EQUIP_MAP[key];

    for (const fam of EQUIP_FAMILY_DEFAULTS) {
      if (fam.test.test(key)) {
        for (const [variantRe, code] of fam.variants) {
          if (variantRe.test(key)) return code;
        }
        return fam.fallback;
      }
    }

    const match = key.match(/(\d{3})/);
    return match ? match[1] : guessEquipCode(leg);
  }

// Worried Pip for warnings (airport change, rush only, $0.00).
function worriedPip(width) {
  const el = document.createElement('span');
  el.className = 'ia-worried';
  el.setAttribute('aria-hidden', 'true');
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '10 10 76 80');
  svg.setAttribute('width', String(width));
  svg.setAttribute('height', String(Math.round(width * 80 / 76)));
  svg.style.display = 'block';
  const add = (tag, attrs) => { const n = document.createElementNS(NS, tag); Object.keys(attrs).forEach((k) => n.setAttribute(k, attrs[k])); svg.appendChild(n); };
  add('path', { d: 'M22 70 L22 38 Q22 26 34 26 L62 26 Q74 26 74 38 L74 62 Q74 74 62 74 L40 74 L30 84 L31 74 Q22 73 22 70 Z', fill: '#fecaca' });
  add('path', { d: 'M35 41 L44 44 M61 41 L52 44', stroke: '#7f1d1d', 'stroke-width': '3.4', 'stroke-linecap': 'round', fill: 'none' });
  add('circle', { cx: '40', cy: '50', r: '4', fill: '#7f1d1d' });
  add('circle', { cx: '56', cy: '50', r: '4', fill: '#7f1d1d' });
  add('path', { d: 'M40 64 Q48 57 56 64', stroke: '#7f1d1d', 'stroke-width': '3.2', 'stroke-linecap': 'round', fill: 'none' });
  el.appendChild(svg);
  return el;
}

const VI_HEADER = '   FLIGHT  DATE  SEGMENT DPTR  ARVL    MLS  EQP  ELPD MILES SM';

// ====================================================================
// SECTION 10 · RingCentral website: places the calls the BO asks for
// ====================================================================
// Runs on app.ringcentral.com only. Every RingCentral tab reports itself
// (in Tampermonkey's shared storage) so the BO knows one is open. When the
// BO sends a number, the chosen tab puts it in the dialpad and presses
// Call right away -- no page load. The dialpad can live in the main tab
// or in the popped-out keypad window; the popped-out window is an
// about:blank window the RingCentral page draws into, so it's reached by
// catching it when the page opens it (window.open below, which is why
// this part runs as early as the page allows). This part only places
// outgoing calls; it never answers or changes anything else.
(function () {
  'use strict';
  if (location.hostname !== 'app.ringcentral.com') return;
  if (window.top !== window) return;

  const W = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
  const TAB = Math.random().toString(36).slice(2, 10);
  // A tab the BO opened only to run a call link (it's closed again once the
  // call is up, unless it's the only RingCentral tab).
  const HELPER = /\/redirect|\/r\/call/.test(location.pathname);
  const TABS_KEY = 'ia-rc-tabs';
  const DIAL_KEY = 'ia-rc-dial';
  const ACK_KEY = 'ia-rc-ack';
  const INPUT_ID = 'PHONE_DIALER_INPUT_ID';
  const CALL_BTN = '[data-test-automation-id="telephony-dial-btn"]';
  const PHONE_NAV = '[data-test-automation-id="phone"]';

  // --- Popped-out keypad windows ----------------------------------------
  const popouts = [];
  try {
    const nativeOpen = W.open;
    W.open = function () {
      const win = nativeOpen.apply(this, arguments);
      try { if (win) popouts.push(win); } catch (e) { /* ignore */ }
      return win;
    };
  } catch (e) { /* can't watch pop-outs; the main tab's dialpad still works */ }

  function docs() {
    const out = [];
    for (let i = popouts.length - 1; i >= 0; i--) {
      const win = popouts[i];
      let d = null;
      try { if (!win.closed) d = win.document; } catch (e) { d = null; }
      if (d) out.push(d); else popouts.splice(i, 1);
    }
    out.push(document);
    return out;
  }
  const shown = (el) => !!(el && el.getClientRects().length);
  function findDialer() {
    for (const d of docs()) {
      const input = d.getElementById(INPUT_ID);
      if (shown(input)) return { doc: d, input };
    }
    return null;
  }
  function waitFor(fn, ms) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      const tick = () => {
        let v = null;
        try { v = fn(); } catch (e) { v = null; }
        if (v) { resolve(v); return; }
        if (Date.now() - t0 > ms) { resolve(null); return; }
        setTimeout(tick, 80);
      };
      tick();
    });
  }

  async function dial(number) {
    let ctx = findDialer();
    if (!ctx) {
      // Not on the Phone page: open it (sidebar Phone), then its dialpad.
      const nav = document.querySelector(PHONE_NAV);
      if (nav) nav.click();
      ctx = await waitFor(findDialer, 2500);
      if (!ctx) {
        // Phone page open but on another view (e.g. call history): its
        // Dialpad tab/link.
        const dp = document.querySelector('a[href*="/dialpad"], [data-test-automation-id*="ialpad"]:not([data-test-automation-id*="popOut"])');
        if (dp) { dp.click(); ctx = await waitFor(findDialer, 2500); }
      }
    }
    if (!ctx) return false;
    const { doc, input } = ctx;
    const win = doc.defaultView || W;
    // React keeps its own copy of the box's value; setting it through the
    // native setter and firing "input" is what makes React accept it.
    const setter = Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, 'value').set;
    input.focus();
    setter.call(input, '');
    input.dispatchEvent(new win.Event('input', { bubbles: true }));
    setter.call(input, number);
    input.dispatchEvent(new win.Event('input', { bubbles: true }));
    const btn = await waitFor(() => {
      const b = doc.querySelector(CALL_BTN);
      return b && !b.disabled && b.getAttribute('aria-disabled') !== 'true' ? b : null;
    }, 2500);
    if (!btn) return false;
    btn.click();
    return true;
  }

  // --- Tell the BO this tab is here (every 2s) --------------------------
  let lastFocus = document.hasFocus() ? Date.now() : 0;
  window.addEventListener('focus', () => { lastFocus = Date.now(); beat(); });
  function beat() {
    let all = {};
    try { all = JSON.parse(GM_getValue(TABS_KEY, '{}')) || {}; } catch (e) { all = {}; }
    const now = Date.now();
    Object.keys(all).forEach((k) => { if (!all[k] || now - all[k].t > 8000) delete all[k]; });
    if (document.hasFocus()) lastFocus = now;
    all[TAB] = { t: now, helper: HELPER, focus: lastFocus };
    try { GM_setValue(TABS_KEY, JSON.stringify(all)); } catch (e) { /* ignore */ }
  }
  beat();
  setInterval(beat, 2000);
  window.addEventListener('pagehide', () => {
    try {
      const all = JSON.parse(GM_getValue(TABS_KEY, '{}')) || {};
      delete all[TAB];
      GM_setValue(TABS_KEY, JSON.stringify(all));
    } catch (e) { /* ignore */ }
  });

  // --- Calls requested by the BO -----------------------------------------
  const done = new Set();
  GM_addValueChangeListener(DIAL_KEY, async (key, oldV, v, remote) => {
    let req;
    try { req = JSON.parse(v); } catch (e) { return; }
    if (!req || req.to !== TAB || done.has(req.rid) || Date.now() - req.t > 15000) return;
    done.add(req.rid);
    const ack = (stage) => { try { GM_setValue(ACK_KEY, JSON.stringify({ rid: req.rid, stage, tab: TAB, t: Date.now() })); } catch (e) { /* ignore */ } };
    ack('got');
    let ok = false;
    const go = async () => { try { ok = await dial(req.n); } catch (e) { ok = false; } ack(ok ? 'ok' : 'fail'); };
    if (document.body) go(); else document.addEventListener('DOMContentLoaded', go, { once: true });
  });
})();
(function () {
  'use strict';

  // Bail out immediately on any page this half of the script can never
  // apply to, before the MutationObserver below is even created. Without
  // this, being on the CRM site (or any other page @match happens to
  // cover) still pays for a subtree-wide MutationObserver that fires on
  // every DOM mutation just to run host checks that always fail — real,
  // avoidable overhead on a page with nothing for this half to do.
  const _host = location.hostname;
  {
    const _relevant = _host.includes('flybasis.com')
      || _host.includes('agentsearch.vercel.app')
      || _host.includes('awardlogic.com')
      || _host.includes('pointsyeah.com')
      || _host.includes('matrix.itasoftware.com')
      || _host.includes('kayak.com')
      || _host.includes('cheapoair.com')
      || (_host.includes('google.com') && location.pathname.startsWith('/travel/flights'));
    if (!_relevant) return;
  }

  // ------------------------------------------------------------------
  // CONFIG — Sabre GDS Output Conventions
  //
  // Status code depends on which site the itinerary is coming from: the
  // award/points sites build a redemption booking (GK — a status hold
  // used for award/points bookings), everywhere else is a normal cash
  // fare search (SS — a standard sell status). This mirrors the
  // early-exit host check above rather than introducing a new list.
  // ------------------------------------------------------------------
  const _isAwardSite = _host.includes('flybasis.com')
    || _host.includes('agentsearch.vercel.app')
    || _host.includes('awardlogic.com')
    || _host.includes('pointsyeah.com');

  const CONFIG = {
    STATUS_CODE: _isAwardSite ? 'GK' : 'SS',
    ETKT_SUFFIX: '/E',
    SM_FLAG: 'N',
    DEFAULT_MEAL_CODE: 'M',
    DEFAULT_BOOKING_BY_CABIN: { y: 'Y', w: 'W', s: 'S', p: 'W', e: 'Y', j: 'J', b: 'D', f: 'F' },
    CABIN_NAME: { y: 'ECONOMY', w: 'PREMIUM ECONOMY', s: 'PREMIUM ECONOMY', p: 'PREMIUM ECONOMY', j: 'BUSINESS', b: 'BUSINESS', f: 'FIRST', e: 'ECONOMY', c: 'BUSINESS' },
  };

  const AIRLINE_MAP = {
    'saudia': 'SV', 'saudi arabian airlines': 'SV',
    'etihad': 'EY', 'etihad airways': 'EY', 'emirates': 'EK', 'qatar': 'QR', 'qatar airways': 'QR',
    'american': 'AA', 'american airlines': 'AA', 'united': 'UA', 'united airlines': 'UA',
    'delta': 'DL', 'delta air lines': 'DL', 'british airways': 'BA', 'lufthansa': 'LH',
    'air france': 'AF', 'klm': 'KL', 'singapore airlines': 'SQ', 'cathay pacific': 'CX',
    'japan airlines': 'JL', 'ana': 'NH', 'all nippon airways': 'NH', 'turkish airlines': 'TK',
    'air india': 'AI', 'akasa air': 'QP', 'indigo': '6E', 'gulf air': 'GF', 'oman air': 'WY',
    'virgin atlantic': 'VS', 'air canada': 'AC', 'qantas': 'QF', 'swiss': 'LX',
    'austrian': 'OS', 'iberia': 'IB', 'finnair': 'AY', 'korean air': 'KE', 'asiana': 'OZ',
    'eva air': 'BR', 'china airlines': 'CI', 'alaska': 'AS', 'alaska airlines': 'AS', 'jetblue': 'B6',
    'ethiopian': 'ET', 'egyptair': 'MS', 'copa': 'CM', 'avianca': 'AV', 'latam': 'LA',
    'royal air maroc': 'AT', 'lot polish airlines': 'LO', 'aeromexico': 'AM', 'westjet': 'WS',
    'icelandair': 'FI'
  };

  const CABIN_WORD_TO_CODE = {
    economy: 'y', coach: 'y', 'premium economy': 'w', business: 'j', first: 'f'
  };

  const MONTH_MAP = { jan:0, feb:1, mar:2, apr:3, may:4, jun:5, jul:6, aug:7, sep:8, oct:9, nov:10, dec:11 };

  // Great-circle airport distance, computed offline instead of hitting a
  // network API at copy-time — an API call from inside a userscript would
  // be one more thing that can fail (CORS, rate limits, an outage) right
  // when the person is mid-copy, and the input to the formula (each
  // airport's fixed lat/lon) doesn't change, so there's nothing a live
  // lookup would learn that isn't already knowable ahead of time. This is
  // a best-effort MILES figure (straight-line great-circle, not an
  // airline's official routing mileage, which can differ) for whichever
  // airports are in the table below — left blank rather than guessed for
  // any airport not in it.

  // Coarse continent tag for every airport above, used ONLY when one side
  // of a route isn't in AIRPORT_COORDS — the exact haversine calculation
  // above is always tried first and is always preferred when available.
  // NA=North America, SA=South America, EU=Europe, AF=Africa, AS=Asia
  // (Middle East grouped in here, geographically), OC=Oceania.

  // Rough typical hub-to-hub mileage per continent pair — deliberately
  // coarse (see the reasoning above: same-continent variance alone spans
  // a 300-mile hop to a 2,500-mile transcontinental one). Only used when
  // the exact table above has neither airport.

  // Absolute last resort — an airport not in either table above at all.
  // Never leaves the MILES column blank, at the cost of being a flat
  // world-average guess rather than any kind of real estimate.

  // Sabre schedule day-of-week letters, indexed by JS Date#getDay() (0=Sun..6=Sat)

  // ------------------------------------------------------------------
  // Styling — one visual style per site
  // ------------------------------------------------------------------
  GM_addStyle(`
    .gds-btn-base {
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
      user-select: none;
      white-space: nowrap;
    }
    /* TBC Assistant dark dashboard: one look for every site's GDS button */
    .gds-btn-base.gds-btn-base {
      background: #0f172a !important; color: #a5a5fb !important;
      border: 1px solid #7c7cf8 !important; border-radius: 8px !important;
      font-family: 'Segoe UI', system-ui, sans-serif !important; font-weight: 700 !important;
      box-shadow: 0 0 0 1px rgba(124,124,248,.15), 0 2px 8px rgba(0,0,0,.35) !important;
    }
    .gds-btn-base.gds-btn-base:hover { background: #1e293b !important; color: #c7c7fd !important; }
    .gds-btn-base.copied {
      background-color: #2e7d32 !important;
      border-color: #4caf50 !important;
      color: #ffffff !important;
    }

    .price-button-container {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: flex-start !important;
      gap: 6px !important;
      width: auto !important;
    }

    /* ITA Matrix */
    .gds-btn-matrix {
      background-color: #1e88e5 !important;
      color: #ffffff !important;
      border: none !important;
      border-radius: 4px !important;
      padding: 0 10px !important;
      height: 32px !important;
      line-height: 32px !important;
      font-family: Roboto, "Helvetica Neue", sans-serif !important;
      font-size: 12px !important;
      font-weight: 600 !important;
      letter-spacing: 0.5px !important;
      text-transform: uppercase !important;
      box-shadow: 0px 3px 1px -2px rgba(0,0,0,0.2), 0px 2px 2px 0px rgba(0,0,0,0.14) !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      margin: 0 !important;
      vertical-align: middle !important;
      flex-shrink: 0 !important;
    }
    .gds-btn-matrix:hover { background-color: #1565c0 !important; }

    /* FlyBasis / agentsearch — filled violet pill */
    .gds-btn-flybasis {
      background: #7c3aed;
      color: #ffffff;
      border: none;
      border-radius: 999px;
      padding: 6px 16px;
      font-family: system-ui, sans-serif;
      font-size: 13px;
      font-weight: 700;
      box-shadow: 0 2px 8px rgba(124,58,237,.45);
    }
    .gds-btn-flybasis:hover { background: #6d28d9; }

    /* PointsYeah */
    .gds-btn-yeah {
      background: #111827;
      color: #FFC800;
      border: 1px solid #FFC800;
      border-radius: 999px;
      padding: 2px 10px;
      height: 22px;
      font-family: system-ui, sans-serif;
      font-size: 11px;
      font-weight: 700;
      display: inline-flex;
      align-items: center;
    }
    .gds-btn-yeah:hover { background: #FFC800; color: #111827; }

    /* AwardLogic */
    .gds-btn-award {
      background: #ffffff;
      color: #5b21b6;
      border: 1px solid #5b21b6;
      border-radius: 6px;
      padding: 3px 10px;
      margin-top: 6px;
      margin-left: 32px;
      font-family: system-ui, sans-serif;
      font-size: 11px;
      font-weight: 700;
      display: inline-block;
    }
    .gds-btn-award:hover { background: #5b21b6; color: #ffffff; }

    /* Kayak — orange brand accent, sits inline next to the price/Select button */
    .gds-btn-kayak {
      background: #ffffff;
      color: #FF690F;
      border: 1.5px solid #FF690F;
      border-radius: 6px;
      padding: 5px 12px;
      margin-right: 8px;
      font-family: system-ui, sans-serif;
      font-size: 12px;
      font-weight: 700;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .gds-btn-kayak:hover { background: #FF690F; color: #ffffff; }

    /* CheapOair */
    .gds-btn-cheapoair {
      background: #003366;
      color: #ffffff;
      border: none;
      border-radius: 999px;
      padding: 6px 14px;
      margin-left: 10px;
      font-family: system-ui, sans-serif;
      font-size: 12px;
      font-weight: 700;
      display: inline-flex;
      align-items: center;
    }
    .gds-btn-cheapoair:hover { background: #0055a5; }

    .gds-big-copied {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) scale(0.85);
      font-family: system-ui, sans-serif;
      font-size: 72px;
      font-weight: 900;
      letter-spacing: 6px;
      color: #a5a5fb;
      background: rgba(14, 15, 19, 0.94);
      border: 2px solid #7c7cf8;
      padding: 28px 56px;
      border-radius: 20px;
      box-shadow: 0 12px 40px rgba(0,0,0,0.4);
      z-index: 2147483647;
      pointer-events: none;
      animation: gds-big-copied-fade 1.5s ease forwards;
    }
    @keyframes gds-big-copied-fade {
      0%   { opacity: 0;   transform: translate(-50%, -50%) scale(0.85); }
      12%  { opacity: 1;   transform: translate(-50%, -50%) scale(1); }
      70%  { opacity: 1;   transform: translate(-50%, -50%) scale(1); }
      100% { opacity: 0;   transform: translate(-50%, -50%) scale(1.05); }
    }

    /* Google Flights — matches their own outlined "pill" button style */
    .gds-btn-googleflights {
      background: #ffffff;
      color: #1a73e8;
      border: 1px solid #dadce0;
      border-radius: 999px;
      padding: 8px 16px;
      font-family: 'Google Sans', Roboto, Arial, sans-serif;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      line-height: 1;
    }
    .gds-btn-googleflights:hover { background: #f8f9fa; }
  `);

  // ------------------------------------------------------------------
  // Formatting Helpers
  // ------------------------------------------------------------------

  // Normalizes leg.departure / leg.arrival to a real Date object no matter
  // what an adapter handed us. Some adapters (FlyBasis, PointsYeah) pass
  // through raw ISO date strings from JSON rather than Date instances —
  // calling .getDay()/.getFullYear() directly on a string throws, which is
  // exactly what broke FlyBasis. Just as important: an ISO string with a
  // trailing "Z"/offset would otherwise get re-interpreted in the
  // browser's own time zone by `new Date(str)`, silently shifting the
  // calendar date. This reads the printed Y-M-D-H-M numbers literally and
  // builds the Date via the local constructor, so no zone conversion ever
  // happens.

  // Real Sabre/IATA equipment codes are almost never just "the model
  // number written out" — a bare "787" or "A350" or "A330" isn't a valid
  // code on its own (787-8/-9/-10 are 788/789/781; A350-900/-1000 are
  // 359/351; A330-200/-300/-900neo are 332/333/339). The old fallback
  // (grab any 3 consecutive digits from the raw aircraft text) produced
  // exactly those wrong bare numbers whenever the scraped text didn't
  // exactly match an EQUIP_MAP key. This resolves by aircraft FAMILY
  // first, checking for a variant hint, and only defaults to a bare
  // digit-guess if the family itself isn't recognized at all.

  // A carrier's typical widebody on international/long-haul routes —
  // used only as the very last resort below, when a site gives literally
  // no aircraft signal at all (no name, no equipment code). Not exact
  // (a real per-flight lookup would need a live flight-schedule API,
  // which needs a key/subscription and can't be guaranteed available or
  // fast from inside a userscript — the same reasoning as the mileage
  // fallback), but keeps the field populated with something plausible
  // rather than "???".

  // Premium economy class letter for carriers that don't use W.
  const PREMIUM_CLASS_BY_CARRIER = { PR: 'N' };
  function bookingClass(leg) {
    if (leg.bookingCode) return leg.bookingCode;
    if (leg.cabin === 'w' && leg.airline && PREMIUM_CLASS_BY_CARRIER[leg.airline.code]) return PREMIUM_CLASS_BY_CARRIER[leg.airline.code];
    return CONFIG.DEFAULT_BOOKING_BY_CABIN[leg.cabin] || 'Y';
  }

  // ------------------------------------------------------------------
  // Sabre GDS Builders
  // ------------------------------------------------------------------
  function buildIALine(leg, idx, pax) {
    const depD = parseLocal(leg.departure);
    const arrD = parseLocal(leg.arrival);
    const num = String(idx + 1).padStart(2, ' ');
    const carrierFlight = leg.airline.code + String(leg.operatingFlightNumber || leg.flightNumber).padStart(4, ' ');
    const cls = bookingClass(leg);
    const date = formatDate(depD);
    const dow = dowLetter(depD);
    const route = leg.origin.iata + leg.destination.iata;
    const status = `${CONFIG.STATUS_CODE}${pax}`;
    const dep = formatTime(depD).padStart(5, ' ');
    const arr = formatTime(arrD).padStart(5, ' ');

    let rolloverSuffix = '';
    if (!sameCalendarDate(depD, arrD)) {
      rolloverSuffix = `  ${formatDate(arrD)} ${dowLetter(arrD)}`;
    }

    return `${num} ${carrierFlight}${cls} ${date} ${dow} ${route} ${status}  ${dep} ${arr}${rolloverSuffix} ${CONFIG.ETKT_SUFFIX}`;
  }

  function buildVILines(leg, idx) {
    const depD = parseLocal(leg.departure);
    const arrD = parseLocal(leg.arrival);
    const num = String(idx + 1).padStart(2, ' ');

    // A codeshare (operating carrier differs from the marketing carrier
    // shown) is marked by replacing the flight-number field's leading pad
    // space with "*" — e.g. "TP*8559" instead of "TP 8559" — with a
    // "*ORIGIN-DEST OPERATED BY <airline>" line underneath. Only rendered
    // when an adapter actually supplies operatingCarrierCode; none do yet,
    // since none of the sites expose it per-segment in a verified way.
    const flightNumStr = String(leg.operatingFlightNumber || leg.flightNumber);
    const isCodeshare = leg.operatingCarrierCode && leg.operatingCarrierCode !== leg.airline.code;
    const carrierFlight = isCodeshare
      ? leg.airline.code + '*' + flightNumStr.padStart(4, ' ')
      : leg.airline.code + flightNumStr.padStart(5, ' ');

    const date = formatDate(depD);
    const segment = `${leg.origin.iata} ${leg.destination.iata}`;
    const dep = formatTime(depD).padStart(5, ' ');
    const arr = formatTime(arrD).padStart(5, ' ');
    const dayDiff = daysBetween(depD, arrD);
    // Positive dayDiff (arrival lands a day+ later) shows "¥N"; negative
    // (arrival lands a day EARLIER — routes crossing the date line
    // westbound, e.g. Taipei to San Francisco, commonly do this) shows
    // "-N". Same 3-character field width either way.
    let rolloverField;
    if (dayDiff > 0) rolloverField = `\u00a5${dayDiff} `;
    else if (dayDiff < 0) rolloverField = `${dayDiff} `;
    else rolloverField = '   ';
    const meal = leg.mealCode || CONFIG.DEFAULT_MEAL_CODE;
    const eqp = equipCode(leg).padStart(3, ' ');
    const elp = elapsed(leg.duration);
    const distance = leg.distance != null ? leg.distance : lookupDistance(leg.origin.iata, leg.destination.iata);
    const miles = distance != null ? String(distance).padStart(4, ' ') : '    ';

    const row = `${num} ${carrierFlight} ${date} ${segment} ${dep} ${arr}${rolloverField}${meal}    ${eqp}  ${elp}  ${miles}  ${CONFIG.SM_FLAG}`;

    const extraLines = [];
    const termParts = [];
    if (leg.departureTerminal) termParts.push(`DEP-TERMINAL ${leg.departureTerminal}`);
    if (leg.arrivalTerminal) termParts.push(`ARR-TERMINAL ${leg.arrivalTerminal}`);
    if (termParts.length) extraLines.push(termParts.join('                 '));

    if (isCodeshare) {
      extraLines.push(`*${leg.origin.iata}-${leg.destination.iata} OPERATED BY ${(leg.operatingCarrierName || leg.operatingCarrierCode).toUpperCase()}`);
    }

    const alliance = ALLIANCE_MAP[leg.airline.code];
    if (alliance) extraLines.push(alliance);

    const cabinName = CONFIG.CABIN_NAME[(leg.cabin || '').toLowerCase()] || (leg.cabin || '').toUpperCase();
    if (cabinName) extraLines.push(`CABIN-${cabinName}`);

    return [row, ...extraLines];
  }

  function buildBoth(itinerary) {
    const pax = itinerary.pax || 1;
    const allLegs = itinerary.flights.flatMap((f) => f.legs);
    const iaText = allLegs.map((leg, i) => buildIALine(leg, i, pax)).join('\n');
    const viText = [VI_HEADER, ...allLegs.flatMap((leg, i) => buildVILines(leg, i))].join('\n');
    return `*IA\n${iaText}\n\nVI*\n${viText}`;
  }

  function copyText(text) {
    if (typeof GM_setClipboard === 'function') {
      GM_setClipboard(text);
      return;
    }
    navigator.clipboard?.writeText(text).catch(() => {});
  }

  function showBigCopiedIndicator() {
    const el = document.createElement('div');
    el.textContent = 'COPIED';
    el.className = 'gds-big-copied';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1500);
  }

  // Hooks used by the Pip popover (see "Send to lead" below): in capture
  // mode the built *IA/VI* text is handed back instead of copied.
  let gdsCaptureResolve = null;
  let gdsCopyListener = null;

  // Never copy or send a broken *IA: every flight line must have its
  // airline, flight number, class, date and route. If a site changed its
  // page and something wasn't read, it fails loudly instead.
  function gdsTextProblem(text) {
    const m = String(text || '').match(/^\*IA\n([\s\S]*?)\n\nVI\*/);
    if (!m) return null; // not *IA output
    const rows = m[1].split('\n').filter((l) => l.trim());
    if (!rows.length) return 'No flights read';
    const ok = /^\s*\d+ [A-Z0-9]{2} *\d{1,5}[A-Z] \d{2}[A-Z]{3} [A-Z] [A-Z]{6} [A-Z]{2}\d+ +\d{3,4}[AP] +\d{3,4}[AP]/;
    return rows.every((r) => ok.test(r)) ? null : 'Flight details missing';
  }

  function flashButton(btn, textToCopy, showBig) {
    const problem = gdsTextProblem(textToCopy);
    if (problem) { flashError(btn, '❌ ' + problem + ' — not copied'); return; }
    if (gdsCaptureResolve) { const r = gdsCaptureResolve; gdsCaptureResolve = null; r({ ok: true, text: textToCopy }); return; }
    if (gdsCopyListener) gdsCopyListener(true);
    copyText(textToCopy);
    if (showBig) showBigCopiedIndicator();
    const originalText = btn.textContent;
    btn.textContent = '\u2713 Copied';
    btn.classList.add('copied');
    setTimeout(() => {
      btn.textContent = originalText;
      btn.classList.remove('copied');
    }, 1500);
  }

  function flashError(btn, label) {
    if (gdsCaptureResolve) { const r = gdsCaptureResolve; gdsCaptureResolve = null; r({ ok: false, error: label }); return; }
    if (gdsCopyListener) gdsCopyListener(false, label);
    const orig = btn.textContent;
    btn.textContent = label;
    setTimeout(() => (btn.textContent = orig), 1500);
  }

  function parseDurationMinutes(str) {
    const h = /(\d+)\s*h/i.exec(str || '');
    const m = /(\d+)\s*m/i.exec(str || '');
    return (h ? parseInt(h[1], 10) : 0) * 60 + (m ? parseInt(m[1], 10) : 0);
  }

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // ------------------------------------------------------------------
  // ITA MATRIX ADAPTER — real per-segment data from the expanded detail row
  // ------------------------------------------------------------------
  // ITA's row/detail markup never prints a year — only "Sun, Nov 8" style
  // text — so the year has to be inferred. A flight whose month/day has
  // already passed in the current calendar year is next year's flight,
  // not this year's (e.g. searching in Sept 2026 for a "Feb 13" departure
  // means Feb 13 2027, not the already-past Feb 13 2026). Getting this
  // wrong doesn't just mislabel the year — every day-of-week letter and
  // date-rollover marker in the IA/VI output shifts with it.
  function inferYear(month, day) {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const candidate = new Date(now.getFullYear(), month, day);
    return candidate < todayStart ? now.getFullYear() + 1 : now.getFullYear();
  }

  function itaParseDateTime(dateStr, timeStr) {
    // dateStr e.g. "Sun, Nov 8" (weekday prefix optional); timeStr e.g. "6:00 AM"
    const dm = (dateStr || '').match(/([A-Za-z]{3})\s+(\d{1,2})/);
    if (!dm) return new Date();
    const month = MONTH_MAP[dm[1].toLowerCase()] ?? 0;
    const day = parseInt(dm[2], 10);
    const year = inferYear(month, day);

    let hours = 12, minutes = 0;
    const tm = (timeStr || '').match(/(\d{1,2}):(\d{2})\s*(AM|PM)/i);
    if (tm) {
      hours = parseInt(tm[1], 10);
      minutes = parseInt(tm[2], 10);
      const isPM = tm[3].toUpperCase() === 'PM';
      if (isPM && hours < 12) hours += 12;
      if (!isPM && hours === 12) hours = 0;
    }
    return new Date(year, month, day, hours, minutes, 0, 0);
  }

  function parseClockTime(timeStr) {
    const tm = (timeStr || '').match(/(\d{1,2}):(\d{2})\s*(AM|PM)/i);
    if (!tm) return { h: 12, m: 0 };
    let h = parseInt(tm[1], 10);
    const m = parseInt(tm[2], 10);
    const isPM = tm[3].toUpperCase() === 'PM';
    if (isPM && h < 12) h += 12;
    if (!isPM && h === 12) h = 0;
    return { h, m };
  }

  // Rough UTC-offset estimate from longitude alone (15 degrees per hour).
  // Ignores real timezone/DST boundaries, but is far better than nothing
  // for disambiguating which calendar day an arrival actually falls on —
  // see resolveArrivalDate below for why that matters.
  function estimateUtcOffset(code) {
    const coord = AIRPORT_COORDS[code];
    return coord ? Math.round(coord[1] / 15) : null;
  }

  // Resolves an arrival's calendar date from its own local clock time and
  // the segment's real elapsed flight duration, instead of relying on
  // page text like "on <date>" always being present (it isn't, on every
  // leg, in practice — see itaParseDetailSegments, which still prefers
  // that text when present and only falls back to this).
  //
  // The naive approach — just checking which day-offset (0, 1, 2...)
  // gets naiveElapsed close to the real duration — silently picks the
  // WRONG day whenever the timezone difference between the two airports
  // is large enough to be comparable to the flight duration itself (e.g.
  // Taipei-San Francisco: ~16h timezone gap on an ~11h flight). In that
  // case an earlier arrival date (crossing the date line) can look like
  // a worse "fit" than a same-day arrival that's actually wrong. Biasing
  // the search by each airport's rough longitude-based UTC offset (see
  // estimateUtcOffset) resolves that ambiguity correctly, and also
  // handles arrivals that land a day EARLIER than departure (a negative
  // day offset), which the old range (0 to 2 only) could never find at
  // all.
  function resolveArrivalDate(depDate, arrHour, arrMinute, durationMin, originCode, destCode) {
    const depOffset = estimateUtcOffset(originCode);
    const arrOffset = estimateUtcOffset(destCode);
    const expectedTzDiffMin = (depOffset != null && arrOffset != null) ? (arrOffset - depOffset) * 60 : null;

    let best = null;
    let bestScore = Infinity;
    for (let dayOffset = -2; dayOffset <= 2; dayOffset++) {
      const candidate = new Date(depDate.getFullYear(), depDate.getMonth(), depDate.getDate() + dayOffset, arrHour, arrMinute, 0, 0);
      const naiveElapsed = Math.round((candidate - depDate) / 60000);
      const impliedTzDiff = naiveElapsed - durationMin;
      const score = expectedTzDiffMin != null
        ? Math.abs(impliedTzDiff - expectedTzDiffMin)
        : Math.abs(impliedTzDiff);
      if (score < bestScore) {
        bestScore = score;
        best = candidate;
      }
    }
    return best;
  }

  function itaParseDetailSegments(detailRow) {
    const items = detailRow.querySelectorAll('mat-list-item');
    const legs = [];
    items.forEach((item) => {
      const infoLines = item.querySelectorAll('.info-line');
      if (infoLines.length < 4) return;

      const routeLine = infoLines[0];
      const bTag = routeLine.querySelector('b');
      const routeText = (bTag?.textContent || '').trim();
      const routeMatch = routeText.match(/\(([A-Z]{3})\)\s*to\s*.*\(([A-Z]{3})\)/i);
      if (!routeMatch) return;
      const originCode = routeMatch[1];
      const destCode = routeMatch[2];
      const depDateMatch = routeLine.textContent.match(/on\s+([A-Za-z]{3},?\s*[A-Za-z]{3}\s+\d{1,2})\s*$/i);
      const depDateStr = depDateMatch ? depDateMatch[1] : '';

      const timeLine = infoLines[1];
      const bTags = timeLine.querySelectorAll('b');
      const depTimeStr = bTags[0]?.textContent.trim() || '';
      const arrTimeStr = bTags[1]?.textContent.trim() || '';

      // The page sometimes prints an explicit arrival date ("on <date>")
      // right after the arrival time — when it's there, it's ground
      // truth and is used directly. When it isn't, the duration-based
      // resolveArrivalDate below is the fallback.
      const arrDateMatch = timeLine.textContent.match(/on\s+([A-Za-z]{3},?\s*[A-Za-z]{3}\s+\d{1,2})\s*$/i);

      // Prefer the explicit "(Xh Ym)" elapsed text the page already shows —
      // computing it from the two parsed local clock times would be wrong
      // for any route that crosses time zones (dep/arr are parsed naively
      // in the browser's own time zone, not the airports').
      const explicitDurMatch = timeLine.textContent.match(/\(([^()]*)\)\s*$/);
      const explicitDurMin = explicitDurMatch ? parseDurationMinutes(explicitDurMatch[1]) : 0;

      // The flight-number line ends with "(operated by <airline>)" for
      // codeshares — the old regex required digits at the very END of the
      // string (`\d+$`), so that trailing text made it fail to match at
      // all, silently dropping the flight number. Matching the digit run
      // wherever it appears (no end anchor) is robust to any trailing
      // text; the operated-by carrier is captured separately below.
      const flightLine = infoLines[2].textContent.trim();
      const flightMatch = flightLine.match(/^(.+?)\s+(\d+)/);
      const airlineName = flightMatch ? flightMatch[1].trim() : flightLine;
      const flightNumber = flightMatch ? flightMatch[2] : '';

      const operatedByMatch = flightLine.match(/operated by\s+([^)]+)\)/i);
      const operatingCarrierName = operatedByMatch ? operatedByMatch[1].trim() : '';
      const operatingCarrierCode = operatingCarrierName ? (AIRLINE_MAP[operatingCarrierName.toLowerCase()] || '') : '';

      const aircraft = (infoLines[3]?.textContent || '').trim();

      const serviceLine = item.querySelector('.service-line');
      const cabinMatch = serviceLine ? serviceLine.textContent.match(/(Economy|Premium Economy|Business|First)\s*(?:\(([A-Za-z0-9]+)\))?/i) : null;
      const cabinWord = cabinMatch ? cabinMatch[1].toLowerCase() : 'economy';
      const bookingCode = cabinMatch && cabinMatch[2] ? cabinMatch[2].toUpperCase() : '';

      let cabinCode = 'y';
      if (cabinWord.includes('business')) cabinCode = 'j';
      else if (cabinWord.includes('first')) cabinCode = 'f';
      else if (cabinWord.includes('premium')) cabinCode = 'w';

      const carrierImg = item.querySelector('.carrier-img');
      const carrierMatch = carrierImg?.src.match(/\/([A-Z0-9]{2,3})\.png/i);
      const carrier = carrierMatch ? carrierMatch[1].toUpperCase() : (AIRLINE_MAP[airlineName.toLowerCase()] || '');

      const depDateObj = itaParseDateTime(depDateStr, depTimeStr);
      const arrClock = parseClockTime(arrTimeStr);
      let arrDateObj;
      if (arrDateMatch) {
        arrDateObj = itaParseDateTime(arrDateMatch[1], arrTimeStr);
      } else if (explicitDurMin > 0) {
        arrDateObj = resolveArrivalDate(depDateObj, arrClock.h, arrClock.m, explicitDurMin, originCode, destCode);
      } else {
        arrDateObj = new Date(depDateObj.getFullYear(), depDateObj.getMonth(), depDateObj.getDate(), arrClock.h, arrClock.m, 0, 0);
      }
      const durMin = explicitDurMin > 0 ? explicitDurMin : Math.max(0, Math.round((arrDateObj - depDateObj) / 60000));

      legs.push({
        airline: { code: carrier },
        flightNumber,
        cabin: cabinCode,
        bookingCode: bookingCode || undefined,
        aircraft,
        origin: { iata: originCode },
        destination: { iata: destCode },
        departure: depDateObj,
        arrival: arrDateObj,
        duration: durMin,
        operatingCarrierCode: operatingCarrierCode || undefined,
        operatingCarrierName: operatingCarrierName || undefined,
      });
    });
    return legs;
  }

  function getItaPaxCount(row) {
    const priceLink = row.querySelector('a[href*="/itinerary?search="]');
    if (!priceLink) return 1;
    try {
      const url = new URL(priceLink.href, location.origin);
      const searchParam = url.searchParams.get('search');
      if (searchParam) {
        const payload = JSON.parse(atob(decodeURIComponent(searchParam)));
        return parseInt(payload?.pax?.adults || '1', 10);
      }
    } catch (e) {}
    return 1;
  }

  async function handleItaCopy(row, btn) {
    const paxCount = getItaPaxCount(row);

    let detailRow = row.nextElementSibling;
    let hasDetail = detailRow && detailRow.classList.contains('detail-row') && detailRow.querySelector('mat-list-item');

    if (!hasDetail) {
      const cell = row.querySelector('.cdk-column-price') || row.firstElementChild || row;
      cell.click();
      await wait(400);
      detailRow = row.nextElementSibling;
      hasDetail = detailRow && detailRow.classList.contains('detail-row') && detailRow.querySelector('mat-list-item');
    }

    if (!hasDetail) {
      flashError(btn, '\u274c Try expanding');
      return;
    }

    const legs = itaParseDetailSegments(detailRow);
    if (!legs.length) {
      flashError(btn, '\u274c Try expanding');
      return;
    }

    flashButton(btn, buildBoth({ flights: [{ legs }], pax: paxCount }));
  }

  function injectItaButtons() {
    const rows = document.querySelectorAll('tr.mat-mdc-row:not(.detail-row):not([data-gds-injected])');
    rows.forEach((row) => {
      const container = row.querySelector('.price-button-container');
      if (!container) return;

      row.setAttribute('data-gds-injected', '1');

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gds-btn-base gds-btn-matrix';
      btn.textContent = 'GDS';
      btn.title = 'Copy Sabre IA / VI* format for all legs';

      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        const liveRow = e.currentTarget.closest('tr');
        if (liveRow) handleItaCopy(liveRow, btn);
      });

      container.appendChild(btn);
    });
  }

  // ------------------------------------------------------------------
  // FLYBASIS / agentsearch.vercel.app ADAPTER
  // ------------------------------------------------------------------
  // FlyBasis's own data has the carrier code bleeding into the flight
  // number for some alphanumeric IATA codes (confirmed directly in
  // their raw data-json: a JetBlue "B6" leg carries flightNumber
  // "62548" for what's actually flight 2548 — the trailing digit of
  // "B6" prepended; a Discover "4Y" leg carries flightNumber "4Y69" for
  // flight 69 — the whole carrier code prepended this time). Not
  // something either FlyBasis adapter's own parsing introduced — this
  // is what's already in the source before either one touches it, so
  // both need to strip it the same way: the list-view button reads
  // this field straight from JSON with no text parsing at all, and the
  // detail-view one reads the same value from the rendered page text.
  // Passenger count of the Super Basis search, read from the page link
  // (?s= base64 JSON with "pax":"3"). Remembered for this tab so a detail
  // page opened from those results still knows it.
  function fbSearchPax() {
    let n = 0;
    try {
      const sp = new URL(location.href).searchParams.get('s');
      if (sp) n = parseInt(JSON.parse(atob(sp)).pax, 10) || 0;
    } catch (e) { n = 0; }
    try {
      if (n > 0) sessionStorage.setItem('ia-fb-pax', String(n));
      else n = parseInt(sessionStorage.getItem('ia-fb-pax'), 10) || 0;
    } catch (e) { /* ignore */ }
    return n;
  }

  function fbStripCarrierPrefixFromFlightNumber(flightNumber, carrierCode) {
    if (!flightNumber || !carrierCode) return flightNumber;
    const fn = String(flightNumber).trim();
    const cc = String(carrierCode).toUpperCase();
    if (fn.toUpperCase().startsWith(cc)) return fn.slice(cc.length);
    const digitsInCarrier = cc.replace(/[^0-9]/g, '');
    if (digitsInCarrier && fn.startsWith(digitsInCarrier)) return fn.slice(digitsInCarrier.length);
    return fn;
  }

  function fbCleanItineraryFlightNumbers(itinerary) {
    (itinerary.flights || []).forEach((flight) => {
      (flight.legs || []).forEach((leg) => {
        if (leg.airline && leg.airline.code) {
          leg.flightNumber = fbStripCarrierPrefixFromFlightNumber(leg.flightNumber, leg.airline.code);
        }
        if (leg.operatingAirline && leg.operatingAirline.code) {
          leg.operatingFlightNumber = fbStripCarrierPrefixFromFlightNumber(leg.operatingFlightNumber, leg.operatingAirline.code);
        }
      });
    });
    return itinerary;
  }

  // ------------------------------------------------------------------
  // SUPER BASIS worker (2.16.0): a Basis results tab opened by Super Basis
  // in the BO. It waits for the results to stop changing, sends a short
  // summary of each one back to the BO (flights, cheapest program, miles,
  // taxes, the ready *IA / VI* text) and the BO closes the tab.
  // ------------------------------------------------------------------
  function sbSummary(it, id) {
    const pax = fbSearchPax();
    const legs = (it.flights || []).flatMap((f) => f.legs || []);
    if (!legs.length) return null;
    const first = legs[0], last = legs[legs.length - 1];
    const okP = (o) => { const c = programCode(o.program); return c && BO_PROGRAMS.includes(c) ? 0 : 1; };
    const cost = (o) => (typeof o.price === 'number' ? o.price : Infinity);
    const offers = [];
    const collect = (n, d) => {
      if (!n || typeof n !== 'object' || d > 6) return;
      if (Array.isArray(n)) { n.forEach((x) => collect(x, d + 1)); return; }
      if (n.points && n.program) offers.push(n);
      Object.keys(n).forEach((k) => { if (n[k] && typeof n[k] === 'object') collect(n[k], d + 1); });
    };
    collect(it.awards, 0);
    offers.sort((a, b) => okP(a) - okP(b) || cost(a) - cost(b));
    const o = offers[0] || null;
    const seats = o && (o.seats || o.remainingSeats || o.availableSeats || o.seatsRemaining);
    const legNo = (l) => (l.airline && l.airline.code ? l.airline.code : '') + ' ' + fbStripCarrierPrefixFromFlightNumber(String(l.flightNumber || ''), l.airline && l.airline.code);
    let text = '';
    try { text = buildBoth(fbCleanItineraryFlightNumbers(JSON.parse(JSON.stringify(pax ? Object.assign({}, it, { pax }) : it)))); } catch (e) { text = ''; }
    let problem = '';
    try { problem = text ? (gdsTextProblem(text) || '') : 'Flights not readable'; } catch (e) { problem = ''; }
    const code = o ? programCode(o.program) : null;
    const miles = o ? Number(o.points) || 0 : 0;
    const taxes = o ? Math.round((Number(o.surcharge) || 0) * 100) / 100 : 0;
    const cash = o ? 0 : Number(it.total || (it.flights && it.flights[0] && it.flights[0].price)) || 0;
    let price = null;
    if (o && code && BO_PROGRAMS.includes(code)) price = { kind: 'award', parts: [{ points: miles, taxesPerPerson: taxes, program: code }] };
    else if (!o && cash > 0) price = { kind: 'cash', perPerson: cash };
    return {
      id: String(id || ''),
      dep: String(first.departure || ''), arr: String(last.arrival || ''),
      route: [first.origin && first.origin.iata].concat(legs.map((l) => l.destination && l.destination.iata)).filter(Boolean),
      flights: legs.map(legNo),
      stops: legs.length - 1,
      mins: legs.reduce((t, l) => t + (Number(l.duration) || 0), 0),
      cabin: String(first.cabin || ''),
      program: code || (o ? String(o.program) : ''),
      programName: code ? (PROGRAM_NAMES[code] || code) : (o ? String(o.program) : ''),
      miles, taxes, cash,
      seats: seats != null ? Number(seats) || 0 : null,
      text, problem, price,
      rush: code && RUSH_PROGRAMS[code] ? RUSH_PROGRAMS[code] + ' Detected, Rush flight only' : '',
      inf: { cash: INFANT_CASH_NET, miles: INFANT_AWARD_MILES },
    };
  }
  (function sbWorker() {
    if (!/agentsearch\.vercel\.app|flybasis\.com/.test(location.hostname) || window.top !== window) return;
    let job = null;
    try { job = JSON.parse(GM_getValue('ia-sb-job', 'null')); } catch (e) { job = null; }
    if (!job || !Array.isArray(job.urls) || Date.now() - job.at > 15 * 60 * 1000) return;
    const sOf = (u) => { try { return new URL(u, location.href).searchParams.get('s'); } catch (e) { return null; } };
    const mine = sOf(location.href);
    // Same search: exact link, or (if Basis rewrote it) same route and date.
    const sig = (sv) => { try { const j = JSON.parse(atob(sv)); const st = j.stops[0]; return [st.origin[0].code, st.destination[0].code, st.date.value, st.date.range, j.cabin, j.pax].join('|'); } catch (e) { return null; } };
    let idx = job.urls.findIndex((u) => sOf(u) === mine);
    if (idx < 0 && mine) { const me = sig(mine); idx = me ? job.urls.findIndex((u) => sig(sOf(u)) === me) : -1; }
    if (idx < 0 || !mine) return;
    const key = 'ia-sb-res-' + job.id + '-' + idx;
    const report = (state, items) => { try { GM_setValue(key, JSON.stringify({ state, items, url: location.href, at: Date.now() })); } catch (e) { /* ignore */ } };
    report('searching', []);
    const t0 = Date.now();
    let lastN = -1, stableAt = Date.now();
    const tick = setInterval(() => {
      const cards = document.querySelectorAll('[data-json][data-itinerary-id]');
      const n = cards.length;
      if (n !== lastN) { lastN = n; stableAt = Date.now(); }
      const quiet = Date.now() - stableAt;
      const txt = (document.body && document.body.innerText || '').slice(0, 30000);
      const none = n === 0 && /no (flights|results|itineraries|availability)/i.test(txt);
      const signedOut = n === 0 && /sign in|log in|login/i.test(txt) && Date.now() - t0 > 8000;
      const timedOut = Date.now() - t0 > 75000;
      if (!((n > 0 && quiet > 4000) || (none && quiet > 3000) || signedOut || timedOut)) return;
      clearInterval(tick);
      const items = [];
      cards.forEach((c) => { try { const x = sbSummary(JSON.parse(c.dataset.json), c.dataset.itineraryId); if (x) items.push(x); } catch (e) { /* skip */ } });
      report(items.length ? 'done' : (signedOut ? 'signedout' : 'empty'), items);
    }, 500);
  })();

  function injectFlyBasisButtons() {
    const cards = document.querySelectorAll('[data-json][data-itinerary-id]');
    cards.forEach((card) => {
      const existing = card.querySelector('.gds-btn-flybasis');
      if (existing) {
        // Present already — but the site can add new badge icons to this
        // same row asynchronously (a warning icon showing up once some
        // status finishes computing, after the button already landed).
        // Since appendChild only ever placed it last at the moment it was
        // inserted, a sibling arriving later strands it in the middle —
        // confirmed directly: simulating a later-arriving third icon
        // reproduced exactly that sandwiched order. Re-asserting "last
        // child of its row" on every scan, not just at insertion, keeps
        // it correctly positioned as the row's membership keeps changing.
        const row = existing.parentElement;
        if (row && row.lastElementChild !== existing) row.appendChild(existing);
        return;
      }
      let itinerary;
      try { itinerary = JSON.parse(card.dataset.json); } catch (e) { return; }
      if (!itinerary || !Array.isArray(itinerary.flights)) return;

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gds-btn-base gds-btn-flybasis';
      btn.textContent = 'GDS';
      btn.title = 'Copy Sabre IA / VI* format for this itinerary (all directions)';

      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        const pax = fbSearchPax();
        flashButton(btn, buildBoth(fbCleanItineraryFlightNumbers(pax ? Object.assign({}, itinerary, { pax }) : itinerary)));
      });

      // Insert as a normal flex child of the icon row (which holds
      // zero, one, two, or three little badge icons depending on the
      // option), rather than absolutely positioning it — an absolutely
      // positioned button anchored by `right` visibly jumps sideways
      // the instant its own text changes width (flashing "Copied!" is
      // wider than "GDS"), since growing wider pushes its left edge
      // further left. As a normal flex child, the row just
      // accommodates the width change smoothly, same as it already
      // does for however many icons happen to be there.
      //
      // A row-reverse theory was tried here and turned out wrong —
      // comparing this page against the itinerary-detail page (whose
      // own button has always used a plain appendChild, and looks
      // correct) showed this row is a normal, non-reversed flex
      // container after all. Matching that same appendChild here
      // brings the two pages back in line with each other.
      //
      // That fixed the ordering but not a separate problem: this row is
      // positioned via margin-left:auto within the summary line, not
      // anchored to a fixed right edge — so when its own content grows
      // wider (flashing "Copied!"), the ROW's right edge moves right
      // right along with it, past the card's own boundary, and gets
      // clipped — confirmed directly from the screenshots, where the
      // expanded button visibly runs off the edge of the card. Taking
      // the row out of normal flex flow and anchoring it with
      // position:absolute; right:0 on its nearest positioned ancestor
      // fixes the row's right edge in place regardless of how wide its
      // content gets; justify-content:flex-end inside it then means
      // growth pushes the icons further left, not the row further
      // right.
      const iconRow = card.querySelector('.ml-auto.flex.w-24.shrink-0.items-center.gap-1');
      if (iconRow) {
        const summaryRow = iconRow.closest('.flex.h-10.w-full.items-center.gap-12') || iconRow.parentElement;
        if (summaryRow && getComputedStyle(summaryRow).position === 'static') {
          summaryRow.style.position = 'relative';
        }
        iconRow.style.position = 'absolute';
        iconRow.style.right = '0';
        iconRow.style.top = '50%';
        iconRow.style.transform = 'translateY(-50%)';
        iconRow.style.width = 'auto';
        iconRow.style.justifyContent = 'flex-end';
        iconRow.appendChild(btn);
      } else {
        btn.style.position = 'absolute';
        btn.style.right = '20px';
        btn.style.top = '34px';
        card.appendChild(btn);
      }
    });
  }

  // ------------------------------------------------------------------
  // FLYBASIS ITINERARY-DETAIL PAGE — a genuinely separate page reached
  // by opening an option "further, on its own" (distinct from the
  // inline accordion the list view above expands into, which DOES have
  // data-json on its own card and needs none of this). This standalone
  // page has no data-json anywhere, so segments are read straight off
  // the rendered text instead: each one is a ".flex.w-full.gap-4" block
  // containing an airline-code <img alt="XX">, a "City (IATA) to City
  // (IATA)" <p>, a day-of-week/month/day <p>, a "XX 123 (Operated by
  // ...)" flight-number <p>, two time <button>s (arrival's optional
  // <sup>+1</sup> for a next-day arrival), a "(Xh Ym)" duration <p>, and
  // an "Aircraft | Cabin (X)" <p>. FlyBasis states "Operated by ..." on
  // every segment, including ones where that's just the same airline
  // operating its own metal — not a real codeshare signal, so it's read
  // but not used to build an OPERATED BY line, which would otherwise be
  // wrong on nearly every leg.
  // ------------------------------------------------------------------
  function fbdParseSegments(container) {
    const legs = [];
    const candidates = container.querySelectorAll('.flex.w-full.gap-4');
    candidates.forEach((seg) => {
      const img = seg.querySelector('img[alt]');
      if (!img) return;
      const carrierCode = (img.getAttribute('alt') || '').trim();
      if (!/^[A-Z0-9]{2,3}$/.test(carrierCode)) return;

      const paras = Array.from(seg.querySelectorAll('p'));
      const routeP = paras.find((p) => /\([A-Z]{3}\).*\([A-Z]{3}\)/.test(p.textContent));
      if (!routeP) return;
      const routeMatch = routeP.textContent.match(/\(([A-Z]{3})\).*?\(([A-Z]{3})\)/);
      const origin = routeMatch[1];
      const dest = routeMatch[2];

      const routeRow = routeP.parentElement;
      const dateP = Array.from(routeRow.querySelectorAll('p')).find((p) => p !== routeP);
      const dateText = dateP ? dateP.textContent.trim() : '';

      // Previously re-extracted the carrier from this same paragraph via
      // a second regex (/^[A-Z0-9]{2,3}\s*(\d+)/) — redundant, since
      // carrierCode above is already known reliably from the airline
      // logo, and actively wrong whenever the page renders the carrier
      // and flight number with no space between them (e.g. "B62548"
      // rather than "B6 2548"): the greedy {2,3} quantifier would eat
      // one extra digit into the "carrier" group, corrupting both
      // values (confirmed directly — "B62548" parsed as carrier "B62",
      // flightNum "548", and worse once carrierCode + flightNumber get
      // concatenated back together downstream). Stripping the already-
      // known carrierCode off the front of the text instead sidesteps
      // the whole problem — no quantifier to overmatch, and it works
      // whether or not the page puts a space in between.
      const flightP = paras.find((p) => p.textContent.trim().startsWith(carrierCode) && /\d/.test(p.textContent));
      const flightText = flightP ? flightP.textContent.trim() : '';
      const afterCarrier = flightText.startsWith(carrierCode) ? flightText.slice(carrierCode.length).trim() : flightText.trim();
      // Grab the whole next token, not just a leading digit run — the
      // remaining text can itself still start with the carrier code
      // again (FlyBasis's data for Discover's "4Y" leg literally says
      // "4Y 4Y69": stripping just the first "4Y " here still leaves
      // "4Y69", and a digits-only match on that stops at "4" — a lone
      // digit that then looks exactly like the digit-prefix case and
      // gets stripped to nothing). Passing the full token through
      // fbStripCarrierPrefixFromFlightNumber lets it catch either shape
      // properly, however many times the carrier ended up embedded.
      const tokenMatch = afterCarrier.match(/^([^\s(]+)/);
      // Even once correctly read off the page, the flight number FlyBasis
      // itself displays can still have the carrier code bled into it —
      // see fbStripCarrierPrefixFromFlightNumber for the confirmed
      // examples (JetBlue's trailing digit, Discover's whole code). This
      // page text has the exact same underlying data, so needs the same
      // cleanup, not just the list-view adapter that reads it from JSON.
      const flightNumber = fbStripCarrierPrefixFromFlightNumber(tokenMatch ? tokenMatch[1] : '', carrierCode);

      const buttons = seg.querySelectorAll('button[data-state]');
      const depTimeText = buttons[0] ? buttons[0].textContent.trim() : '';
      const arrBtn = buttons[1];
      let arrTimeText = '', dayOffset = 0;
      if (arrBtn) {
        const sup = arrBtn.querySelector('sup');
        if (sup) {
          dayOffset = parseInt(sup.textContent.replace('+', ''), 10) || 0;
          arrTimeText = arrBtn.textContent.replace(sup.textContent, '').trim();
        } else {
          arrTimeText = arrBtn.textContent.trim();
        }
      }

      const durP = paras.find((p) => /^\(\d+h(\s*\d+m)?\)$/.test(p.textContent.trim()));
      const durText = durP ? durP.textContent.trim() : '';
      const durMatch = durText.match(/(\d+)h(?:\s*(\d+)m)?/);
      const durMin = durMatch ? parseInt(durMatch[1], 10) * 60 + (durMatch[2] ? parseInt(durMatch[2], 10) : 0) : 0;

      // The trailing "(X)" booking-class letter isn't always there —
      // confirmed directly: some legs render as "Airbus A320 | Economy "
      // with nothing after "Economy" at all. Both the selector and the
      // regex previously required that letter to match anything, so
      // legs without it lost their aircraft AND cabin entirely, not just
      // the class letter — which is what was producing wrong, guessed
      // equipment codes downstream (equipCode falls back to a default
      // when the aircraft string it's given is empty). Making the "(X)"
      // portion optional in both places fixes this without weakening
      // the match for legs that do have it.
      const acP = paras.find((p) => p.textContent.includes('|'));
      const acText = acP ? acP.textContent.trim() : '';
      const acMatch = acText.match(/^(.*?)\s*\|\s*([^(]*?)\s*(?:\(([A-Z])\))?\s*$/);
      const aircraft = acMatch ? acMatch[1].trim() : '';
      const cabinName = acMatch ? acMatch[2].trim().toLowerCase() : '';
      let cabinCode = 'y';
      if (cabinName.includes('business')) cabinCode = 'j';
      else if (cabinName.includes('first')) cabinCode = 'f';
      else if (cabinName.includes('premium')) cabinCode = 'w';

      legs.push({ carrierCode, origin, dest, dateText, flightNumber, depTimeText, arrTimeText, dayOffset, durMin, aircraft, cabinCode });
    });
    return legs;
  }

  function fbdParseTime(t) {
    const m = (t || '').match(/(\d{1,2}):(\d{2})\s*([AP]M)/i);
    if (!m) return { h: 0, m: 0 };
    let h = parseInt(m[1], 10);
    const mi = parseInt(m[2], 10);
    const ap = m[3].toUpperCase();
    if (ap === 'PM' && h < 12) h += 12;
    if (ap === 'AM' && h === 12) h = 0;
    return { h, m: mi };
  }

  function fbdParseDateText(dateText) {
    const m = (dateText || '').match(/([A-Za-z]{3})\w*\s+(\d{1,2})\s*$/);
    if (!m) return null;
    const month = MONTH_MAP[m[1].slice(0, 3).toLowerCase()];
    if (month === undefined) return null;
    return { month, day: parseInt(m[2], 10) };
  }

  function fbdBuildLegs(rawSegments) {
    const legs = [];
    rawSegments.forEach((seg) => {
      const dateParts = fbdParseDateText(seg.dateText);
      if (!dateParts) return;
      const year = inferYear(dateParts.month, dateParts.day);
      const dep = fbdParseTime(seg.depTimeText);
      const departure = new Date(year, dateParts.month, dateParts.day, dep.h, dep.m, 0, 0);
      const arr = fbdParseTime(seg.arrTimeText);
      const arrival = new Date(year, dateParts.month, dateParts.day + seg.dayOffset, arr.h, arr.m, 0, 0);

      legs.push({
        airline: { code: seg.carrierCode },
        flightNumber: seg.flightNumber,
        cabin: seg.cabinCode,
        aircraft: seg.aircraft,
        origin: { iata: seg.origin },
        destination: { iata: seg.dest },
        departure,
        arrival,
        duration: seg.durMin,
      });
    });
    return legs;
  }

  function injectFlyBasisDetailButton() {
    // Anchor on the header row itself rather than a generic utility-
    // class combo (those are common enough elsewhere that matching on
    // class alone risks landing on the wrong row) — the route+date
    // summary text ("X to Y on Sat, Jan 23") is distinctive enough to
    // find the right one reliably. Also requires there to be NO
    // data-json anywhere on the page — if there is, this is the inline
    // accordion (which the list-view button above already handles), not
    // the standalone detail page, and this should stay out of its way.
    if (document.querySelector('[data-json][data-itinerary-id]')) return;
    const headerP = Array.from(document.querySelectorAll('p')).find((p) => / to .+ on [A-Za-z]{3},\s*[A-Za-z]{3}\s+\d/.test(p.textContent));
    if (!headerP) return;
    const row = headerP.closest('.flex.w-full.items-center.justify-between');
    if (!row || row.dataset.gdsDetailWired) return;
    row.dataset.gdsDetailWired = '1';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'gds-btn-base gds-btn-flybasis';
    btn.textContent = 'GDS';
    btn.title = 'Copy Sabre IA / VI* format for this itinerary';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const container = document.querySelector('.mb-\\[100px\\]') || document.body;
      const rawSegments = fbdParseSegments(container);
      const legs = fbdBuildLegs(rawSegments);
      if (legs.length) {
        flashButton(btn, buildBoth({ flights: [{ legs }], pax: fbSearchPax() || 1 }));
      } else {
        flashError(btn, '\u274c No data');
      }
    });
    // The row is already "justify-between" (title on the left, a small
    // icon-group on the right) — appending into that existing right-
    // side group lands this at the far right naturally, flowing with
    // whatever's already there, rather than needing absolute
    // positioning to force it into a corner.
    const rightGroup = row.querySelector('.flex.items-center.gap-1') || row;
    rightGroup.appendChild(btn);
  }

  // ------------------------------------------------------------------
  // POINTSYEAH ADAPTER
  // ------------------------------------------------------------------
  function pyParsePax() {
    const params = new URLSearchParams(location.search);
    const adults = parseInt(params.get('adults') || '1', 10) || 1;
    const children = parseInt(params.get('children') || '0', 10) || 0;
    return adults + children;
  }

  // Reads every flight in an expanded PointsYeah itinerary. PointsYeah has
  // shown the flight line ("PR101 · Boeing 777" or just "PR101 ·"), the
  // cabin and the flight time both AFTER the arrival and BETWEEN departure
  // and arrival, so each flight's details are looked for anywhere in its
  // own block (from its departure up to the next flight's departure),
  // never at one fixed position.
  function pyParseDetailLegs(detailEl) {
    const lines = detailEl.innerText.split('\n').map((s) => s.replace(/ /g, ' ').trim()).filter(Boolean);
    const dtRe = /^[A-Za-z]{3},\s*[A-Za-z]{3}\s+\d{1,2},?\s+\d{4}\s+\d{1,2}:\d{2}\s*(am|pm)$/i;
    const stationRe = /\(([A-Z]{3})\)\s*$/;
    const flightRe = /^([A-Z0-9]{2})\s?(\d{1,4})(?![\dhm])\s*(?:[·•|]\s*(.*))?$/;
    const cabinRe = /^(premium economy|premium|economy|coach|business|first)\b(?:.*?\(([A-Z])\))?/i;
    const durRe = /^(\d{1,2})\s*h(?:\s*(\d{1,2})\s*m)?$/i;

    // Departure/arrival pairs: a date-time line followed by "Airport (XXX)".
    const stamps = [];
    for (let i = 0; i < lines.length - 1; i++) {
      if (dtRe.test(lines[i]) && stationRe.test(lines[i + 1])) stamps.push(i);
    }
    const legs = [];
    for (let k = 0; k + 1 < stamps.length; k += 2) {
      const di = stamps[k];
      const ai = stamps[k + 1];
      const end = k + 2 < stamps.length ? stamps[k + 2] : lines.length;
      let flightNo = '', aircraft = '', cabin = '', bookingCode = '', durMin = 0;
      for (let j = di + 2; j < end; j++) {
        if (j === ai || j === ai + 1) continue;
        const t = lines[j];
        if (j > ai && /^layover/i.test(t)) break;
        const dm = !durMin && t.match(durRe);
        if (dm) { durMin = parseInt(dm[1], 10) * 60 + (parseInt(dm[2] || '0', 10) || 0); continue; }
        const fm = !flightNo && t.match(flightRe);
        if (fm) { flightNo = fm[1] + fm[2]; aircraft = (fm[3] || '').trim(); continue; }
        const cm = !cabin && t.match(cabinRe);
        if (cm) { cabin = /^premium/i.test(cm[1]) ? 'premium economy' : cm[1].toLowerCase(); if (cm[2]) bookingCode = cm[2]; }
      }
      legs.push({ depDT: lines[di], depCode: lines[di + 1].match(stationRe)[1], arrDT: lines[ai], arrCode: lines[ai + 1].match(stationRe)[1], flightNo, aircraft, cabin, bookingCode, durMin });
    }
    return legs;
  }

  // Flight numbers from the card header ("Philippine Airlines - PR101"),
  // for when the expanded block doesn't show them.
  function pyHeaderFlightNos(anchorEl) {
    let card = anchorEl;
    for (let i = 0; i < 8 && card && card.parentElement; i++) card = card.parentElement;
    const text = card ? card.innerText : '';
    return Array.from(text.matchAll(/ - ([A-Z0-9]{2})\s?(\d{1,4})\b/g)).map((m) => m[1] + m[2]);
  }

  function pyTzDuration(leg) {
    const plain = Math.round((leg.arrival - leg.departure) / 60000);
    const o1 = estimateUtcOffset(leg.origin.iata);
    const o2 = estimateUtcOffset(leg.destination.iata);
    if (o1 == null || o2 == null) return Math.max(0, plain);
    return Math.max(0, plain - (o2 - o1) * 60);
  }

  function pyToDate(dtStr) {
    return new Date(dtStr.replace(/^[A-Za-z]{3},\s*/, ''));
  }

  function pyFindDetailBlock(anchorEl) {
    const details = document.querySelectorAll('div[class*="rounded-t-none"][class*="rounded-l-2xl"]');
    const anchorRect = anchorEl.getBoundingClientRect();
    let best = null;
    let bestDist = Infinity;
    details.forEach((d) => {
      const r = d.getBoundingClientRect();
      const dist = r.top - anchorRect.top;
      if (dist >= -5 && dist < bestDist) {
        bestDist = dist;
        best = d;
      }
    });
    return best;
  }

  function pyBuildItinerary(anchorEl) {
    const detailEl = pyFindDetailBlock(anchorEl);
    if (!detailEl) return null;
    const rawLegs = pyParseDetailLegs(detailEl);
    if (!rawLegs.length) return null;

    const pax = pyParsePax();
    const headerNos = pyHeaderFlightNos(anchorEl);
    const legs = rawLegs.map((rl, i) => {
      const fno = rl.flightNo || (headerNos.length === rawLegs.length ? headerNos[i] : '');
      const leg = {
        airline: { code: fno.slice(0, 2) },
        flightNumber: fno.slice(2),
        cabin: CABIN_WORD_TO_CODE[rl.cabin] || 'y',
        aircraft: rl.aircraft,
        origin: { iata: rl.depCode },
        destination: { iata: rl.arrCode },
        departure: pyToDate(rl.depDT),
        arrival: pyToDate(rl.arrDT),
        duration: rl.durMin || 0,
      };
      // No duration shown: work it out with both airports' time zones
      // (plain subtraction of two local times is wrong across zones).
      if (!leg.duration) leg.duration = pyTzDuration(leg);
      if (rl.bookingCode) leg.bookingCode = rl.bookingCode;
      return leg;
    });

    return { flights: [{ legs }], pax };
  }

  async function handlePointsYeahCopy(bellBtn, btn) {
    let itinerary = pyBuildItinerary(bellBtn);

    if (!itinerary) {
      // The itinerary breakdown only renders once the row/option is
      // expanded. The bell button (and its immediate wrapper) is a
      // price-alert control, not an expand toggle — clicking anywhere
      // near it opens an unrelated promo dialog, so those are excluded
      // entirely. Climb further out to the row/card ancestors instead.
      const candidates = [
        bellBtn.closest('tr'),
        bellBtn.parentElement?.parentElement,
        bellBtn.parentElement?.parentElement?.parentElement,
        bellBtn.parentElement?.parentElement?.parentElement?.parentElement,
      ].filter(Boolean);

      for (const trigger of candidates) {
        if (itinerary) break;
        trigger.click();
        await wait(400);
        itinerary = pyBuildItinerary(bellBtn);
      }
    }

    if (itinerary) {
      flashButton(btn, buildBoth(itinerary));
    } else {
      flashError(btn, '\u274c No data');
    }
  }

  function injectPointsYeahButtons() {
    const bellPaths = document.querySelectorAll('path[fill="#FFC800"]');
    bellPaths.forEach((path) => {
      const bellBtn = path.closest('button');
      if (!bellBtn) return;
      const container = bellBtn.parentElement;
      if (!container || container.dataset.gdsInjected) return;
      container.dataset.gdsInjected = '1';

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gds-btn-base gds-btn-yeah';
      btn.textContent = 'GDS';
      btn.title = 'Copy Sabre IA / VI* format for this itinerary';
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        handlePointsYeahCopy(bellBtn, btn);
      });
      container.appendChild(btn);
    });
  }

  // ------------------------------------------------------------------
  // AWARDLOGIC ADAPTER
  //
  // The collapsed result row (`.results-trip-list-item`) never exposes a
  // real flight number — only a rough cabin % summary — so that path is
  // kept only as a last-resort fallback (flight number "????").
  //
  // Clicking the option opens an "add to itinerary" detail view
  // (`.results-trip-add`) that DOES expose real flight numbers, per-leg
  // cabin, and per-leg duration. The GDS button now clicks to open that
  // view (if not already open) and parses it instead.
  // ------------------------------------------------------------------
  function alParsePax() {
    const m = location.pathname.match(/(\d+):(\d+):(\d+):(\d+):(\d+):(\d+)$/);
    if (m) return (parseInt(m[1], 10) || 1) + (parseInt(m[2], 10) || 0);
    return 1;
  }

  function alParseDate() {
    const m = location.pathname.match(/(\d{4}-\d{2}-\d{2})/);
    return m ? m[1] : new Date().toISOString().slice(0, 10);
  }

  function alBaseYear() {
    const m = alParseDate().match(/^(\d{4})/);
    return m ? parseInt(m[1], 10) : new Date().getFullYear();
  }

  function alParseTime12(timeStr, ampm) {
    const [hStr, mStr] = (timeStr || '0:0').split(':');
    let h = parseInt(hStr, 10) || 0;
    const m = parseInt(mStr, 10) || 0;
    const isPM = /pm/i.test(ampm || '');
    if (isPM && h < 12) h += 12;
    if (!isPM && h === 12) h = 0;
    return { h, m };
  }

  // Builds a Date from a "Mon Day" style text (e.g. "Tue, Oct 27") plus a
  // "H:MM AM/PM" clock string, anchored to the given year.
  function alDateFromParts(monthDayText, timeStr, year) {
    const dm = (monthDayText || '').match(/([A-Za-z]{3})\s+(\d{1,2})/);
    if (!dm) return null;
    const month = MONTH_MAP[dm[1].toLowerCase()];
    if (month === undefined) return null;
    const day = parseInt(dm[2], 10);
    const { h, m } = alParseTime12(...(timeStr || '').match(/(\d{1,2}:\d{2})\s*(AM|PM)/i)?.slice(1) || ['0:0', 'AM']);
    return new Date(year, month, day, h, m, 0, 0);
  }

  function alBuildItinerary(card) {
    const airlineImg = card.querySelector('.airline-logo-wrapper__img img');
    const carrier = (airlineImg?.alt || '').trim().toUpperCase();
    const points = card.querySelectorAll('.results-trip-list-item__time-info-point');
    if (points.length < 2) return null;

    const depAirport = points[0].querySelector('.results-trip-list-item__time-info-airport')?.textContent.trim();
    const depTimeStr = points[0].querySelector('.results-trip-list-item__time-info-time')?.textContent.trim();
    const depAmPm = points[0].querySelector('.results-trip-list-item__time-info-half-day')?.textContent.trim();
    const arrAirport = points[1].querySelector('.results-trip-list-item__time-info-airport')?.textContent.trim();
    const durationStr = card.querySelector('.results-trip-list-item__time-info-sum')?.textContent.trim() || '0h 0m';
    const cabinText = card.querySelector('.results-trip-list-item__cabin-info')?.textContent.trim() || '';
    const cabinWordMatch = cabinText.match(/economy|premium economy|business|first/i);
    const cabinWord = cabinWordMatch ? cabinWordMatch[0].toLowerCase() : 'economy';
    const cabinCode = CABIN_WORD_TO_CODE[cabinWord] || 'y';

    if (!depAirport || !arrAirport || !depTimeStr) return null;

    const year = alBaseYear();
    const { h, m } = alParseTime12(depTimeStr, depAmPm);
    const depDate = new Date(year, 0, 1);
    const dateStr = alParseDate();
    const dm = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (dm) depDate.setFullYear(parseInt(dm[1], 10), parseInt(dm[2], 10) - 1, parseInt(dm[3], 10));
    depDate.setHours(h, m, 0, 0);
    const durMin = parseDurationMinutes(durationStr);
    const arrDate = new Date(depDate.getTime() + durMin * 60000);

    const leg = {
      airline: { code: carrier },
      flightNumber: '????',
      cabin: cabinCode,
      aircraft: '',
      origin: { iata: depAirport },
      destination: { iata: arrAirport },
      departure: depDate,
      arrival: arrDate,
      duration: durMin,
    };
    return { flights: [{ legs: [leg] }], pax: alParsePax() };
  }

  // Parses the expanded "results-trip-add" detail view for real per-segment
  // flight numbers / cabins / durations. Only two overall dates are shown
  // in this markup (trip depart date, trip arrival date) — not one date per
  // segment — so as a best effort, earlier segments anchor to the overall
  // departure date and the final segment anchors to the overall arrival
  // date (identical in the common case where the whole itinerary lands the
  // same calendar day it departs).
  function alParseExpandedSegments(detailEl) {
    const year = alBaseYear();
    const departText = detailEl.querySelector('.trip-info-card__time-date')?.textContent.trim() || '';
    const arriveTextRaw = detailEl.querySelector('.trip-info-card__time-arrival')?.textContent || '';
    const arriveText = arriveTextRaw.replace(/^\s*This flight arrives\s*-\s*/i, '').trim() || departText;

    const segEls = detailEl.querySelectorAll('.results-trip-add-flight');
    const legs = [];

    segEls.forEach((segEl, idx) => {
      const points = segEl.querySelectorAll('.results-trip-add-flight__point');
      if (points.length < 2) return;

      const depCode = points[0].querySelector('.results-trip-add-flight__point-abbr')?.textContent.trim() || '';
      const depTimeStr = points[0].querySelector('.results-trip-add-flight__point-date')?.textContent.trim() || '';
      const arrCode = points[1].querySelector('.results-trip-add-flight__point-abbr')?.textContent.trim() || '';

      const infoItems = segEl.querySelectorAll('.results-trip-add-flight__info-item');
      const flightText = (infoItems[0]?.textContent || '').replace(/\|\s*$/, '').trim();
      const flightMatch = flightText.match(/^([A-Z0-9]{2})\s*(\d+)/i);
      const carrier = flightMatch ? flightMatch[1].toUpperCase() : '';
      const flightNumber = flightMatch ? flightMatch[2] : '';
      if (!depCode || !arrCode || !flightNumber) return;

      const cabinText = (segEl.querySelector('.results-trip-add-flight__cabin')?.textContent || '').trim().toLowerCase();
      const cabinCode = CABIN_WORD_TO_CODE[cabinText] || 'y';

      const durationStr = segEl.querySelector('.results-trip-add-flight__duration span')?.textContent.trim() || '0h 0m';
      const durMin = parseDurationMinutes(durationStr);

      const isLast = idx === segEls.length - 1;
      const depDate = alDateFromParts(isLast ? arriveText : departText, depTimeStr, year);
      if (!depDate) return;
      const arrDate = new Date(depDate.getTime() + durMin * 60000);

      legs.push({
        airline: { code: carrier },
        flightNumber,
        cabin: cabinCode,
        aircraft: '',
        origin: { iata: depCode },
        destination: { iata: arrCode },
        departure: depDate,
        arrival: arrDate,
        duration: durMin,
      });
    });

    return legs;
  }

  async function handleAwardLogicCopy(card, btn) {
    let legs = [];
    let detailEl = document.querySelector('.results-trip-add');
    const wasAlreadyOpen = !!detailEl;
    let trigger = null;
    let hidden = false;

    if (!detailEl) {
      const triggerSelectors = [
        '.results-trip-list-item__flight-wrapper',
        '.results-trip-list-item__info-flight',
        '.results-trip-list-item__airline-info',
      ];
      for (const sel of triggerSelectors) {
        trigger = card.querySelector(sel);
        if (trigger) break;
      }
      trigger = trigger || card;
      trigger.click();
    }

    for (let attempt = 0; attempt < 5 && !legs.length; attempt++) {
      await wait(300);
      detailEl = document.querySelector('.results-trip-add');
      if (detailEl && !wasAlreadyOpen && !hidden) {
        // Hide it via CSS immediately so there's no visible flash while
        // we read it — this is purely cosmetic now, not the close
        // mechanism itself (see below). Hidden elements are still fully
        // readable via the DOM, so parsing is unaffected.
        //
        // Explicitly target `.wl-ui-modal` itself (the true outermost
        // root — it carries its own positioning custom properties, so
        // it's almost certainly the element actually covering the page)
        // rather than climbing a fixed number of parentElement levels,
        // which previously stopped one level short of it and left it
        // un-hidden — very likely the actual source of the page staying
        // unclickable even after the close click below.
        let el = detailEl;
        for (let level = 0; level < 3 && el; level++) {
          el.style.setProperty('display', 'none', 'important');
          el = el.parentElement;
        }
        const modalRootEl = detailEl.closest('.wl-ui-modal');
        if (modalRootEl) modalRootEl.style.setProperty('display', 'none', 'important');
        document.querySelectorAll('.wl-ui-modal__overlay').forEach((overlay) => {
          overlay.style.setProperty('display', 'none', 'important');
        });
        hidden = true;
      }
      if (detailEl) legs = alParseExpandedSegments(detailEl);
    }

    if (!wasAlreadyOpen && detailEl) {
      // Use the framework's own close button rather than guessing at
      // what it does internally (scroll-lock, click-blocking overlay,
      // event listeners, etc.) — clicking it runs the real teardown, so
      // nothing needs to be reverse-engineered or manually restored.
      // Hiding above is what prevents the visible flash; this is what
      // actually leaves the page clickable again afterward.
      const modalRoot = detailEl.closest('.wl-ui-modal');
      const closeIcon = (modalRoot && modalRoot.querySelector('.wl-ui-modal__close-icon'))
        || document.querySelector('.wl-ui-modal__close-icon')
        || document.querySelector('.user-ui-icon-modal-close');
      if (closeIcon) {
        // Un-hide the root right before the click — some frameworks'
        // click handlers bail out early if they read the element as
        // already hidden/not-visible, so the forced hide above could
        // itself prevent the close handler from ever running.
        if (modalRoot) modalRoot.style.removeProperty('display');
        closeIcon.click();
        await wait(200);
        // Hide again in case anything flashed visible during that gap.
        if (modalRoot) modalRoot.style.setProperty('display', 'none', 'important');
      }
      // Cheap extra safety net regardless of whether a close icon was
      // found — a plain scroll-lock (inline `overflow` on body/html) is
      // a common secondary cause of "page won't scroll/click" and costs
      // nothing to clear even if it wasn't the actual cause here.
      document.body.style.removeProperty('overflow');
      document.documentElement.style.removeProperty('overflow');
    }

    if (legs.length) {
      flashButton(btn, buildBoth({ flights: [{ legs }], pax: alParsePax() }));
      return;
    }

    // Fallback: row-level summary only (flight number unavailable there).
    const itinerary = alBuildItinerary(card);
    if (itinerary) {
      flashButton(btn, buildBoth(itinerary));
    } else {
      flashError(btn, '\u274c No data');
    }
  }

  function injectAwardLogicButtons() {
    const cabinBlocks = document.querySelectorAll('.results-trip-list-item__cabin:not([data-gds-injected])');
    cabinBlocks.forEach((cabinEl) => {
      cabinEl.setAttribute('data-gds-injected', '1');
      const card = cabinEl.closest('.results-trip-list-item') || cabinEl.closest('.results-trip-list-item__info');
      if (!card) return;

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gds-btn-base gds-btn-award';
      btn.textContent = 'GDS';
      btn.title = 'Copy Sabre IA / VI* format for this result';
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        handleAwardLogicCopy(card, btn);
      });
      cabinEl.parentElement.insertBefore(btn, cabinEl.nextSibling);
    });
  }

  // ------------------------------------------------------------------
  // KAYAK ADAPTER
  //
  // The leg-checkbox summary (`.hJSA-item`) never had real flight numbers
  // — that's why it always produced "????". Each result also has a
  // sibling "-details" panel (`.o-C7`, id ending in "-details") with real
  // per-segment data: a `data-flightnumber` attribute right on each
  // segment, explicit departure AND arrival dates (so no guessing needed
  // for rollovers), cabin, and aircraft type. That panel is preferred;
  // the leg-checkbox summary is kept only as a last-resort fallback.
  // ------------------------------------------------------------------
  function kyResolveYear(month) {
    const matches = [...location.pathname.matchAll(/(\d{4})-(\d{2})-(\d{2})/g)];
    for (const m of matches) {
      if (parseInt(m[2], 10) - 1 === month) return parseInt(m[1], 10);
    }
    return matches.length ? parseInt(matches[0][1], 10) : new Date().getFullYear();
  }

  function kyParseCabin() {
    const path = location.pathname.toLowerCase();
    if (path.includes('business')) return 'j';
    if (path.includes('first')) return 'f';
    if (path.includes('premium')) return 'w';
    return 'y';
  }

  function kyFindDetailsPanel(card) {
    const container = card.closest('.Fxw9-result-item-container') || card.closest('[class*="-result-item-container"]') || card.parentElement;
    if (!container) return null;
    return container.querySelector('[id$="-details"]') || container.querySelector('.o-C7');
  }

  function kyParseFullDate(dateText, timeText) {
    const dm = (dateText || '').match(/([A-Za-z]{3})\s+(\d{1,2})/);
    if (!dm) return null;
    const month = MONTH_MAP[dm[1].toLowerCase()];
    if (month === undefined) return null;
    const day = parseInt(dm[2], 10);
    const year = inferYear(month, day);
    const { h, m } = parseClockTime(timeText);
    return new Date(year, month, day, h, m, 0, 0);
  }

  // Kayak renames the short code at the front of its class names now and
  // then (c1hxM → KyKt, qvW6 → FTA5…), so the details are read by the stable
  // end of each name ("-inline-segment-body", "-half-column"…) and by
  // data-flightnumber, whatever the code in front is.
  const kyQ = (root, suffix) => root.querySelector('[class*="' + suffix + '"]');
  const kyQA = (root, suffix) => Array.from(root.querySelectorAll('[class*="' + suffix + '"]'));
  const kyHas = (el, suffix) => Array.from(el.classList).some((c) => c.endsWith(suffix));
  function kyParseDetailsSegments(detailsPanel) {
    const legs = [];
    const cabinFallback = kyParseCabin();
    const segEls = detailsPanel.querySelectorAll('[data-flightnumber]');

    segEls.forEach((seg) => {
      const flightNumber = seg.getAttribute('data-flightnumber') || '';
      const img = seg.querySelector('[class*="-carrier-icon"] img') || seg.querySelector('img[src*="/airlines/"]');
      const carrierMatch = img?.src.match(/\/([A-Z0-9]{2})\.png/i);
      let carrier = carrierMatch ? carrierMatch[1].toUpperCase() : '';
      if (!carrier) {
        const name = (img?.alt || '').trim().toLowerCase();
        carrier = AIRLINE_MAP[name] || '';
      }
      if (!flightNumber || !carrier) return;

      const inlineBody = kyQ(seg, '-inline-segment-body');
      if (!inlineBody) return;

      const rowEntries = kyQA(inlineBody, '-row-entry').filter((r) => Array.from(r.classList).some((c) => c.endsWith('-row-entry')));
      const dateRow = rowEntries.find((r) => kyHas(r, '-day-with-date'));
      const routeRow = rowEntries.find((r) => !kyHas(r, '-day-with-date'));
      const durationEntry = kyQA(inlineBody, '-duration-entry').find((r) => kyHas(r, '-duration-entry'));
      if (!routeRow || !dateRow || !durationEntry) return;

      const cols = (row) => kyQA(row, '-half-column').filter((c) => kyHas(c, '-half-column'));
      const routeCols = cols(routeRow);
      const originCode = routeCols[0]?.textContent.trim() || '';
      const destCode = routeCols[1]?.textContent.trim() || '';

      const dateCols = cols(dateRow);
      const depDateText = dateCols[0]?.textContent.trim() || '';
      const arrDateText = dateCols[1]?.textContent.trim() || depDateText;

      const timeDisplays = kyQA(durationEntry, '-time-display').filter((c) => kyHas(c, '-time-display'));
      const depTimeText = timeDisplays[0]?.textContent.trim() || '';
      const arrTimeText = timeDisplays[1]?.textContent.trim() || '';

      const durCol = kyQA(durationEntry, '-duration-column').find((c) => kyHas(c, '-duration-column'));
      const durationText = durCol?.textContent.trim() || '0h 0m';
      const durMin = parseDurationMinutes(durationText);

      const cabinWord = (kyQ(seg, '-cabin-display')?.textContent || '').trim().toLowerCase();
      const cabinCode = CABIN_WORD_TO_CODE[cabinWord] || cabinFallback;

      const aircraft = (seg.querySelector('[aria-label="Aircraft"]')?.textContent || '').trim();

      const depDate = kyParseFullDate(depDateText, depTimeText);
      const arrDate = kyParseFullDate(arrDateText, arrTimeText);
      if (!depDate || !arrDate || !originCode || !destCode) return;

      legs.push({
        airline: { code: carrier },
        flightNumber,
        cabin: cabinCode,
        aircraft,
        origin: { iata: originCode },
        destination: { iata: destCode },
        departure: depDate,
        arrival: arrDate,
        duration: durMin,
      });
    });

    return legs;
  }

  // Legacy fallback: the leg-checkbox summary. No real flight numbers are
  // ever exposed here, so this only runs when the details panel can't be
  // found at all.
  function kyParseLeg(liEl, cabinCode) {
    const img = liEl.querySelector('.c5iUd-leg-carrier img');
    const carrierMatch = img?.src.match(/\/([A-Z]{2})\.png/i);
    let carrier = carrierMatch ? carrierMatch[1].toUpperCase() : '';
    if (!carrier) {
      const name = (img?.alt || '').trim().toLowerCase();
      carrier = AIRLINE_MAP[name] || '';
    }

    const dateShort = liEl.querySelector('.c9L-i .vmXl')?.textContent.trim() || '';
    const dm = dateShort.match(/(\d{1,2})\/(\d{1,2})/);
    if (!dm) return null;
    const month = parseInt(dm[1], 10) - 1;
    const day = parseInt(dm[2], 10);
    const year = kyResolveYear(month);

    const timesEl = liEl.querySelector('.VY2U .vmXl-mod-variant-large');
    const timesText = timesEl?.textContent || '';
    const timeMatches = [...timesText.matchAll(/(\d{1,2}):(\d{2})\s*(am|pm)/gi)];
    if (timeMatches.length < 2) return null;
    const depM = timeMatches[0];
    let depH = parseInt(depM[1], 10);
    const depMin = parseInt(depM[2], 10);
    if (/pm/i.test(depM[3]) && depH < 12) depH += 12;
    if (/am/i.test(depM[3]) && depH === 12) depH = 0;

    const durationStr = liEl.querySelector('.xdW8 .vmXl')?.textContent.trim() || '0h 0m';
    const durMin = parseDurationMinutes(durationStr);

    const codes = liEl.querySelectorAll('.EFvI .a6Um-mod-ellipsis span');
    const originCode = codes[0]?.textContent.trim() || '';
    const destCode = codes[1]?.textContent.trim() || '';
    if (!originCode || !destCode) return null;

    const depDate = new Date(year, month, day, depH, depMin, 0, 0);
    const arrDate = new Date(depDate.getTime() + durMin * 60000);

    return {
      airline: { code: carrier },
      flightNumber: '????',
      cabin: cabinCode,
      aircraft: '',
      origin: { iata: originCode },
      destination: { iata: destCode },
      departure: depDate,
      arrival: arrDate,
      duration: durMin,
    };
  }

  function kyBuildItinerary(card) {
    const cabinCode = kyParseCabin();
    const legItems = card.querySelectorAll('.hJSA-item');
    const legs = [];
    legItems.forEach((li) => {
      const leg = kyParseLeg(li, cabinCode);
      if (leg) legs.push(leg);
    });
    if (!legs.length) return null;
    return { flights: legs.map((leg) => ({ legs: [leg] })), pax: kySearchPax() };
  }

  function kySearchPax() {
    const p = location.pathname;
    const a = p.match(/\/(\d+)adults/);
    const c = p.match(/\/children((?:-[0-9A-Za-z]+)+)/);
    const kids = c ? c[1].split('-').filter((t) => t && !/L$/i.test(t)).length : 0; // lap infants (1L) take no seat
    return Math.max(1, (a ? parseInt(a[1], 10) : 1) + kids);
  }

  async function handleKayakCopy(card, btn) {
    let panel = kyFindDetailsPanel(card);
    let legs = panel ? kyParseDetailsSegments(panel) : [];

    if (!legs.length) {
      // The details panel may only render once the card is expanded.
      const expandTarget = card.querySelector('.hJSA') || card.querySelector('.nrc6-main') || card;
      expandTarget.click();
      await wait(500);
      panel = kyFindDetailsPanel(card);
      legs = panel ? kyParseDetailsSegments(panel) : [];
    }

    const itinerary = legs.length ? { flights: [{ legs }], pax: kySearchPax() } : kyBuildItinerary(card);

    if (itinerary) {
      flashButton(btn, buildBoth(itinerary));
    } else {
      flashError(btn, '\u274c No data');
    }
  }

  function injectKayakButtons() {
    const cards = document.querySelectorAll('.nrc6:not([data-gds-injected])');
    cards.forEach((card) => {
      const priceSection = card.querySelector('.nrc6-price-section');
      if (!priceSection) return;
      card.setAttribute('data-gds-injected', '1');

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gds-btn-base gds-btn-kayak';
      btn.textContent = 'GDS';
      btn.title = 'Copy Sabre IA / VI* format for this result';
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        handleKayakCopy(card, btn);
      });

      // Anchor the button right next to this card's own booking/select
      // control so it reads as "this option's" GDS copy.
      const bookingBtn = priceSection.querySelector('.M_JD-booking-btn') || priceSection.querySelector('.oVHK');
      if (bookingBtn) {
        bookingBtn.insertAdjacentElement('beforebegin', btn);
      } else {
        priceSection.insertBefore(btn, priceSection.firstChild);
      }
    });
  }

  // ------------------------------------------------------------------
  // CHEAPOAIR ADAPTER
  //
  // `.trip-selection-popup__times` (dep/arr time-cols) is a SIBLING of
  // the route/flight-number container, not a child of it — segments are
  // found by walking each `...__times` block and pairing it with its
  // preceding sibling. That sibling's own class name isn't stable (some
  // pages have it as `.flight-segment-container`, others as a bare
  // `.fp-position-relative` with no segment-specific class at all), so
  // it's identified by containing `.trip-selection-popup__route` instead
  // of by class name.
  // ------------------------------------------------------------------
  function coParseDateTime(dateText, timeText) {
    const dm = (dateText || '').match(/([A-Za-z]{3})\s+(\d{1,2})/);
    const tm = (timeText || '').match(/(\d{1,2}):(\d{2})\s*(AM|PM)/i);
    if (!dm || !tm) return new Date();
    const month = MONTH_MAP[dm[1].toLowerCase()] ?? 0;
    const day = parseInt(dm[2], 10);
    let h = parseInt(tm[1], 10);
    const m = parseInt(tm[2], 10);
    const isPM = tm[3].toUpperCase() === 'PM';
    if (isPM && h < 12) h += 12;
    if (!isPM && h === 12) h = 0;
    const year = coResolveYear(month);
    return new Date(year, month, day, h, m, 0, 0);
  }

  function coResolveYear(month) {
    const params = new URLSearchParams(location.search);
    const parse = (s) => {
      if (!s) return null;
      const parts = s.split('/').map(Number);
      if (parts.length !== 3) return null;
      return { month: parts[0] - 1, year: parts[2] };
    };
    const f = parse(params.get('fromDt') || params.get('dt1'));
    const t = parse(params.get('toDt') || params.get('dt2'));
    if (f && f.month === month) return f.year;
    if (t && t.month === month) return t.year;
    return f ? f.year : new Date().getFullYear();
  }

  function coParsePax() {
    const params = new URLSearchParams(location.search);
    const ad = parseInt(params.get('ad') || '1', 10) || 1;
    const ch = parseInt(params.get('ch') || '0', 10) || 0;
    return ad + ch;
  }

  // CheapOair renders this same detail popup with at least two different
  // class-prefix conventions for the time-column/time/time-divider
  // pieces specifically ("trip-selection-popup__" vs "trip-details__")
  // — which one shows up isn't tied to airline, route, or anything else
  // identifiable ahead of time (a mixed-cabin itinerary rendered with
  // "trip-details__" here, but an earlier fix needed
  // "trip-selection-popup__" for what looked like the same kind of
  // card). Hardcoding either one is chasing a moving target, so these
  // try both and use whichever one actually finds something.
  function qsaAnyClass(root, classNames) {
    for (const cls of classNames) {
      const found = root.querySelectorAll(cls);
      if (found.length) return found;
    }
    return root.querySelectorAll(classNames[0]);
  }
  function qsAnyClass(root, classNames) {
    for (const cls of classNames) {
      const found = root.querySelector(cls);
      if (found) return found;
    }
    return null;
  }

  function coParseSegments(card) {
    const legs = [];
    const timesBlocks = card.querySelectorAll('.trip-selection-popup__times');

    timesBlocks.forEach((timesEl) => {
      const sibling = timesEl.previousElementSibling;
      if (!sibling) return;
      // The route/flight-number container is sometimes the previous
      // sibling ITSELF (not a wrapper containing it) — querySelector never
      // matches the element it's called on, only descendants, so that
      // case needs an explicit .matches() check or every segment gets
      // silently skipped (this was the actual "no data" bug).
      const c = sibling.matches && sibling.matches('.trip-selection-popup__route')
        ? sibling
        : sibling.querySelector('.trip-selection-popup__route');
      if (!c) return;

      let cabinWord = 'economy';
      c.querySelectorAll('.trip-selection-popup__equipment-info').forEach((sp) => {
        const t = sp.textContent;
        const m = t.match(/cabin:\s*([a-z\s]+)/i);
        if (m) cabinWord = m[1].trim().toLowerCase();
      });
      let cabinCode = 'y';
      if (cabinWord.includes('business')) cabinCode = 'j';
      else if (cabinWord.includes('first')) cabinCode = 'f';
      else if (cabinWord.includes('premium')) cabinCode = 'w';

      const flightSpan = c.querySelector('.airlinecode.fp-no-wrap, span.fp-no-wrap');
      const flightText = flightSpan?.textContent.trim() || '';
      // Carrier codes aren't always two LETTERS — JetBlue is "B6", and
      // other carriers mix digits into their 2-character code the same
      // way. Requiring [A-Z]{2} silently dropped any of those (this is
      // why JetBlue's leg specifically went missing — nothing airline-
      // specific about it otherwise, the regex just never matched "B6").
      const flightMatch = flightText.match(/^([A-Z0-9]{2})\s*(\d+)$/i);
      const carrier = flightMatch ? flightMatch[1].toUpperCase() : '';
      const flightNumber = flightMatch ? flightMatch[2] : '';

      const equipCodeSpan = c.querySelector('.tippy-action.is--underline');
      const equipmentCode = equipCodeSpan?.textContent.trim() || '';
      const aircraftHint = (c.querySelector('.sr-only')?.getAttribute('aria-label') || '').trim();

      const timeCols = qsaAnyClass(timesEl, ['.trip-selection-popup__time-col', '.trip-details__time-col']);
      if (timeCols.length < 2 || !flightNumber) return;

      const depTimeEl = qsAnyClass(timeCols[0], ['.trip-selection-popup__time', '.trip-details__time']);
      const depTimeText = depTimeEl ? depTimeEl.childNodes[0]?.textContent.trim() : '';
      const depDateText = timeCols[0].querySelector('.fp-font-sm.fp-font-normal')?.textContent.trim() || '';
      const depAirportSpans = timeCols[0].querySelectorAll('.trip-details__airport-code span');
      const depAirportText = depAirportSpans[depAirportSpans.length - 1]?.textContent.trim() || '';
      const depCode = (depAirportText.match(/\(([A-Z]{3})\)/) || [])[1] || '';

      const arrTimeEl = qsAnyClass(timeCols[1], ['.trip-selection-popup__time', '.trip-details__time']);
      const arrTimeText = arrTimeEl ? arrTimeEl.childNodes[0]?.textContent.trim() : '';
      const arrDateText = timeCols[1].querySelector('.fp-font-sm.fp-font-normal')?.textContent.trim() || '';
      const arrAirportSpans = timeCols[1].querySelectorAll('.trip-details__airport-code span');
      const arrAirportText = arrAirportSpans[arrAirportSpans.length - 1]?.textContent.trim() || '';
      const arrCode = (arrAirportText.match(/\(([A-Z]{3})\)/) || [])[1] || '';

      const dividerEl = qsAnyClass(timesEl, ['.trip-selection-popup__time-divider', '.trip-details__time-divider']);
      const travelTimeEl = dividerEl ? qsAnyClass(dividerEl, ['.trip-selection-popup__time', '.trip-details__time']) : null;
      const travelTimeText = travelTimeEl?.textContent.trim() || '0h 0m';
      const durMin = parseDurationMinutes(travelTimeText);

      const depDate = coParseDateTime(depDateText, depTimeText);
      // Arrival comes from the page's own stated arrival date+time, not
      // from adding the travel-time duration to departure. That
      // addition is wrong for any international leg: depDate is built
      // as a plain JS Date, which JavaScript anchors to whatever
      // timezone the browser itself is running in — not the airport's
      // real one. Reading a wall-clock time back off "departure instant
      // + duration" only comes out right if the browser's own timezone
      // happens to match the destination's, which for a route like
      // LHR→IAD it very much won't. The page already states the real
      // arrival date and time directly (the same way Kayak's adapter in
      // this file already does it) — using that sidesteps needing any
      // timezone math at all, correct or not.
      const arrDate = coParseDateTime(arrDateText, arrTimeText);

      if (!depCode || !arrCode) return;

      legs.push({
        airline: { code: carrier },
        flightNumber,
        cabin: cabinCode,
        equipmentCode,
        aircraft: aircraftHint,
        origin: { iata: depCode },
        destination: { iata: arrCode },
        departure: depDate,
        arrival: arrDate,
        duration: durMin,
      });
    });

    return legs;
  }

  async function handleCheapOairCopy(card, btn) {
    let legs = coParseSegments(card);

    if (!legs.length) {
      // The explicit trigger for the full flight-details view — clicking
      // it can render the popup either nested inside the card or as a
      // page-level tab/modal outside it, so both scopes are checked
      // after clicking rather than assuming one or the other.
      const detailTriggers = card.querySelectorAll('.is--flight-action');
      if (detailTriggers.length) {
        detailTriggers.forEach((el) => el.click());
        await wait(600);
        legs = coParseSegments(card);
        if (!legs.length) legs = coParseSegments(document);
      }
    }

    if (!legs.length) {
      // Older page-state fallback, in case a different build uses this
      // trigger instead.
      const oldDetailButtons = card.querySelectorAll('.itinerary-card__down-btn');
      if (oldDetailButtons.length) {
        oldDetailButtons.forEach((b) => b.click());
        await wait(500);
        legs = coParseSegments(card);
        if (!legs.length) legs = coParseSegments(document);
      }
    }

    if (legs.length) {
      flashButton(btn, buildBoth({ flights: [{ legs }], pax: coParsePax() }), true);
    } else {
      flashError(btn, '\u274c No data');
    }
  }

  function injectCheapOairButtons() {
    const cards = document.querySelectorAll('.itinerary-card:not([data-gds-injected])');
    cards.forEach((card) => {
      card.setAttribute('data-gds-injected', '1');
      const priceEl = card.querySelector('.itinerary-card__price');
      if (!priceEl) return;

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gds-btn-base gds-btn-cheapoair';
      btn.textContent = 'GDS';
      btn.title = 'Copy Sabre IA / VI* format for this itinerary';
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        handleCheapOairCopy(card, btn);
      });
      priceEl.appendChild(btn);
    });
  }

  // ------------------------------------------------------------------
  // GOOGLE FLIGHTS ADAPTER
  //
  // Unlike every other site here, Google Flights embeds a clean,
  // authoritative data string right in the DOM — a
  // `data-travelimpactmodelwebsiteurl` attribute whose `itinerary=`
  // query param is a comma-separated list of
  // "ORIGIN-DEST-CARRIER-FLIGHTNUM-YYYYMMDD" per segment. That gives
  // exact carrier/flight-number/route/departure-date for free, with a
  // real year — no inference needed. Only the clock times, cabin,
  // aircraft, and duration still have to be read from the visible
  // per-segment breakdown (`[jsname="lVbzR"]` blocks), and even the
  // duration comes from the page's own explicit "Travel time: Xhr Ymin"
  // text rather than being computed — computing it from the local
  // dep/arr clock times would be wrong across time zones (that's the
  // whole reason ITA needed the explicit-text fix earlier: this
  // itinerary's first leg's "Travel time" is 7h45m, but naively
  // subtracting local clock times gives 13h45m).
  // ------------------------------------------------------------------
  function gfParseClockTimeAmPm(t) {
    const m = (t || '').match(/(\d{1,2}):(\d{2})\s*([AP]M)/i);
    if (!m) return { h: 0, m: 0 };
    let h = parseInt(m[1], 10);
    const mi = parseInt(m[2], 10);
    const ap = m[3].toUpperCase();
    if (ap === 'PM' && h < 12) h += 12;
    if (ap === 'AM' && h === 12) h = 0;
    return { h, m: mi };
  }

  function gfFindSliceCards() {
    const seenIds = new Set();
    const cards = [];
    document.querySelectorAll('[data-slice-id]').forEach((el) => {
      const sliceId = el.getAttribute('data-slice-id');
      if (!sliceId || seenIds.has(sliceId)) return;
      seenIds.add(sliceId);
      cards.push(el.closest('[role="listitem"]') || el);
    });
    return cards;
  }

  function gfParseSlice(sliceContainer) {
    const dataEl = sliceContainer.querySelector('[data-travelimpactmodelwebsiteurl]');
    const url = dataEl ? dataEl.getAttribute('data-travelimpactmodelwebsiteurl') : '';
    const itinMatch = url.match(/itinerary=([^&]+)/);
    const itinStr = itinMatch ? decodeURIComponent(itinMatch[1]) : '';
    const segMeta = itinStr.split(',').filter(Boolean).map((s) => {
      const parts = s.split('-');
      if (parts.length < 5) return null;
      const [origin, dest, carrier, flightNum, ymd] = parts;
      return { origin, dest, carrier, flightNum, ymd };
    }).filter(Boolean);

    const segBlocks = sliceContainer.querySelectorAll('[jsname="lVbzR"]');
    const legs = [];

    segBlocks.forEach((block, idx) => {
      const meta = segMeta[idx];
      if (!meta) return;

      const depLabelEl = block.querySelector('.dPzsIb [aria-label^="Departure time"]');
      const depLabel = depLabelEl ? depLabelEl.getAttribute('aria-label') : '';
      const depTimeMatch = depLabel.match(/Departure time:\s*([\d:]+\s*[AP]M)/i);

      const arrContainer = block.querySelector('.SWFQlc');
      const arrLabelEl = arrContainer ? arrContainer.querySelector('[aria-label^="Arrival time"]') : null;
      const arrLabel = arrLabelEl ? arrLabelEl.getAttribute('aria-label') : '';
      const arrTimeMatch = arrLabel.match(/Arrival time:\s*([\d:]+\s*[AP]M)/i);
      const arrDateMatch = arrLabel.match(/on\s+\w+,\s+(\w+)\s+(\d{1,2})/i);

      const durText = (block.querySelector('.CQYfx, .P102Lb') || {}).textContent || '';
      const durMatch = durText.match(/Travel time:\s*(\d+)\s*hr(?:\s*(\d+)\s*min)?/i);
      const durMin = durMatch ? (parseInt(durMatch[1], 10) * 60 + (durMatch[2] ? parseInt(durMatch[2], 10) : 0)) : 0;

      const infoContainer = block.querySelector('.MX5RWe');
      const cabinSpan = infoContainer ? infoContainer.querySelector('[jsname="Pvlywd"]') : null;
      const cabinText = (cabinSpan ? cabinSpan.textContent : '').trim().toLowerCase();
      let cabinCode = 'y';
      if (cabinText.includes('business')) cabinCode = 'j';
      else if (cabinText.includes('first')) cabinCode = 'f';
      else if (cabinText.includes('premium')) cabinCode = 'w';

      const bareSpans = infoContainer ? Array.from(infoContainer.querySelectorAll('.Xsgmwe'))
        .filter((el) => el.classList.length === 1 && !el.hasAttribute('jsname')) : [];
      const aircraftText = bareSpans.length ? bareSpans[bareSpans.length - 1].textContent.trim() : '';

      const year = parseInt(meta.ymd.slice(0, 4), 10);
      const month = parseInt(meta.ymd.slice(4, 6), 10) - 1;
      const day = parseInt(meta.ymd.slice(6, 8), 10);

      const depClock = gfParseClockTimeAmPm(depTimeMatch ? depTimeMatch[1] : '');
      const departure = new Date(year, month, day, depClock.h, depClock.m, 0, 0);

      const arrClock = gfParseClockTimeAmPm(arrTimeMatch ? arrTimeMatch[1] : '');
      let arrDay = day, arrMonth = month, arrYear = year;
      if (arrDateMatch) {
        const mAbbr = arrDateMatch[1].slice(0, 3).toLowerCase();
        const mIdx = MONTH_MAP[mAbbr];
        if (mIdx !== undefined) {
          arrMonth = mIdx;
          arrDay = parseInt(arrDateMatch[2], 10);
          arrYear = (arrMonth < month) ? year + 1 : year;
        }
      }
      const arrival = new Date(arrYear, arrMonth, arrDay, arrClock.h, arrClock.m, 0, 0);

      legs.push({
        airline: { code: meta.carrier },
        flightNumber: meta.flightNum,
        cabin: cabinCode,
        aircraft: aircraftText,
        origin: { iata: meta.origin },
        destination: { iata: meta.dest },
        departure,
        arrival,
        duration: durMin,
      });
    });

    return legs;
  }

  function gfParsePax() {
    const el = document.querySelector('[jsname="xAX4ff"]');
    const m = (el ? el.textContent : '').match(/(\d+)\s*passenger/i);
    return m ? parseInt(m[1], 10) : 1;
  }

  function handleGoogleFlightsCopy(btn) {
    const cards = gfFindSliceCards();
    const legs = [];
    cards.forEach((card) => legs.push(...gfParseSlice(card)));
    if (legs.length) {
      flashButton(btn, buildBoth({ flights: [{ legs }], pax: gfParsePax() }));
    } else {
      flashError(btn, '\u274c No data');
    }
  }

  function injectGoogleFlightsButton() {
    const priceBox = document.querySelector('.Y4xNqf');
    if (!priceBox) return;
    // Check the button's actual live presence rather than a flag stored
    // on the container — Google's own rendering re-renders this
    // container's contents once the real price arrives (replacing
    // whatever's inside it, including anything injected), but the
    // container ELEMENT itself survives that re-render. A dataset flag
    // set on that surviving element would stay set even after its
    // children — including this button — got wiped out from under it,
    // which is exactly why the button was disappearing once the page
    // "landed": the flag said "already done" when it very much wasn't.
    if (priceBox.querySelector('.gds-btn-googleflights')) return;
    priceBox.style.display = 'flex';
    priceBox.style.alignItems = 'center';
    priceBox.style.gap = '12px';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'gds-btn-base gds-btn-googleflights';
    btn.textContent = 'GDS';
    btn.title = 'Copy Sabre IA / VI* format for this itinerary';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handleGoogleFlightsCopy(btn);
    });
    priceBox.insertBefore(btn, priceBox.firstChild);
  }


  // ==================================================================
  // Pip "Send to lead" — the GDS button becomes Pip's face. Clicking it
  // opens a mini Pip screen with:
  //   • GDS      — the usual *IA/VI* copy
  //   • LEAD ID  — paste a lead number and the option (segments + price,
  //                or miles & taxes for award) is added to that lead in
  //                the BO automatically, in a background BO tab.
  // ==================================================================
  const SEND_JOB_KEY = 'js-sendjob';
  const RATES_TO_USD = { USD: 1, EUR: 1.1256, GBP: 1.3236, CAD: 0.7016 };
  const INFANT_CASH_NET = 400;
  const INFANT_AWARD_MILES = 10000;
  const RUSH_PROGRAMS = { TK: 'Turkish Miles&Smiles', AA: 'American AAdvantage', B6: 'JetBlue TrueBlue', VS: 'Virgin Atlantic Flying Club', SQ: 'Singapore KrisFlyer' };
  // Mile programs the BO accepts (its own list).
  const BO_PROGRAMS = ['AA','AC','AD','AF','AS','AV','B6','BA','CM','CX','DL','EK','EY','IB','JL','LH','QF','QR','SK','SQ','TK','TP','UA','VS'];
  const PROGRAM_NAMES = {
    AA: 'American AAdvantage', AC: 'Air Canada Aeroplan', AD: 'Azul Fidelidade', AF: 'Air France-KLM Flying Blue',
    AS: 'Alaska Mileage Plan', AV: 'Avianca LifeMiles', B6: 'JetBlue TrueBlue', BA: 'British Airways Avios',
    CM: 'Copa ConnectMiles', CX: 'Cathay Asia Miles', DL: 'Delta SkyMiles', EK: 'Emirates Skywards',
    EY: 'Etihad Guest', IB: 'Iberia Avios', JL: 'JAL Mileage Bank', LH: 'Lufthansa Miles & More',
    QF: 'Qantas Frequent Flyer', QR: 'Qatar Privilege Club', SK: 'SAS EuroBonus', SQ: 'Singapore KrisFlyer',
    TK: 'Turkish Miles&Smiles', TP: 'TAP Miles&Go', UA: 'United MileagePlus', VS: 'Virgin Atlantic Flying Club',
  };
  // Program names / logo names as the award sites write them -> BO code.
  const PROGRAM_ALIASES = [
    [/mileageplus|\bunited\b/i, 'UA'], [/aadvantage|american/i, 'AA'], [/aeroplan|air canada/i, 'AC'],
    [/flying ?blue|air ?france|\bklm\b/i, 'AF'], [/alaska|mileage ?plan|atmos|atoms|hawaiian/i, 'AS'], [/lifemiles|avianca/i, 'AV'],
    [/trueblue|jetblue/i, 'B6'], [/british|executive ?club/i, 'BA'], [/connectmiles|\bcopa\b/i, 'CM'],
    [/asia ?miles|cathay/i, 'CX'], [/skymiles|delta/i, 'DL'], [/skywards|emirates/i, 'EK'], [/etihad/i, 'EY'],
    [/iberia/i, 'IB'], [/\bjal\b|japan airlines/i, 'JL'], [/miles ?(&|and) ?more|lufthansa/i, 'LH'], [/qantas/i, 'QF'],
    [/qatar|privilege ?club/i, 'QR'], [/eurobonus|\bsas\b/i, 'SK'], [/krisflyer|singapore/i, 'SQ'],
    [/miles ?(&|and) ?smiles|turkish/i, 'TK'], [/\btap\b|miles ?(&|and) ?go/i, 'TP'], [/virgin/i, 'VS'], [/azul|tudoazul/i, 'AD'],
  ];

  // Award options must use a program from the BO's "Mile program" list.
  function programSupported(c) {
    if (!c || c.kind !== 'award') return true;
    if (c.parts) return c.parts.every((p) => programSupported(Object.assign({ kind: 'award' }, p)));
    const code = programCode(c.program);
    return !!code && BO_PROGRAMS.includes(code);
  }

  function programCode(raw) {
    if (!raw) return null;
    const t = String(raw).trim();
    // KLM (KL) and Air France (AF) share Flying Blue: KL is booked as AF.
    if (/^KL$/i.test(t) || /^KL[_\-\s.]/i.test(t)) return 'AF';
    if (/^[A-Z0-9]{2}$/i.test(t)) return t.toUpperCase();
    // Site slugs like "AS_ATOMS_REWARDS" / "ua-mileageplus": the leading
    // airline code says it all when the BO knows it.
    const pre = t.match(/^([A-Z0-9]{2})[_\-\s.]/i);
    if (pre && BO_PROGRAMS.includes(pre[1].toUpperCase())) return pre[1].toUpperCase();
    const words = t.replace(/[_\-.]+/g, ' ');
    for (const [re, code] of PROGRAM_ALIASES) if (re.test(words)) return code;
    return null;
  }

  // "$1,224.79" / "USD 1,224.79" / "€4.97" / "+ est* €4.97" / "2162 US dollars"
  function parseMoney(text) {
    if (!text) return null;
    const t = String(text).replace(/\s+/g, ' ').trim();
    let currency = 'USD';
    if (/€|EUR|euro/i.test(t)) currency = 'EUR';
    else if (/£|GBP|pound/i.test(t)) currency = 'GBP';
    else if (/C\$|CA\$|CAD|canadian/i.test(t)) currency = 'CAD';
    else if (/\$|USD|US dollar/i.test(t)) currency = 'USD';
    else if (/[A-Z]{3}/.test(t) && !/USD/.test(t)) currency = (t.match(/\b([A-Z]{3})\b/) || [])[1] || 'USD';
    const m = t.replace(/,/g, '').match(/(\d+(?:\.\d+)?)/);
    if (!m) return null;
    return { amount: parseFloat(m[1]), currency };
  }

  function toUsd(money) {
    if (!money) return null;
    const rate = RATES_TO_USD[money.currency];
    if (!rate) return { error: 'Unknown currency ' + money.currency };
    return { usd: Math.round(money.amount * rate * 100) / 100 };
  }

  function parsePoints(text) {
    const m = String(text || '').replace(/,/g, '').match(/(\d+(?:\.\d+)?)\s*(k)?/i);
    if (!m) return null;
    return Math.round(parseFloat(m[1]) * (m[2] ? 1000 : 1));
  }

  // FlyBasis's advanced detail page: a "Program | Cost | Points | Taxes |
  // Link" table instead of the result card's data. Cheapest supported
  // program first, the rest selectable in the dropdown.
  function fbDetailPrices() {
    const out = [];
    document.querySelectorAll('.divide-y > div').forEach((row) => {
      const cells = Array.from(row.children);
      if (cells.length < 4) return;
      const program = cells[0].textContent.trim();
      if (!/^[A-Z0-9]{2}$/.test(program)) return;
      const cost = parseMoney(cells[1].textContent);
      const points = parsePoints(cells[2].textContent);
      const taxes = parseMoney(cells[3].textContent);
      if (!points) return;
      out.push({ kind: 'award', points, taxes: taxes || { amount: 0, currency: 'USD' }, program, _cost: cost ? cost.amount : Infinity });
    });
    const ok = (o) => (BO_PROGRAMS.includes(programCode(o.program)) ? 0 : 1);
    out.sort((a, b) => ok(a) - ok(b) || a._cost - b._cost);
    out.forEach((o) => delete o._cost);
    return out;
  }

  // --- Price readers, one per site. Each returns a list of choices:
  // { kind:'cash', money } or { kind:'award', points, taxes(money), program }
  function readPrice(origBtn) {
    const host = location.hostname;
    try {
      if (host.includes('matrix.itasoftware.com')) {
        const row = origBtn.closest('tr');
        const label = row && Array.from(row.querySelectorAll('.mdc-button__label')).find((l) => /\$|€|£|\d/.test(l.textContent) && !l.closest('.gds-btn-base'));
        return label ? [{ kind: 'cash', money: parseMoney(label.textContent) }] : [];
      }
      if (host.includes('kayak.com')) {
        const card = origBtn.closest('.nrc6');
        const el = card && card.querySelector('.e2GB-price-text');
        return el ? [{ kind: 'cash', money: parseMoney(el.textContent) }] : [];
      }
      if (host.includes('cheapoair.com')) {
        const card = origBtn.closest('.itinerary-card');
        const amt = (card && card.querySelector('.fpamount')) || document.querySelector('#GrandTotal .fpamount');
        if (!amt) return [];
        const curEl = amt.parentElement && amt.parentElement.querySelector('.fpcurrencytext');
        return [{ kind: 'cash', money: parseMoney((curEl ? curEl.textContent : '') + ' ' + amt.textContent.replace(/\s+/g, '')) }];
      }
      if (host.includes('google.com')) {
        const box = document.querySelector('.Y4xNqf') || document;
        const el = Array.from(box.querySelectorAll('[aria-label]')).find((e) => /^\s*[\d,.]+\s+[A-Za-z ]+$/.test(e.getAttribute('aria-label')) && /dollar|euro|pound/i.test(e.getAttribute('aria-label')));
        return el ? [{ kind: 'cash', money: parseMoney(el.getAttribute('aria-label')) }] : [];
      }
      if (host.includes('flybasis.com') || host.includes('agentsearch.vercel.app')) {
        const card = origBtn.closest('[data-json]');
        if (!card) return fbDetailPrices();
        const it = JSON.parse(card.dataset.json);
        const f = (it.flights || [])[0] || {};
        // Every program offered for this flight (primary + duplicates);
        // take the cheapest by FlyBasis's own "Cost".
        const costOf = (o) => (typeof o.price === 'number' ? o.price : Infinity);
        // Cheapest among the programs the BO supports; others only if none is.
        const ok = (o) => { const c = programCode(o.program); return c && BO_PROGRAMS.includes(c) ? 0 : 1; };
        const allOffers = (node) => {
          const offers = [];
          const collect = (n, d) => {
            if (!n || typeof n !== 'object' || d > 6) return;
            if (Array.isArray(n)) { n.forEach((x) => collect(x, d + 1)); return; }
            if (n.points && n.program) offers.push(n);
            Object.keys(n).forEach((k) => { if (n[k] && typeof n[k] === 'object') collect(n[k], d + 1); });
          };
          collect(node, 0);
          offers.sort((a, b) => ok(a) - ok(b) || costOf(a) - costOf(b));
          return offers;
        };
        const cheapest = (node) => allOffers(node)[0] || null;
        // Round trip: one award entry per direction (outbound, inbound),
        // each priced on its own.
        const awards = Array.isArray(it.awards) ? it.awards : [];
        if ((it.flights || []).length >= 2 && awards.length === it.flights.length) {
          const parts = awards.map(cheapest);
          if (parts.every(Boolean)) {
            const P = parts.map((a) => ({ points: a.points, taxes: { amount: a.surcharge || 0, currency: 'USD' }, program: a.program }));
            const same = P.every((x) => programCode(x.program) === programCode(P[0].program));
            if (same) {
              // Same program both ways: one ticket, totals added up.
              return [{ kind: 'award', points: P.reduce((t, x) => t + x.points, 0), taxes: { amount: Math.round(P.reduce((t, x) => t + x.taxes.amount, 0) * 100) / 100, currency: 'USD' }, program: P[0].program }];
            }
            // Different programs: two tickets (outbound = 1, inbound = 2).
            return [{ kind: 'award', points: P[0].points, taxes: P[0].taxes, program: P[0].program, parts: P.slice(0, 2) }];
          }
        }
        const sorted = allOffers(awards);
        const award = sorted[0] || null;
        // Both AA and AS on offer: give a dropdown (cheapest first, then
        // the AA and AS choices) so either one can be picked.
        const pickOf = (code) => sorted.find((o) => programCode(o.program) === code);
        if (pickOf('AA') && pickOf('AS')) {
          const list = [award, pickOf('AA'), pickOf('AS')].filter((o, i, a) => o && a.indexOf(o) === i);
          return list.map((a) => ({ kind: 'award', points: a.points, taxes: { amount: a.surcharge || 0, currency: 'USD' }, program: a.program }));
        }
        if (it.ticket === 'awd' || award || f.points) {
          const a = award || f;
          return [{ kind: 'award', points: a.points, taxes: { amount: a.surcharge || 0, currency: 'USD' }, program: a.program }];
        }
        return [{ kind: 'cash', money: { amount: it.total || f.price, currency: 'USD' } }];
      }
      if (host.includes('pointsyeah.com')) {
        const scopes = [];
        const bell = origBtn.parentElement && origBtn.parentElement.querySelector('button');
        if (bell && typeof pyFindDetailBlock === 'function') { const d = pyFindDetailBlock(bell); if (d) scopes.push(d); }
        let up = origBtn.parentElement;
        for (let i = 0; i < 8 && up; i++, up = up.parentElement) if (up.querySelector('img[src*="/programs/"]')) { scopes.push(up); break; }
        const seen = new Set();
        const out = [];
        scopes.forEach((scope) => scope.querySelectorAll('img[src*="/programs/"]').forEach((img) => {
          let row = img;
          for (let i = 0; i < 8 && row && !/pts/.test(row.textContent); i++) row = row.parentElement;
          if (!row || seen.has(row)) return;
          seen.add(row);
          const slug = (img.getAttribute('src').match(/programs\/([^./]+)\./) || [])[1] || '';
          const txt = row.textContent.replace(/\s+/g, ' ');
          const pts = parsePoints((txt.match(/([\d,.]+k?)\s*pts/i) || [])[1]);
          const taxM = txt.match(/([$€£]|C\$|CA\$)\s?([\d,.]+)\s*tax/i);
          if (!pts) return;
          out.push({ kind: 'award', points: pts, taxes: taxM ? parseMoney(taxM[1] + taxM[2]) : { amount: 0, currency: 'USD' }, program: slug });
        }));
        return out;
      }
      if (host.includes('awardlogic.com')) {
        const card = origBtn.closest('.results-trip-list-item') || origBtn.closest('.results-trip-list-item__info');
        if (!card) return [];
        const pts = parsePoints((card.querySelector('.results-trip-list-item__price-title') || {}).textContent);
        const tax = parseMoney((card.querySelector('.results-trip-list-item__price-taxes') || {}).textContent);
        const progEl = card.querySelector('.results-trip-list-item__flight-program h3');
        if (!pts) return [];
        return [{ kind: 'award', points: pts, taxes: tax || { amount: 0, currency: 'USD' }, program: progEl ? progEl.textContent.trim() : '' }];
      }
    } catch (e) { /* fall through */ }
    return [];
  }

  function describeChoice(c) {
    if (!c) return '';
    if (c.kind === 'cash') return c.money ? ('$' + (toUsd(c.money).usd || c.money.amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' / person') : '';
    if (c.parts) return c.parts.map((p) => describeChoice(Object.assign({ kind: 'award' }, p)).replace(' / person', '')).join('  ↩  ') + ' / person';
    const code = programCode(c.program) || String(c.program || '?').toUpperCase();
    const tx = toUsd(c.taxes) || {};
    return code + ' · ' + Number(c.points).toLocaleString('en-US') + ' pts + $' + (tx.usd != null ? tx.usd.toFixed(2) : '?') + ' / person';
  }

  // --- Route helpers for the "is this the right lead?" check -----------
  const CITY_AIRPORTS = {
    NYC: ['JFK','EWR','LGA'], WAS: ['IAD','DCA','BWI'], LON: ['LHR','LGW','STN','LTN','LCY','SEN'], PAR: ['CDG','ORY','BVA'],
    CHI: ['ORD','MDW'], TYO: ['HND','NRT'], MIL: ['MXP','LIN','BGY'], ROM: ['FCO','CIA'], MOW: ['SVO','DME','VKO'],
    SAO: ['GRU','CGH','VCP'], RIO: ['GIG','SDU'], BUE: ['EZE','AEP'], STO: ['ARN','BMA','NYO'], OSA: ['KIX','ITM','UKB'],
    SEL: ['ICN','GMP'], SHA: ['PVG','SHA'], BJS: ['PEK','PKX'], YTO: ['YYZ','YTZ'], YMQ: ['YUL','YMX'], DTT: ['DTW'],
    DFW: ['DFW','DAL'], QDF: ['DFW','DAL'], HOU: ['IAH','HOU'], BKK: ['BKK','DMK'], JKT: ['CGK','HLP'], OSL: ['OSL','TRF','RYG'],
    LAX: ['LAX','BUR','LGB','SNA','ONT'], SFO: ['SFO','OAK','SJC'], MIA: ['MIA','FLL','PBI'], IST: ['IST','SAW'],
    DXB: ['DXB','DWC','SHJ'], BER: ['BER'], MEL: ['MEL','AVV'], TPE: ['TPE','TSA'], MNL: ['MNL','CRK'],
  };
  function areaOf(code) {
    const c = String(code || '').toUpperCase();
    const set = new Set([c]);
    for (const [city, list] of Object.entries(CITY_AIRPORTS)) {
      if (city === c || list.includes(c)) { set.add(city); list.forEach((a) => set.add(a)); }
    }
    return set;
  }
  function sameArea(a, b) {
    const A = areaOf(a);
    for (const x of areaOf(b)) if (A.has(x)) return true;
    return false;
  }
  const MON3 = { JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5, JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11 };
  // Origin = first departure; destination = where the traveller stays
  // (longest gap > 24h), otherwise the final arrival.
  function optionRoute(gdsText) {
    const legs = [];
    let year = new Date().getFullYear(), lastMonth = null;
    for (const line of gdsText.split('\n')) {
      const m = line.match(/^\s*\d+\s+[A-Z0-9]{2}\s*\d+[A-Z]\s+(\d{2})([A-Z]{3})\s+[A-Z]\s+([A-Z]{3})([A-Z]{3})\s+\S+\s+(\d{3,4}[AP])\s+(\d{3,4}[AP])(?:\s+(\d{2})([A-Z]{3}))?/);
      if (!m) continue;
      const mon = MON3[m[2]];
      if (lastMonth !== null && mon < lastMonth) year++;
      lastMonth = mon;
      const hm = (t) => { let h = parseInt(t.slice(0, -3), 10) || 0; const mi = parseInt(t.slice(-3, -1), 10); if (t.endsWith('P') && h < 12) h += 12; if (t.endsWith('A') && h === 12) h = 0; return [h, mi]; };
      const [dh, dm] = hm(m[5]); const [ah, am] = hm(m[6]);
      const dep = new Date(year, mon, parseInt(m[1], 10), dh, dm);
      const arr = m[7] ? new Date(year, MON3[m[8]], parseInt(m[7], 10), ah, am) : new Date(year, mon, parseInt(m[1], 10), ah, am);
      legs.push({ from: m[3], to: m[4], dep, arr });
    }
    if (!legs.length) return null;
    let dest = legs[legs.length - 1].to, best = 24 * 3600e3;
    for (let i = 0; i < legs.length - 1; i++) {
      const gap = legs[i + 1].dep - legs[i].arr;
      if (gap > best) { best = gap; dest = legs[i].to; }
    }
    // Only real trip ends count — never a connection airport (a PHL→MXP
    // trip connecting in LHR must NOT pass for an LHR lead).
    const airports = [legs[0].from, dest, legs[legs.length - 1].to];
    return { from: legs[0].from, to: dest, airports };
  }

  // --- Theme colors for Pip's face (same skin as the BO's Pip) ----------
  const FACE_THEMES = {
    midnight: { acc: '#7c7cf8' }, teal: { acc: '#14b8a6' }, pink: { acc: '#ec4899' },
    black: { acc: '#cbd5e1' }, gold: { acc: '#eab308' }, rainbow: { acc: '#a78bfa' },
  };
  function faceTheme() {
    return iaPalette();
  }

  const PIP_MINI = (th) => `<path d="M22 70 L22 38 Q22 26 34 26 L62 26 Q74 26 74 38 L74 62 Q74 74 62 74 L40 74 L30 84 L31 74 Q22 73 22 70 Z" fill="${th.acc}"/><circle cx="40" cy="47" r="4.5" fill="${th.eye}"/><circle cx="56" cy="47" r="4.5" fill="${th.eye}"/>`;
  const FACE_SVG = (th) => `<svg width="34" height="27" viewBox="0 0 34 27" aria-hidden="true">
      <rect x="0.5" y="0.5" width="33" height="26" rx="9" fill="${th.bg}" stroke="${th.line2}" stroke-width="1"/>
      <g transform="translate(17 13.5) scale(0.27) translate(-48 -55)">${PIP_MINI(th)}</g>
    </svg>`;

  // --- Safe markup builder ---------------------------------------------
  // Google's sites (ITA Matrix, Google Flights) enforce "Trusted Types",
  // which makes any innerHTML assignment throw — that's what stopped Pip's
  // face from appearing on ITA. This builds the same markup from plain DOM
  // calls instead, so it works everywhere.
  const SVG_NS = 'http://www.w3.org/2000/svg';
  function buildNodes(markup, inSvg) {
    const out = [];
    const stack = [{ kids: out, svg: !!inSvg }];
    const re = /<!--[\s\S]*?-->|<\/([a-zA-Z0-9]+)\s*>|<([a-zA-Z0-9]+)((?:\s+[^\s=>\/]+(?:\s*=\s*"[^"]*")?)*)\s*(\/?)>|([^<]+)/g;
    let m;
    while ((m = re.exec(markup))) {
      const top = stack[stack.length - 1];
      if (m[0].startsWith('<!--')) continue;
      if (m[1]) { if (stack.length > 1) stack.pop(); continue; }
      if (m[2]) {
        const tag = m[2];
        const svg = top.svg || tag === 'svg';
        const el = svg ? document.createElementNS(SVG_NS, tag) : document.createElement(tag);
        const attrRe = /([^\s=]+)(?:\s*=\s*"([^"]*)")?/g;
        let a;
        while ((a = attrRe.exec(m[3] || ''))) el.setAttribute(a[1], a[2] != null ? a[2].replace(/&quot;/g, '"').replace(/&amp;/g, '&') : '');
        if (top.el) top.el.appendChild(el); else top.kids.push(el);
        if (!m[4] && !/^(br|input|img|hr|meta)$/i.test(tag)) stack.push({ el, svg });
        continue;
      }
      if (m[5]) {
        const t = document.createTextNode(m[5].replace(/&nbsp;/g, '\u00a0').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'));
        if (top.el) top.el.appendChild(t); else top.kids.push(t);
      }
    }
    return out;
  }
  function setMarkup(el, markup) {
    while (el.firstChild) el.removeChild(el.firstChild);
    buildNodes(markup, el instanceof SVGElement).forEach((n) => el.appendChild(n));
  }

  // --- Popover (one at a time), isolated from the site's CSS ------------
  let openPopover = null;
  function closePopover() {
    if (openPopover) { if (openPopover.unpin) openPopover.unpin(); openPopover.host.remove(); openPopover = null; }
  }
  document.addEventListener('mousedown', (e) => {
    if (!openPopover) return;
    if (openPopover.host.contains(e.target) || (openPopover.trigger && openPopover.trigger.contains(e.target))) return;
    if (openPopover.busy) return; // don't close mid-send
    closePopover();
  }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && openPopover && !openPopover.busy) closePopover(); }, true);

  const POPOVER_CSS = (th) => `
    :host { all: initial; }
    .wrap { position: fixed; z-index: 2147483646; width: 232px; font-family: Inter, 'Segoe UI', system-ui, sans-serif; color: ${th.text}; }
    .body { background: ${th.bg}; border: 1px solid ${th.line}; border-radius: 12px; padding: 10px 10px 8px; box-shadow: ${th.shadow}; }
    .title { display: flex; align-items: center; gap: 7px; font-weight: 600; font-size: 12.5px; color: ${th.title}; margin: 0 0 9px; line-height: 1; user-select: none; }
    .copy { margin-top: 8px; text-align: right; font-size: 10px; color: ${th.foot}; user-select: none; }
    .screen { background: transparent; padding: 0; position: relative; }
    .gds { display: block; width: 100%; height: 34px; border: 0; border-radius: 8px; cursor: pointer;
      background: ${th.pri}; color: ${th.onpri}; font: 600 13px/1 inherit; letter-spacing: .04em; transition: filter .15s, background .2s; }
    .gds:hover { filter: brightness(1.08); }
    .gds.ok { background: #16a34a; color: #fff; } .gds.err { background: ${th.stop}; color: #fff; }
    .lead { margin-top: 8px; width: 100%; box-sizing: border-box; height: 34px; border-radius: 8px; border: 1px solid ${th.line2}; outline: none;
      padding: 0 10px; font: 600 14px/34px ui-monospace, 'Cascadia Mono', Consolas, monospace; letter-spacing: .1em; text-align: center;
      color: ${th.title}; background: ${th.field}; transition: border-color .15s; }
    .lead:focus { border-color: ${th.acc}; }
    .lead.bad { border-color: ${th.stop}; color: ${th.bad}; }
    .lead::placeholder { color: ${th.muted}; letter-spacing: .14em; font-weight: 600; }
    .lead:disabled { opacity: .6; }
    .sellrow { width: fit-content; margin: 8px auto 0; display: flex; align-items: center; gap: 4px; height: 30px; border-radius: 8px; padding: 0 10px;
      background: ${th.field}; border: 1px solid ${th.line2}; transition: border-color .15s; }
    .sellrow:focus-within { border-color: ${th.acc}; }
    .sellrow.bad { border-color: ${th.stop}; }
    .sell-l { font-weight: 600; font-size: 10px; line-height: 1; letter-spacing: .12em; color: ${th.muted}; }
    .sell-d { font: 600 14px/1 ui-monospace, 'Cascadia Mono', Consolas, monospace; color: ${th.muted}; margin-left: 8px; }
    .sell-on { display: inline-flex; align-items: center; gap: 6px; cursor: pointer; user-select: none; }
    .sell-cb { width: 14px; height: 14px; margin: 0; accent-color: ${th.acc}; cursor: pointer; }
    .sellrow.off .sell-d, .sellrow.off .sell { opacity: .35; }
    .sell { width: 62px; flex: none; border: 0; outline: none; background: transparent; text-align: right; color: ${th.title};
      font: 600 14px/28px ui-monospace, 'Cascadia Mono', Consolas, monospace; letter-spacing: .04em; padding: 0; }
    .sell::placeholder { color: ${th.muted}; font-style: italic; font-weight: 500; letter-spacing: 0; }
    .sell:disabled { opacity: .6; }
    .price { margin-top: 8px; font-size: 11.5px; color: ${th.sec}; text-align: center; min-height: 14px; }
    select.pick { margin-top: 6px; width: 100%; font: 11.5px inherit; border-radius: 6px; border: 1px solid ${th.line2}; background: ${th.field}; color: ${th.text}; padding: 4px; }
    .warn { margin-top: 7px; padding: 4px 6px; border-radius: 6px; border: 1px solid ${th.stop}; color: ${th.bad}; font-weight: 600; font-size: 11px; text-align: center; }
    .flag { margin-top: 6px; padding: 4px 6px; border-radius: 6px; border: 1px solid #f59e0b; color: ${iaIsLight(th.mode) ? '#b45309' : '#fcd34d'}; font-weight: 600; font-size: 11px; text-align: center; }
    .status { margin-top: 6px; font-size: 11.5px; text-align: center; color: ${th.muted}; min-height: 14px; }
    .status.ok { color: ${th.ok}; font-weight: 600; } .status.err { color: ${th.bad}; font-weight: 600; }
    .confirm { margin-top: 8px; padding: 9px; border-radius: 8px; background: ${th.field}; border: 1px solid ${th.line2}; font-size: 12px; color: ${th.text}; text-align: center; }
    .confirm b { font-weight: 700; color: ${th.title}; }
    .row { display: flex; gap: 6px; margin-top: 8px; }
    .row button { flex: 1; height: 28px; border-radius: 6px; font: 600 12px inherit; cursor: pointer; }
    .yes { background: ${th.pri}; color: ${th.onpri}; border: 0; } .no { background: transparent; color: ${th.text}; border: 1px solid ${th.line2}; }
    .dots::after { content: ''; animation: dots 1.2s steps(4) infinite; }
    @keyframes dots { 0% { content: ''; } 25% { content: '.'; } 50% { content: '..'; } 75% { content: '...'; } }
    /* Sky Glass */
    .body { background: ${th.sky}, ${th.glass}; -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5); border: 1px solid ${th.edge}; border-radius: 18px; padding: 11px 11px 9px; box-shadow: ${th.shadow}, inset 0 1px 0 ${th.edge}; }
    .title { font-weight: 800; font-size: 13px; }
    .gds { height: 36px; border-radius: 12px; font-weight: 800; background: linear-gradient(135deg, color-mix(in srgb, ${th.pri} 78%, #fff), ${th.pri}); box-shadow: 0 8px 18px color-mix(in srgb, ${th.pri} 32%, transparent); }
    .lead { border-radius: 12px; border: 1px solid transparent; background: ${th.chip}; box-shadow: ${th.chipshadow}; font-weight: 700; }
    .sellrow { border-radius: 12px; border: 1px solid transparent; background: ${th.chip}; box-shadow: ${th.chipshadow}; }
    .sell-l { font-weight: 800; }
    .sell, .sell-d { font-weight: 700; }
    .price { font-weight: 700; }
    .status { font-weight: 700; }
    .copy { font-weight: 700; }
    select.pick { border-radius: 10px; border-color: transparent; background: ${th.chip}; font-weight: 700; }
    .warn, .flag { border-radius: 10px; }
    .confirm { border-radius: 12px; border-color: transparent; background: ${th.inner}; }
    .row button { height: 30px; border-radius: 10px; font-weight: 800; }
    .no { border: 0; background: ${th.chip}; color: ${th.title}; }
  ` + (iaIsNova(th.mode) ? `
    /* Nova */
    .wrap { font-family: ${IA_NOVA_FONT}; }
    .body { border: 1px solid ${th.line}; border-radius: 24px; padding: 12px 12px 10px; box-shadow: ${th.shadow}; }
    .title { font-family: ${IA_NOVA_DISPLAY}; font-weight: 600; font-size: 12px; letter-spacing: -.01em; }
    .gds { height: 40px; border-radius: 999px; background: ${th.pri}; color: ${th.onpri}; box-shadow: 0 10px 22px -12px color-mix(in srgb, ${th.text} 70%, transparent);
      transition: transform .3s cubic-bezier(.34,1.4,.64,1); }
    .gds:hover { filter: none; transform: translateY(-1px); } .gds:active { transform: scale(.96); }
    .gds.ok { background: ${th.ok}; color: ${th.onpri}; }
    .lead { height: 38px; border-radius: 999px; box-shadow: inset 0 0 0 1.5px ${th.line}; font-family: ${IA_NOVA_MONO}; font-weight: 500; }
    .lead:focus { border-color: ${th.acc}; }
    .sellrow { border-radius: 999px; box-shadow: inset 0 0 0 1.5px ${th.line}; }
    .sell, .sell-d { font-family: ${IA_NOVA_MONO}; font-weight: 500; }
    .sell-l, .copy { font-family: ${IA_NOVA_MONO}; font-weight: 500; letter-spacing: .1em; text-transform: uppercase; }
    select.pick { border-radius: 14px; }
    .confirm { border-radius: 16px; }
    .row button { height: 34px; border-radius: 999px; transition: transform .3s cubic-bezier(.34,1.4,.64,1); }
    .row button:active { transform: scale(.95); }
    .no { box-shadow: inset 0 0 0 1.5px ${th.line}; }
  ` : '') + (iaIsCalm(th.mode) ? `
    /* Calm */
    .body { border-radius: 16px; }
    .title { font-weight: 800; font-size: 12.5px; }
    .gds, .lead, .sellrow, .row button { border-radius: 10px; }
    .gds { box-shadow: none; }
    .sell-l, .copy { font-family: ${IA_CALM_FONT}; letter-spacing: 0; text-transform: none; font-weight: 700; }
  ` : '');

  function openBmoPopover(trigger, origBtn) {
    if (openPopover && openPopover.trigger === trigger) { closePopover(); return; }
    closePopover();
    const th = faceTheme();
    const host = document.createElement('div');
    const root = host.attachShadow({ mode: 'open' });
    const styleEl = document.createElement('style');
    styleEl.textContent = POPOVER_CSS(th);
    root.appendChild(styleEl);
    buildNodes(`
      <div class="wrap"><div class="body"><div class="title"><svg width="18" height="19" viewBox="10 10 76 80" aria-hidden="true">${PIP_MINI(th)}</svg>TBC Assistant</div><div class="screen">
        <button class="gds" type="button">GDS</button>
        <input class="lead" type="text" inputmode="numeric" placeholder="LEAD ID" autocomplete="off" spellcheck="false">
        <div class="sellrow"><label class="sell-on" title="Set the sell price when adding (off = $0.00 as usual)"><input class="sell-cb" type="checkbox"><span class="sell-l">SELL</span></label><span class="sell-d">$</span><input class="sell" type="text" inputmode="decimal" maxlength="9" placeholder="auto" autocomplete="off" spellcheck="false"></div>
        <div class="price"></div>
        <div class="extra"></div>
        <div class="status"></div>
        <div class="copy">\u00a9 TBC Assistant</div>
      </div></div></div>`).forEach((n) => root.appendChild(n));
    document.documentElement.appendChild(host);
    const wrap = root.querySelector('.wrap');
    // Pinned to Pip's face: it follows the face when the page (or any
    // scrolling panel) moves, instead of floating in one screen spot.
    const r0 = trigger.getBoundingClientRect();
    const h0 = wrap.offsetHeight || 260;
    const openAbove = r0.bottom + 8 + h0 > window.innerHeight && r0.top - 8 - h0 > 0;
    let rafId = 0;
    const place = () => {
      rafId = 0;
      if (!trigger.isConnected) { if (openPopover && !openPopover.busy) closePopover(); return; }
      const r = trigger.getBoundingClientRect();
      const h = wrap.offsetHeight || h0;
      wrap.style.left = Math.max(8, Math.min(r.left + r.width / 2 - 116, window.innerWidth - 240)) + 'px';
      wrap.style.top = (openAbove ? r.top - 8 - h : r.bottom + 8) + 'px';
    };
    const onMove = () => { if (!rafId) rafId = requestAnimationFrame(place); };
    place();
    window.addEventListener('scroll', onMove, true);
    window.addEventListener('resize', onMove);

    const state = { host, root, trigger, origBtn, busy: false, choices: [], choiceIdx: 0 };
    state.unpin = () => { window.removeEventListener('scroll', onMove, true); window.removeEventListener('resize', onMove); if (rafId) cancelAnimationFrame(rafId); };
    try { GM_setValue('js-sendjob-warm', Date.now()); } catch (e) { /* ignore */ } // let the BO get ready
    openPopover = state;
    const gdsBtn = root.querySelector('.gds');
    const lead = root.querySelector('.lead');
    const priceEl = root.querySelector('.price');
    const extra = root.querySelector('.extra');
    const status = root.querySelector('.status');

    function setStatus(text, cls) { status.className = 'status' + (cls ? ' ' + cls : ''); setMarkup(status, text || ''); }
    state.setStatus = setStatus;

    // Sell box: Net + 10% rounded up to a price ending in 88-92. Cash is
    // worked out right here; award Net is only known once the BO prices
    // the miles, so it's done there ("auto"). Typing a price overrides.
    const sellIn = root.querySelector('.sell');
    const sellRow = root.querySelector('.sellrow');
    state.sellEnding = [88, 89, 90, 91, 92][Math.floor(Math.random() * 5)];
    state.sellAuto = true;
    const roundSellP = (x) => { let v = Math.floor(x / 100) * 100 + state.sellEnding; if (v < x) v += 100; return v; };
    function autoSell() {
      if (!state.sellAuto) return;
      const c = state.choices[state.choiceIdx];
      const u = c && c.kind === 'cash' ? toUsd(c.money) : null;
      sellIn.value = u && !u.error && u.usd > 0 ? String(roundSellP(u.usd * 1.1)) : '';
      sellIn.placeholder = 'auto';
    }
    sellIn.addEventListener('input', () => {
      state.sellAuto = !sellIn.value.trim();
      sellRow.classList.remove('bad');
      if (state.sellAuto) autoSell();
    });
    sellIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') lead.focus(); });
    // Tick = set the sell price; untick = leave it $0.00 as usual. Remembered.
    const sellCb = root.querySelector('.sell-cb');
    let sellOn = true;
    try { sellOn = GM_getValue('js-sell-on', true) !== false; } catch (e) { sellOn = true; }
    const applyOn = () => { sellCb.checked = sellOn; sellRow.classList.toggle('off', !sellOn); sellIn.disabled = !sellOn; };
    applyOn();
    sellCb.addEventListener('change', () => { sellOn = sellCb.checked; try { GM_setValue('js-sell-on', sellOn); } catch (e) { /* ignore */ } applyOn(); });
    state.sellSpec = () => {
      if (!sellOn) return null;
      if (state.sellAuto) return { value: null, ending: state.sellEnding };
      const t = sellIn.value.trim().replace(/^\$\s*/, '').replace(/,(?=\d{3}\b)/g, '');
      if (!/^\d+(\.\d{1,2})?$/.test(t)) return { bad: true };
      return { value: Math.round(parseFloat(t) * 100) / 100, ending: state.sellEnding };
    };

    function renderChoice() {
      const c = state.choices[state.choiceIdx];
      // With a dropdown, the dropdown itself shows the price: no repeat line.
      priceEl.textContent = c ? describeChoice(c) : 'Price not found on this result';
      priceEl.style.display = c && state.choices.length > 1 ? 'none' : '';
      autoSell();
      extra.querySelectorAll('.warn').forEach((w) => w.remove());
      const code = c && c.kind === 'award' ? programCode(c.program) : null;
      const unsupported = !!c && !programSupported(c);
      state.unsupported = unsupported;
      lead.classList.toggle('bad', unsupported);
      if (unsupported) setStatus('Mileage program not supported', 'err');
      else if (/not supported/.test(status.textContent)) setStatus('');
      if (false && code && RUSH_PROGRAMS[code]) { // rush warning lives on the BO option only
        const w = document.createElement('div');
        w.className = 'warn';
        w.textContent = RUSH_PROGRAMS[code] + ' Detected, Rush flight only';
        extra.appendChild(w);
      }
    }
    function loadChoices() {
      state.choices = readPrice(origBtn);
      const firstOk = state.choices.findIndex(programSupported);
      state.choiceIdx = firstOk > 0 ? firstOk : 0;
      extra.textContent = '';
      if (state.choices.length > 1) {
        const sel = document.createElement('select');
        sel.className = 'pick';
        state.choices.forEach((c, i) => { const o = document.createElement('option'); o.value = i; o.textContent = describeChoice(c).replace(' / person', '') + (programSupported(c) ? '' : ' (not supported)'); sel.appendChild(o); });
        sel.value = String(state.choiceIdx);
        sel.addEventListener('change', () => { state.choiceIdx = parseInt(sel.value, 10); renderChoice(); });
        extra.appendChild(sel);
      }
      renderChoice();
    }
    loadChoices();

    gdsBtn.addEventListener('click', () => {
      gdsCopyListener = (ok, label) => {
        gdsCopyListener = null;
        gdsBtn.classList.remove('ok', 'err');
        gdsBtn.classList.add(ok ? 'ok' : 'err');
        gdsBtn.textContent = ok ? '✓ COPIED' : (label || 'No data');
        setTimeout(() => { gdsBtn.classList.remove('ok', 'err'); gdsBtn.textContent = 'GDS'; }, 1400);
      };
      origBtn.click();
    });

    // Lead IDs are exactly 6 digits: anything else is rejected in red.
    let typeTimer = null;
    const markBad = (bad) => { lead.classList.toggle('bad', !!bad); if (bad) setStatus('Wrong Lead ID', 'err'); };
    const fire = () => {
      if (state.busy) return;
      const raw = lead.value.trim();
      const id = raw.replace(/\D/g, '');
      if (!/^\d{6}$/.test(id) || /[^\d\s#]/.test(raw)) { markBad(true); return; }
      markBad(false);
      lead.value = id;
      sendToLead(state, id);
    };
    lead.addEventListener('paste', () => setTimeout(fire, 0));
    lead.addEventListener('keydown', (e) => { if (e.key === 'Enter') { clearTimeout(typeTimer); fire(); } });
    lead.addEventListener('input', () => {
      clearTimeout(typeTimer);
      const n = lead.value.replace(/\D/g, '').length;
      if (n > 6 || /[^\d\s#]/.test(lead.value)) { markBad(true); return; }
      lead.classList.remove('bad');
      if (status.classList.contains('err')) setStatus('');
      if (n === 6) typeTimer = setTimeout(fire, 700);
    });
    setTimeout(() => lead.focus(), 0);
  }

  // Asks the site's own GDS logic for the *IA/VI* text without copying it.
  function captureGds(origBtn) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => { gdsCaptureResolve = null; resolve({ ok: false, error: 'Timed out reading flights' }); }, 9000);
      gdsCaptureResolve = (res) => { clearTimeout(timer); resolve(res); };
      origBtn.click();
    });
  }

  async function sendToLead(state, leadId) {
    const { root, origBtn, setStatus } = state;
    const lead = root.querySelector('.lead');
    state.busy = true;
    lead.disabled = true;
    const done = (html, cls) => { setStatus(html, cls); state.busy = false; lead.disabled = false; };

    const sellSpec = state.sellSpec ? state.sellSpec() : null;
    if (sellSpec && sellSpec.bad) { root.querySelector('.sellrow').classList.add('bad'); return done('Sell price: numbers only, e.g. 4890', 'err'); }
    setStatus('Reading option<span class="dots"></span>');
    const cap = await captureGds(origBtn);
    if (!cap.ok) return done(cap.error || 'Could not read the flights', 'err');
    if (!state.choices.length) { state.choices = readPrice(origBtn); }
    const choice = state.choices[state.choiceIdx];
    if (!choice) return done('Price not found on this result', 'err');

    // Price checks up front, before touching the BO.
    let price;
    if (choice.kind === 'cash') {
      const u = toUsd(choice.money);
      if (!u || u.error) return done((u && u.error) || 'Price not readable', 'err');
      price = { kind: 'cash', perPerson: u.usd };
    } else {
      const parts = [];
      for (const p of (choice.parts || [choice])) {
        const code = programCode(p.program);
        if (!code || !BO_PROGRAMS.includes(code)) return done('Mileage program not supported', 'err');
        const tx = toUsd(p.taxes || { amount: 0, currency: 'USD' });
        if (!tx || tx.error) return done((tx && tx.error) || 'Taxes not readable', 'err');
        parts.push({ points: p.points, taxesPerPerson: tx.usd, program: code });
      }
      price = Object.assign({ kind: 'award', parts }, parts[0]);
    }
    const route = optionRoute(cap.text);

    const jobId = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const statusKey = 'js-sendjob-status-' + jobId;
    const decisionKey = 'js-sendjob-decision-' + jobId;
    try {
      GM_setValue(SEND_JOB_KEY + '-' + jobId, JSON.stringify({ id: jobId, leadId, gds: cap.text, createdAt: Date.now() }));
    } catch (e) { return done('Could not hand over to the BO', 'err'); }

    setStatus('Contacting BO<span class="dots"></span>');
    let tab = null;
    let claimed = false;
    // Ask any open BO tab to do the job invisibly (in a hidden frame inside
    // that tab). Only if no BO tab answers within ~3s, open one in the
    // background instead.
    try { GM_setValue('js-sendjob-request', JSON.stringify({ id: jobId, leadId, t: Date.now() })); } catch (e) { /* ignore */ }
    setTimeout(() => {
      if (claimed || !state.busy) return;
      // A BO tab is open and alive, just slow to answer: wait for it rather
      // than opening a second BO that would add the option again.
      let alive = {};
      try { alive = JSON.parse(GM_getValue('js-sendjob-alive', '{}') || '{}') || {}; } catch (e) { alive = {}; }
      if (Object.keys(alive).some((k) => alive[k] && Date.now() - alive[k].t < 90000)) {
        setStatus('Waiting for the BO<span class="dots"></span>');
        return;
      }
      setStatus('No BO tab open \u2014 opening one<span class="dots"></span>');
      try {
        tab = GM_openInTab('https://bo.travelbusinessclass.com/leads/' + leadId + '?jsjob=' + jobId, { active: false, insert: true, setParent: true });
      } catch (e) { done('Could not open the BO', 'err'); }
    }, 3000);

    const cleanup = () => {
      try { if (tab && tab.close) tab.close(); } catch (e) { /* ignore */ }
      try { GM_setValue(statusKey, null); GM_setValue(decisionKey, null); GM_setValue(SEND_JOB_KEY + '-' + jobId, null); } catch (e) { /* ignore */ }
      if (listenerId != null && typeof GM_removeValueChangeListener === 'function') { try { GM_removeValueChangeListener(listenerId); } catch (e) { /* ignore */ } }
    };
    const overall = setTimeout(() => { cleanup(); done('BO did not respond — is it logged in?', 'err'); }, 90000);

    let listenerId = null;
    listenerId = GM_addValueChangeListener(statusKey, (name, oldV, newV) => {
      if (!newV) return;
      let st;
      try { st = JSON.parse(newV); } catch (e) { return; }
      if (st.phase === 'claimed') {
        claimed = true;
        setStatus('Opening lead ' + leadId + '<span class="dots"></span>');
        // The BO tab runs whatever version was installed when it was loaded.
        const mine = (typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || '';
        if (mine && st.v !== mine) state.boStale = true;
      } else if (st.phase === 'lead') {
        claimed = true;
        onLeadInfo(st);
      } else if (st.phase === 'saving') {
        setStatus('Adding to lead ' + leadId + '<span class="dots"></span>');
      } else if (st.phase === 'selling') {
        setStatus('Setting sell price<span class="dots"></span>');
      } else if (st.phase === 'done') {
        clearTimeout(overall);
        cleanup();
        const sv = st.sell && st.sell.ADT;
        if (sv) { const si = root.querySelector('.sell'); si.value = String(sv); }
        const sellTxt = sv ? ' · Sell $' + Number(sv).toLocaleString('en-US') : '';
        if (state.boStale) { done('✓ Added to lead ' + leadId + (st.optionId ? ' · option ' + st.optionId : '') + '<br>Your BO tab runs an older TBC Assistant \u2014 reload it (F5)', 'err'); return; }
        if (st.sell && st.sell.error) done('✓ Added to lead ' + leadId + (st.optionId ? ' · option ' + st.optionId : '') + '<br>Sell price not set: ' + st.sell.error, 'err');
        else done('✓ Added to lead ' + leadId + (st.optionId ? ' · option ' + st.optionId : '') + sellTxt, 'ok');
      } else if (st.phase === 'error') {
        clearTimeout(overall);
        cleanup();
        done(st.message || 'Something went wrong', 'err');
      }
    });

    function decide(go, fill) {
      try { GM_setValue(decisionKey, JSON.stringify({ go, fill })); } catch (e) { /* ignore */ }
      if (!go) { clearTimeout(overall); setTimeout(cleanup, 300); done('Cancelled — nothing was added'); }
    }

    function onLeadInfo(info) {
      // Build exactly what goes into the BO, using the lead's passengers.
      const pax = info.pax || { adults: 1, children: 0, infants: 0 };
      const flags = [];
      let fill;
      if (price.kind === 'cash') {
        fill = { mode: 'cash', ADT: price.perPerson, CHD: price.perPerson, INF: INFANT_CASH_NET };
        if (pax.children) flags.push('Child priced same as adult');
        if (pax.infants) flags.push('Infant set to $' + INFANT_CASH_NET + ' default');
      } else {
        const full = (pax.adults || 0) + (pax.children || 0);
        const parts = price.parts.map((p) => ({
          miles: p.points * full + INFANT_AWARD_MILES * (pax.infants || 0),
          taxes: Math.round(p.taxesPerPerson * (full + (pax.infants || 0)) * 100) / 100,
          program: p.program,
        }));
        fill = Object.assign({ mode: 'award', parts }, parts[0]);
        if (pax.children) flags.push('Child priced same as adult');
        if (pax.infants) flags.push('Infant added at ' + INFANT_AWARD_MILES.toLocaleString('en-US') + ' miles + same taxes as adult');
      }
      fill.flags = flags;
      if (sellSpec) fill.sell = sellSpec;
      if (price.kind === 'award') {
        const rush = [...new Set(price.parts.map((p) => p.program))].filter((c) => RUSH_PROGRAMS[c]);
        if (rush.length) fill.rush = rush.map((c) => RUSH_PROGRAMS[c]).join(' & ') + ' Detected, Rush flight only';
      }

      const extra = root.querySelector('.extra');
      extra.querySelectorAll('.flag').forEach((f) => f.remove());
      flags.forEach((t) => { const d = document.createElement('div'); d.className = 'flag'; d.textContent = '⚠ ' + t; extra.appendChild(d); });

      // Fine when the option starts or ends at either end of the lead, in
      // either direction (so PIT→LHR on an LHR→PIT lead is fine).
      // Connection airports don't count. Otherwise ask.
      const ok = !route || !info.from || !info.to
        || (route.airports || [route.from, route.to]).some((a) => sameArea(a, info.from) || sameArea(a, info.to));
      if (ok) {
        decide(true, fill);
        return;
      }
      // Neither end matches: ask first.
      setStatus('');
      const box = document.createElement('div');
      box.className = 'confirm';
      setMarkup(box, 'Lead <b>' + leadId + '</b> is going from <b>' + info.from + '</b> to <b>' + info.to + '</b>.<br>Are you sure you want to proceed?<div class="row"><button class="yes" type="button">Yes</button><button class="no" type="button">No</button></div>');
      root.querySelector('.screen').appendChild(box);
      box.querySelector('.yes').addEventListener('click', () => { box.remove(); setStatus('Adding to lead ' + leadId + '<span class="dots"></span>'); decide(true, fill); });
      box.querySelector('.no').addEventListener('click', () => { box.remove(); decide(false); });
    }
  }

  // Swap every GDS button for Pip's face (the original stays hidden and
  // still does the actual copy work).
  function bmoizeGdsButtons() {
    // The face goes right BEFORE the hidden original, so the original stays
    // where each site's own code expects it (FlyBasis keeps re-checking
    // that its button is the row's last child; putting the face after it
    // made the two fight over that spot, so the face kept getting moved
    // and clicks on it never registered).
    document.querySelectorAll('.gds-btn-base:not([data-bmo])').forEach((orig) => {
      orig.setAttribute('data-bmo', '1');
      try {
        const trig = document.createElement('span');
        trig.className = 'gds-pip-trigger';
        trig.title = "TBC Assistant: GDS copy / send to lead";
        setMarkup(trig, FACE_SVG(faceTheme()));
        trig.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); openBmoPopover(trig, orig); }, true);
        ['mousedown', 'mouseup', 'pointerdown', 'pointerup'].forEach((t) => trig.addEventListener(t, (e) => e.stopPropagation()));
        orig.insertAdjacentElement('beforebegin', trig);
        orig.style.setProperty('display', 'none', 'important'); // only once the face is in place
        sizeTrigger(trig, orig);
      } catch (e) { /* keep the plain GDS button if anything fails */ }
    });
    document.querySelectorAll('.gds-btn-base[data-bmo]').forEach((orig) => {
      const prev = orig.previousElementSibling;
      if (!prev || !prev.classList.contains('gds-pip-trigger')) {
        const stray = orig.parentElement && orig.parentElement.querySelector(':scope > .gds-pip-trigger');
        if (stray) orig.insertAdjacentElement('beforebegin', stray);
      }
      if (prev && prev.classList.contains('gds-pip-trigger') && !prev.dataset.sized) sizeTrigger(prev, orig);
    });
  }

  // Per-site size, so the face sits in proportion to what's next to it.
  function sizeTrigger(trig, orig) {
    const host = location.hostname;
    let h = 27;
    let ref = null;
    if (host.includes('matrix.itasoftware.com')) {
      ref = orig.parentElement && orig.parentElement.querySelector('.mdc-button, button:not(.gds-btn-base)');
      h = 30;
    } else if (host.includes('kayak.com')) {
      const sec = orig.closest('.nrc6-price-section') || orig.parentElement;
      ref = sec && sec.querySelector('.M_JD-booking-btn, .oVHK');
      h = 36;
      // Sit on its own line with its right edge flush with "View deal".
      trig.style.cssText += ';display:flex;width:fit-content;margin:0 0 6px auto;';
    } else if (host.includes('awardlogic.com') || host.includes('cheapoair.com') || host.includes('google.com')) {
      h = 34;
    }
    if (ref) {
      const rh = ref.getBoundingClientRect().height;
      if (rh >= 18 && rh <= 60) h = host.includes('kayak.com') ? rh : rh - 2;
      else return; // not laid out yet; try again on the next scan
    }
    const svg = trig.querySelector('svg');
    if (svg && host.includes('matrix.itasoftware.com') && ref) {
      // ITA: exactly as tall as the price button, flush beside it — the
      // face's own artwork fills the full height (no empty margin in the
      // drawing), centered on the same line, with a small even gap.
      const rh = ref.getBoundingClientRect().height;
      svg.setAttribute('viewBox', '0 0.5 34 26');
      svg.setAttribute('height', String(Math.round(rh)));
      svg.setAttribute('width', String(Math.round(rh * 34 / 26)));
      svg.style.display = 'block';
      trig.style.cssText += ';margin:0 0 0 4px;align-self:center;vertical-align:middle;line-height:0;';
    } else if (svg) { svg.setAttribute('height', String(Math.round(h))); svg.setAttribute('width', String(Math.round(h * 34 / 27))); }
    trig.dataset.sized = '1';
  }

  GM_addStyle(`
    .gds-pip-trigger { display: inline-flex; align-items: center; justify-content: center; cursor: pointer; vertical-align: middle;
      margin: 0 4px; line-height: 0; transition: filter .15s ease; flex-shrink: 0; }
    .gds-pip-trigger:hover { filter: brightness(1.25); }
    .gds-pip-trigger:active { transform: translateY(1px) scale(.98); }
  `);

  // ------------------------------------------------------------------
  // INITIALIZATION & OBSERVER
  // ------------------------------------------------------------------
  function init() {
    const host = location.hostname;
    if (host.includes('flybasis.com') || host.includes('agentsearch.vercel.app')) { injectFlyBasisButtons(); injectFlyBasisDetailButton(); }
    if (host.includes('matrix.itasoftware.com')) injectItaButtons();
    if (host.includes('pointsyeah.com')) injectPointsYeahButtons();
    if (host.includes('awardlogic.com')) injectAwardLogicButtons();
    if (host.includes('kayak.com')) injectKayakButtons();
    if (host.includes('cheapoair.com')) injectCheapOairButtons();
    if (host.includes('google.com') && location.pathname.startsWith('/travel/flights')) injectGoogleFlightsButton();
    bmoizeGdsButtons();
  }

  // Coalesce bursts of mutations into a single init() per animation
  // frame rather than one per mutation record. On a busy SPA this
  // MutationObserver's callback can fire dozens of times within a
  // single visual update (React/Vue-style frameworks batch many small
  // DOM writes together), and each of those was re-running every
  // injectXButtons() query on every single firing. Capping it to once
  // per frame keeps the same effective responsiveness (a few ms, never
  // perceptible) while cutting out the redundant re-scans and the
  // short-lived NodeList allocations each one creates.
  let initScheduled = false;
  const observer = new MutationObserver(() => {
    if (initScheduled) return;
    initScheduled = true;
    requestAnimationFrame(() => {
      initScheduled = false;
      init();
    });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  init();

  // The URL-change-triggered retry burst that used to live here still
  // wasn't reliable enough — worth being honest that I don't actually
  // know the precise mechanism (Google's SPA transition timing, or
  // requestAnimationFrame getting throttled while the tab is
  // backgrounded during that transition — rAF callbacks are not
  // guaranteed to fire promptly in a hidden tab, which the coalescing
  // above depends on). Rather than keep guessing at the right trigger to
  // watch for, this just tries unconditionally, forever, on a plain
  // setInterval (not tied to animation frames, so it isn't subject to
  // that same throttling risk) as long as the URL is under
  // /travel/flights. Each attempt is two cheap querySelector calls that
  // no-op immediately once the button's already there, so running this
  // indefinitely costs nothing worth worrying about — it guarantees
  // eventual correctness without needing to know why the other paths
  // sometimes miss.
  if (location.hostname.includes('google.com')) {
    setInterval(() => {
      if (location.pathname.startsWith('/travel/flights')) injectGoogleFlightsButton();
    }, 1000);
  }
})();

// --------------------------------------------------------------------
// Shared CRM DOM-scan scheduler — PARTs 2, 3 and 4 all run together on
// the same CRM page. Each used to keep its own separate MutationObserver
// watching the whole document (childList+subtree on document.documentElement
// -- the most expensive observer scope there is), so a single DOM
// mutation anywhere on the page -- and this CRM has a live terminal that
// appends output constantly -- fired THREE independent observers and
// three separate rAF-coalesced re-scans. On a low-end PC that's real,
// avoidable CPU/RAM overhead: three copies of the browser's own mutation
// bookkeeping, tripled event dispatch, tripled callback-array churn. One
// shared observer with one shared rAF batch running all three parts'
// scan functions does the exact same job for a third of the cost, with
// no change in behavior. (PART 1 runs only on flight-search sites, never
// alongside these, so it keeps its own separate observer rather than
// pulling in this machinery where it'd never be shared with anything.)
// Speed: the scans used to run on every animation frame the page changed
// (up to ~60 a second while the BO loads or the terminal prints). Now they
// run at most once every 250 ms, always with a final run after the last
// change, so nothing is missed -- just picked up a fraction of a second
// later. Scans that must react instantly can be registered as "fast" and
// still run every frame.
// The BO's stored login. It now lives in localStorage as a JSON object,
// accessTokenData = { authorization: "Bearer <jwt>", userInfo: {...} }
// (older BO builds kept a bare JWT under a key containing "token").
// Returns a ready Authorization header value, or ''.
// BO API headers seen by SECTION 2 (from the BO's own requests), also used by SECTION 4.
const __jsApi = { headers: {} };
function __jsStoredAuth() {
  try {
    const raw = localStorage.getItem('accessTokenData');
    if (raw) {
      let a = '';
      try { const j = JSON.parse(raw); a = String((j && (j.authorization || j.access_token || j.token)) || ''); } catch (e) { a = raw; }
      a = a.replace(/^"|"$/g, '').trim();
      if (a) return /^bearer\s/i.test(a) ? a : 'Bearer ' + a;
    }
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      const v = (localStorage.getItem(k) || '').replace(/^"|"$/g, '');
      if (/token/i.test(k) && /^[\w-]+\.[\w-]+\.[\w-]+$/.test(v)) return 'Bearer ' + v;
    }
  } catch (e) { /* ignore */ }
  return '';
}
const __jsScanCallbacks = [];
const __jsFastScanCallbacks = [];
const __JS_SCAN_GAP_MS = 250;
let __jsScanScheduled = false;
let __jsFastScheduled = false;
let __jsScanLast = 0;
let __jsSharedObserver = null;
function __jsRegisterScan(fn) { __jsScanCallbacks.push(fn); }
function __jsRegisterFastScan(fn) { __jsFastScanCallbacks.push(fn); }
function __jsRunList(list) { for (const fn of list) { try { fn(); } catch (e) { /* one part's error shouldn't stop the others */ } } }
function __jsEnsureSharedObserver() {
  if (__jsSharedObserver) return;
  __jsSharedObserver = new MutationObserver(() => {
    if (__jsFastScanCallbacks.length && !__jsFastScheduled) {
      __jsFastScheduled = true;
      requestAnimationFrame(() => { __jsFastScheduled = false; __jsRunList(__jsFastScanCallbacks); });
    }
    if (__jsScanScheduled) return;
    __jsScanScheduled = true;
    const run = () => requestAnimationFrame(() => {
      __jsScanScheduled = false;
      __jsScanLast = Date.now();
      __jsRunList(__jsScanCallbacks);
    });
    const wait = __JS_SCAN_GAP_MS - (Date.now() - __jsScanLast);
    if (wait > 0) setTimeout(run, wait); else run();
  });
  __jsSharedObserver.observe(document.documentElement, { childList: true, subtree: true });
}

// ====================================================================
// SECTION 2 · CRM "Add option" modal: Sort Me + auto-carrier + auto-next
// ====================================================================
(function () {
  'use strict';

  // Same reasoning as the other half of this file — bail out before the
  // MutationObserver is created on any page that isn't this CRM site, so
  // being on Kayak/Google Flights/etc. doesn't also pay for a
  // subtree-wide observer that's checking for a modal class that will
  // never exist there.
  if (!location.hostname.includes('travelbusinessclass.com')) return;

  // ------------------------------------------------------------------
  // Scoped to /leads/* — the "Add option" modal only exists on lead
  // pages (e.g. .../leads/614528), so there's no need to run anywhere
  // else on the CRM.
  // ------------------------------------------------------------------

  const MONTH_MAP = { JAN:0, FEB:1, MAR:2, APR:3, MAY:4, JUN:5, JUL:6, AUG:7, SEP:8, OCT:9, NOV:10, DEC:11 };

  // Longitude of common airports, used only to estimate a UTC offset
  // (round(longitude/15)) so legs across very different time zones sort
  // correctly (e.g. a Sydney departure vs a San Francisco departure on
  // "the same" local date/time-of-day are not directly comparable —
  // comparing raw local clock times misorders exactly this kind of
  // connection). Ignores DST; imprecise right at zone boundaries; but a
  // same-day slip in local time essentially never flips which of two
  // *different* flights in an itinerary should come first.
  const AIRPORT_LON = {
    JFK:-73.7781, EWR:-74.1745, LGA:-73.8740, BOS:-71.0096, IAD:-77.4565, DCA:-77.0402,
    BWI:-76.6684, PHL:-75.2424, ORD:-87.9073, ATL:-84.4277, MIA:-80.2870, MCO:-81.3081,
    FLL:-80.1527, TPA:-82.5311, DFW:-97.0403, IAH:-95.3368, AUS:-97.6664, DEN:-104.6737,
    LAX:-118.4085, SFO:-122.3790, SAN:-117.1933, SEA:-122.3088, PDX:-122.5951, LAS:-115.1537,
    PHX:-112.0116, SLC:-111.9791, MSP:-93.2223, DTW:-83.3534, CLT:-80.9431, MSY:-90.2580,
    STL:-90.3700, MCI:-94.7139, PIT:-80.2329, CLE:-81.8498, IND:-86.2944, CMH:-82.8919,
    BNA:-86.6782, MEM:-89.9767, JAX:-81.6879, RDU:-78.7875, SAT:-98.4698, ELP:-106.3781,
    SJC:-121.9291, OAK:-122.2197, SNA:-117.8682, ONT:-117.6012, BUR:-118.3587, HNL:-157.9251,
    YVR:-123.1792, YYZ:-79.6248, YUL:-73.7408, YYC:-114.0076, MEX:-99.0721, CUN:-86.8771,
    PTY:-79.3835, BOG:-74.1469, LIM:-77.1143, GRU:-46.4731, GIG:-43.2506, EZE:-58.5358,
    SCL:-70.7858, LHR:-0.4543, LGW:-0.1903, MAN:-2.2750, CDG:2.5479, ORY:2.3652, AMS:4.7683,
    FRA:8.5622, MUC:11.7861, ZRH:8.5492, VIE:16.5697, MAD:-3.5676, BCN:2.0785, LIS:-9.1359,
    FCO:12.2389, ATH:23.9445, IST:28.7519, CPH:12.6560, ARN:17.9186, OSL:11.1004, HEL:24.9633,
    DUB:-6.2701, BRU:4.4844, WAW:20.9671, PRG:14.2600, BUD:19.2611, KEF:-22.6056,
    DXB:55.3657, AUH:54.6511, DOH:51.6081, RUH:46.6988, JED:39.1565, CAI:31.4056,
    JNB:28.2460, CPT:18.6017, NBO:36.9278, LOS:3.3212, ADD:38.7993,
    HND:139.7798, NRT:140.3929, ICN:126.4407, PVG:121.8083, PEK:116.6031, PKX:116.4109, HKG:113.9185,
    TPE:121.2328, SIN:103.9915, BKK:100.7501, KUL:101.7099, MNL:121.0198, DEL:77.1000,
    BOM:72.8679, CMB:79.8841, SYD:151.1753, MEL:144.8410, BNE:153.1175, PER:115.9669, AKL:174.7850,
  };

  function estimateUtcOffset(iata) {
    const lon = AIRPORT_LON[iata];
    return lon != null ? Math.round(lon / 15) : 0;
  }

  // Reads the CRM's own displayed clock (the small "10:37 / KIV / 13
  // Sep" widget) as the reference "now" for year-inference, instead of
  // trusting the browser's system clock. If the system clock is ever in
  // a different timezone or has drifted from the CRM's own business
  // time, trusting it could push a date to the wrong side of a
  // month/year boundary — e.g. a departure in December and a return in
  // January should resolve to the SAME booking year for December and
  // the NEXT year for January, and that call is only as good as
  // whatever "now" it's measured against. Falls back to the system
  // clock if the widget isn't found (year still comes from the system
  // clock either way, since the widget doesn't display one).
  function getReferenceNow() {
    const activeEl = document.querySelector('[data-active="true"]');
    if (activeEl) {
      const m = activeEl.textContent.match(/\b(\d{1,2})\s+([A-Za-z]{3})\b/);
      if (m) {
        const month = MONTH_MAP[m[2].slice(0, 3).toUpperCase()];
        if (month !== undefined) {
          return new Date(new Date().getFullYear(), month, parseInt(m[1], 10));
        }
      }
    }
    return new Date();
  }

  function inferYear(month, day, referenceNow) {
    const now = referenceNow || new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const candidate = new Date(now.getFullYear(), month, day);
    return candidate < todayStart ? now.getFullYear() + 1 : now.getFullYear();
  }

  function parseSabreTime(t) {
    const ap = t.slice(-1).toUpperCase();
    const digits = t.slice(0, -1);
    let hh, mm;
    if (digits.length >= 3) {
      mm = parseInt(digits.slice(-2), 10);
      hh = parseInt(digits.slice(0, digits.length - 2), 10);
    } else {
      hh = parseInt(digits, 10);
      mm = 0;
    }
    if (ap === 'P' && hh < 12) hh += 12;
    if (ap === 'A' && hh === 12) hh = 0;
    return { hh, mm };
  }

  // A rough UTC instant for the leg's LOCAL departure wall-clock — used
  // ONLY as a tie-breaker now (see reorderByContinuity below), never as
  // the primary sort signal, since it silently goes wrong for any
  // airport missing from AIRPORT_LON (falls back to offset 0/UTC, which
  // can flip two legs' relative order without any obvious sign it did).
  function utcDepartureKey(ddmon, timeTok, originIata, referenceNow) {
    const m = ddmon.match(/^(\d{2})([A-Z]{3})$/);
    if (!m) return Number.MAX_SAFE_INTEGER;
    const day = parseInt(m[1], 10);
    const month = MONTH_MAP[m[2].toUpperCase()];
    if (month === undefined) return Number.MAX_SAFE_INTEGER;
    const year = inferYear(month, day, referenceNow);
    const { hh, mm } = parseSabreTime(timeTok);
    const offset = estimateUtcOffset(originIata);
    return Date.UTC(year, month, day, hh - offset, mm, 0, 0);
  }

  function stripPrompt(line) {
    return line.replace(/^[\u276F>]\s*/, ''); // "❯ " or "> " terminal prompt prefix
  }

  // Marker-position based splitting — tolerant of *IA/VI* appearing in
  // EITHER order, glued onto the end of a previous line with no line
  // break, and a stray junk character sometimes attached right after the
  // marker (seen: "VI*\u00AB" / "*IA\u00AB" from some copy paths). Scanning
  // the whole text for marker positions handles all of this in one pass,
  // instead of assuming *IA always comes first on its own clean line.
  function splitByMarkers(rawText) {
    const text = rawText.split(/\r?\n/).map(stripPrompt).join('\n');
    // "*I" is accepted as *IA (both are valid Sabre entries); the
    // lookahead stops "*IST-JFK OPERATED BY…" style lines matching.
    const markerRe = /(\*IA?(?![A-Z])|VI\*|\*VI)[\u00ab\u00bb]?/g; // "*VI" accepted as VI*
    const matches = [];
    let m;
    while ((m = markerRe.exec(text))) {
      const t = m[1] === '*VI' ? 'VI*' : (m[1].startsWith('*I') ? '*IA' : m[1]);
      matches.push({ type: t, end: markerRe.lastIndex, index: m.index });
    }
    const sections = [];
    for (let i = 0; i < matches.length; i++) {
      const start = matches[i].end;
      const end = i + 1 < matches.length ? matches[i + 1].index : text.length;
      sections.push({ type: matches[i].type, content: text.slice(start, end) });
    }
    return sections;
  }

  function parseIaLines(content) {
    return content.split('\n').filter((l) => /^\s*\d+\s+/.test(l));
  }

  function parseViChunks(content) {
    const lines = content.split('\n').filter((l) => !/^\s*FLIGHT\s+DATE\s+SEGMENT/i.test(l));
    const chunks = [];
    let cur = null;
    for (const l of lines) {
      if (/^\s*\d+\s+/.test(l)) {
        if (cur) chunks.push(cur);
        cur = [l];
      } else if (cur) {
        if (l.trim() !== '') cur.push(l);
      }
    }
    if (cur) chunks.push(cur);
    return chunks;
  }

  // Parses one "*IA" section paired with its matching "VI*" section (the
  // segment's FLIGHT row plus every continuation line under it — DEP/ARR
  // TERMINAL, operated-by, alliance, CABIN-x) by position within the pair.
  function parseBlock(iaContent, viContent, referenceNow) {
    const iaLines = parseIaLines(iaContent);
    const viChunks = parseViChunks(viContent);
    const legs = [];
    for (let idx = 0; idx < iaLines.length; idx++) {
      const iaMatch = iaLines[idx].match(/^\s*\d+\s+(.*)$/);
      if (!iaMatch) continue;
      const iaRest = iaMatch[1].replace(/\s+$/, '');

      const carrierMatch = iaRest.match(/^([A-Z0-9]{2})/);
      const carrier = carrierMatch ? carrierMatch[1] : '';
      const dateMatch = iaRest.match(/(\d{2}[A-Z]{3})/);
      const timeMatches = iaRest.match(/\b\d{3,4}[AP]\b/g) || [];
      const routeMatch = iaRest.match(/\d{2}[A-Z]{3}\s+[A-Z]\s+([A-Z]{3})([A-Z]{3})\s/);
      const origin = routeMatch ? routeMatch[1] : null;
      const destination = routeMatch ? routeMatch[2] : null;

      const sortKey = (dateMatch && timeMatches.length)
        ? utcDepartureKey(dateMatch[1], timeMatches[0], origin, referenceNow)
        : Number.MAX_SAFE_INTEGER;

      const viChunk = viChunks[idx];
      const viFirstLine = viChunk ? viChunk[0].replace(/^\s*\d+\s+/, '') : '';
      const viOtherLines = viChunk ? viChunk.slice(1) : [];

      legs.push({ iaRest, carrier, origin, destination, sortKey, viFirstLine, viOtherLines });
    }
    return legs;
  }

  // Splits the raw text into *IA/VI* section pairs (in whichever order
  // they appear) and parses each pair into legs. referenceNow is
  // resolved once here (a single quick peek at the CRM's own clock)
  // rather than once per leg, since it can't meaningfully change
  // between legs parsed from the same paste.
  // When the VI* / *I header lines weren't pasted, find each section by
  // what its lines look like and put the markers back in front of them.
  //   *I line:  " 1 DL3161Y 08MAY J ORDBOS SS1  1010A  136P /E"
  //   VI line:  " 1 DL 3161 08MAY ORD BOS 1010A  136P ..."  (or the FLIGHT header)
  function addMissingMarkers(rawText) {
    const lines = String(rawText || '').split(/\r?\n/).map(stripPrompt);
    const IA_RE = /^\s*\d+\s+[A-Z0-9]{2}\s*\d{1,5}[A-Z]\s+\d{2}[A-Z]{3}\s+[A-Z]\s+[A-Z]{6}\s/;
    const VI_RE = /^\s*(FLIGHT\s+DATE\s+SEGMENT|\d+\s+[A-Z0-9]{2}[\s*]*\d{1,5}\s+\d{2}[A-Z]{3}\s+[A-Z]{3}\s+[A-Z]{3}\s)/i;
    const ia = lines.findIndex((l) => IA_RE.test(l));
    const vi = lines.findIndex((l) => VI_RE.test(l));
    if (ia < 0 || vi < 0) return rawText;
    const out = lines.slice();
    // Insert the later one first so the earlier index stays right.
    if (ia > vi) { out.splice(ia, 0, '*I'); out.splice(vi, 0, 'VI*'); }
    else { out.splice(vi, 0, 'VI*'); out.splice(ia, 0, '*I'); }
    return out.join('\n');
  }

  function parseRawSegments(rawText) {
    const referenceNow = getReferenceNow();
    let sections = splitByMarkers(rawText);
    if (sections.length < 2) sections = splitByMarkers(addMissingMarkers(rawText));
    const legs = [];
    for (let i = 0; i < sections.length; i += 2) {
      const a = sections[i];
      const b = sections[i + 1];
      if (!a || !b) break;
      const iaSection = a.type === '*IA' ? a : (b.type === '*IA' ? b : null);
      const viSection = a.type === 'VI*' ? a : (b.type === 'VI*' ? b : null);
      if (!iaSection || !viSection) continue;
      legs.push(...parseBlock(iaSection.content, viSection.content, referenceNow));
    }
    return legs;
  }

  // Orders legs by flight CONTINUITY — leg N+1 departs from wherever leg
  // N arrived — rather than by comparing each leg's own local clock time
  // in isolation. Local-time comparison alone breaks the moment one leg's
  // airport isn't in AIRPORT_LON (silently falls back to a UTC offset of
  // 0), which can flip two legs' relative order with no obvious sign it
  // happened. Continuity has no such failure mode: it only needs matching
  // airport CODES, never timezone data, for anything actually connected.
  // Date/time is used only as a tie-breaker — to pick where to "cut" a
  // closed loop open (a round trip that returns to its starting city has
  // no leg without a predecessor), and to order separate, unconnected
  // chains relative to each other.
  function reorderByContinuity(legs) {
    // CHRONOLOGICAL order first: every leg sorted by its departure
    // date/time (estimated UTC, so a Sydney vs San Francisco departure
    // compare correctly). The old continuity-first ordering welded any
    // route loop together (e.g. SEA-BCN 15MAY, BCN-LHR 28MAY, LHR-SEA
    // 28MAY) and pushed a leg dated in between (CDG-CAI 17MAY) after it.
    // Continuity is now only a local repair: two neighbouring legs less
    // than ~30h apart are swapped when the later one clearly feeds the
    // earlier one (its arrival = the other's departure) and not the other
    // way round — that covers a time-zone estimate that's off by a few
    // hours for an airport missing from AIRPORT_LON. Legs with no
    // readable date keep their pasted order at the end.
    const out = legs.map((leg, i) => ({ leg, i }))
      .sort((a, b) => (a.leg.sortKey - b.leg.sortKey) || (a.i - b.i))
      .map((x) => x.leg);
    const NEAR = 30 * 3600 * 1000;
    for (let pass = 0; pass < out.length; pass++) {
      let changed = false;
      for (let k = 0; k + 1 < out.length; k++) {
        const a = out[k], b = out[k + 1];
        if (a.sortKey === Number.MAX_SAFE_INTEGER || b.sortKey === Number.MAX_SAFE_INTEGER) continue;
        if (Math.abs(b.sortKey - a.sortKey) >= NEAR) continue;
        const aFeedsB = a.destination && a.destination === b.origin;
        const bFeedsA = b.destination && b.destination === a.origin;
        if (bFeedsA && !aFeedsB) { out[k] = b; out[k + 1] = a; changed = true; }
      }
      if (!changed) break;
    }
    return out;
  }

  function buildMerged(legs) {
    const sorted = reorderByContinuity(legs);
    const iaLines = sorted.map((leg, idx) => `${String(idx + 1).padStart(2, ' ')} ${leg.iaRest}`);
    const viLines = ['   FLIGHT  DATE  SEGMENT DPTR  ARVL    MLS  EQP  ELPD MILES SM'];
    // Sabre ends the VI section with a "." on its last line. Take it off
    // whichever leg had it and put it back on the very last line, so it
    // doesn't end up in the middle after sorting.
    let hadEndDot = false;
    sorted.forEach((leg, idx) => {
      const other = leg.viOtherLines.map((l) => {
        if (/\.\s*$/.test(l) && /^[A-Z-]+\.\s*$/.test(l.trim())) { hadEndDot = true; return l.replace(/\.(\s*)$/, '$1'); }
        return l;
      });
      viLines.push(`${String(idx + 1).padStart(2, ' ')} ${leg.viFirstLine}`);
      viLines.push(...other);
    });
    if (hadEndDot && viLines.length > 1) viLines[viLines.length - 1] = viLines[viLines.length - 1].replace(/\s*$/, '') + '.';
    // Same layout agents paste from the Sabre terminal: VI* first, then *I.
    return `VI*\n${viLines.join('\n')}\n\n*I\n${iaLines.join('\n')}`;
  }

  function detectCarrier(legs) {
    const counts = {};
    legs.forEach((leg) => { if (leg.carrier) counts[leg.carrier] = (counts[leg.carrier] || 0) + 1; });
    let best = null, bestCount = 0;
    for (const [code, count] of Object.entries(counts)) {
      if (count > bestCount) { best = code; bestCount = count; }
    }
    return best;
  }

  // Hidden BO "send to lead" worker frame (see the Send to lead section).
  const IN_WORKER_FRAME = window.top !== window && /^jsworker-/.test(window.name || '');

  // Chrome slows plain timers in a background tab to once a second (once
  // a MINUTE after 5 minutes hidden) — that's what made Send to lead
  // crawl. Timers inside a tiny Web Worker aren't slowed, so waits use
  // that whenever this page is hidden.
  let fastTimer;
  let fastTimerOk = false;
  // Fallback when no worker: message-loop until the time is up. Messages
  // aren't slowed in background tabs. Only used for the short waits.
  function spinWait(ms, resolve) {
    const end = performance.now() + ms;
    const ch = new MessageChannel();
    ch.port1.onmessage = () => { if (performance.now() >= end) { ch.port1.close(); resolve(); } else ch.port2.postMessage(0); };
    ch.port2.postMessage(0);
  }
  function getFastTimer() {
    if (fastTimer !== undefined) return fastTimer;
    fastTimer = null;
    try {
      const src = 'onmessage=function(e){setTimeout(function(){postMessage(e.data.id)},e.data.ms)}';
      const w = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
      const pending = new Map();
      let seq = 0;
      w.onmessage = (e) => { if (e.data === -1) { fastTimerOk = true; return; } const f = pending.get(e.data); if (f) { pending.delete(e.data); f(); } };
      w.onerror = () => { fastTimer = null; pending.forEach((f) => setTimeout(f, 0)); pending.clear(); };
      fastTimer = (fn, ms) => { const id = ++seq; pending.set(id, fn); w.postMessage({ id, ms }); };
      w.postMessage({ id: -1, ms: 0 }); // proves the worker really runs (a CSP can block it)
    } catch (e) { fastTimer = null; }
    return fastTimer;
  }

  function wait(ms) {
    return new Promise((resolve) => {
      if (!(document.hidden || IN_WORKER_FRAME) || ms > 1500) { setTimeout(resolve, ms); return; }
      const ft = getFastTimer();
      if (ft && fastTimerOk) ft(resolve, ms); else spinWait(ms, resolve);
    });
  }

  // In the hidden worker frame a real .focus() would pull keyboard focus
  // out of whatever you're typing in — so there it only fires the events.
  function softFocus(el) {
    if (!el) return;
    if (IN_WORKER_FRAME) {
      el.dispatchEvent(new FocusEvent('focus'));
      el.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
    } else {
      el.focus();
    }
  }

  // ---- Make the hidden worker frame run at full speed ---------------
  // Chrome treats a page in a background tab very differently from one
  // on screen: timers are slowed to once a second (or once a MINUTE),
  // animation frames stop completely, and the page reports itself as
  // hidden (apps often hold work until it's visible again). That's why
  // the BO only got going once you switched to its tab. Inside the
  // hidden worker frame only, the BO is made to believe it's on screen
  // and gets timers that aren't slowed down.
  if (IN_WORKER_FRAME) {
    try {
      const W = unsafeWindow;
      const D = W.document;
      // 1. "You're visible and focused."
      const def = (o, k, v) => { try { Object.defineProperty(o, k, { configurable: true, get: () => v }); } catch (e) { /* ignore */ } };
      def(D, 'hidden', false);
      def(D, 'visibilityState', 'visible');
      def(D, 'webkitHidden', false);
      def(D, 'webkitVisibilityState', 'visible');
      try { D.hasFocus = () => true; } catch (e) { /* ignore */ }
      // Swallow the real "you're hidden now" events.
      const stopHidden = (e) => { if (e.isTrusted) e.stopImmediatePropagation(); };
      D.addEventListener('visibilitychange', stopHidden, true);
      W.addEventListener('blur', stopHidden, true);
      W.addEventListener('pagehide', stopHidden, true);
      W.addEventListener('freeze', stopHidden, true);

      // 2. Unthrottled timers, run from a tiny Web Worker.
      const src = 'var t={};onmessage=function(e){var d=e.data;if(d.op==="c"){clearTimeout(t[d.id]);clearInterval(t[d.id]);delete t[d.id];return;}'
        + 'if(d.op==="i"){t[d.id]=setInterval(function(){postMessage(d.id)},d.ms);}else{t[d.id]=setTimeout(function(){delete t[d.id];postMessage(d.id)},d.ms);}}';
      const tw = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
      const tasks = new Map();
      let seq = 1e8; // well clear of the browser's own timer ids
      tw.onmessage = (e) => {
        const t = tasks.get(e.data);
        if (!t) return;
        if (!t.repeat) tasks.delete(e.data);
        try { t.fn.apply(W, t.args); } catch (err) { setTimeout(() => { throw err; }, 0); }
      };
      const nST = W.setTimeout.bind(W);
      const nSI = W.setInterval.bind(W);
      const nCT = W.clearTimeout.bind(W);
      const nCI = W.clearInterval.bind(W);
      let workerOk = false;
      tw.postMessage({ op: 't', id: 0, ms: 0 });
      tasks.set(0, { fn: () => { workerOk = true; }, args: [] });
      const add = (repeat) => function (fn, ms, ...args) {
        if (typeof fn !== 'function' || !workerOk) return (repeat ? nSI : nST)(fn, ms, ...args);
        const id = ++seq;
        tasks.set(id, { fn, args, repeat });
        tw.postMessage({ op: repeat ? 'i' : 't', id, ms: Math.max(0, +ms || 0) });
        return id;
      };
      const clear = (native) => function (id) {
        if (tasks.has(id)) { tasks.delete(id); tw.postMessage({ op: 'c', id }); } else native(id);
      };
      W.setTimeout = add(false);
      W.setInterval = add(true);
      W.clearTimeout = clear(nCT);
      W.clearInterval = clear(nCI);
      // 3. Animation frames (which never fire in a hidden tab) ~60fps.
      W.requestAnimationFrame = (cb) => W.setTimeout(() => cb(W.performance.now()), 16);
      W.cancelAnimationFrame = (id) => W.clearTimeout(id);
      // Wake anything that was waiting to become visible.
      nST(() => { try { D.dispatchEvent(new Event('visibilitychange')); W.dispatchEvent(new Event('focus')); } catch (e) { /* ignore */ } }, 0);
    } catch (e) { /* keep the BO as it is */ }
  }

  // The worker frame is a full second copy of the BO: keep it silent.
  if (IN_WORKER_FRAME) {
    try {
      const W = unsafeWindow;
      W.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
      if (W.AudioContext) W.AudioContext.prototype.resume = function () { return Promise.resolve(); };
      if (W.Notification) {
        const N = function () { return { close() {}, addEventListener() {} }; };
        N.permission = 'denied';
        N.requestPermission = () => Promise.resolve('denied');
        W.Notification = N;
      }
    } catch (e) { /* ignore */ }
  }

  function setNativeValue(el, value) {
    const proto = Object.getPrototypeOf(el);
    const setter = (Object.getOwnPropertyDescriptor(proto, 'value') || {}).set
      || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
      || Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    setter.call(el, value);
  }

  // ------------------------------------------------------------------
  // Vue multiselect carrier field — the option list is fully rendered in
  // the DOM up front (confirmed from the page's own HTML: even obscure
  // carriers show up before anything is typed), so the match can be
  // found directly by aria-label rather than needing to replicate the
  // visual search-filter behavior. Still opens the dropdown the way a
  // real click/focus would first, in case the click handler expects
  // that state.
  // ------------------------------------------------------------------
  // Reads whatever's currently DISPLAYED as selected in this multiselect
  // (not what's in the hidden options dropdown) — clones the wrapper,
  // strips the dropdown out of the clone, and reads what visible text
  // remains, plus the search input's own value (inputs don't contribute
  // to textContent). Doesn't need to know this component's exact class
  // name for "currently selected label" — whatever renders there when
  // something's selected shows up either way.
  function currentMultiselectDisplay(wrapper, input) {
    const clone = wrapper.cloneNode(true);
    const dropdown = clone.querySelector('.form-multiselect-dropdown');
    if (dropdown) dropdown.remove();
    const visibleText = (clone.textContent || '').trim();
    return (visibleText + ' ' + (input.value || '')).trim();
  }

  async function selectCarrier(modalRoot, carrierCode) {
    if (!carrierCode) return false;
    const input = modalRoot.querySelector('.form-multiselect-search');
    if (!input) return false;
    const wrapper = input.closest('.form-multiselect');
    if (!wrapper) return false;

    // Skip the whole select flow if this carrier is already the one
    // shown selected — re-clicking through to select the SAME value
    // still fires this component's real selection interactions, which
    // very plausibly triggers the site's own "carrier changed"
    // handling even when nothing actually changed. That's fine (even
    // wanted) the first time a fresh option is built from empty, but
    // Sort Me calls this unconditionally on every click — so editing or
    // duplicating an option that already has its carrier correctly set
    // was re-triggering that handling on every single Sort Me press,
    // which is the likely cause of the segments field getting reset
    // right back to what it was before.
    const already = currentMultiselectDisplay(wrapper, input);
    if (new RegExp('\\b' + carrierCode + '\\b', 'i').test(already)) {
      return true;
    }

    softFocus(input);
    input.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    input.click();

    setNativeValue(input, carrierCode);
    input.dispatchEvent(new Event('input', { bubbles: true }));

    const re = new RegExp('^' + carrierCode + '\\s*-', 'i');
    for (let attempt = 0; attempt < 15; attempt++) {
      await wait(100);
      const options = wrapper.querySelectorAll('.form-multiselect-option');
      const match = Array.from(options).find((li) =>
        re.test((li.getAttribute('aria-label') || li.textContent || '').trim())
      );
      if (match) {
        match.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        match.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
        match.click();
        return true;
      }
    }
    return false;
  }

  // ------------------------------------------------------------------
  // PCC / ticketing-agency multiselect — same underlying Vue multiselect
  // component as the carrier field above (form-multiselect /
  // form-multiselect-search / form-multiselect-option), but this later
  // step of the modal has three of these side by side (Fare type,
  // Tkt. type, and PCC all share the exact same wrapper classes, so
  // there's no CSS selector that picks PCC out from Fare type alone —
  // Tkt. type at least gets an extra "form-multiselect--multiple"
  // class, but the other two are identical).
  //
  // The full markup confirms every one of the three renders its whole
  // <li> option list into the DOM up front — just hidden behind an
  // "is-hidden" class on the dropdown, not actually absent — the same
  // as the carrier field. That means the right wrapper can be found by
  // reading each one's already-present options directly, with nothing
  // opened yet, rather than opening each multiselect in turn just to
  // inspect it (which is what made this visibly flick through Fare
  // type and Tkt. type first before landing on PCC). Once found, only
  // that one field ever gets opened.
  //
  // Match on each <li>'s inner <span> text, not its own aria-label:
  // the currently-selected option's aria-label gets a "✓ " prefix
  // added (aria-label="✓ 10XH"), which would stop matching the moment
  // 10XH becomes the selected value — the <span> stays plain "10XH"
  // regardless of selection state.
  // ------------------------------------------------------------------
  function findMultiselectOption(wrapper, code) {
    return Array.from(wrapper.querySelectorAll('.form-multiselect-option')).find((li) => {
      const label = (li.querySelector('span')?.textContent || li.textContent || '').trim();
      return label.toUpperCase() === code.toUpperCase();
    });
  }

  async function selectPcc(modalRoot, pccCode) {
    if (!pccCode) return false;
    const wrappers = Array.from(modalRoot.querySelectorAll('.form-multiselect'));
    const wrapper = wrappers.find((w) => findMultiselectOption(w, pccCode));
    if (!wrapper) return false;

    const input = wrapper.querySelector('.form-multiselect-search');
    if (!input) return false;

    softFocus(input);
    input.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    input.click();

    let match = null;
    for (let attempt = 0; attempt < 10; attempt++) {
      await wait(100);
      match = findMultiselectOption(wrapper, pccCode);
      if (match) break;
    }
    if (!match) return false;

    match.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    match.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    match.click();
    return true;
  }

  function flashButtonLabel(btn, text, revertTo) {
    btn.textContent = text;
    setTimeout(() => { btn.textContent = revertTo; }, 1400);
  }

  // ------------------------------------------------------------------
  // Auto-next — finds the primary "Next" button fresh each time rather
  // than reusing a stored reference, since the modal's own step-change
  // likely tears down and re-renders this markup between the two clicks
  // (same reasoning as re-detecting the modal itself on every open).
  // ------------------------------------------------------------------
  const AUTO_NEXT_STORAGE_KEY = 'gds-crm-auto-next-enabled';

  // This agency's fixed PCC / ticketing code — auto-pcc always selects
  // this one, the same way auto-carrier always aims at whatever carrier
  // the parsed legs say, except this value doesn't come from the
  // itinerary at all (PCC is tied to the agency, not the flight), so
  // it's just a constant here rather than something detected per-quote.
  const AUTO_PCC_CODE = '10XH';

  function findNextButton() {
    return Array.from(document.querySelectorAll('button.btn-primary'))
      .find((b) => b.textContent.trim().toLowerCase() === 'next');
  }

  // Polls for the Next button rather than grabbing it on the first try.
  // Right before this runs, Sort Me has just dispatched input/change on
  // the textarea and clicked through the carrier multiselect — Vue's own
  // reactivity (re-validating the form, enabling the button) needs a
  // tick to catch up with that, and grabbing a still-disabled button
  // immediately produces a click that does nothing, which is
  // indistinguishable from "auto-next isn't running" from the outside.
  // Skipping a disabled match and trying again fixes that without
  // guessing a single fixed delay that may not always be enough.
  async function findNextButtonReady(maxAttempts = 15, delayMs = 150) {
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      const btn = findNextButton();
      if (btn && !btn.disabled) return btn;
      await wait(delayMs);
    }
    return findNextButton(); // last-ditch: click whatever exists, even if still disabled
  }

  async function clickNextTwice(modalRoot) {
    const first = await findNextButtonReady();
    if (!first) return;
    first.click();
    await wait(400);
    const second = await findNextButtonReady();
    if (second) second.click();

    // Give the next step's own fields (PCC / Tkt. type multiselects)
    // time to actually render before trying to find and open them.
    await wait(500);
    if (modalRoot) await selectPcc(modalRoot, AUTO_PCC_CODE);
  }

  async function maybeAutoNext(modalRoot, autoNextCheckbox, legs) {
    if (autoNextCheckbox && autoNextCheckbox.checked && legs.length) {
      await clickNextTwice(modalRoot);
    }
  }

  // When auto-next is OFF, Sort Me should hand focus back to the
  // segments box instead of leaving it sitting in the carrier
  // multiselect's search input — mirrors what pressing Tab twice does
  // by hand on this modal. A short wait first lets that multiselect's
  // own post-selection focus handling settle, so a direct .focus() call
  // isn't immediately stolen back by it. Re-queries the textarea fresh
  // rather than reusing an old reference, in case Vue re-rendered it.
  // The two synthetic Tab keydowns are a fallback for the (less likely,
  // but possible) case where it's the app's own JS-driven tab handling —
  // not a direct focus target — that's actually moving focus here;
  // real browser Tab-navigation itself ignores untrusted synthetic
  // events, so this can only help if the app is listening for the key
  // itself, and does nothing if the direct focus() above already worked.
  async function returnFocusToSegmentsBox(modalRoot) {
    await wait(150);
    const ta = modalRoot.querySelector('textarea.font-robotoMono');
    if (ta) {
      ta.focus();
      return;
    }
    const active = document.activeElement || document.body;
    for (let i = 0; i < 2; i++) {
      active.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', code: 'Tab', bubbles: true }));
      active.dispatchEvent(new KeyboardEvent('keyup', { key: 'Tab', code: 'Tab', bubbles: true }));
    }
  }

  // ------------------------------------------------------------------
  // GDS TERMINAL — "paste a flight list, get it built on the terminal"
  //
  // Own, duplicated copy of the *IA/VI* build engine (buildIALine,
  // buildVILines, buildBoth, equipCode, lookupDistance, etc.) — the
  // "real" copy lives in Part 1, but Part 1 deliberately bails out
  // immediately on any page outside its own flight-search-site list
  // (see the early-exit guard at the top of this file), which includes
  // this CRM's own domain. So Part 1's copy never gets defined here to
  // share. Duplicating just this output-building slice (not the whole
  // file) keeps that early-exit optimization intact while still giving
  // this half everything it needs to build full GDS output on its own.
  // Reuses MONTH_MAP, AIRPORT_LON, estimateUtcOffset, inferYear, and
  // getReferenceNow already declared above for Sort Me — no need to
  // duplicate those too.
  // ------------------------------------------------------------------
  const CONFIG = {
    STATUS_CODE: "GK", ETKT_SUFFIX: "/E", SM_FLAG: "N", DEFAULT_MEAL_CODE: "M",
    DEFAULT_BOOKING_BY_CABIN: { y: "Y", w: "W", s: "S", p: "W", e: "Y", j: "J", b: "D", f: "F" },
    CABIN_NAME: { y: "ECONOMY", w: "PREMIUM ECONOMY", s: "PREMIUM ECONOMY", p: "PREMIUM ECONOMY", j: "BUSINESS", b: "BUSINESS", f: "FIRST", e: "ECONOMY", c: "BUSINESS" },
  };

  // Premium economy class letter for carriers that don't use W.
  const PREMIUM_CLASS_BY_CARRIER = { PR: 'N' };
  function bookingClass(leg) {
    if (leg.bookingCode) return leg.bookingCode;
    if (leg.cabin === 'w' && leg.airline && PREMIUM_CLASS_BY_CARRIER[leg.airline.code]) return PREMIUM_CLASS_BY_CARRIER[leg.airline.code];
    return CONFIG.DEFAULT_BOOKING_BY_CABIN[leg.cabin] || 'Y';
  }

  function buildIALine(leg, idx, pax) {
    const depD = parseLocal(leg.departure);
    const arrD = parseLocal(leg.arrival);
    const num = String(idx + 1).padStart(2, ' ');
    const carrierFlight = leg.airline.code + String(leg.operatingFlightNumber || leg.flightNumber).padStart(4, ' ');
    const cls = bookingClass(leg);
    const date = formatDate(depD);
    const dow = dowLetter(depD);
    const route = leg.origin.iata + leg.destination.iata;
    const status = `${CONFIG.STATUS_CODE}${pax}`;
    const dep = formatTime(depD).padStart(5, ' ');
    const arr = formatTime(arrD).padStart(5, ' ');

    let rolloverSuffix = '';
    if (!sameCalendarDate(depD, arrD)) {
      rolloverSuffix = `  ${formatDate(arrD)} ${dowLetter(arrD)}`;
    }

    return `${num} ${carrierFlight}${cls} ${date} ${dow} ${route} ${status}  ${dep} ${arr}${rolloverSuffix} ${CONFIG.ETKT_SUFFIX}`;
  }

  function buildVILines(leg, idx) {
    const depD = parseLocal(leg.departure);
    const arrD = parseLocal(leg.arrival);
    const num = String(idx + 1).padStart(2, ' ');

    // A codeshare (operating carrier differs from the marketing carrier
    // shown) is marked by replacing the flight-number field's leading pad
    // space with "*" — e.g. "TP*8559" instead of "TP 8559" — with a
    // "*ORIGIN-DEST OPERATED BY <airline>" line underneath. Only rendered
    // when an adapter actually supplies operatingCarrierCode; none do yet,
    // since none of the sites expose it per-segment in a verified way.
    const flightNumStr = String(leg.operatingFlightNumber || leg.flightNumber);
    const isCodeshare = leg.operatingCarrierCode && leg.operatingCarrierCode !== leg.airline.code;
    const carrierFlight = isCodeshare
      ? leg.airline.code + '*' + flightNumStr.padStart(4, ' ')
      : leg.airline.code + flightNumStr.padStart(5, ' ');

    const date = formatDate(depD);
    const segment = `${leg.origin.iata} ${leg.destination.iata}`;
    const dep = formatTime(depD).padStart(5, ' ');
    const arr = formatTime(arrD).padStart(5, ' ');
    const dayDiff = daysBetween(depD, arrD);
    // Positive dayDiff (arrival lands a day+ later) shows "¥N"; negative
    // (arrival lands a day EARLIER — routes crossing the date line
    // westbound, e.g. Taipei to San Francisco, commonly do this) shows
    // "-N". Same 3-character field width either way.
    let rolloverField;
    if (dayDiff > 0) rolloverField = `\u00a5${dayDiff} `;
    else if (dayDiff < 0) rolloverField = `${dayDiff} `;
    else rolloverField = '   ';
    const meal = leg.mealCode || CONFIG.DEFAULT_MEAL_CODE;
    const eqp = equipCode(leg).padStart(3, ' ');
    const elp = elapsed(leg.duration);
    const distance = leg.distance != null ? leg.distance : lookupDistance(leg.origin.iata, leg.destination.iata);
    const miles = distance != null ? String(distance).padStart(4, ' ') : '    ';

    const row = `${num} ${carrierFlight} ${date} ${segment} ${dep} ${arr}${rolloverField}${meal}    ${eqp}  ${elp}  ${miles}  ${CONFIG.SM_FLAG}`;

    const extraLines = [];
    const termParts = [];
    if (leg.departureTerminal) termParts.push(`DEP-TERMINAL ${leg.departureTerminal}`);
    if (leg.arrivalTerminal) termParts.push(`ARR-TERMINAL ${leg.arrivalTerminal}`);
    if (termParts.length) extraLines.push(termParts.join('                 '));

    if (isCodeshare) {
      extraLines.push(`*${leg.origin.iata}-${leg.destination.iata} OPERATED BY ${(leg.operatingCarrierName || leg.operatingCarrierCode).toUpperCase()}`);
    }

    const alliance = ALLIANCE_MAP[leg.airline.code];
    if (alliance) extraLines.push(alliance);

    const cabinName = CONFIG.CABIN_NAME[(leg.cabin || '').toLowerCase()] || (leg.cabin || '').toUpperCase();
    if (cabinName) extraLines.push(`CABIN-${cabinName}`);

    return [row, ...extraLines];
  }

  function buildBoth(itinerary) {
    const pax = itinerary.pax || 1;
    const allLegs = itinerary.flights.flatMap((f) => f.legs);
    const iaText = allLegs.map((leg, i) => buildIALine(leg, i, pax)).join('\n');
    const viText = [VI_HEADER, ...allLegs.flatMap((leg, i) => buildVILines(leg, i))].join('\n');
    return `*IA\n${iaText}\n\nVI*\n${viText}`;
  }

  // ------------------------------------------------------------------
  // Flight-list format parser — e.g.:
  //   1   DL*5262   D 21SEP   MCI JFK   1219P 425P
  //   2   DL 246    D 21SEP   JFK KEF   1155P 930A¥1
  // Works on flattened single-line text just as well as real multi-line
  // text — a plain <input> strips real newlines on paste, and this
  // scans for the repeating row pattern directly rather than splitting
  // on line breaks, so it doesn't care either way.
  //
  // The "*" between carrier and flight number (vs a plain space) is
  // parsed but NOT treated as a codeshare/operated-by signal — the list
  // gives no actual operating-carrier data, and fabricating an
  // "OPERATED BY" line from a guess would be worse than leaving it out.
  //
  // No duration is given, so it's computed from the AIRPORT_LON-based
  // UTC offset estimate already used by Sort Me's own sorting (see
  // above) — leg.departure/leg.arrival themselves stay as naive local
  // wall-clock Date objects for correct display (buildIALine reads
  // getHours()/getMinutes() straight off them), only the separately
  // computed `duration` number needs the timezone awareness.
  //
  // The class letter (single letter like "D") is mapped to a cabin
  // using common industry convention (F/A/P=first, J/C/D/I/Z/R=business,
  // W/E=premium economy, everything else=economy) — this isn't
  // universal across every carrier, just a reasonable default.
  // ------------------------------------------------------------------
  const CLASS_LETTER_TO_CABIN = {
    F: 'f', A: 'f', P: 'f',
    J: 'j', C: 'j', D: 'j', I: 'j', Z: 'j', R: 'j',
    W: 'w', E: 'w',
    Y: 'y', B: 'y', H: 'y', K: 'y', L: 'y', M: 'y', N: 'y', Q: 'y', S: 'y', T: 'y', U: 'y', V: 'y', X: 'y', G: 'y', O: 'y',
  };

  const FLIGHT_LIST_ROW_RE = /(\d+)\s+([A-Z0-9]{2})(\*|\s+)(\d{1,4})\s+([A-Z])\s+(\d{2}[A-Z]{3})\s+([A-Z]{3})\s+([A-Z]{3})\s+(\d{3,4}[AP])\s+(\d{3,4}[AP])(\u00a5\d+|-\d+)?/g;

  function looksLikeFlightList(text) {
    FLIGHT_LIST_ROW_RE.lastIndex = 0;
    return FLIGHT_LIST_ROW_RE.test(text);
  }

  function parseFlightListFormat(text, referenceNow) {
    const rows = [];
    let m;
    FLIGHT_LIST_ROW_RE.lastIndex = 0;
    while ((m = FLIGHT_LIST_ROW_RE.exec(text))) {
      const [, , carrier, , flightNum, classLetter, ddmon, origin, dest, depTok, arrTok, rollover] = m;
      const dm = ddmon.match(/^(\d{2})([A-Z]{3})$/);
      const day = parseInt(dm[1], 10);
      const month = MONTH_MAP[dm[2]];
      if (month === undefined) continue;
      const year = inferYear(month, day, referenceNow);

      const dep = parseSabreTime(depTok);
      const departure = new Date(year, month, day, dep.hh, dep.mm, 0, 0);

      const arr = parseSabreTime(arrTok);
      let arrDayOffset = 0;
      if (rollover) {
        const n = parseInt(rollover.slice(1), 10);
        arrDayOffset = rollover[0] === '\u00a5' ? n : -n;
      }
      const arrival = new Date(year, month, day + arrDayOffset, arr.hh, arr.mm, 0, 0);

      const depOffset = estimateUtcOffset(origin);
      const arrOffset = estimateUtcOffset(dest);
      const depUtcMs = Date.UTC(year, month, day, dep.hh - depOffset, dep.mm);
      const arrUtcMs = Date.UTC(year, month, day + arrDayOffset, arr.hh - arrOffset, arr.mm);
      const duration = Math.round((arrUtcMs - depUtcMs) / 60000);

      rows.push({
        airline: { code: carrier },
        flightNumber: flightNum,
        cabin: CLASS_LETTER_TO_CABIN[classLetter.toUpperCase()] || 'y',
        aircraft: '',
        origin: { iata: origin },
        destination: { iata: dest },
        departure,
        arrival,
        duration,
      });
    }
    return rows;
  }

  // ------------------------------------------------------------------
  // Terminal wiring — intercepts Enter on the "TYPE COMMAND HERE" input
  // in the capture phase, BEFORE the real terminal's own handler gets
  // the event, but only when the typed/pasted text actually matches the
  // flight-list format above. Anything else falls through untouched and
  // goes to the real GDS backend as normal — this only ever intercepts
  // the one specific pattern it knows how to build itself.
  // ------------------------------------------------------------------
  function injectTerminalResponse(container, commandText, responseText) {
    const outputDiv = document.createElement('div');
    outputDiv.className = 'terminal__output';
    outputDiv.style.width = '100%';
    outputDiv.style.marginTop = '0px';

    const pre = document.createElement('pre');

    const cmdSpan = document.createElement('span');
    cmdSpan.className = 'terminal-delta__command-input';
    cmdSpan.textContent = '\u276F ' + commandText + '\n';

    const respSpan = document.createElement('span');
    respSpan.textContent = responseText + '\n';

    pre.appendChild(cmdSpan);
    pre.appendChild(respSpan);
    outputDiv.appendChild(pre);
    container.appendChild(outputDiv);
    container.scrollTop = container.scrollHeight;
  }

  function wireTerminal() {
    const input = document.querySelector('input.input-field__input[placeholder="TYPE COMMAND HERE"]');
    const terminal = document.querySelector('.terminal__viewport__scrollable');
    if (!input || !terminal || input.dataset.gdsTerminalWired) return;
    input.dataset.gdsTerminalWired = '1';

    input.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const text = input.value;
      if (!looksLikeFlightList(text)) return; // not our format — let the real GDS handle it

      e.preventDefault();
      e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();

      const legs = parseFlightListFormat(text, getReferenceNow());
      const responseText = legs.length
        ? buildBoth({ flights: [{ legs }], pax: 1 })
        : 'No flights available';
      injectTerminalResponse(terminal, text, responseText);

      setNativeValue(input, '');
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }, true); // capture phase — must run before the real handler
  }

  // ------------------------------------------------------------------
  // Modal wiring — runs once per modal instance (Vue tears down and
  // recreates this markup each time the modal opens, so re-detecting on
  // every appearance is intentional, not a bug).
  // ------------------------------------------------------------------
  function wireModal(modalRoot) {
    if (modalRoot.dataset.sortMeWired) return;
    modalRoot.dataset.sortMeWired = '1';

    const footer = modalRoot.querySelector('.app-modal__footer');
    const textarea = modalRoot.querySelector('textarea.font-robotoMono');
    if (!footer || !textarea) return;

    // --- "Sort Me" button, far left, same visual theme as Cancel/Next ---
    footer.style.display = 'flex';
    footer.style.justifyContent = 'space-between';
    footer.style.alignItems = 'center';

    const sortBtn = document.createElement('button');
    sortBtn.type = 'button';
    sortBtn.className = 'btn min-w-20 px-4 btn-sm btn-outline-secondary';
    sortBtn.textContent = 'Sort Me';

    // Sort Me, plus (optionally) the passenger-count steppers, travel
    // together as one group so the steppers land immediately to Sort
    // Me's right regardless of whatever else footer.insertBefore puts
    // ahead of them.
    const sortGroup = document.createElement('div');
    sortGroup.style.cssText = 'display:flex;align-items:center;gap:6px;';
    sortGroup.appendChild(sortBtn);

    // --- Passenger-count +/- steppers, experts pages only. Bumps the
    // trailing digit on every SS/GK status code in the segments box by
    // one passenger per click (SS1 -> SS2 -> SS3 ..., same for GK),
    // clamped to a 1-9 range (a GDS PNR can't carry a 0 or 10+ pax
    // segment). Reads/writes the textarea directly rather than going
    // through parseRawSegments/buildMerged, since this only ever needs
    // to touch one status-code digit, never re-derive or reorder
    // anything else already in the box.
    // ------------------------------------------------------------------
    if (location.pathname.includes('/experts/')) {
      function currentPaxCount(text) {
        const m = text.match(/\b(?:SS|GK)(\d+)\b/);
        return m ? parseInt(m[1], 10) : 1;
      }
      function withPaxCount(text, count) {
        return text.replace(/\b(SS|GK)\d+\b/g, (_, prefix) => `${prefix}${count}`);
      }
      function bumpPax(delta) {
        const ta = modalRoot.querySelector('textarea.font-robotoMono');
        if (!ta) return;
        const current = currentPaxCount(ta.value);
        const next = Math.max(1, Math.min(9, current + delta));
        if (next === current) return;
        setNativeValue(ta, withPaxCount(ta.value, next));
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        ta.dispatchEvent(new Event('change', { bubbles: true }));
      }

      const plusBtn = document.createElement('button');
      plusBtn.type = 'button';
      plusBtn.className = 'btn min-w-8 px-3 btn-sm btn-outline-secondary';
      plusBtn.textContent = '+';
      plusBtn.title = 'Add a passenger (SS/GK +1)';
      plusBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); bumpPax(1); });

      const minusBtn = document.createElement('button');
      minusBtn.type = 'button';
      minusBtn.className = 'btn min-w-8 px-3 btn-sm btn-outline-secondary';
      minusBtn.textContent = '\u2212';
      minusBtn.title = 'Remove a passenger (SS/GK -1)';
      minusBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); bumpPax(-1); });

      sortGroup.appendChild(plusBtn);
      sortGroup.appendChild(minusBtn);
    }

    footer.insertBefore(sortGroup, footer.firstChild);

    // --- Auto-next checkbox, below the Next button ---
    const autoNextRow = document.createElement('div');
    autoNextRow.style.cssText = 'display:flex;justify-content:flex-end;margin-top:6px;width:100%;';
    autoNextRow.innerHTML = `
      <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;">
        <input type="checkbox" class="gds-auto-next-checkbox">
        Auto-next
      </label>
    `;
    footer.appendChild(autoNextRow);
    footer.style.flexWrap = 'wrap';
    const autoNextCheckbox = autoNextRow.querySelector('.gds-auto-next-checkbox');
    autoNextCheckbox.checked = localStorage.getItem(AUTO_NEXT_STORAGE_KEY) === '1';
    autoNextCheckbox.addEventListener('change', () => {
      localStorage.setItem(AUTO_NEXT_STORAGE_KEY, autoNextCheckbox.checked ? '1' : '0');
    });

    // Edit/Duplicate skips straight past the raw-text step (there's
    // nothing to paste when the segments already exist) to a structured
    // view instead — each leg as its own read-only row, not one
    // editable block of text. `textarea` above was only ever real for
    // whatever step existed at the moment this modal was first wired;
    // if the site has since moved past it, that reference is now
    // pointing at a detached piece of the page, and querying fresh from
    // modalRoot would come back empty too, since this step genuinely
    // has no textarea. Getting back uses the site's own "Edit PQ" (one
    // step in) and "Back" (two steps in) buttons — controls it already
    // provides for exactly this — rather than doing anything to the
    // auto-advance itself, which stays untouched either way.
    async function findTextareaOrNavigateBack() {
      let ta = modalRoot.querySelector('textarea.font-robotoMono');
      if (ta) return ta;
      for (let attempt = 0; attempt < 6; attempt++) {
        const buttons = Array.from(modalRoot.querySelectorAll('.app-modal__footer button'));
        const editPq = buttons.find((b) => b.textContent.trim() === 'Edit PQ');
        const back = buttons.find((b) => b.textContent.trim() === 'Back');
        if (editPq) editPq.click();
        else if (back) back.click();
        else break; // no known way back from wherever this is
        await wait(400);
        ta = modalRoot.querySelector('textarea.font-robotoMono');
        if (ta) return ta;
      }
      return null;
    }

    sortBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const ta = await findTextareaOrNavigateBack();
      if (!ta) {
        flashButtonLabel(sortBtn, 'Could not find segments box', 'Sort Me');
        return;
      }
      const legs = parseRawSegments(ta.value);
      if (!legs.length) {
        flashButtonLabel(sortBtn, 'No segments found', 'Sort Me');
        return;
      }
      const merged = buildMerged(legs);
      setNativeValue(ta, merged);
      ta.dispatchEvent(new Event('input', { bubbles: true }));
      ta.dispatchEvent(new Event('change', { bubbles: true }));

      const carrier = detectCarrier(legs);
      await selectCarrier(modalRoot, carrier);
      autoCarrierFired = true;

      flashButtonLabel(sortBtn, '\u2713 Sorted!', 'Sort Me');
      if (autoNextCheckbox && autoNextCheckbox.checked) {
        await maybeAutoNext(modalRoot, autoNextCheckbox, legs);
      } else {
        await returnFocusToSegmentsBox(modalRoot);
      }
    });

    // --- Auto-detect carrier once, the first time segments actually
    // appear in the box (paste or type), then leave the field alone —
    // this closure's own `autoCarrierFired` flag is fresh every time
    // wireModal runs, and wireModal only runs once per modal DOM
    // instance (guarded by dataset.sortMeWired above), so closing and
    // reopening the modal naturally re-arms this for one more fire.
    //
    // Auto-next runs from here too now, at explicit request — fire the
    // moment valid legs appear, without waiting for Sort Me to be
    // clicked. Worth being clear about the tradeoff this brings back:
    // for a modal opened to edit or duplicate an option, the box
    // already has valid legs the instant it opens, before anything new
    // is added, so if content gets pasted in more than one piece rather
    // than all at once, this can fire (and click Next) using whatever's
    // in the field at that moment — including content someone was still
    // in the middle of adding. That's the previous, deliberate reason
    // this was kept off here; it's back on because it was asked for
    // specifically, not because that risk stopped applying.
    let debounceTimer = null;
    let autoCarrierFired = false;
    const initialTextareaValue = textarea.value;
    textarea.addEventListener('input', () => {
      if (autoCarrierFired || sendJobActive) return;
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(async () => {
        // Also don't fire off of content that was already there when
        // the modal opened — only once it's genuinely been added to or
        // changed, so pre-filled content on an edit/duplicate open
        // can't masquerade as "the user just finished pasting."
        if (textarea.value === initialTextareaValue) return;
        const legs = parseRawSegments(textarea.value);
        if (!legs.length) return; // wait for real content before consuming the one-shot
        autoCarrierFired = true;
        const carrier = detectCarrier(legs);
        if (carrier) await selectCarrier(modalRoot, carrier);
        // Selecting the carrier moves focus onto that dropdown, leaving
        // the segments box with no cursor in it — fine if auto-next is
        // about to move past this step anyway, but if it's off, the
        // person is very likely about to paste more flights right after
        // this one, and having to click back into the box each time
        // defeats the point of pasting them "next to each other."
        // Sending focus back to the end of the existing text (not just
        // focusing it) means the next paste lands appended, not
        // dropped wherever the cursor happened to default to.
        if (!autoNextCheckbox.checked) {
          // Two newlines, same as pressing Enter twice by hand — leaves
          // a full blank line between this flight and whatever gets
          // pasted next, so the two stay visibly separated in the box
          // rather than running straight into each other. Dispatching
          // input/change here re-enters this same listener, but
          // autoCarrierFired is already true by this point, so that
          // re-entrant call just hits the early return above and does
          // nothing — same guard, doing its job a second time.
          const newValue = textarea.value + '\n\n';
          setNativeValue(textarea, newValue);
          textarea.dispatchEvent(new Event('input', { bubbles: true }));
          textarea.dispatchEvent(new Event('change', { bubbles: true }));
          textarea.focus();
          const end = newValue.length;
          textarea.setSelectionRange(end, end);
        }
        await maybeAutoNext(modalRoot, autoNextCheckbox, legs);
      }, 500);
    });
  }

  // ------------------------------------------------------------------
  // Miles / Taxes +1 / -1 steppers — pricing screen (Published/Private/
  // CK/Award tour-fare form). +1 and -1 don't add or subtract a fixed
  // step; they add or remove one PASSENGER's worth of the figure
  // originally entered. So the field's own current value isn't enough
  // state on its own — what's tracked is the per-passenger base value
  // (whatever was in the box the first time a stepper was used, or
  // right after the person last typed something new by hand) and a
  // passenger count starting at 1, and each press recomputes
  // base × count from scratch rather than nudging the displayed number
  // directly. That's what makes -1 land exactly back on a value +1 had
  // already produced, instead of drifting from rounding.
  //
  // Typing a new number directly into the field resets that base to
  // whatever was just typed (and count back to 1) — otherwise editing
  // the field by hand while a stepper still remembered an older base
  // would make the next +1/-1 jump to a stale, unrelated number.
  // ------------------------------------------------------------------
  function wireStepper(input) {
    if (!input || input.dataset.stepperWired) return;
    input.dataset.stepperWired = '1';

    const wrapper = input.closest('.relative');
    const row = input.closest('.flex.items-center');
    if (!wrapper || !row) return;

    let baseValue = null;
    let count = 1;
    let programmaticChange = false;

    function currentNumericValue() {
      const n = parseFloat(String(input.value).replace(/,/g, ''));
      return Number.isNaN(n) ? null : n;
    }

    function ensureBase() {
      if (baseValue === null) {
        const v = currentNumericValue();
        if (v === null) return false;
        baseValue = v;
        count = 1;
      }
      return true;
    }

    function applyCount() {
      programmaticChange = true;
      const next = baseValue * count;
      const rounded = Math.round(next * 100) / 100; // keep taxes' cents clean without float drift
      setNativeValue(input, String(rounded));
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      programmaticChange = false;
    }

    input.addEventListener('input', () => {
      if (programmaticChange) return;
      baseValue = null;
      count = 1;
    });

    const minusBtn = document.createElement('button');
    minusBtn.type = 'button';
    minusBtn.className = 'gds-stepper-btn';
    minusBtn.textContent = '\u2212';
    minusBtn.title = 'Remove one passenger';
    minusBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!ensureBase()) return;
      if (count > 1) count -= 1;
      applyCount();
    });

    const plusBtn = document.createElement('button');
    plusBtn.type = 'button';
    plusBtn.className = 'gds-stepper-btn';
    plusBtn.textContent = '+';
    plusBtn.title = 'Add one passenger';
    plusBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!ensureBase()) return;
      count += 1;
      applyCount();
    });

    const stepperStyle = (btn) => {
      btn.style.cssText = `
        width: 26px; height: 26px; flex: none; border-radius: 6px;
        border: 1px solid #475569; background: #1e293b; color: #e2e8f0;
        font-size: 14px; font-weight: 600; line-height: 1; cursor: pointer;
        display: inline-flex; align-items: center; justify-content: center;
        padding: 0; transition: background 0.15s, border-color 0.15s;
      `;
      btn.addEventListener('mouseenter', () => { btn.style.background = '#334155'; btn.style.borderColor = '#64748b'; });
      btn.addEventListener('mouseleave', () => { btn.style.background = '#1e293b'; btn.style.borderColor = '#475569'; });
    };
    stepperStyle(minusBtn);
    stepperStyle(plusBtn);

    row.insertBefore(minusBtn, wrapper);
    row.insertBefore(plusBtn, wrapper.nextSibling);
  }

  function wireMilesTaxesSteppers() {
    document.querySelectorAll('.form-label').forEach((label) => {
      const text = label.textContent.trim().replace(/\*$/, '').trim().toUpperCase();
      if (text !== 'MILES' && text !== 'TAXES') return;
      const wrapper = label.closest('.relative');
      const input = wrapper ? wrapper.querySelector('input') : null;
      if (input) wireStepper(input);
    });
  }

  // The Miles/Taxes rows above are now wider than before — each has a
  // stepper button sitting to the left of its input, pushing that input
  // further right than it used to be. Mile Program's row never got that
  // treatment, so it stayed put and now reads as no longer lined up
  // with the two boxes above it. Rather than guess the pixel offset a
  // button-plus-gap actually produces (that depends on this page's own
  // CSS, which isn't something to assume from outside it), measure how
  // far an already-wired Miles/Taxes input actually sits from its own
  // row's left edge, and match that same offset exactly.
  function wireMileProgramAlignment() {
    document.querySelectorAll('.form-label').forEach((label) => {
      const text = label.textContent.trim().replace(/\*$/, '').trim().toUpperCase();
      if (text !== 'MILE PROGRAM') return;
      const row = label.closest('.flex.items-center');
      if (!row || row.dataset.mileProgramAligned) return;

      const referenceInput = document.querySelector('input[data-stepper-wired]');
      if (!referenceInput) return; // steppers not wired yet — try again next scan
      const referenceRow = referenceInput.closest('.flex.items-center');
      if (!referenceRow) return;

      const offset = referenceInput.getBoundingClientRect().left - referenceRow.getBoundingClientRect().left;
      row.dataset.mileProgramAligned = '1';
      row.style.paddingLeft = offset + 'px';
    });
  }


  // ==================================================================
  // "Send to lead" worker — runs in the background BO tab that the Pip
  // popover on a flight site opens (URL carries ?jsjob=<id>). It reads
  // the lead, reports it back for the route check, then fills the BO's
  // own Add Option form (so the BO itself builds the segments) and saves.
  // ==================================================================
  let sendJobActive = false;
  const OPTION_FLAGS_KEY = 'js-option-flags';

  function jobStatus(jobId, obj) {
    try { GM_setValue('js-sendjob-status-' + jobId, JSON.stringify(Object.assign({ t: Date.now() }, obj))); } catch (e) { /* ignore */ }
  }

  // Resolves the moment fn() is truthy: re-checked on every DOM change
  // (no waiting for the next poll) plus a fast-timer poll as a backstop.
  function waitFor(fn, timeoutMs, stepMs) {
    return new Promise((resolve) => {
      let done = false;
      let mo = null;
      const finish = (v) => { if (done) return; done = true; if (mo) mo.disconnect(); resolve(v); };
      const check = () => { if (done) return; let v = null; try { v = fn(); } catch (e) { v = null; } if (v) finish(v); };
      check();
      if (done) return;
      try {
        mo = new MutationObserver(check);
        mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
      } catch (e) { mo = null; }
      const end = Date.now() + (timeoutMs || 10000);
      const step = Math.min(stepMs || 250, 200);
      const tick = () => { if (done) return; check(); if (done) return; if (Date.now() >= end) finish(null); else setTimeout(tick, step); };
      setTimeout(tick, step);
    });
  }

  // Waits for a GM value (set from another tab) without polling.
  function waitForGM(key, timeoutMs) {
    return new Promise((resolve) => {
      const read = () => { try { return JSON.parse(GM_getValue(key, 'null')); } catch (e) { return null; } };
      const now = read();
      if (now) { resolve(now); return; }
      let done = false;
      let lid = null;
      const fin = (x) => {
        if (done) return;
        done = true;
        try { if (lid != null && typeof GM_removeValueChangeListener === 'function') GM_removeValueChangeListener(lid); } catch (e) { /* ignore */ }
        resolve(x);
      };
      lid = GM_addValueChangeListener(key, () => { const x = read(); if (x) fin(x); });
      setTimeout(() => fin(read()), timeoutMs);
    });
  }

  // Switch the worker frame to another lead WITHOUT reloading the BO:
  // tell the BO's own router to go there.
  function routeToLead(leadId) {
    const path = '/leads/' + leadId;
    if (location.pathname === path) return;
    try {
      const W = unsafeWindow;
      const rootEl = W.document.querySelector('[data-v-app]') || W.document.querySelector('#app');
      const app = rootEl && rootEl.__vue_app__;
      const router = (app && app.config && app.config.globalProperties.$router) || (rootEl && rootEl.__vue__ && rootEl.__vue__.$router);
      if (router) { router.push(path); return; }
    } catch (e) { /* fall through */ }
    history.pushState(history.state, '', path);
    window.dispatchEvent(new PopStateEvent('popstate', { state: history.state }));
  }

  function readLeadCard(leadId) {
    const tag = Array.from(document.querySelectorAll('span')).find((sp) => sp.textContent.trim() === '#' + leadId);
    if (!tag) return null;
    let root = tag;
    for (let i = 0; i < 12 && root; i++) {
      root = root.parentElement;
      if (root && root.querySelectorAll('.text-base.leading-6.font-semibold').length >= 2) break;
    }
    if (!root) return null;
    const codes = Array.from(root.querySelectorAll('.text-base.leading-6.font-semibold')).map((e) => e.textContent.trim());
    const nameEl = root.querySelector('span.truncate');
    let pax = { adults: 1, children: 0, infants: 0 };
    for (const box of root.querySelectorAll('div.flex.items-center')) {
      const spans = Array.from(box.querySelectorAll(':scope > span'));
      if (spans.length === 3 && spans.every((sp) => /^\d+$/.test(sp.textContent.trim())) && box.querySelectorAll(':scope > svg').length >= 3) {
        const [a, c, i] = spans.map((sp) => parseInt(sp.textContent.trim(), 10));
        pax = { adults: a, children: c, infants: i };
        break;
      }
    }
    return { from: codes[0] || '', to: codes[codes.length - 1] || '', client: nameEl ? nameEl.textContent.trim() : '', pax };
  }

  function existingOptionIds() {
    return new Set(Array.from(document.querySelectorAll('input[id^="checkbox-switch-"]')).map((i) => i.id.replace('checkbox-switch-', '')));
  }

  function setField(input, value) {
    softFocus(input);
    setNativeValue(input, String(value));
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function inputByLabel(scope, labelText) {
    const want = labelText.toUpperCase();
    const label = Array.from(scope.querySelectorAll('.form-label')).find((l) => l.textContent.replace(/\*/g, '').trim().toUpperCase() === want);
    const box = label && label.closest('.relative');
    return box ? box.querySelector('input.form-control') : null;
  }

  async function selectMileProgram(modal, code) {
    const label = Array.from(modal.querySelectorAll('.form-label')).find((l) => /mile program/i.test(l.textContent));
    const wrapper = label && label.closest('.relative') && label.closest('.relative').querySelector('.form-multiselect');
    if (!wrapper) return false;
    const input = wrapper.querySelector('.form-multiselect-search');
    if (input) { softFocus(input); input.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); input.click(); }
    const li = await waitFor(() => findMultiselectOption(wrapper, code), 3000, 100);
    if (!li) return false;
    li.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    li.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    li.click();
    return true;
  }

  // Net column by position on screen: the input under the "Net" header,
  // on the same line as the ADT / CHD / INF label. Works whatever the
  // BO's markup is (single ticket or each ticket of Multiple Tkt).
  function fillCashNetByLayout(scope, fill, yMin, yMax, colRe) {
    const vis0 = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 ? r : null; };
    // Optional band: only things between yMin and yMax (one ticket's area).
    const vis = (el) => { const r = vis0(el); return r && (yMin == null || r.top >= yMin) && (yMax == null || r.top < yMax) ? r : null; };
    const netLabel = Array.from(scope.querySelectorAll('label, .form-label, div, span'))
      .find((l) => l.children.length === 0 && (colRe || /^net\*?$/i).test(l.textContent.trim()) && vis(l));
    if (!netLabel) return false;
    const nr = vis(netLabel);
    const nx = nr.left + nr.width / 2;
    const inputs = Array.from(scope.querySelectorAll('input')).filter((i) => i.type !== 'checkbox' && i.type !== 'radio' && vis(i));
    let filled = 0;
    ['ADT', 'CHD', 'INF'].forEach((type) => {
      if (fill[type] == null) return;
      const lab = Array.from(scope.querySelectorAll('*')).find((e) => e.children.length === 0 && e.textContent.trim().toUpperCase() === type && vis(e) && vis(e).top > nr.top);
      if (!lab) return;
      const lr = vis(lab);
      const ly = lr.top + lr.height / 2;
      const inp = inputs.find((i) => { const r = vis(i); return Math.abs(r.top + r.height / 2 - ly) < 14 && r.left - 6 <= nx && r.right + 6 >= nx; });
      if (inp) { setField(inp, fill[type]); filled++; }
    });
    return filled > 0;
  }

  function fillCashNet(modal, fill, colRe) {
    try { if (fillCashNetByLayout(modal, fill, null, null, colRe)) return true; } catch (e) { /* fall back to markup */ }
    const netLabel = Array.from(modal.querySelectorAll('label.form-label')).find((l) => (colRe || /^net\b/i).test(l.textContent.trim()));
    if (!netLabel) return false;
    const headerRow = netLabel.closest('.flex');
    const headerLabels = Array.from(headerRow.querySelectorAll('label.form-label'));
    const idx = headerLabels.indexOf(netLabel);
    let filled = 0;
    modal.querySelectorAll('div.flex.items-start').forEach((row) => {
      const first = row.firstElementChild;
      const type = first ? first.textContent.trim().toUpperCase() : '';
      if (!['ADT', 'CHD', 'INF'].includes(type) || fill[type] == null) return;
      const inputs = row.querySelectorAll('input.form-control');
      if (inputs[idx]) { setField(inputs[idx], fill[type]); filled++; }
    });
    return filled > 0;
  }

  function saveOptionFlags(optionId, fill) {
    if (!optionId || (!(fill.flags && fill.flags.length) && !fill.rush)) return;
    let all = {};
    try { all = JSON.parse(GM_getValue(OPTION_FLAGS_KEY, '{}')) || {}; } catch (e) { all = {}; }
    all[optionId] = { flags: fill.flags || [], rush: fill.rush || '', at: Date.now() };
    // keep the store small: drop entries older than 30 days
    const cutoff = Date.now() - 30 * 864e5;
    Object.keys(all).forEach((k) => { if (all[k].at < cutoff) delete all[k]; });
    try { GM_setValue(OPTION_FLAGS_KEY, JSON.stringify(all)); } catch (e) { /* ignore */ }
  }

  // The block of the price step that belongs to one ticket (Multiple Tkt):
  // the largest container around its Award button holding no other one.
  function ticketBlock(modal, awardBtn) {
    const count = (el) => Array.from(el.querySelectorAll('button')).filter((b) => b.textContent.trim() === 'Award').length;
    let b = awardBtn;
    while (b.parentElement && b.parentElement !== modal && count(b.parentElement) === 1) b = b.parentElement;
    return b;
  }

  // Segment step: every segment under "Inbound" gets ticket number `n`.
  function inboundSelects(modal) {
    const heads = Array.from(modal.querySelectorAll('h3'));
    const inH = heads.find((h) => /^\s*inbound\s*$/i.test(h.textContent));
    if (!inH) return [];
    const nextH = heads.slice(heads.indexOf(inH) + 1)[0] || null;
    return Array.from(modal.querySelectorAll('.input-select__value')).filter((el) =>
      (inH.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)
      && (!nextH || (nextH.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_PRECEDING)));
  }
  const selectTitle = (el) => ((el.querySelector('.input-select__value__text__title') || el).textContent || '').trim();

  // The BO's ticket-number dropdown: .dropdown.input-select; opening it
  // fills .dropdown__content with .input-select__option rows whose title
  // is "1", "1 Upgrade", "1 ELR", … "2", … — we want the plain number.
  async function chooseInputSelect(valueEl, text) {
    if (selectTitle(valueEl) === text) return true;
    const box = valueEl.closest('.input-select') || valueEl.parentElement;
    const titleOf = (o) => ((o.querySelector('.input-select__option__text__title') || o).textContent || '').trim();
    const findOpt = () => Array.from(box.querySelectorAll('.input-select__option')).find((o) => titleOf(o) === text) || null;
    const press = (el) => ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach((t) => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true })));
    const openWays = [
      (el) => el.click(),
      (el) => press(el),
      (el) => { press(el); el.click(); },
      (el) => { softFocus(el); el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true })); },
    ];
    const open = async () => {
      if (findOpt()) return findOpt();
      for (const way of openWays) {
        way(valueEl);
        const o = await waitFor(findOpt, 600, 40);
        if (o) return o;
      }
      return null;
    };
    const pickWays = [
      (o) => o.click(),
      (o) => { press(o); o.click(); },
      (o) => { const r = o.closest('[role="option"]') || o; press(r); r.click(); },
    ];
    const done = () => (!valueEl.isConnected || selectTitle(valueEl) === text ? true : null);
    for (const pick of pickWays) {
      const opt = await open();
      if (!opt) return false;
      pick(opt);
      if (await waitFor(done, 700, 40)) return true;
    }
    return !!done();
  }

  async function setInboundTicket(modal, text) {
    const count = inboundSelects(modal).length;
    if (!count) return false;
    for (let i = 0; i < count; i++) {
      const el = inboundSelects(modal)[i]; // fresh each time (Vue may re-render)
      if (!el) return false;
      await chooseInputSelect(el, text);
      await wait(120);
    }
    return inboundSelects(modal).every((el) => selectTitle(el) === text);
  }

  async function runSendJob(jobId, opts) {
    opts = opts || {};
    let job;
    try { job = JSON.parse(GM_getValue('js-sendjob-' + jobId, 'null')); } catch (e) { job = null; }
    if (!job) return;
    const closeTab = (ms) => { if (!opts.persistent) setTimeout(() => { if (window.top === window) window.close(); }, ms); };
    const fail = (message) => { sendJobActive = false; jobStatus(jobId, { phase: 'error', message }); closeTab(1500); };
    try {
      if (/login/i.test(location.pathname)) return fail('Log into the BO first, then try again');
      if (opts.persistent && location.pathname !== '/leads/' + job.leadId) {
        routeToLead(job.leadId);
        if (!(await waitFor(() => readLeadCard(job.leadId), 6000, 150))) {
          // The BO didn't switch in place — load the lead properly; the
          // frame picks this same job back up once it's loaded.
          try { sessionStorage.setItem('jsw-resume-' + opts.token, jobId); } catch (e) { /* ignore */ }
          location.href = '/leads/' + job.leadId;
          return;
        }
      }
      const info = await waitFor(() => readLeadCard(job.leadId), 30000, 200);
      if (!info) return fail('Lead ' + job.leadId + ' not found (or BO not logged in)');
      jobStatus(jobId, Object.assign({ phase: 'lead' }, info));

      // Meanwhile, let the lead's option list finish loading, so the new
      // option can be told apart from the ones already there.
      let prevN = -1;
      let stableSince = Date.now();
      const settled = waitFor(() => {
        const n = existingOptionIds().size;
        if (n !== prevN) { prevN = n; stableSince = Date.now(); }
        return Date.now() - stableSince > 500 && document.querySelector('.lead-options-header-cell') ? true : null;
      }, 8000, 100);

      const decision = await waitForGM('js-sendjob-decision-' + jobId, 180000);
      if (!decision || !decision.go) { closeTab(300); return; }
      const fill = decision.fill;
      jobStatus(jobId, { phase: 'saving' });
      sendJobActive = true;
      await settled;

      const before = existingOptionIds();
      const headerCell = await waitFor(() => Array.from(document.querySelectorAll('.lead-options-header-cell')).find((c) => c.querySelector('svg.feather-plus')), 15000);
      const plusBtn = headerCell && headerCell.querySelector('svg.feather-plus').closest('button');
      if (!plusBtn) return fail('Could not find the Add option (+) button');
      plusBtn.click();

      const modal = await waitFor(() => document.querySelector('.app-modal__container--price-quote'), 10000);
      if (!modal) return fail('The Add option form did not open');
      const ta = await waitFor(() => modal.querySelector('textarea.font-robotoMono'), 8000);
      if (!ta) return fail('Segments box not found');
      setField(ta, job.gds);
      await wait(250);
      await selectCarrier(modal, detectCarrier(parseRawSegments(job.gds)));
      await wait(200);
      const split = fill.mode === 'award' && fill.parts && fill.parts.length > 1;
      if (split) {
        // Return on a different program: inbound segments go on ticket 2.
        const n1 = await findNextButtonReady();
        if (!n1) return fail('Next button not found');
        n1.click();
        const inH = await waitFor(() => Array.from(modal.querySelectorAll('h3')).find((h) => /^\s*inbound\s*$/i.test(h.textContent)), 10000);
        if (!inH) return fail('Inbound section not found');
        await wait(200);
        if (!(await setInboundTicket(modal, '2'))) return fail('Could not set the return to ticket 2');
        await wait(250);
        const n2 = await findNextButtonReady();
        if (n2) n2.click();
        await wait(500);
        await selectPcc(modal, AUTO_PCC_CODE);
      } else {
        await clickNextTwice(modal);
      }

      const priceStep = await waitFor(() => Array.from(modal.querySelectorAll('label.form-label')).find((l) => /^net\b/i.test(l.textContent.trim())), 12000);
      if (!priceStep) return fail('Price step did not load');

      if (split) {
        const multi = Array.from(modal.querySelectorAll('button')).find((b) => /^multiple\s*tkt$/i.test(b.textContent.trim()));
        if (!multi) return fail('Multiple Tkt button not found');
        multi.click();
        const awardBtns = await waitFor(() => { const a = Array.from(modal.querySelectorAll('button')).filter((b) => b.textContent.trim() === 'Award'); return a.length >= 2 ? a : null; }, 8000);
        if (!awardBtns) return fail('Second ticket did not appear');
        for (let i = 0; i < 2; i++) {
          const part = fill.parts[i];
          const scope = ticketBlock(modal, awardBtns[i]);
          awardBtns[i].click();
          const milesInput = await waitFor(() => inputByLabel(scope, 'MILES'), 6000);
          const taxesInput = inputByLabel(scope, 'TAXES');
          if (!milesInput || !taxesInput) return fail('Miles/Taxes fields not found on ticket ' + (i + 1));
          setField(milesInput, part.miles);
          setField(taxesInput, part.taxes);
          if (!(await selectMileProgram(scope, part.program))) return fail('Mile program ' + part.program + ' could not be selected on ticket ' + (i + 1));
          await wait(150);
        }
      } else if (fill.mode === 'award') {
        const awardBtn = Array.from(modal.querySelectorAll('button')).find((b) => b.textContent.trim() === 'Award');
        if (!awardBtn) return fail('Award switch not found');
        awardBtn.click();
        const milesInput = await waitFor(() => inputByLabel(modal, 'MILES'), 6000);
        const taxesInput = inputByLabel(modal, 'TAXES');
        if (!milesInput || !taxesInput) return fail('Miles/Taxes fields not found');
        setField(milesInput, fill.miles);
        setField(taxesInput, fill.taxes);
        if (!(await selectMileProgram(modal, fill.program))) return fail('Mile program ' + fill.program + ' could not be selected');
      } else if (!fillCashNet(modal, fill)) {
        return fail('Net price field not found');
      }
      await wait(300);
      let sell = null;
      if (fill.sell) {
        try { sell = await fillModalSell(modal, fill.sell); } catch (e) { sell = { error: (e && e.message) || String(e) }; }
      }

      const saveBtn = await waitFor(() => Array.from(modal.querySelectorAll('button.btn-primary')).find((b) => b.textContent.trim() === 'Save' && !b.disabled), 6000);
      if (!saveBtn) return fail('Save button not available (form not complete?)');
      // Last guard: if another copy of this job is already saving, stop
      // here quietly (and reset this hidden copy) -- one option, never two.
      const saveKey = 'js-sendjob-saving-' + jobId;
      const me = (opts.token || 'tab') + ':' + Math.random().toString(36).slice(2, 8);
      if (GM_getValue(saveKey, null)) { sendJobActive = false; if (opts.persistent) location.href = '/leads/' + job.leadId; return; }
      GM_setValue(saveKey, me);
      await wait(450);
      if (GM_getValue(saveKey, null) !== me) { sendJobActive = false; if (opts.persistent) location.href = '/leads/' + job.leadId; return; }
      setTimeout(() => { try { GM_setValue(saveKey, null); } catch (e) { /* ignore */ } }, 5 * 60 * 1000);
      saveBtn.click();

      // The new option = an option that wasn't there before AND shows
      // exactly the flights just sent (an older option that only finished
      // loading late must never be taken for it).
      const jobSigs = gdsJobSigs(job.gds);
      const newId = await waitFor(() => {
        const fresh = Array.from(existingOptionIds()).filter((id) => !before.has(id));
        if (!jobSigs.length) return fresh.length === 1 ? fresh[0] : null;
        const hits = fresh.filter((id) => { const sg = optionSigsById(id); return sg && sg.join('|') === jobSigs.join('|'); });
        if (hits.length) return hits.map(Number).sort((a, b) => b - a)[0].toString();
        return null;
      }, 30000, 200) || (() => {
        // Flights shown differently than sent: accept only a single new
        // option that is also the newest one on the lead.
        const all = Array.from(existingOptionIds()).map(Number);
        const fresh = all.filter((id) => !before.has(String(id)));
        return fresh.length === 1 && fresh[0] === Math.max(...all) ? String(fresh[0]) : null;
      })();
      sendJobActive = false;
      if (!newId) return fail('Saved, but the new option could not be confirmed \u2014 please check the lead');
      saveOptionFlags(newId, fill);
      saveOptionRaw(newId, job.gds);
      saveOptionCost(newId, fill);
      jobStatus(jobId, { phase: 'done', optionId: newId, sell });
      closeTab(1500);
    } catch (e) {
      fail('Error: ' + (e && e.message ? e.message : e));
    }
  }

  // Sell price for an option just added: what you typed in the Pip pop-up,
  // or else the option's Net (as the lead page shows it) + 10%, rounded up
  // to a price ending in 88-92 (e.g. Net 4,400 -> 4,890). Children get the
  // same as adults when you typed a price, infants get their Net + 10%.
  function roundSell(x, ending) {
    let v = Math.floor(x / 100) * 100 + ending;
    if (v < x) v += 100;
    return v;
  }
  // Fills "Sell price*" in the Add option form, from the form's own Net
  // (per passenger type; with Multiple Tkt, the total is shared out by
  // each ticket's Net). Done before Save, so nothing is changed later.
  async function fillModalSell(modal, spec) {
    const vis = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 ? r : null; };
    const leaf = (re) => Array.from(modal.querySelectorAll('label, .form-label, div, span')).filter((l) => l.children.length === 0 && re.test(l.textContent.trim()) && vis(l));
    const read = () => {
      const sellLabels = leaf(/^sell price\*?$/i).sort((x, y) => vis(x).top - vis(y).top);
      if (!sellLabels.length) return null;
      const netLabels = leaf(/^net\*?$/i);
      const inputs = Array.from(modal.querySelectorAll('input')).filter((i) => i.type !== 'checkbox' && i.type !== 'radio' && vis(i));
      const blocks = sellLabels.map((sl, i) => {
        const sr = vis(sl);
        const yMax = sellLabels[i + 1] ? vis(sellLabels[i + 1]).top - 2 : Infinity;
        const nl = netLabels.filter((n) => Math.abs(vis(n).top - sr.top) < 12).sort((x, y) => Math.abs(vis(x).left - sr.left) - Math.abs(vis(y).left - sr.left))[0];
        if (!nl) return null;
        const nr = vis(nl);
        const sx = sr.left + sr.width / 2, nx = nr.left + nr.width / 2;
        const rows = {};
        ['ADT', 'CHD', 'INF'].forEach((type) => {
          const lab = Array.from(modal.querySelectorAll('*')).find((e) => e.children.length === 0 && e.textContent.trim().toUpperCase() === type && vis(e) && vis(e).top > sr.top && vis(e).top < yMax);
          if (!lab) return;
          const lr = vis(lab);
          const ly = lr.top + lr.height / 2;
          const at = (x) => inputs.find((inp) => { const r = vis(inp); return Math.abs(r.top + r.height / 2 - ly) < 14 && r.left - 6 <= x && r.right + 6 >= x; });
          const sellIn = at(sx), netIn = at(nx);
          if (sellIn && netIn && sellIn !== netIn) rows[type] = { sellIn, net: parseFloat(String(netIn.value).replace(/[^\d.-]/g, '')) || 0 };
        });
        return rows;
      }).filter(Boolean);
      return blocks.length ? blocks : null;
    };
    // Award Net is worked out by the form once miles/program are in.
    const blocks = await waitFor(() => { const b = read(); return b && b.some((x) => x.ADT && x.ADT.net > 0) ? b : null; }, 5000, 150) || read();
    if (!blocks) throw new Error('Sell price field not found');
    const ending = [88, 89, 90, 91, 92].includes(spec.ending) ? spec.ending : 90;
    const out = {};
    ['ADT', 'CHD', 'INF'].forEach((type) => {
      const parts = blocks.map((b) => b[type]).filter(Boolean);
      if (!parts.length) return;
      const net = parts.reduce((t, p) => t + p.net, 0);
      let total;
      if (type === 'INF') total = net > 0 ? Math.ceil(net * 1.1) : 0;
      else if (spec.value > 0) total = spec.value;
      else total = net > 0 ? roundSell(net * 1.1, ending) : 0;
      if (!total) return;
      let left = total;
      parts.forEach((p, i) => {
        const v = i === parts.length - 1 ? Math.round(left * 100) / 100 : Math.round((net ? total * p.net / net : total / parts.length) * 100) / 100;
        left -= v;
        setField(p.sellIn, v);
      });
      out[type] = total;
    });
    if (!out.ADT) throw new Error('Net not shown in the form');
    await wait(150);
    return { ADT: out.ADT, all: out };
  }

  // Flight fingerprints ("PR101 08OCT HNLMNL") of the *IA lines sent.
  function gdsJobSigs(gds) {
    const ia = (String(gds || '').split(/\n\s*VI\*/)[0] || '');
    return ia.split('\n').map((l) => {
      const m = l.match(/^\s*\d+\s+([A-Z0-9]{2})\s*(\d{1,5})[A-Z]\s+(\d{2}[A-Z]{3})\s+[A-Z]\s+([A-Z]{3})([A-Z]{3})\b/);
      return m ? m[1] + parseInt(m[2], 10) + ' ' + m[3] + ' ' + m[4] + m[5] : null;
    }).filter(Boolean);
  }
  // The flights an option's card shows on the lead page.
  function optionCardById(id) {
    const cb = document.getElementById('checkbox-switch-' + id);
    if (!cb) return null;
    const opt = cb.closest('.lead-option');
    if (opt) return opt;
    for (let up = cb.parentElement; up && up !== document.body; up = up.parentElement) {
      if (up.querySelectorAll('input[id^="checkbox-switch-"]').length > 1) return null;
      if (up.querySelector('.lead-option-segment-segments')) return up;
    }
    return null;
  }
  function optionSigsById(id) {
    const card = optionCardById(id);
    const box = card && card.querySelector('.lead-option-segment-segments');
    if (!box) return null;
    const sigs = Array.from(box.querySelectorAll(':scope > pre')).map((p) => segSig((p.querySelector('.overflow-hidden') || p).textContent)).filter(Boolean);
    return sigs.length ? sigs : null;
  }

  // Fallback mode: a background tab opened with ?jsjob=<id>.
  (function startSendJobIfAny() {
    if (IN_WORKER_FRAME) return;
    const jobId = new URLSearchParams(location.search).get('jsjob');
    if (jobId && /^\/leads\/\d+/.test(location.pathname)) runSendJob(jobId);
  })();

  // ---- Warm worker frame ------------------------------------------
  // One open BO tab keeps an invisible copy of the BO loaded on your LAST
  // lead (in a hidden frame — nothing in your tab changes, no focus is
  // taken, no sound). Sending to the same lead again is then instant;
  // a different lead is switched to in place, without reloading.
  // Opening Pip's popover on a flight site wakes it up ahead of time.
  const HOST_KEY = 'js-sendjob-host';
  const LAST_LEAD_KEY = 'js-sendjob-lastlead';
  const ALIVE_KEY = 'js-sendjob-alive';
  // Live BO tabs: { token: { t: last "I'm here", seen: last time on screen } }.
  // A background tab may only manage a beat a minute, so 90s counts as live;
  // a closed tab removes itself.
  function readAlive() {
    let all = {};
    try { all = JSON.parse(GM_getValue(ALIVE_KEY, '{}') || '{}') || {}; } catch (e) { all = {}; }
    const now = Date.now();
    Object.keys(all).forEach((k) => { if (!all[k] || now - all[k].t > 90000) delete all[k]; });
    return all;
  }

  (function workerFrame() {
    if (!IN_WORKER_FRAME) return;
    const token = window.name.slice('jsworker-'.length);
    const runKey = 'js-sendjob-run-' + token;
    const startedKey = 'jsw-started-' + token;
    const resumeKey = 'jsw-resume-' + token;
    const loadedAt = Date.now();
    const queue = [];
    let busy = false;
    const ss = (fn) => { try { return fn(); } catch (e) { return null; } };

    async function pump() {
      if (busy) return;
      const r = queue.shift();
      if (!r) return;
      busy = true;
      ss(() => sessionStorage.setItem(startedKey, r.jobId));
      try { await runSendJob(r.jobId, { persistent: true, token }); } catch (e) { /* reported inside */ }
      busy = false;
      pump();
    }
    function take(raw) {
      let r;
      try { r = JSON.parse(raw); } catch (e) { return; }
      if (!r || !r.jobId || Date.now() - r.t > 120000) return;
      const resume = ss(() => sessionStorage.getItem(resumeKey)) === r.jobId;
      if (!resume && ss(() => sessionStorage.getItem(startedKey)) === r.jobId) return; // already done
      if (resume) ss(() => sessionStorage.removeItem(resumeKey));
      if (queue.some((q) => q.jobId === r.jobId)) return;
      queue.push(r);
      pump();
    }
    GM_addValueChangeListener(runKey, (n, o, v) => { if (v) take(v); });
    const pending = GM_getValue(runKey, null);
    if (pending) take(pending); // a job that arrived while this frame was loading
    void loadedAt;
  })();

  (function hostSendWorker() {
    if (window.top !== window) return; // only real BO tabs host
    const tabToken = Math.random().toString(36).slice(2);
    const FOCUS_KEY = 'js-sendjob-focustab';
    let frame = null;

    // Who takes a job — decided instantly, no timers (a background tab's
    // timers can be delayed up to a minute, which is what made the flight
    // site give up and open a new tab):
    //   1. the tab already holding the warm frame,
    //   2. else the BO tab you used last,
    //   3. else any BO tab.
    // Each key is cleared when its tab closes.
    const readKey = (k) => { try { return GM_getValue(k, null) || null; } catch (e) { return null; } };
    const readHost = () => { const v = readKey(HOST_KEY); try { const h = typeof v === 'string' ? JSON.parse(v) : v; return h && h.token ? h : null; } catch (e) { return null; } };
    const markFocus = () => { if (!document.hidden) { try { GM_setValue(FOCUS_KEY, tabToken); } catch (e) { /* ignore */ } } };
    markFocus();
    window.addEventListener('focus', markFocus);
    document.addEventListener('visibilitychange', markFocus);

    // Every open BO tab says "I'm here" every few seconds (and when you look
    // at it), so the tab picked for a job is always a live one, and the
    // choice never depends on notes a reload may have wiped.
    let lastSeen = document.hidden ? 0 : Date.now();
    function beat() {
      if (!document.hidden) lastSeen = Date.now();
      const all = readAlive();
      all[tabToken] = { t: Date.now(), seen: lastSeen };
      try { GM_setValue(ALIVE_KEY, JSON.stringify(all)); } catch (e) { /* ignore */ }
    }
    beat();
    setInterval(beat, 3000);
    document.addEventListener('visibilitychange', beat);
    window.addEventListener('focus', beat);
    window.addEventListener('pagehide', () => {
      const h = readHost();
      if (h && h.token === tabToken) { try { GM_setValue(HOST_KEY, null); } catch (e) { /* ignore */ } }
      if (readKey(FOCUS_KEY) === tabToken) { try { GM_setValue(FOCUS_KEY, null); } catch (e) { /* ignore */ } }
      const all = readAlive();
      delete all[tabToken];
      try { GM_setValue(ALIVE_KEY, JSON.stringify(all)); } catch (e) { /* ignore */ }
    });
    // The tab for a job: the one holding the warm frame, else the BO tab
    // you used last, else the first live one by a fixed order -- always
    // a tab that's still there.
    function chosenToken() {
      const all = readAlive();
      const live = Object.keys(all);
      const h = readHost();
      if (h && all[h.token]) return h.token;
      const f = readKey(FOCUS_KEY);
      if (f && all[f]) return f;
      if (!live.length) return tabToken;
      return live.sort((a, b) => (all[b].seen - all[a].seen) || (a < b ? -1 : 1))[0];
    }

    function ensureFrame(leadId) {
      if (frame && frame.isConnected) return frame;
      frame = document.createElement('iframe');
      frame.name = 'jsworker-' + tabToken;
      frame.setAttribute('aria-hidden', 'true');
      frame.tabIndex = -1;
      frame.style.cssText = 'position:fixed;left:-20000px;top:0;width:1400px;height:900px;opacity:0;pointer-events:none;border:0;visibility:hidden;';
      frame.src = '/leads/' + leadId;
      document.body.appendChild(frame);
      try { GM_setValue(HOST_KEY, JSON.stringify({ token: tabToken, t: Date.now() })); } catch (e) { /* ignore */ }
      return frame;
    }

    // Warm from the start: the chosen BO tab loads the frame on your last
    // lead as soon as it opens, so it's long ready before you need it.
    // Speed: it used to load the moment the tab opened, so every BO tab
    // loaded the whole BO twice at once. Now it waits until the page has
    // finished loading and settled, and only in a tab you're looking at.
    // (Opening Pip's popover still warms it at once, and a job builds it
    // on the spot if it isn't there yet.)
    (function warmOnLoad() {
      const WARM_DELAY_MS = 15000;
      const go = () => {
        if (frame && frame.isConnected) return;
        const last = String(GM_getValue(LAST_LEAD_KEY, '') || '');
        if (!/^\d{6}$/.test(last) || readHost()) return;
        const who = readKey(FOCUS_KEY);
        if (who && who !== tabToken) return;
        ensureFrame(last);
      };
      const later = () => setTimeout(() => {
        if (!document.hidden) { go(); return; }
        const onShow = () => { if (document.hidden) return; document.removeEventListener('visibilitychange', onShow); later(); };
        document.addEventListener('visibilitychange', onShow);
      }, WARM_DELAY_MS);
      if (document.readyState === 'complete') later(); else window.addEventListener('load', later, { once: true });
    })();

    // Pip's popover opened somewhere: get the frame ready on the last lead.
    GM_addValueChangeListener('js-sendjob-warm', () => {
      const who = chosenToken();
      if (who && who !== tabToken) return;
      if (frame && frame.isConnected) { try { GM_setValue('js-sendjob-refresh-' + tabToken, Date.now()); } catch (e) { /* ignore */ } return; }
      const last = String(GM_getValue(LAST_LEAD_KEY, '') || '');
      if (!/^\d{6}$/.test(last)) return;
      ensureFrame(last);
    });

    GM_addValueChangeListener('js-sendjob-request', (name, oldV, newV) => {
      if (!newV) return;
      let req;
      try { req = JSON.parse(newV); } catch (e) { return; }
      if (!req || !req.id || Date.now() - req.t > 15000) return;
      const claimKey = 'js-sendjob-claim-' + req.id;
      const who = chosenToken();
      if (who !== tabToken) {
        // Not ours — but step in if the chosen tab doesn't answer.
        setTimeout(() => { if (!GM_getValue(claimKey, null)) takeJob(req); }, 1500);
        return;
      }
      takeJob(req);
    });

    // Only one tab may run a job. Writing a claim and checking it isn't
    // enough on its own (Tampermonkey passes values between tabs with a
    // small delay, so several tabs could each see "unclaimed"), so every
    // tab that wants it writes its claim, waits for storage to settle, and
    // reads it back: only the tab whose claim stuck goes ahead.
    async function claim(claimKey) {
      if (GM_getValue(claimKey, null)) return false;
      try { GM_setValue(claimKey, tabToken); } catch (e) { return false; }
      await wait(450);
      return GM_getValue(claimKey, null) === tabToken;
    }

    async function takeJob(req) {
      const claimKey = 'js-sendjob-claim-' + req.id;
      if (!(await claim(claimKey))) return;
      jobStatus(req.id, { phase: 'claimed', v: (typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || '' });
      try { GM_setValue(LAST_LEAD_KEY, req.leadId); } catch (e) { /* ignore */ }

      const f = ensureFrame(req.leadId);
      GM_setValue('js-sendjob-run-' + tabToken, JSON.stringify({ jobId: req.id, leadId: req.leadId, t: Date.now() }));

      const statusKey = 'js-sendjob-status-' + req.id;
      const decisionKey = 'js-sendjob-decision-' + req.id;
      let closed = false;
      const ids = [];
      const finish = (reset) => {
        if (closed) return;
        closed = true;
        ids.forEach((id) => { try { if (typeof GM_removeValueChangeListener === 'function') GM_removeValueChangeListener(id); } catch (e) { /* ignore */ } });
        // (the claim stays set, so no other tab ever re-runs this job)
        // After an error, give the frame a clean start on that lead.
        if (reset && f.isConnected) f.src = '/leads/' + req.leadId;
      };
      ids.push(GM_addValueChangeListener(statusKey, (n, o, v) => {
        try {
          const st = JSON.parse(v || 'null');
          if (st && st.phase === 'done') finish(false);
          if (st && st.phase === 'error') finish(true);
        } catch (e) { /* ignore */ }
      }));
      ids.push(GM_addValueChangeListener(decisionKey, (n, o, v) => {
        try { const d = JSON.parse(v || 'null'); if (d && d.go === false) finish(false); } catch (e) { /* ignore */ }
      }));
      setTimeout(() => finish(false), 4 * 60 * 1000);
    }
  })();

  // ==================================================================
  // MERGE — header button next to + and select-all. Select two (or more)
  // options, e.g. two separate one-ways, press Merge: their segments go
  // through Sort Me into ONE new option — cash, Net 0, PCC 10XH.
  // ==================================================================
  const OPTION_RAW_KEY = 'js-option-raw';
  const optionRawCache = new Map(); // option id -> raw *IA/VI* text
  const optionObjCache = new Map(); // option id -> the API object it came from
  const idObjCache = new Map(); // any id seen in the BO's data -> objects carrying it
  const detailCache = new Map(); // option id -> its full detail reply (what "edit" loads)
  const DETAIL_URL_KEY = 'js-pq-detail-url-v2'; // v2: forget an address learned by guessing

  // When the BO loads an option's full details (what clicking "edit"
  // does), remember that address, with the option number swapped for
  // {id} — from then on Merge loads any option's cost the same way,
  // without opening anything.
  function learnDetailUrl(url, json) {
    try {
      const path = String(url).replace(/^https?:\/\/[^/]+/, '');
      const nums = path.match(/\d{3,}/g) || [];
      // Speed: the cheap check (is this option on the page?) comes first;
      // the response is only turned back into text when it is.
      const n = nums.find((x) => document.getElementById('checkbox-switch-' + x));
      if (!n) return;
      const text = JSON.stringify(json);
      if (!/miles_count|"net|net_price|sell_type/i.test(text)) return;
      detailCache.set(n, json);
      GM_setValue(DETAIL_URL_KEY, path.replace(n, '{id}'));
    } catch (e) { /* ignore */ }
  }
  // Speed: reading through the BO's API answers waits for a quiet moment
  // (at most half a second), so it never competes with the page loading.
  const jsIdle = (fn) => { try { if (typeof requestIdleCallback === 'function') { requestIdleCallback(() => { try { fn(); } catch (e) { /* ignore */ } }, { timeout: 500 }); return; } } catch (e) { /* fall through */ } setTimeout(() => { try { fn(); } catch (e) { /* ignore */ } }, 0); };
  const OPTION_COST_KEY = 'js-option-cost';
  function saveOptionCost(optionId, fill) {
    if (!optionId || !fill) return;
    let all = {};
    try { all = JSON.parse(GM_getValue(OPTION_COST_KEY, '{}')) || {}; } catch (e) { all = {}; }
    const c = fill.mode === 'cash' ? { mode: 'cash', ADT: fill.ADT, CHD: fill.CHD, INF: fill.INF } : { mode: 'award', miles: fill.miles, taxes: fill.taxes, program: fill.program, split: !!(fill.parts && fill.parts.length > 1) };
    all[optionId] = Object.assign(c, { at: Date.now() });
    const cutoff = Date.now() - 30 * 864e5;
    Object.keys(all).forEach((k) => { if (all[k].at < cutoff) delete all[k]; });
    try { GM_setValue(OPTION_COST_KEY, JSON.stringify(all)); } catch (e) { /* ignore */ }
  }
  const apiHeaders = __jsApi.headers;
  let pageFetch = null;

  function saveOptionRaw(optionId, raw) {
    if (!optionId || !raw || !/\*IA?(?![A-Z])/.test(raw)) return;
    let all = {};
    try { all = JSON.parse(GM_getValue(OPTION_RAW_KEY, '{}')) || {}; } catch (e) { all = {}; }
    all[optionId] = { raw, at: Date.now() };
    const cutoff = Date.now() - 30 * 864e5;
    Object.keys(all).forEach((k) => { if (all[k].at < cutoff) delete all[k]; });
    try { GM_setValue(OPTION_RAW_KEY, JSON.stringify(all)); } catch (e) { /* ignore */ }
  }

  // Pull every "*IA … VI*" text out of a BO API reply, keyed by the id of
  // the object it belongs to (the option / price quote).
  function harvestRaw(json) {
    const idKeys = ['id', 'pk', 'price_quote_id', 'priceQuoteId', 'lead_price_quote_id'];
    const walk = (node, ids, depth) => {
      if (!node || typeof node !== 'object' || depth > 14) return;
      if (Array.isArray(node)) { node.forEach((x) => walk(x, ids, depth + 1)); return; }
      const own = idKeys.map((k) => node[k]).filter((v) => v != null && /^\d+$/.test(String(v))).map(String);
      const here = own.length ? own : ids;
      if (node.id != null && /^\d+$/.test(String(node.id))) {
        const list = idObjCache.get(String(node.id)) || [];
        if (!list.includes(node) && list.length < 6) list.push(node);
        idObjCache.set(String(node.id), list);
      }
      Object.keys(node).forEach((k) => {
        const v = node[k];
        if (typeof v === 'string') {
          if (/\*IA?(?![A-Z])/.test(v) && /VI\*|\*VI/.test(v)) here.forEach((id) => { optionRawCache.set(id, v); if (own.length) optionObjCache.set(id, node); });
        } else if (v && typeof v === 'object') {
          walk(v, here, depth + 1);
        }
      });
    };
    walk(json, [], 0);
  }

  // Watch the BO's own API traffic: remember its auth headers (to make the
  // same call ourselves) and the options' raw segments it loads.
  (function sniffApi() {
    if (window.top !== window) return;
    try {
      const W = unsafeWindow;
      const XP = W.XMLHttpRequest.prototype;
      const open = XP.open;
      const setH = XP.setRequestHeader;
      const send = XP.send;
      XP.open = function (m, u) { this.__jsUrl = String(u || ''); this.__jsMethod = String(m || 'GET'); return open.apply(this, arguments); };
      XP.setRequestHeader = function (k, v) {
        try { if (/\/api\//.test(this.__jsUrl || '') && !/^content-(type|length)$/i.test(k)) apiHeaders[k] = v; } catch (e) { /* ignore */ }
        return setH.apply(this, arguments);
      };
      XP.send = function (body) {
        try {
          if (/PriceQuoteFormModel/.test(this.__jsUrl || '') && /^(put|post)$/i.test(this.__jsMethod || '')) learnPqShape(body);
          if (/\/api\//.test(this.__jsUrl || '')) {
            this.addEventListener('load', () => jsIdle(() => {
              try {
                const j = this.responseType === 'json' ? this.response : JSON.parse(this.responseText);
                harvestRaw(j);
                if (/^get$/i.test(this.__jsMethod || 'GET')) learnDetailUrl(this.__jsUrl, j);
                if (/\/(me|profile|account|auth\/user|user\/current|current)(\b|\/|\?|$)/i.test(this.__jsUrl || '') && !/lead/i.test(this.__jsUrl || '')) {
                  const r = j && (j.result || j.data || j.user || j);
                  const n = nameFromObj(r) || nameFromObj(r && r.user);
                  if (n) saveAgentName(n);
                }
              } catch (e) { /* not JSON */ }
            }));
          }
        } catch (e) { /* ignore */ }
        return send.apply(this, arguments);
      };
      if (typeof W.fetch === 'function') {
        const f = W.fetch;
        pageFetch = f.bind(W);
        W.fetch = function (input, init) {
          const url = String((input && input.url) || input || '');
          const p = f.apply(this, arguments);
          if (/\/api\//.test(url)) {
            try {
              const h = (init && init.headers) || (input && input.headers);
              if (h) {
                if (typeof h.forEach === 'function' && !Array.isArray(h)) h.forEach((v, k) => { if (!/^content-/i.test(k)) apiHeaders[k] = v; });
                else Object.keys(h).forEach((k) => { if (!/^content-/i.test(k)) apiHeaders[k] = h[k]; });
              }
            } catch (e) { /* ignore */ }
            const method = String((init && init.method) || (input && input.method) || 'GET');
            if (/PriceQuoteFormModel/.test(url) && /^(put|post)$/i.test(method) && init && init.body) learnPqShape(init.body);
            p.then((r) => r.clone().json()).then((j) => jsIdle(() => { harvestRaw(j); if (/^get$/i.test(method)) learnDetailUrl(url, j); })).catch(() => {});
          }
          return p;
        };
      }
    } catch (e) { /* ignore */ }
  })();

  // The agent's first name for Pip's name strip, found without needing the
  // profile menu opened: from the login token, or the BO's own account
  // reply. Stored for Pip (PART 4) under the same key it reads.
  const AGENT_NAME_KEY = 'bmo-first-name';
  function saveAgentName(n) {
    const first = String(n || '').trim().split(/\s+/)[0].replace(/[^\p{L}'-]/gu, '');
    if (first && first.length > 1) { try { if (GM_getValue(AGENT_NAME_KEY, '') !== first) GM_setValue(AGENT_NAME_KEY, first); } catch (e) { /* ignore */ } }
    return !!first;
  }
  function nameFromObj(o) {
    if (!o || typeof o !== 'object') return null;
    return o.first_name || o.firstName || o.given_name || (o.name && /\s/.test(o.name) ? o.name : null) || null;
  }
  function nameFromJwt(tok) {
    try {
      const part = String(tok).replace(/^Bearer\s+/i, '').split('.')[1];
      if (!part) return null;
      const json = JSON.parse(decodeURIComponent(escape(atob(part.replace(/-/g, '+').replace(/_/g, '/')))));
      return nameFromObj(json) || nameFromObj(json.user) || nameFromObj(json.data) || null;
    } catch (e) { return null; }
  }
  function findAgentName() {
    const tokens = [];
    Object.keys(apiHeaders).forEach((k) => { if (/authorization/i.test(k)) tokens.push(apiHeaders[k]); });
    { const sa3 = __jsStoredAuth(); if (sa3) tokens.push(sa3); }
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const v = (localStorage.getItem(localStorage.key(i)) || '').replace(/^"|"$/g, '');
        if (/^[\w-]+\.[\w-]+\.[\w-]+$/.test(v)) tokens.push(v);
        else if (/first_?name/i.test(v) && v.length < 20000) {
          try { const j = JSON.parse(v); const n = nameFromObj(j) || nameFromObj(j.user) || nameFromObj(j.auth && j.auth.user); if (n && saveAgentName(n)) return; } catch (e) { /* ignore */ }
        }
      }
    } catch (e) { /* ignore */ }
    for (const t of tokens) { const n = nameFromJwt(t); if (n && saveAgentName(n)) return; }
  }
  if (window.top === window) { setTimeout(findAgentName, 1500); setTimeout(findAgentName, 6000); }

  function rawFor(id) {
    if (optionRawCache.has(id)) return optionRawCache.get(id);
    try { const all = JSON.parse(GM_getValue(OPTION_RAW_KEY, '{}')) || {}; if (all[id]) return all[id].raw; } catch (e) { /* ignore */ }
    return null;
  }

  async function fetchLeadOptions(leadId) {
    const headers = Object.assign({ Accept: 'application/json' }, apiHeaders);
    if (!Object.keys(apiHeaders).some((k) => /authorization/i.test(k))) {
      // No call seen yet: try a stored login token.
      const sa0 = __jsStoredAuth();
      if (sa0) headers.Authorization = sa0;
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          const v = localStorage.getItem(k) || '';
          if (/token/i.test(k) && /^[\w-]+\.[\w-]+\.[\w-]+$/.test(v.replace(/^"|"$/g, ''))) { headers.Authorization = 'Bearer ' + v.replace(/^"|"$/g, ''); break; }
        }
      } catch (e) { /* ignore */ }
    }
    const doFetch = pageFetch || window.fetch.bind(window);
    try {
      const r = await doFetch('/api/database/v2/LeadPriceQuoteList/find?pks=' + leadId, { credentials: 'include', headers });
      if (r.ok) harvestRaw(await r.json());
    } catch (e) { /* ignore */ }
  }

  // One option's details as the BO's "edit" loads them.
  async function loadOptionDetail(id) {
    const j = await apiGet('/api/database/v1/priceQuotes/PriceQuoteFormModel/' + id);
    const r = j && (j.result || j.data || j);
    if (!r || !Array.isArray(r.preTickets)) return null;
    detailCache.set(String(id), r);
    if (r.raw_segments) optionRawCache.set(String(id), r.raw_segments);
    return r;
  }

  // preTickets -> [{ cost, segNums }]. Cash keeps its sell type and the
  // Net per passenger; award keeps miles, taxes and program (all totals,
  // exactly as stored on the option).
  function ticketsFromDetail(r) {
    const PAX = { adult: 'ADT', adt: 'ADT', child: 'CHD', chd: 'CHD', infant: 'INF', inf: 'INF' };
    const segs = Array.isArray(r.segments) ? r.segments : [];
    const pts = r.preTickets || [];
    return pts.map((pt, idx) => {
      let cost;
      if (/award/i.test(pt.sell_type || '')) {
        cost = { mode: 'award', miles: Number(pt.miles_count) || 0, taxes: Number(pt.award_tax_amount) || 0, program: MILE_PROGRAM_IDS[pt.mile_price_program_id] || '' };
        if (!cost.program || !cost.miles) cost = null;
      } else {
        cost = { mode: 'cash', sellType: pt.sell_type || 'public' };
        (pt.prices || []).forEach((pr) => {
          const t = PAX[String(pr.passenger_type || '').toLowerCase()];
          if (t && pr.net_price != null) cost[t] = Number(pr.net_price);
          // Com. val. (a dollar amount, one per passenger type, like Net).
          if (t && pr.commission != null && Number(pr.commission)) { cost.com = cost.com || {}; cost.com[t] = Number(pr.commission); }
        });
        if (cost.ADT == null && cost.CHD == null && cost.INF == null) cost = null;
      }
      let segNums = segs.filter((sg) => String(sg.pre_ticket_id) === String(pt.id)).map((sg) => Number(sg.number));
      if (!segNums.length && pts.length === 1) segNums = segs.map((sg) => Number(sg.number));
      if (!segNums.length && idx === 0 && !segs.length) segNums = [];
      return { cost, segNums };
    });
  }

  async function apiGet(path) {
    const headers = Object.assign({ Accept: 'application/json' }, apiHeaders);
    if (!Object.keys(headers).some((k) => /authorization/i.test(k))) {
      const sa1 = __jsStoredAuth();
      if (sa1) headers.Authorization = sa1;
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          const v = (localStorage.getItem(k) || '').replace(/^"|"$/g, '');
          if (/token/i.test(k) && /^[\w-]+\.[\w-]+\.[\w-]+$/.test(v)) { headers.Authorization = 'Bearer ' + v; break; }
        }
      } catch (e) { /* ignore */ }
    }
    const doFetch = pageFetch || window.fetch.bind(window);
    try {
      const r = await doFetch(path, { credentials: 'include', headers });
      return r.ok ? await r.json() : null;
    } catch (e) { return null; }
  }

  // Load one option's full details the way "edit" does, without opening it.
  async function fetchOptionDetail(id) {
    const learned = GM_getValue(DETAIL_URL_KEY, '');
    // Only the address the BO itself used for "edit" — no guessing.
    const guesses = [learned].filter(Boolean);
    for (const g of guesses) {
      const j = await apiGet(g.replace('{id}', id));
      if (!j) continue;
      harvestRaw(j);
      detailCache.set(String(id), j);
      if (costFromObj(j)) {
        if (g !== learned) { try { GM_setValue(DETAIL_URL_KEY, g); } catch (e) { /* ignore */ } }
        return true;
      }
    }
    return false;
  }

  function optionsScope(headerCell) {
    let node = headerCell.parentElement;
    while (node && node !== document.body) {
      if (node.querySelector('input[id^="checkbox-switch-"]')) return node;
      node = node.parentElement;
    }
    return document;
  }

  function leadIdFor(el) {
    const m = location.pathname.match(/\/leads\/(\d{5,})/);
    if (m) return m[1];
    for (let node = el; node && node !== document.body; node = node.parentElement) {
      const sp = Array.from(node.querySelectorAll('span')).find((x) => /^#\d{5,}$/.test(x.textContent.trim()));
      if (sp) return sp.textContent.trim().slice(1);
    }
    return null;
  }

  // BO "Mile program" dropdown ids -> program code.
  const MILE_PROGRAM_IDS = { 16: 'AA', 1: 'AC', 19: 'AD', 3: 'AF', 20: 'AS', 15: 'AV', 22: 'B6', 4: 'BA', 17: 'CM', 11: 'CX', 10: 'DL', 5: 'EK', 18: 'EY', 23: 'IB', 24: 'JL', 7: 'LH', 9: 'QF', 14: 'QR', 13: 'SK', 8: 'SQ', 2: 'TK', 21: 'TP', 6: 'UA', 12: 'VS' };

  // An existing option's cost: what Pip stored when it added it, else
  // read from the BO's own data for that option.
  function costFor(id) {
    const d = detailCache.get(String(id));
    if (d && Array.isArray(d.preTickets)) { const t = ticketsFromDetail(d); if (t.length && t[0].cost) return t[0].cost; }
    try { const all = JSON.parse(GM_getValue(OPTION_COST_KEY, '{}')) || {}; if (all[id] && !all[id].split) return all[id]; } catch (e) { /* ignore */ }
    const cands = [detailCache.get(String(id)), optionObjCache.get(id)].filter(Boolean);
    for (const obj of cands) { const c = costFromObj(obj); if (c) return c; }
    try { console.warn("[TBC Assistant] merge:" + ' no cost found for option ' + id, cands.length ? cands : '(option not in the BO data)'); } catch (e) { /* ignore */ }
    return null;
  }

  function costFromObj(obj) {
    const num = (v) => { const n = parseFloat(String(v).replace(/[^\d.-]/g, '')); return Number.isFinite(n) ? n : null; };
    let award = null;
    const cash = {};
    const walk = (n, d) => {
      if (!n || typeof n !== 'object' || d > 8) return;
      if (Array.isArray(n)) { n.forEach((x) => walk(x, d + 1)); return; }
      if (!award && n.miles_count != null && num(n.miles_count)) {
        const pid = n.mile_price_program_id != null ? n.mile_price_program_id : (n.mile_price_program && n.mile_price_program.id);
        award = { mode: 'award', miles: num(n.miles_count), taxes: num(n.award_tax_amount) || 0, program: MILE_PROGRAM_IDS[pid] || (n.mile_price_program && n.mile_price_program.code) || '' };
      }
      // Cash: per-passenger Net, whatever the BO calls the fields.
      const PAX = { ADT: 'ADT', ADULT: 'ADT', ADL: 'ADT', ADULTS: 'ADT', CHD: 'CHD', CHILD: 'CHD', CNN: 'CHD', CHILDREN: 'CHD', INF: 'INF', INFANT: 'INF', INFANTS: 'INF' };
      const keys = Object.keys(n);
      let type = null;
      keys.forEach((k) => { const v = n[k]; if (!type && typeof v === 'string' && PAX[v.trim().toUpperCase()] && /type|pax|passenger|code|kind|age|category/i.test(k)) type = PAX[v.trim().toUpperCase()]; });
      const netKey = keys.find((k) => /^net(_?(price|amount|fare|value|cost))?$/i.test(k) && n[k] != null && typeof n[k] !== 'object' && num(n[k]) != null);
      if (type && netKey && cash[type] == null) cash[type] = num(n[netKey]);
      // Flat forms: adt_net / net_adt / adult_net_price …
      keys.forEach((k) => {
        const m = k.match(/^(adt|adult|chd|child|cnn|inf|infant)_?net|^net_?(?:price_?|amount_?)?(adt|adult|chd|child|cnn|inf|infant)$/i);
        if (m && n[k] != null && typeof n[k] !== 'object' && num(n[k]) != null) {
          const t = PAX[(m[1] || m[2]).toUpperCase()];
          if (t && cash[t] == null) cash[t] = num(n[k]);
        }
      });
      // A ticket with one Net and no passenger type: treat as adult.
      if (!type && netKey && n.sell_type && !/award/i.test(n.sell_type) && cash.ADT == null) cash.ADT = num(n[netKey]);
      if (n.sell_type && !cash.sellType && !/award/i.test(n.sell_type)) cash.sellType = String(n.sell_type);
      Object.keys(n).forEach((k) => { if (n[k] && typeof n[k] === 'object') walk(n[k], d + 1); });
    };
    walk(obj, 0);
    if (award && award.program) return award;
    if (cash.ADT != null || cash.CHD != null || cash.INF != null) return Object.assign({ mode: 'cash' }, cash);
    return null;
  }

  // Segment step: give each segment row its ticket number.
  async function setSegmentTickets(modal, ticketOfSeg) {
    const rows = () => Array.from(modal.querySelectorAll('.input-select__value')).map((el) => {
      const row = el.closest('.flex.items-center') || el.parentElement;
      const pre = row && row.parentElement && (row.querySelector('pre') || row.parentElement.querySelector('pre'));
      const m = pre && pre.textContent.match(/^\s*(\d+)/);
      return { el, seg: m ? parseInt(m[1], 10) : null };
    });
    const list = rows();
    if (!list.length) return false;
    for (let i = 0; i < list.length; i++) {
      const r = rows()[i]; // fresh each time (Vue may re-render)
      if (!r) return false;
      const seg = r.seg != null ? r.seg : i + 1;
      const want = String(ticketOfSeg[seg - 1] || 1);
      if (!(await chooseInputSelect(r.el, want))) return false;
      await wait(100);
    }
    return true;
  }

  let merging = false;
  async function mergeSelected(headerCell, btn) {
    if (merging) return;
    const say = (t, ms) => { btn.textContent = t; if (ms) setTimeout(() => { btn.textContent = 'Merge'; }, ms); };
    const scope = optionsScope(headerCell);
    const ids = Array.from(scope.querySelectorAll('input[id^="checkbox-switch-"]'))
      .filter((c) => c.checked).map((c) => c.id.replace('checkbox-switch-', ''));
    if (ids.length < 2) { say('Select 2 options', 1800); return; }
    merging = true;
    try {
      say('Merging…');
      // Each option's full details, straight from the BO (the same data
      // "edit" loads), all at once: segments, and every ticket's cost.
      const details = await Promise.all(ids.map((id) => loadOptionDetail(id)));
      let raws = ids.map((id, i) => (details[i] && details[i].raw_segments) || rawFor(id));
      if (raws.some((r) => !r)) {
        const leadId = leadIdFor(headerCell);
        if (leadId) { await fetchLeadOptions(leadId); raws = ids.map((id, i) => raws[i] || rawFor(id)); }
      }
      const missing = ids.filter((id, i) => !raws[i]);
      if (missing.length) { say('Can\'t read option ' + missing.join(', '), 3000); return; }

      // Tickets are numbered per option, in the order the options sit in
      // the lead (top one = 1, next = 2, …). An option that already has
      // several tickets keeps them, each as its own ticket. Segments are
      // sorted by Sort Me but every segment keeps its own ticket number.
      const opts = ids.map((id, i) => ({ id, legs: parseRawSegments(raws[i]), detail: details[i] }));
      if (opts.some((o) => !o.legs.length)) { say('No segments found', 2500); return; }
      const tickets = []; // [{ cost }]
      const legs = [];
      opts.forEach((o) => {
        const parts = o.detail ? ticketsFromDetail(o.detail) : null;
        if (parts && parts.length) {
          const base = tickets.length;
          parts.forEach((p) => tickets.push({ cost: p.cost }));
          o.legs.forEach((l, k) => { l.ticket = base + 1 + (parts.findIndex((p) => p.segNums.includes(k + 1)) >= 0 ? parts.findIndex((p) => p.segNums.includes(k + 1)) : 0); legs.push(l); });
        } else {
          tickets.push({ cost: costFor(o.id) });
          o.legs.forEach((l) => { l.ticket = tickets.length; legs.push(l); });
        }
      });
      if (tickets.length > 4) { say('Max 4 tickets', 2500); return; }
      const sorted = reorderByContinuity(legs);
      const mergedText = buildMerged(sorted);
      const ticketOfSeg = sorted.map((l) => l.ticket);
      const costs = tickets.map((t) => t.cost);
      const opts2 = tickets; // one entry per ticket for the price step

      sendJobActive = true; // keep the modal's own auto-carrier/auto-next out of it
      const plus = headerCell.querySelector('svg.feather-plus');
      const plusBtn = plus && plus.closest('button');
      if (!plusBtn) { say('No + button', 2500); return; }
      plusBtn.click();
      const modal = await waitFor(() => document.querySelector('.app-modal__container--price-quote'), 10000);
      const ta = modal && await waitFor(() => modal.querySelector('textarea.font-robotoMono'), 8000);
      if (!ta) { say('Form did not open', 2500); return; }
      setField(ta, mergedText);
      await wait(250);
      await selectCarrier(modal, detectCarrier(sorted));
      await wait(200);

      // Ticket numbers per option.
      say('Tickets…');
      const n1 = await findNextButtonReady();
      if (!n1) { say('Next not found', 2500); return; }
      n1.click();
      if (!(await waitFor(() => modal.querySelector('.input-select__value'), 10000))) { say('Segment step did not load', 2500); return; }
      await wait(200);
      if (!(await setSegmentTickets(modal, ticketOfSeg))) { say('Could not set ticket numbers', 3000); return; }
      await wait(250);
      const n2 = await findNextButtonReady();
      if (n2) n2.click();
      await wait(500);
      await selectPcc(modal, AUTO_PCC_CODE);
      const net = await waitFor(() => Array.from(modal.querySelectorAll('label.form-label')).find((l) => /^net\b/i.test(l.textContent.trim())), 12000);
      if (!net) { say('Price step did not load', 2500); return; }

      // Multiple Tkt, then each option's own cost in its own ticket.
      const multi = Array.from(modal.querySelectorAll('button')).find((b) => /^multiple\s*tkt$/i.test(b.textContent.trim()));
      if (!multi) { say('No Multiple Tkt button', 2500); return; }
      multi.click();
      const awardBtns = await waitFor(() => { const a = Array.from(modal.querySelectorAll('button')).filter((b) => b.textContent.trim() === 'Award'); return a.length >= opts2.length ? a : null; }, 8000);
      if (!awardBtns) { say('Tickets did not appear', 2500); return; }
      const noCost = [];
      const noCom = [];
      for (let i = 0; i < opts2.length; i++) {
        const c = costs[i];
        if (!c) { noCost.push(i + 1); continue; }
        // Fresh every time: filling one ticket can re-render the others.
        const btnNow = Array.from(modal.querySelectorAll('button')).filter((b) => b.textContent.trim() === 'Award')[i];
        if (!btnNow) { noCost.push(i + 1); continue; }
        const scope = ticketBlock(modal, btnNow);
        if (c.mode === 'award') {
          // Click this ticket's own Award switch, re-trying until its
          // Miles box shows up (a click during a redraw can get lost).
          const awardBtnAt = () => Array.from(modal.querySelectorAll('button')).filter((b) => b.textContent.trim() === 'Award')[i];
          const scopeNow = () => { const b = awardBtnAt(); return b ? ticketBlock(modal, b) : scope; };
          let mi = null;
          for (let t = 0; t < 4 && !mi; t++) {
            const b = awardBtnAt();
            if (b) { b.scrollIntoView({ block: 'nearest' }); b.click(); }
            mi = await waitFor(() => inputByLabel(scopeNow(), 'MILES'), 1500, 100);
          }
          const sc = scopeNow();
          const tx = inputByLabel(sc, 'TAXES');
          if (!mi || !tx) { noCost.push(i + 1); continue; }
          setField(mi, c.miles);
          setField(tx, c.taxes);
          if (!(await selectMileProgram(sc, c.program))) noCost.push(i + 1);
        } else {
          // Same sell type as the original option (Published / Private / CK).
          const st = String(c.sellType || '').toLowerCase();
          const want = /private/.test(st) ? 'Private' : (/^ck$|consolid/.test(st) ? 'CK' : 'Published');
          const stBtn = want && Array.from(scope.querySelectorAll('button')).find((b) => b.textContent.trim() === want);
          if (stBtn) { stBtn.click(); await wait(250); }
          // This ticket's area on screen: from its Award switch down to the
          // next ticket's (or the end of the form).
          const band = () => {
            const all = Array.from(modal.querySelectorAll('button')).filter((b) => b.textContent.trim() === 'Award');
            const top = all[i] ? all[i].getBoundingClientRect().top - 4 : null;
            const nxt = all[i + 1] ? all[i + 1].getBoundingClientRect().top - 60 : null;
            return [top, nxt];
          };
          // Every passenger type the option has (ADT, CHD, INF), each on
          // its own, so one filling first never cuts the others short.
          for (const type of ['ADT', 'CHD', 'INF']) {
            if (c[type] == null) continue;
            const one = { [type]: c[type] };
            const ok = await waitFor(() => {
              const sc = (() => { const b = Array.from(modal.querySelectorAll('button')).filter((x) => x.textContent.trim() === 'Award')[i]; return b ? ticketBlock(modal, b) : scope; })();
              if (fillCashNet(sc, one)) return true;
              const [y0, y1] = band();
              return fillCashNetByLayout(modal, one, y0, y1) ? true : null;
            }, 4000, 150);
            if (!ok) noCost.push((i + 1) + ' ' + type);
            await wait(120);
          }
          // Then each passenger type's Com. val., in the same ticket.
          const COM = /^com\.?\s*val\.?\*?$/i;
          for (const type of ['ADT', 'CHD', 'INF']) {
            if (!c.com || c.com[type] == null) continue;
            const one = { [type]: c.com[type] };
            const ok = await waitFor(() => {
              const sc = (() => { const b = Array.from(modal.querySelectorAll('button')).filter((x) => x.textContent.trim() === 'Award')[i]; return b ? ticketBlock(modal, b) : scope; })();
              if (fillCashNet(sc, one, COM)) return true;
              const [y0, y1] = band();
              return fillCashNetByLayout(modal, one, y0, y1, COM) ? true : null;
            }, 4000, 150);
            if (!ok) noCom.push((i + 1) + ' ' + type);
            await wait(120);
          }
        }
        await wait(150);
      }
      // Stops before Save so you can check it.
      const todo = [];
      if (noCost.length) todo.push('fill cost: tkt ' + noCost.join(', '));
      if (noCom.length) todo.push('fill Com. val.: tkt ' + noCom.join(', '));
      say(todo.length ? '✓ Merged — ' + todo.join(' · ') : '✓ Merged — check & Save', todo.length ? 6000 : 3000);
    } catch (e) {
      say('Merge failed', 2500);
    } finally {
      sendJobActive = false;
      merging = false;
    }
  }

  // Click "#630962," under the client's name → copies 630962.
  function wireLeadIdCopy() {
    document.querySelectorAll('div.text-secondary-400.text-xs.font-medium:not([data-ia-idcopy])').forEach((el) => {
      const m = el.textContent.match(/#\s*(\d{5,})/);
      if (!m) return;
      el.setAttribute('data-ia-idcopy', '1');
      el.style.cursor = 'copy';
      el.title = 'Click to copy lead ID';
      el.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const id = (el.textContent.match(/#\s*(\d{5,})/) || [])[1];
        if (!id) return;
        try { GM_setClipboard(id, 'text'); } catch (err) { try { navigator.clipboard.writeText(id); } catch (e2) { /* ignore */ } }
        el.classList.add('ia-idcopied');
        setTimeout(() => el.classList.remove('ia-idcopied'), 900);
      }, true);
    });
  }

  // ==================================================================
  // Quick SELL edit — a pen next to each SELL amount on an option
  // (ADT / CHD / INF). Type the price, Enter: saved straight to the BO
  // (the same PUT its own "edit → Save" sends), nothing else changes.
  // ==================================================================
  const PQ_SHAPE_KEY = 'js-pq-shape';
  const PQ_TOP_KEYS = ['lead_id', 'raw_segments', 'validating_carrier_id', 'currency_id', 'active_till', 'adult_count', 'child_count', 'infant_count', 'itinerary_type', 'client_remark', 'agent_remark', 'saleType', 'check_payment_ps', 'tour_fare_type', 'hotel_info', 'published_price', 'segments', 'preTickets'];
  const PQ_SEG_KEYS = ['type', 'flight_id', 'id', 'is_return', 'line_raw', 'number', 'part_number', 'pre_ticket_id', 'original_pre_ticket_id', 'pre_ticket_number', 'additional', 'flight_class', 'baggage_quantity', 'baggage_weight'];

  // Whenever the BO itself saves an option, note exactly which fields it
  // sends, so our save always matches the BO's own.
  function learnPqShape(body) {
    try {
      const b = typeof body === 'string' ? JSON.parse(body) : body;
      if (!b || !Array.isArray(b.segments) || !Array.isArray(b.preTickets)) return;
      const shape = { top: Object.keys(b), seg: b.segments[0] ? Object.keys(b.segments[0]) : null };
      GM_setValue(PQ_SHAPE_KEY, JSON.stringify(shape));
    } catch (e) { /* ignore */ }
  }

  function buildPqBody(r) {
    let shape = null;
    try { shape = JSON.parse(GM_getValue(PQ_SHAPE_KEY, 'null')); } catch (e) { shape = null; }
    const top = (shape && shape.top) || PQ_TOP_KEYS;
    const segKeys = (shape && shape.seg) || PQ_SEG_KEYS;
    const body = {};
    top.forEach((k) => {
      if (k === 'segments') {
        body.segments = (r.segments || []).map((sg) => { const o = {}; segKeys.forEach((sk) => { o[sk] = sk === 'type' && sg.type == null ? '' : sg[sk]; }); return o; });
      } else if (k === 'published_price') {
        body.published_price = r.published_price != null ? r.published_price : 0;
      } else if (r[k] !== undefined) {
        body[k] = r[k];
      } else if (k === 'client_remark' || k === 'agent_remark') {
        body[k] = '';
      } else {
        body[k] = null;
      }
    });
    return body;
  }

  async function apiSend(method, path, body) {
    const headers = Object.assign({ Accept: 'application/json', 'Content-Type': 'application/json' }, apiHeaders);
    if (!Object.keys(headers).some((k) => /authorization/i.test(k))) { const sa2 = __jsStoredAuth(); if (sa2) headers.Authorization = sa2; }
    const doFetch = pageFetch || window.fetch.bind(window);
    const r = await doFetch(path, { method, credentials: 'include', headers, body: JSON.stringify(body) });
    let j = null;
    try { j = await r.json(); } catch (e) { /* ignore */ }
    if (!r.ok || (j && j.success === false)) {
      let msg = (j && (j.message || j.error)) || ('HTTP ' + r.status);
      const errs = j && (j.errors || (j.result && j.result.errors));
      if (errs && typeof errs === 'object') msg += ' — ' + JSON.stringify(errs).slice(0, 300);
      throw new Error(msg);
    }
    return j;
  }

  async function saveSellPrice(optionId, type, value, netShown) {
    const r = await loadOptionDetail(optionId);
    if (!r) throw new Error('Could not load the option');
    const want = { ADT: 'adult', CHD: 'child', INF: 'infant' }[type];
    // Safety check: the option we're about to change must have the same
    // Net as the row you edited. If not, it's the wrong option — stop.
    if (netShown != null) {
      const netBo = (r.preTickets || []).map((pt) => (pt.prices || []).find((p) => String(p.passenger_type).toLowerCase() === want)).filter(Boolean)
        .reduce((t, p) => t + (Number(p.net_price) || 0), 0);
      if (Math.abs(netBo - netShown) > 1) {
        throw new Error('this row (Net ' + money(netShown) + ') does not match option ' + optionId + ' in the BO (Net ' + money(netBo) + '). Nothing was changed \u2014 refresh the page and try again');
      }
    }
    // The SELL shown is the total over all of the option's tickets. With
    // several tickets the new total is split by each ticket's Net (so each
    // ticket keeps its share); cents left over go on the last one.
    const rows = (r.preTickets || []).map((pt) => (pt.prices || []).find((p) => String(p.passenger_type).toLowerCase() === want)).filter(Boolean);
    if (!rows.length) throw new Error('No ' + type + ' price on this option');
    if (rows.length === 1) {
      rows[0].sell_amount = value;
    } else {
      const nets = rows.map((p) => Math.max(0, Number(p.net_price) || 0));
      const tot = nets.reduce((a, b) => a + b, 0);
      let left = value;
      rows.forEach((p, i) => {
        if (i === rows.length - 1) { p.sell_amount = Math.round(left * 100) / 100; return; }
        const share = Math.round((tot ? value * nets[i] / tot : value / rows.length) * 100) / 100;
        p.sell_amount = share;
        left -= share;
      });
    }
    // The BO hands cash tickets back with mile program -1 ("none"), but
    // must receive null for it — sending -1 back is what made it refuse.
    (r.preTickets || []).forEach((pt) => {
      if (!(Number(pt.mile_price_program_id) > 0)) pt.mile_price_program_id = null;
      if (!/award/i.test(pt.sell_type || '')) {
        if (!Number(pt.miles_count)) pt.miles_count = null;
        if (!Number(pt.award_tax_amount)) pt.award_tax_amount = null;
      }
      (pt.prices || []).forEach((pr) => { if (pr.upgrade_mile_price_program_id != null && !(Number(pr.upgrade_mile_price_program_id) > 0)) pr.upgrade_mile_price_program_id = null; });
    });
    const url = '/api/database/v1/priceQuotes/PriceQuoteFormModel/' + optionId;
    try {
      await apiSend('PUT', url, buildPqBody(r));
    } catch (e1) {
      // Second try: send the option exactly as the BO gave it to us
      // (every field), in case this kind of option needs more of them.
      const full = Object.assign({}, r);
      ['id', 'created_by', 'created_at', 'is_viewed', 'is_viewed_at', 'is_sent', 'is_sent_at'].forEach((k) => delete full[k]);
      if (full.published_price == null) full.published_price = 0;
      try { await apiSend('PUT', url, full); } catch (e2) { throw new Error(e1.message + (e2.message !== e1.message ? ' / ' + e2.message : '')); }
    }
    // Never trust "saved" on its word: read the option back from the BO and
    // only report success if the new Sell price is really stored there.
    const back = await loadOptionDetail(optionId);
    const stored = back && (back.preTickets || []).map((pt) => (pt.prices || []).find((p) => String(p.passenger_type).toLowerCase() === want)).filter(Boolean)
      .reduce((t, p) => t + (Number(p.sell_amount) || 0), 0);
    if (!back || Math.abs((stored || 0) - value) > 0.02) {
      throw new Error('The BO did not keep the new Sell price (it still has ' + money(stored || 0) + '). Please set it with edit.');
    }
    return back;
  }

  const money = (n) => (n < 0 ? '-' : '') + '$' + Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const parseCell = (t) => parseFloat(String(t || '').replace(/[^\d.-]/g, '')) || 0;

  // Accepts plain prices only: 8103 / 8103.24 / 8,103.24 / $8103.24.
  // Two or more dots in a row count as one ("8103..24" -> 8103.24).
  // Anything else (letters, quotes, two separate dots...) is refused.
  function parseSellInput(raw) {
    let t = String(raw || '').trim().replace(/^\$\s*/, '').replace(/\.{2,}/g, '.');
    if (/^\d{1,3}(,\d{3})+(\.\d{1,2})?$/.test(t)) t = t.replace(/,/g, '');
    if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
    const v = Math.round(parseFloat(t) * 100) / 100;
    return Number.isFinite(v) ? v : null;
  }
  function showSellToast(msg) {
    const toast = document.createElement('div');
    toast.className = 'ia-sell-toast';
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 6000);
  }

  // ---- $0.00 send guard ---------------------------------------------
  // Pressing Send on the quote email: if any quote in it shows $0.00,
  // stop and ask first.
  function zeroPriceQuotes() {
    const docs = [document];
    document.querySelectorAll('iframe').forEach((f) => { try { if (f.contentDocument) docs.push(f.contentDocument); } catch (e) { /* other origin */ } });
    const hits = [];
    docs.forEach((d) => {
      d.querySelectorAll('b.n').forEach((b) => {
        const t = b.textContent.replace(/\s+/g, ' ').trim();
        if (!/^\$\s?0(\.0+)?(\s|$)/.test(t)) return;
        const cell = b.closest('td') || b.parentElement;
        const img = cell && cell.querySelector('img[alt]');
        hits.push(img ? img.getAttribute('alt') : 'a quote');
      });
      // The other email design: "$0.00 USD" in a bold <p>, with "Total per
      // adult" under it and the airline's logo (carrier_img/PR.png) above.
      d.querySelectorAll('p').forEach((p) => {
        if (p.closest('b.n')) return;
        const t = p.textContent.replace(/\s+/g, ' ').trim();
        if (!/^\$\s?0(\.0+)?(\s?[A-Z]{3})?$/.test(t)) return;
        const cell = p.closest('td') || p.parentElement;
        if (!cell || !/total per|per (adult|person|passenger)/i.test(cell.textContent)) return;
        const img = cell.querySelector('img');
        const alt = img && img.getAttribute('alt');
        const code = img && ((img.getAttribute('src') || '').match(/carrier_img\/([A-Z0-9]{2})\./i) || [])[1];
        hits.push(alt || (code ? code.toUpperCase() : 'a quote'));
      });
    });
    return hits;
  }
  let zeroSendApproved = false;
  if (window.top === window) {
    document.addEventListener('click', (e) => {
      const btn = e.target && e.target.closest && e.target.closest('button.button.--primary');
      if (!btn || btn.textContent.trim() !== 'Send') return;
      if (zeroSendApproved) { zeroSendApproved = false; return; }
      const hits = zeroPriceQuotes();
      if (!hits.length) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      const back = document.createElement('div');
      back.className = 'ia-zero-back';
      const box = document.createElement('div');
      box.className = 'ia-zero-box';
      const h = document.createElement('div');
      h.className = 'ia-zero-title';
      h.textContent = '$0.00 price in this send';
      box.appendChild(worriedPip(84));
      const p2 = document.createElement('div');
      p2.className = 'ia-zero-text';
      p2.textContent = (hits.length === 1 ? '1 quote shows' : hits.length + ' quotes show') + ' $0.00 to the client (' + hits.join(', ') + '). Set the Sell price before sending.';
      const row = document.createElement('div');
      row.className = 'ia-zero-row';
      const no = document.createElement('button');
      no.type = 'button'; no.className = 'ia-zero-no'; no.textContent = 'Go back';
      const yes = document.createElement('button');
      yes.type = 'button'; yes.className = 'ia-zero-yes'; yes.textContent = 'Send anyway';
      row.append(no, yes);
      box.append(h, p2, row);
      back.appendChild(box);
      document.body.appendChild(back);
      no.focus();
      no.addEventListener('click', () => back.remove());
      yes.addEventListener('click', () => { back.remove(); zeroSendApproved = true; btn.click(); });
    }, true);
  }

  // Which option a price table belongs to — read from the page at the
  // moment it's needed. (The BO reuses the same table elements for
  // different options when its list re-renders, so an id remembered
  // earlier can point at the wrong option: that is what made a new price
  // land on the option below and not on the one that was edited.)
  function optionIdOfTable(table) {
    const opt = table.closest('.lead-option') || table.closest('[class*="lead-option"]');
    let cb = opt && opt.querySelector('input[id^="checkbox-switch-"]');
    for (let up = table.parentElement; !cb && up && up !== document.body; up = up.parentElement) {
      const all = up.querySelectorAll('input[id^="checkbox-switch-"]');
      if (all.length === 1) cb = all[0];
      if (all.length > 1) break;
    }
    return cb ? cb.id.replace('checkbox-switch-', '') : null;
  }

  // Flight fingerprint of a segment line: "AC8502 21APR ATLYYZ".
  function segSig(line) {
    const m = String(line || '').toUpperCase().match(/\b([A-Z0-9]{2})\s*\*?\s*(\d{1,4})\s+[A-Z]\s+(\d{2}[A-Z]{3})\s+([A-Z]{3})\s*([A-Z]{3})\b/);
    return m ? m[1] + parseInt(m[2], 10) + ' ' + m[3] + ' ' + m[4] + m[5] : null;
  }
  // The flights shown in the same option card as this price table.
  function shownSegSigs(table) {
    for (let up = table.parentElement; up && up !== document.body; up = up.parentElement) {
      const boxes = up.querySelectorAll('.lead-option-segment-segments');
      if (boxes.length > 1) return null; // went past this option
      if (boxes.length === 1) {
        const sigs = Array.from(boxes[0].querySelectorAll(':scope > pre')).map((p) => segSig((p.querySelector('.overflow-hidden') || p).textContent)).filter(Boolean);
        return sigs.length ? sigs : null;
      }
    }
    return null;
  }
  function detailSegSigs(r) {
    return (r.segments || []).slice().sort((a, b) => (a.number || 0) - (b.number || 0)).map((sg) => segSig(sg.line_raw)).filter(Boolean);
  }
  // Finds the option this price table REALLY belongs to: its flights and
  // its Net must match what the BO has for that option. Tries the option
  // the page layout points at first, then every other option on the page.
  // Returns null unless exactly one option matches.
  async function resolveOptionForTable(table, type, netShown) {
    const want = { ADT: 'adult', CHD: 'child', INF: 'infant' }[type];
    const sigs = shownSegSigs(table);
    const first = optionIdOfTable(table);
    const ids = Array.from(new Set([first].concat(Array.from(document.querySelectorAll('input[id^="checkbox-switch-"]')).map((c) => c.id.replace('checkbox-switch-', ''))).filter(Boolean)));
    const fits = (r) => {
      if (!r) return false;
      if (sigs && detailSegSigs(r).join('|') !== sigs.join('|')) return false;
      if (netShown != null) {
        const netBo = (r.preTickets || []).map((pt) => (pt.prices || []).find((x) => String(x.passenger_type).toLowerCase() === want)).filter(Boolean)
          .reduce((t, x) => t + (Number(x.net_price) || 0), 0);
        if (Math.abs(netBo - netShown) > 1) return false;
      }
      return true;
    };
    if (!sigs && netShown == null) return null; // nothing to check against: refuse
    if (first) {
      const r = await loadOptionDetail(first);
      if (fits(r) && sigs) return { id: first, netChecked: true }; // flights + Net match: certain
    }
    const details = await Promise.all(ids.map((id) => loadOptionDetail(id).then((r) => ({ id, r })).catch(() => ({ id, r: null }))));
    const hits = details.filter((d) => fits(d.r));
    if (hits.length === 1) return { id: hits[0].id, netChecked: true };
    // Award options: the Net the page shows (miles value + taxes) isn't the
    // number the BO stores, so the Net check can't be used. Then the option
    // is accepted only when two independent things agree: it's the ONLY
    // option on the page with exactly these flights, AND it's the option
    // this table sits in.
    if (!hits.length && sigs && first) {
      const sameFlights = details.filter((d) => d.r && detailSegSigs(d.r).join('|') === sigs.join('|'));
      if (sameFlights.length === 1 && sameFlights[0].id === first) return { id: first, netChecked: false };
    }
    return null;
  }

  function wireSellEdit() {
    if (window.top !== window) return;
    document.querySelectorAll('table.lead-option-price-table').forEach((table) => {
      const heads = Array.from(table.querySelectorAll('thead th')).map((th) => th.textContent.trim().toUpperCase());
      const sellIdx = heads.indexOf('SELL');
      const netIdx = heads.indexOf('NET');
      if (sellIdx < 0) return;
      if (!optionIdOfTable(table)) return;
      table.querySelectorAll('tbody tr').forEach((tr) => {
        const tds = tr.querySelectorAll('td');
        const type = (tds[0] ? tds[0].textContent : '').trim().toUpperCase();
        if (!['ADT', 'CHD', 'INF'].includes(type)) return;
        const cell = tds[sellIdx];
        if (!cell || cell.querySelector('.ia-sell-pen')) return;
        const pen = document.createElement('span');
        pen.className = 'ia-sell-pen';
        pen.title = 'Edit ' + type + ' sell price';
        pen.innerHTML = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>';
        cell.insertBefore(pen, cell.firstChild);
        cell.style.whiteSpace = 'nowrap';
        const zero = () => { const t = Array.from(cell.childNodes).filter((n) => n.nodeType === 3).map((n) => n.textContent).join(''); return parseCell(t) === 0; };
        const syncPen = () => { if (!cell.querySelector('.ia-sell-input')) pen.style.display = zero() ? '' : 'none'; };
        syncPen();
        cell._jsSyncPen = syncPen;
        cell.classList.add('ia-sell-cell');
        cell.title = 'Click to edit ' + type + ' sell price';
        cell.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (cell.querySelector('.ia-sell-input')) return;
          const textNode = Array.from(cell.childNodes).find((n) => n.nodeType === 3 && n.textContent.trim());
          const old = parseCell(textNode ? textNode.textContent : cell.textContent);
          const input = document.createElement('input');
          input.className = 'ia-sell-input';
          input.type = 'text';
          input.inputMode = 'decimal';
          input.value = old ? String(old) : '';
          cell.style.whiteSpace = 'nowrap';
          if (textNode) textNode.textContent = '';
          pen.style.display = 'none';
          cell.appendChild(input);
          input.focus();
          input.select();
          let busy = false;
          const close = (shown) => { input.remove(); if (textNode) textNode.textContent = shown; pen.style.display = ''; if (cell._jsSyncPen) cell._jsSyncPen(); };
          const commit = async () => {
            if (busy) return;
            const v = parseSellInput(input.value);
            if (v === null) {
              // Not a clean number (e.g. "8103.'24"): refuse, keep editing.
              input.classList.add('is-bad');
              input.title = 'Numbers only, e.g. 8103.24';
              showSellToast('Not saved \u2014 "' + input.value + '" is not a valid price. Use numbers only, e.g. 8103.24');
              setTimeout(() => input.focus(), 0);
              return;
            }
            if (v === old) { close(money(old)); return; }
            busy = true;
            input.disabled = true;
            input.classList.add('is-saving');
            try {
              // Re-read everything from the page right now: the option this
              // table shows, and this row's Net (used as a cross-check).
              const rowNow = Array.from(table.querySelectorAll('tbody tr')).find((r) => ((r.querySelector('td') || {}).textContent || '').trim().toUpperCase() === type);
              const netShown = rowNow && netIdx >= 0 ? parseCell(rowNow.querySelectorAll('td')[netIdx].textContent) : null;
              // Identify the option by its flights + Net in the BO, never by
              // page position alone.
              const found = await resolveOptionForTable(table, type, netShown);
              if (!found) throw new Error('could not be sure which option this is, so nothing was changed \u2014 please use edit for this one');
              await saveSellPrice(found.id, type, Math.round(v * 100) / 100, found.netChecked ? netShown : null);
              close(money(v));
              cell.classList.add('ia-sell-saved');
              setTimeout(() => cell.classList.remove('ia-sell-saved'), 1200);
              // Keep the TTL row and the profit badge in step.
              const rows = Array.from(table.querySelectorAll('tbody tr'));
              const ttl = rows.find((r) => /^TTL$/i.test((r.querySelector('td') || {}).textContent.trim()));
              if (ttl) {
                let sum = 0;
                let net = 0;
                rows.forEach((r) => {
                  const c = r.querySelectorAll('td');
                  if (!['ADT', 'CHD', 'INF'].includes((c[0] || {}).textContent.trim().toUpperCase())) return;
                  const qty = parseCell((c[1] || {}).textContent) || 1;
                  const sellTxt = Array.from(c[sellIdx].childNodes).filter((n) => n.nodeType === 3).map((n) => n.textContent).join('');
                  sum += parseCell(sellTxt) * qty;
                  if (netIdx >= 0) net += parseCell(c[netIdx].textContent) * qty;
                });
                const tc = ttl.querySelectorAll('td')[sellIdx];
                if (tc) tc.textContent = money(sum);
                const badge = table.parentElement && table.parentElement.querySelector('.lead-option-price-total');
                if (badge && netIdx >= 0) badge.textContent = money(sum - net);
              }
            } catch (err) {
              close(money(old));
              cell.classList.add('ia-sell-err');
              cell.title = 'Not saved: ' + (err && err.message ? err.message : err);
              const toast = document.createElement('div');
              toast.className = 'ia-sell-toast';
              toast.textContent = 'Sell price not saved: ' + (err && err.message ? err.message : err);
              document.body.appendChild(toast);
              setTimeout(() => toast.remove(), 7000);
              setTimeout(() => cell.classList.remove('ia-sell-err'), 2500);
            }
          };
          input.addEventListener('input', () => { input.classList.remove('is-bad'); });
          input.addEventListener('keydown', (ev) => {
            ev.stopPropagation();
            if (ev.key === 'Enter') { ev.preventDefault(); commit(); }
            if (ev.key === 'Escape') { ev.preventDefault(); close(money(old)); }
          });
          input.addEventListener('blur', () => { if (busy) return; if (parseSellInput(input.value) === null) { close(money(old)); return; } commit(); });
          ['click', 'mousedown'].forEach((t) => input.addEventListener(t, (ev) => ev.stopPropagation()));
        });
      });
    });
  }

  // ==================================================================
  // SEARCH PANEL — replaces the BO's Kayak-price box on a lead with quick
  // search buttons for that lead (Google, ELR, Matrix ▾, PointsYeah ▾,
  // Basis ▾, Kayak) plus cabin / ±days and "Open all" (Kayak + Matrix in
  // background tabs). The lead's route, dates and passengers are read from
  // the BO's own Matrix link inside that same box. URL builders adapted
  // from the Flight Search widget.
  // ==================================================================
  const FXP_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const FXP_ITA_CABIN = { COACH: 'Y', ECONOMY: 'Y', 'PREMIUM-COACH': 'W', PREMIUM_COACH: 'W', 'PREMIUM-ECONOMY': 'W', PREMIUM_ECONOMY: 'W', BUSINESS: 'B', FIRST: 'F' };
  const srchCabinLabel = (c) => ({ Y: 'Economy', W: 'Premium Economy', B: 'Business', F: 'First' }[c] || 'Business');
  const srchAddDays = (d, n) => { const x = new Date(d + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
  const srchFmt = (d) => { if (!d) return '?'; const p = d.split('-'); return parseInt(p[2], 10) + ' ' + FXP_MONTHS[parseInt(p[1], 10) - 1]; };

  function srchLeadFromBox(box) {
    const a = box.querySelector('a[href*="matrix.itasoftware.com/search"]');
    if (!a) return null;
    let p;
    try { p = JSON.parse(atob(new URL(a.href, location.origin).searchParams.get('search'))); } catch (e) { return null; }
    if (!p || !Array.isArray(p.slices) || !p.slices.length) return null;
    const segs = p.slices.map((sl) => ({
      origin: (Array.isArray(sl.origin) ? sl.origin[0] : sl.origin) || null,
      destination: (Array.isArray(sl.dest) ? sl.dest[0] : sl.dest) || null,
      departureDate: (sl.dates && sl.dates.departureDate) || null,
      returnDate: (sl.dates && sl.dates.returnDate) || null,
    })).filter((s) => s.origin && s.destination && s.departureDate);
    if (!segs.length) return null;
    const pax = p.pax || {};
    return {
      segments: segs,
      cabin: FXP_ITA_CABIN[String((p.options && p.options.cabin) || '').toUpperCase()] || 'B',
      adults: parseInt(pax.adults, 10) || 1,
      children: parseInt(pax.children, 10) || 0,
      infants: (parseInt(pax.infantInLap, 10) || 0) + (parseInt(pax.infantInSeat, 10) || 0),
    };
  }
  // Multi-city leads: the BO's box has no Matrix link and only the remark
  // holds the trip, e.g. "SFO HKG 23.12 | HKG KUL 03.01 | KUL SFO 08.12".
  // Dates are day.month; the year comes from the lead card's first date
  // and rolls forward when a leg's month goes back. Passengers and cabin
  // come from the lead card. A leg more than ~6 months after the one
  // before it is flagged (likely a typo) rather than guessed.
  function srchCardInfo(leadId) {
    const tag = Array.from(document.querySelectorAll('span')).find((sp) => sp.textContent.trim() === '#' + leadId);
    if (!tag) return null;
    let root = tag;
    for (let i = 0; i < 12 && root; i++) {
      root = root.parentElement;
      if (root && root.querySelectorAll('.text-base.leading-6.font-semibold').length >= 2) break;
    }
    if (!root) return null;
    let date = null;
    for (const sp of root.querySelectorAll('span.font-semibold')) {
      const m = sp.textContent.trim().match(/^(\d{1,2})\s+([A-Za-z]{3})$/);
      const y = sp.nextElementSibling && sp.nextElementSibling.textContent.trim();
      const mi = m ? FXP_MONTHS.findIndex((x) => x.toLowerCase() === m[2].toLowerCase()) : -1;
      if (m && mi >= 0 && /^\d{4}$/.test(y || '')) { date = { y: +y, m: mi + 1, d: +m[1] }; break; }
    }
    let cabin = null;
    for (const sp of root.querySelectorAll('span.font-medium')) {
      const nx = sp.nextElementSibling;
      if (nx && /^class$/i.test(nx.textContent.trim())) { const c = sp.textContent.trim().toUpperCase(); cabin = { C: 'B', J: 'B', P: 'W' }[c] || (['Y', 'W', 'B', 'F'].includes(c) ? c : null); break; }
    }
    return { date, cabin };
  }
  function srchLeadFromRemark() {
    const idm = location.pathname.match(/^\/leads\/(\d+)/);
    const ta = document.querySelector('textarea.lead-remark-text');
    if (!idm || !ta || !ta.value) return null;
    const re = /\b([A-Za-z]{3})\s*(?:-|–|>|→|\s)\s*([A-Za-z]{3})\s+(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?\b/;
    const raw = [];
    ta.value.split(/[|\n;]+/).forEach((part) => { const m = part.match(re); if (m) raw.push(m); });
    if (!raw.length) return null;
    const card = srchCardInfo(idm[1]) || {};
    const pax = (readLeadCard(idm[1]) || {}).pax || { adults: 1, children: 0, infants: 0 };
    const iso = (y, m, d) => y + '-' + String(m).padStart(2, '0') + '-' + String(d).padStart(2, '0');
    const now = new Date();
    const base = card.date ? new Date(Date.UTC(card.date.y, card.date.m - 1, card.date.d)) : new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
    let year = base.getUTCFullYear();
    let prev = null;
    const warn = [];
    const segs = [];
    raw.forEach((m, i) => {
      const d = +m[3], mo = +m[4];
      if (mo < 1 || mo > 12 || d < 1 || d > 31) return;
      let y = m[5] ? (m[5].length === 2 ? 2000 + +m[5] : +m[5]) : year;
      let t = Date.UTC(y, mo - 1, d);
      if (!m[5]) {
        if (!prev && t < base.getTime() - 60 * 864e5) { y++; t = Date.UTC(y, mo - 1, d); }
        if (prev && t < prev) { y++; t = Date.UTC(y, mo - 1, d); }
      }
      if (prev && t - prev > 183 * 864e5) warn.push('check leg ' + (i + 1) + ' date (' + m[3] + '.' + m[4] + ')');
      prev = t;
      year = y;
      segs.push({ origin: m[1].toUpperCase(), destination: m[2].toUpperCase(), departureDate: iso(y, mo, d), returnDate: null });
    });
    if (!segs.length) return null;
    return { segments: segs, cabin: card.cabin || 'B', adults: Math.max(1, pax.adults || 1), children: pax.children || 0, infants: pax.infants || 0, fromRemark: true, warn };
  }
  // Last resort: some leads have the trip in the BO but no usable Matrix
  // link in the box (it shows "Matrix 0") and nothing in the remark. Ask
  // the BO for the lead (route, dates, passengers) once, then rebuild.
  const srchApiCache = new Map(); // lead id -> lead object | null (none) | 'wait'
  function srchIsoDay(unix, tz) {
    if (!unix) return null;
    const d = new Date(Number(unix) * 1000);
    if (isNaN(d)) return null;
    try { return new Intl.DateTimeFormat('en-CA', { timeZone: tz || 'UTC', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d); }
    catch (e) { return d.toISOString().slice(0, 10); }
  }
  function srchLeadFromApi() {
    const idm = location.pathname.match(/^\/leads\/(\d+)/);
    if (!idm) return null;
    const id = idm[1];
    if (srchApiCache.has(id)) { const v = srchApiCache.get(id); return v && v !== 'wait' ? v : null; }
    const h = Object.assign({ Accept: 'application/json' }, __jsApi.headers);
    if (!Object.keys(h).some((k) => /authorization/i.test(k))) { const sa = __jsStoredAuth(); if (sa) h.Authorization = sa; else return null; }
    srchApiCache.set(id, 'wait');
    const w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
    w.fetch('/api/database/v2/Lead/find?pks=' + id, { credentials: 'include', headers: h })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        const r = j && (j.result || j.data);
        const L = Array.isArray(r) ? r[0] : null;
        const from = L && String(L.from_iata_code || '').toUpperCase();
        const to = L && String(L.to_iata_code || '').toUpperCase();
        const dep = L && srchIsoDay(L.departure_date, L.from_iata_timezone);
        if (!from || !to || !dep) { srchApiCache.set(id, null); return; }
        const ret = srchIsoDay(L.return_date, L.to_iata_timezone);
        const card = srchCardInfo(id) || {};
        const pax = (readLeadCard(id) || {}).pax || {};
        srchApiCache.set(id, {
          segments: [{ origin: from, destination: to, departureDate: dep, returnDate: ret }],
          cabin: card.cabin || 'B',
          adults: Math.max(1, parseInt(L.adult_count, 10) || pax.adults || 1),
          children: parseInt(L.child_count, 10) || pax.children || 0,
          infants: parseInt(L.infant_count, 10) || pax.infants || 0,
          fromApi: true,
        });
        try { wireSearchPanels(); } catch (e) { /* ignore */ }
      })
      .catch(() => { srchApiCache.delete(id); }); // try again on the next re-render
    return null;
  }
  // Sabre JR (Fast Search): JR.<from>/S-O<cabin><to><date>…, with
  // /S-ARUNK<city> where a leg starts somewhere other than the last one ended.
  function srchJR(lead, cab) {
    if (!lead) return '';
    const legs = srchLegs(lead).filter((l) => l.date && l.origin && l.destination);
    if (!legs.length) return '';
    const c = { B: 'C', W: 'S', F: 'F', Y: 'Y' }[cab] || 'C';
    const d = (iso) => { const p = iso.split('-'); return parseInt(p[2], 10) + FXP_MONTHS[parseInt(p[1], 10) - 1].toUpperCase(); };
    let cmd = 'JR.' + legs[0].origin;
    legs.forEach((lg, i) => {
      if (i > 0 && lg.origin !== legs[i - 1].destination) cmd += '/S-ARUNK' + lg.origin;
      cmd += '/S-O' + c + lg.destination + d(lg.date);
    });
    return cmd;
  }
  function srchLegs(lead) {
    const s = lead.segments;
    if (s.length === 1) {
      const legs = [{ label: 'Outbound', origin: s[0].origin, destination: s[0].destination, date: s[0].departureDate }];
      if (s[0].returnDate) legs.push({ label: 'Inbound', origin: s[0].destination, destination: s[0].origin, date: s[0].returnDate });
      return legs;
    }
    return s.map((x, i) => ({ label: 'Leg ' + (i + 1), origin: x.origin, destination: x.destination, date: x.departureDate }));
  }
  function srchKayak(lead, flex, cab) {
    const cabin = { Y: 'economy', W: 'premium', B: 'business', F: 'first' }[cab] || 'business';
    const k = Math.min(Math.max(parseInt(flex, 10) || 0, 0), 3); // Kayak only does ±1..±3
    const f = (d) => (d && k > 0 ? d + '-flexible-' + k + 'days' : d);
    const s = lead.segments;
    let path;
    if (s.length === 1) {
      path = '/flights/' + s[0].origin + '-' + s[0].destination + '/' + f(s[0].departureDate);
      if (s[0].returnDate) path += '/' + f(s[0].returnDate);
    } else {
      // Multi-city: Kayak has no flexible dates here, so exact dates only.
      path = '/flights/' + s.map((x) => x.origin + '-' + x.destination + '/' + x.departureDate).join('/');
    }
    path += '/' + cabin;
    // One adult is Kayak's default (its own multi-city links leave it out).
    if (s.length === 1 || lead.adults > 1 || lead.children || lead.infants) path += '/' + lead.adults + 'adults';
    const t = [];
    for (let i = 0; i < lead.infants; i++) t.push('1L');
    for (let i = 0; i < lead.children; i++) t.push('8');
    if (t.length) path += '/children-' + t.join('-');
    return 'https://www.kayak.com' + path + '?sort=bestflight_a';
  }
  function srchPbVarint(n) { const o = []; while (n > 127) { o.push((n & 0x7f) | 0x80); n >>>= 7; } o.push(n); return o; }
  const srchPbTag = (f, w) => srchPbVarint((f << 3) | w);
  const srchPbStr = (f, v) => { const b = Array.from(new TextEncoder().encode(v)); return [...srchPbTag(f, 2), ...srchPbVarint(b.length), ...b]; };
  const srchPbMsg = (f, b) => [...srchPbTag(f, 2), ...srchPbVarint(b.length), ...b];
  const srchPbNum = (f, v) => [...srchPbTag(f, 0), ...srchPbVarint(v)];
  function srchGoogle(lead, addYvr, cab) {
    const legs = srchLegs(lead).filter((l) => l.date && l.origin && l.destination);
    if (!legs.length) return 'https://www.google.com/travel/flights';
    let tripType;
    if (addYvr) {
      legs.push({ origin: legs[0].origin, destination: 'YVR', date: srchAddDays(legs[legs.length - 1].date, 1) });
      tripType = 3;
    } else {
      tripType = lead.segments.length > 1 ? 3 : (lead.segments[0].returnDate ? 1 : 2);
    }
    let body = [];
    legs.forEach((l) => { body = body.concat(srchPbMsg(3, [].concat(srchPbStr(2, l.date), srchPbMsg(13, srchPbStr(2, l.origin)), srchPbMsg(14, srchPbStr(2, l.destination))))); });
    for (let i = 0; i < lead.adults; i++) body = body.concat(srchPbNum(8, 1));
    for (let i = 0; i < lead.children; i++) body = body.concat(srchPbNum(8, 2));
    for (let i = 0; i < lead.infants; i++) body = body.concat(srchPbNum(8, 4));
    body = body.concat(srchPbNum(9, { Y: 1, W: 2, B: 3, F: 4 }[cab] || 3), srchPbNum(19, tripType));
    const tfs = btoa(String.fromCharCode.apply(null, body)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    return 'https://www.google.com/travel/flights?tfs=' + tfs + '&hl=en&curr=USD';
  }
  const FXP_ITA_EXT = { B: '2', W: 'premium-coach', F: '1', Y: '3' };
  function srchMatrix(lead, cab, mixDep, mixRet, flex) {
    const cabinMap = { Y: 'COACH', W: 'PREMIUM-COACH', B: 'BUSINESS', F: 'FIRST' };
    const segs = lead.segments;
    const multi = segs.length > 1;
    const n = Math.min(Math.max(parseInt(flex, 10) || 0, 0), 2);
    const mod = String(n) + String(n);
    const pax = { adults: String(lead.adults) };
    if (lead.children > 0) pax.children = String(lead.children);
    if (lead.infants > 0) pax.infantInLap = String(lead.infants);
    const ext = (c) => (c ? '+cabin ' + (FXP_ITA_EXT[c] || '2') : '');
    const slices = [];
    if (multi) {
      segs.forEach((s, i) => {
        const mix = i === segs.length - 1 ? (mixRet || mixDep) : (mixDep || mixRet);
        slices.push({ origin: [s.origin], dest: [s.destination], routing: '', ext: ext(mix), dates: { searchDateType: 'specific', departureDate: s.departureDate, departureDateType: 'depart', departureDateModifier: mod, departureDatePreferredTimes: [] } });
      });
    } else {
      const s = segs[0];
      const dates = { searchDateType: 'specific', departureDate: s.departureDate, departureDateType: 'depart', departureDateModifier: mod, departureDatePreferredTimes: [] };
      if (s.returnDate) Object.assign(dates, { returnDate: s.returnDate, returnDateType: 'depart', returnDateModifier: mod, returnDatePreferredTimes: [] });
      slices.push({ origin: [s.origin], dest: [s.destination], routing: '', ext: ext(mixDep), routingRet: '', extRet: s.returnDate ? ext(mixRet) : '', dates });
    }
    const payload = {
      type: multi ? 'multi-city' : (segs[0].returnDate ? 'round-trip' : 'one-way'),
      slices,
      options: { cabin: (mixDep || mixRet) ? 'COACH' : (cabinMap[cab] || 'BUSINESS'), stops: '-1', extraStops: '1', allowAirportChanges: 'true', showOnlyAvailable: 'true', currency: { displayName: 'United States Dollar (USD)', code: 'USD' } },
      pax,
    };
    return 'https://matrix.itasoftware.com/search?search=' + encodeURIComponent(btoa(JSON.stringify(payload)));
  }
  function srchPointsYeah(lead, leg, flex, cab) {
    const c = srchCabinLabel(cab);
    let d1 = leg.date;
    let d2 = leg.date;
    let multi = false;
    if (flex > 0) { d1 = srchAddDays(leg.date, -flex); d2 = srchAddDays(leg.date, flex); multi = true; }
    const q = new URLSearchParams({ cabins: c, cabin: c, banks: 'Amex,Bilt,Capital One,Chase,Citi,WF', airlineProgram: 'AR,AM,AC,KL,AS,AA,AV,DL,EY,AY,B6,LH,QF,SK,TK,UA,VS,VA', tripType: '1', adults: String(lead.adults), children: String(lead.children), departure: leg.origin, arrival: leg.destination, departDate: d1, departDateSec: d2, multiday: String(multi) });
    return 'https://www.pointsyeah.com/search?' + q.toString();
  }
  // Basis (agentsearch): one "pax" number — children and infants count as
  // adults there (award seats cost the same miles). Taken from the lead
  // card's passenger icons when shown (the BO's own search link can lag).
  const FXP_BASIS_PROGRAMS = ['AC', 'KL', 'AS', 'AA', 'AV', 'BA', 'CM', 'DL', 'EY', 'B6', 'QF', 'SQ', 'TP', 'TK', 'UA', 'VS', 'LH', 'QR'];
  function srchPaxTotal(lead) {
    try {
      const m = location.pathname.match(/\/leads\/(\d+)/);
      const card = m && readLeadCard(m[1]);
      if (card && card.pax) { const t = (card.pax.adults || 0) + (card.pax.children || 0) + (card.pax.infants || 0); if (t > 0) return t; }
    } catch (e) { /* fall back to the search link */ }
    return Math.max(1, (lead.adults || 0) + (lead.children || 0) + (lead.infants || 0));
  }
  // Basis access now allows one airport each side and a ±1 day range only.
  const SRCH_BASIS_MAX = 1;
  const SRCH_BASIS_RANGE = 1;
  function srchBasisStop(from, to, date, flex) {
    return { origin: [{ code: from, city: from }], destination: [{ code: to, city: to }], date: { value: date, range: SRCH_BASIS_RANGE } };
  }
  function srchBasis(lead, leg, cab, flex) {
    const payload = {
      tripType: 'oneway',
      stops: [srchBasisStop(leg.origin, leg.destination, leg.date, flex)],
      pax: String(srchPaxTotal(lead)), cabin: srchCabinLabel(cab),
      programs: FXP_BASIS_PROGRAMS,
      enableHC: false, enableFlybasisCPMs: false, isMax: false,
    };
    return 'https://agentsearch.vercel.app/flights?s=' + encodeURIComponent(btoa(JSON.stringify(payload)));
  }
  // Multi-airport search: up to 3 airports on each side.
  const srchCodes = (list) => list.map((c) => ({ code: c, city: c }));
  function srchBasisMulti(lead, from, to, outDate, retDate, cab, flex) {
    const stop = (a, b, d) => ({ origin: srchCodes(a.slice(0, SRCH_BASIS_MAX)), destination: srchCodes(b.slice(0, SRCH_BASIS_MAX)), date: { value: d, range: SRCH_BASIS_RANGE } });
    const payload = {
      tripType: retDate ? 'roundtrip' : 'oneway',
      stops: retDate ? [stop(from, to, outDate), stop(to, from, retDate)] : [stop(from, to, outDate)],
      pax: String(srchPaxTotal(lead)), cabin: srchCabinLabel(cab),
      programs: FXP_BASIS_PROGRAMS,
      enableHC: false, enableFlybasisCPMs: false, isMax: false,
    };
    return 'https://agentsearch.vercel.app/flights?s=' + encodeURIComponent(btoa(JSON.stringify(payload)));
  }
  // Home side = where the trip starts and ends; far side = every other
  // airport. CHI→HAN + KTI→CHI gives CHI / HAN + KTI; HAN→CHI + CHI→KTI
  // gives HAN + KTI / CHI.
  function srchMultiSides(lead) {
    const segs = lead.segments;
    if (segs.length === 1) return { from: [segs[0].origin], to: [segs[0].destination], out: segs[0].departureDate, ret: segs[0].returnDate || null };
    const home = [segs[0].origin, segs[segs.length - 1].destination].filter((c, i, a) => a.indexOf(c) === i);
    const far = [];
    segs.forEach((x) => [x.origin, x.destination].forEach((c) => { if (!home.includes(c) && !far.includes(c)) far.push(c); }));
    return { from: home.slice(0, 3), to: far.slice(0, 3), out: segs[0].departureDate, ret: segs[segs.length - 1].departureDate };
  }
  function srchMultiBox(btn, lead, cab, flex) {
    const again = srchMenu && srchMenu.btn === btn && srchMenu.multi;
    srchCloseMenu();
    if (again) return;
    const sides = srchMultiSides(lead);
    const el = document.createElement('div');
    el.className = 'ia-fxp-menu ia-fxp-menu--fb ia-fxp-ma';
    const h = document.createElement('div');
    h.className = 'ia-fxp-menu-h';
    h.className += ' ia-fxp-ma-h';
    const hT = document.createElement('span');
    hT.textContent = 'Basis \u00b7 one airport each side \u00b7 \u00b11 day';
    const hX = document.createElement('button');
    hX.type = 'button';
    hX.className = 'ia-fxp-ma-close';
    hX.title = 'Close';
    hX.setAttribute('aria-label', 'Close');
    hX.textContent = '\u00d7';
    hX.addEventListener('click', (e) => { e.stopPropagation(); srchCloseMenu(); });
    h.append(hT, hX);
    const row = document.createElement('div');
    row.className = 'ia-fxp-ma-row';
    // Airport chips: 3 letters (or a space/comma/Enter) makes a chip;
    // Backspace in an empty box removes the last whole code; x removes one.
    const box = (ph, val, icon) => {
      const w = document.createElement('label');
      w.className = 'ia-fxp-ma-box';
      const i = document.createElement('span');
      i.className = 'ia-fxp-ma-ic';
      i.textContent = icon;
      const chips = document.createElement('span');
      chips.className = 'ia-fxp-ma-chips';
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.spellcheck = false;
      inp.autocomplete = 'off';
      inp.maxLength = 3;
      const st = { list: val.slice(0, SRCH_BASIS_MAX), w, inp };
      const paint = () => {
        chips.textContent = '';
        st.list.forEach((code, idx) => {
          const c = document.createElement('span');
          c.className = 'ia-fxp-ma-chip';
          c.textContent = code;
          const x = document.createElement('button');
          x.type = 'button';
          x.className = 'ia-fxp-ma-x';
          x.setAttribute('aria-label', 'Remove ' + code);
          x.textContent = '\u00d7';
          x.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); st.list.splice(idx, 1); paint(); inp.focus(); });
          c.appendChild(x);
          chips.appendChild(c);
        });
        inp.placeholder = st.list.length ? '' : ph;
        inp.style.display = st.list.length >= SRCH_BASIS_MAX ? 'none' : '';
        err.textContent = '';
      };
      st.add = (t) => {
        const code = String(t || '').toUpperCase().replace(/[^A-Z]/g, '');
        if (code.length !== 3) return false;
        if (!st.list.includes(code)) { if (st.list.length >= SRCH_BASIS_MAX) st.list = [code]; else st.list.push(code); }
        inp.value = '';
        paint();
        return true;
      };
      st.set = (list) => { st.list = list.slice(0, SRCH_BASIS_MAX); paint(); };
      inp.addEventListener('input', () => {
        inp.value = inp.value.toUpperCase().replace(/[^A-Z]/g, '');
        if (inp.value.length === 3) st.add(inp.value);
      });
      inp.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Backspace' && !inp.value && st.list.length) { e.preventDefault(); st.list.pop(); paint(); return; }
        if ((e.key === ' ' || e.key === ',' || e.key === '+') ) { e.preventDefault(); st.add(inp.value); return; }
        if (e.key === 'Enter') { e.preventDefault(); if (inp.value) st.add(inp.value); else go(sides.ret ? 'rt' : 'out'); }
      });
      // Full: clicking the box lets you type a new code that replaces the old one.
      w.addEventListener('click', () => { inp.style.display = ''; inp.focus(); });
      inp.addEventListener('blur', () => { if (!inp.value) paint(); });
      w.append(i, chips, inp);
      st.paint = paint;
      return st;
    };
    const err = document.createElement('div');
    err.className = 'ia-fxp-ma-err';
    const A = box('Where from', sides.from, '\u25ce');
    const B = box('Where to', sides.to, '\u25c9');
    A.paint();
    B.paint();
    const sw = document.createElement('button');
    sw.type = 'button';
    sw.className = 'ia-fxp-ma-sw';
    sw.title = 'Swap';
    sw.setAttribute('aria-label', 'Swap from and to');
    sw.textContent = '\u21c4';
    sw.addEventListener('click', (e) => { e.stopPropagation(); const t = A.list.slice(); A.set(B.list); B.set(t); });
    row.append(A.w, sw, B.w);
    // Booking class for this Basis search (starts on the lead's cabin).
    let bCab = ['B', 'W', 'F', 'Y'].includes(cab) ? cab : 'B';
    const cabRow = document.createElement('div');
    cabRow.className = 'ia-fxp-ma-info ia-fxp-ma-cabrow';
    const cabLbl = document.createElement('span');
    cabLbl.className = 'ia-fxp-ma-lbl';
    cabLbl.textContent = 'Class';
    const cabPills = document.createElement('span');
    cabPills.className = 'ia-fxp-ma-pills ia-fxp-ma-cab';
    cabPills.setAttribute('role', 'radiogroup');
    cabPills.setAttribute('aria-label', 'Booking class');
    [['B', 'Business'], ['W', 'Premium'], ['F', 'First'], ['Y', 'Economy']].forEach(([v, label]) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.dataset.cab = v;
      b.setAttribute('role', 'radio');
      b.textContent = label;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        bCab = v;
        cabPills.querySelectorAll('button').forEach((x) => { const on = x.dataset.cab === bCab; x.classList.toggle('on', on); x.setAttribute('aria-checked', String(on)); });
      });
      const on = v === bCab;
      b.classList.toggle('on', on);
      b.setAttribute('aria-checked', String(on));
      cabPills.appendChild(b);
    });
    cabRow.append(cabLbl, cabPills);
    // Dates (editable); Basis always searches ±1 day around each one.
    const info = document.createElement('div');
    info.className = 'ia-fxp-ma-info';
    const dateIn = (val, label) => {
      const d = document.createElement('input');
      d.type = 'date';
      d.className = 'ia-fxp-ma-date';
      d.value = val || '';
      d.setAttribute('aria-label', label);
      d.addEventListener('keydown', (e) => e.stopPropagation());
      return d;
    };
    const dOut = dateIn(sides.out, 'Outbound date');
    info.appendChild(dOut);
    let dRet = null;
    if (sides.ret) {
      const arrow = document.createElement('span');
      arrow.className = 'ia-fxp-ma-arrow';
      arrow.textContent = '\u2192';
      dRet = dateIn(sides.ret, 'Return date');
      info.append(arrow, dRet);
    }
    // Basis allows ±1 day only now: always applied, nothing to pick.
    const range = SRCH_BASIS_RANGE;
    const pills = document.createElement('span');
    pills.className = 'ia-fxp-ma-pills';
    pills.setAttribute('aria-label', 'Date range');
    const fixedPill = document.createElement('button');
    fixedPill.type = 'button';
    fixedPill.className = 'on';
    fixedPill.tabIndex = -1;
    fixedPill.title = 'Basis searches \u00b11 day around each date';
    fixedPill.textContent = '\u00b11 day';
    fixedPill.addEventListener('click', (e) => e.stopPropagation());
    pills.appendChild(fixedPill);
    info.appendChild(pills);
    const acts = document.createElement('div');
    acts.className = 'ia-fxp-ma-acts';
    const go = (mode) => {
      [A, B].forEach((x) => { if (x.inp.value) x.add(x.inp.value); });
      const from = A.list, to = B.list;
      if (!from.length || !to.length) { err.textContent = 'Add at least one airport on each side'; return; }
      if (from.length > SRCH_BASIS_MAX || to.length > SRCH_BASIS_MAX) { err.textContent = 'One airport on each side'; return; }
      // Both = two one-way searches (outbound and return), not a round trip.
      const urls = [];
      const out = dOut.value, ret = dRet ? dRet.value : null;
      if ((mode === 'out' || mode === 'rt' || mode === 'trip') && !out) { err.textContent = 'Pick the outbound date'; return; }
      if ((mode === 'ret' || mode === 'rt' || mode === 'trip') && !ret) { err.textContent = 'Pick the return date'; return; }
      if (mode === 'out' || mode === 'rt') urls.push(srchBasisMulti(lead, from, to, out, null, bCab, range));
      if (mode === 'ret' || mode === 'rt') urls.push(srchBasisMulti(lead, to, from, ret, null, bCab, range));
      // Round trip = one Basis search with both legs (tripType "roundtrip").
      if (mode === 'trip') urls.push(srchBasisMulti(lead, from, to, out, ret, bCab, range));
      // The box stays open, so the other leg can be searched next.
      // It closes with x, Esc, or a click anywhere outside it.
      urls.forEach((u) => srchOpenBg(u)); // new tabs in the background: you stay on the lead
      return true;
    };
    const mkAct = (label, mode, main) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'ia-fxp-ma-go' + (main ? ' is-main' : '');
      b.textContent = label;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!go(mode)) return;
        b.textContent = '\u2713 opened';
        clearTimeout(b._iaT);
        b._iaT = setTimeout(() => { b.textContent = label; }, 1600);
      });
      acts.appendChild(b);
    };
    mkAct('Outbound', 'out', !sides.ret);
    if (sides.ret) { mkAct('Return', 'ret', false); mkAct('Both \u2197', 'rt', false); mkAct('Round trip \u2197', 'trip', true); }
    // Super Basis (2.16.0): the same one-way search, with the results shown
    // right here in the lead (GDS / Add to lead) instead of a new tab.
    const sbActs = document.createElement('div');
    sbActs.className = 'ia-fxp-ma-acts ia-sb-acts';
    const sbLbl = document.createElement('span');
    sbLbl.className = 'ia-sb-acts__l';
    sbLbl.textContent = '\u2605 Super Basis \u00b7 results in the lead';
    sbActs.appendChild(sbLbl);
    const sbGo = (mode) => {
      [A, B].forEach((x) => { if (x.inp.value) x.add(x.inp.value); });
      const from = A.list, to = B.list;
      if (!from.length || !to.length) { err.textContent = 'Add at least one airport on each side'; return; }
      const d = mode === 'ret' ? (dRet && dRet.value) : dOut.value;
      if (!d) { err.textContent = mode === 'ret' ? 'Pick the return date' : 'Pick the outbound date'; return; }
      const f = mode === 'ret' ? to : from, t = mode === 'ret' ? from : to;
      const url = srchBasisMulti(lead, f, t, d, null, bCab, range);
      const anchor = btn;
      srchCloseMenu();
      sbStart(anchor, { url, from: f[0], to: t[0], date: d, cab: bCab, pax: srchPaxTotal(lead) });
    };
    [['Outbound', 'out']].concat(sides.ret ? [['Return', 'ret']] : []).forEach(([label, mode]) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'ia-fxp-ma-go ia-sb-go';
      b.textContent = label;
      b.addEventListener('click', (e) => { e.stopPropagation(); sbGo(mode); });
      sbActs.appendChild(b);
    });
    el.append(h, row, cabRow, info, acts, sbActs, err);
    el.addEventListener('mousedown', (e) => e.stopPropagation());
    document.body.appendChild(el);
    const r = btn.getBoundingClientRect();
    el.style.left = Math.max(8, Math.min(r.left, window.innerWidth - el.offsetWidth - 8)) + 'px';
    el.style.top = (r.bottom + 4) + 'px';
    btn.classList.add('is-open');
    srchMenu = { el, btn, multi: true };
    setTimeout(() => B.inp.focus(), 0);
  }

  function srchBasisRound(lead, cab, flex) {
    const s0 = lead.segments[0];
    const payload = {
      tripType: 'roundtrip',
      stops: [srchBasisStop(s0.origin, s0.destination, s0.departureDate, flex), srchBasisStop(s0.destination, s0.origin, s0.returnDate, flex)],
      pax: String(srchPaxTotal(lead)), cabin: srchCabinLabel(cab),
      programs: FXP_BASIS_PROGRAMS,
      enableHC: false, enableFlybasisCPMs: false, isMax: false,
    };
    return 'https://agentsearch.vercel.app/flights?s=' + encodeURIComponent(btoa(JSON.stringify(payload)));
  }


  // ==================================================================
  // SUPER BASIS (2.16.0): runs a Basis search in a background tab, shows
  // the results here in the lead and closes that tab. GDS copies the
  // *IA / VI* text; Add to lead adds the option to this lead (same helper
  // as the flight-site pop-up, priced for the lead's passengers). One
  // airport each side, ±1 day. Nothing is sent to the client.
  // ==================================================================
  let sbCur = null;
  const sbEsc = (x) => String(x == null ? '' : x).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SB_CAB = { B: 'Business', W: 'Premium', F: 'First', Y: 'Economy' };
  function sbWhen(iso) {
    const m = /(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d)/.exec(String(iso || ''));
    if (!m) return { day: '', time: '' };
    const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
    return { day: d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }), time: m[4] + ':' + m[5], ymd: m[1] + m[2] + m[3] };
  }
  function sbDur(mins) { const h = Math.floor(mins / 60), m = mins % 60; return mins ? h + ' h ' + String(m).padStart(2, '0') : ''; }
  function sbStop() {
    if (!sbCur) return;
    clearTimeout(sbCur.timer);
    try { if (sbCur.tab && sbCur.tab.close) sbCur.tab.close(); } catch (e) { /* ignore */ }
    if (sbCur.lid != null && typeof GM_removeValueChangeListener === 'function') { try { GM_removeValueChangeListener(sbCur.lid); } catch (e) { /* ignore */ } }
    try { GM_setValue('ia-sb-res-' + sbCur.id + '-0', null); } catch (e) { /* ignore */ }
    sbCur.lid = null; sbCur.tab = null;
  }
  function sbCard(anchor) {
    const box = anchor.closest('.kayak-offers');
    const body = (box && box.querySelector(':scope > .kayak-offers-body')) || (anchor.parentElement || document.body);
    let card = body.querySelector(':scope > .ia-sb');
    if (!card) {
      card = document.createElement('section');
      card.className = 'ia-sb';
      card.setAttribute('aria-live', 'polite');
      body.appendChild(card);
    }
    card.classList.toggle('ia-sb--nova', typeof iaIsNova === 'function' && iaIsNova(iaMode()));
    return card;
  }
  function sbHead(q) {
    const w = sbWhen(q.date + 'T00:00');
    return '<div class="ia-sb-h"><span class="ia-sb-star" aria-hidden="true">★</span><div class="ia-sb-ht"><b class="ia-sb-t">Super Basis</b>'
      + '<span class="ia-sb-meta">' + sbEsc(q.from) + ' → ' + sbEsc(q.to) + ' · ' + sbEsc(w.day) + ' ±1 day · ' + sbEsc(SB_CAB[q.cab] || 'Business') + ' · ' + q.pax + ' pax</span></div>'
      + '<button type="button" class="ia-sb-ic ia-sb-re" title="Search again" aria-label="Search again">↻</button>'
      + '<button type="button" class="ia-sb-ic ia-sb-x" title="Close" aria-label="Close Super Basis">×</button></div>';
  }
  function sbWireHead(card, anchor, q) {
    card.querySelector('.ia-sb-x').addEventListener('click', (e) => { e.stopPropagation(); sbStop(); card.remove(); sbCur = null; });
    card.querySelector('.ia-sb-re').addEventListener('click', (e) => { e.stopPropagation(); sbStart(anchor, q); });
  }
  function sbStart(anchor, q) {
    sbStop();
    const card = sbCard(anchor);
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    sbCur = { id, q, card, anchor, tab: null, lid: null, timer: 0 };
    card.innerHTML = sbHead(q) + '<div class="ia-sb-st"><span class="ia-sb-spin" aria-hidden="true"></span>Searching Basis in a background tab… this takes up to a minute</div>';
    sbWireHead(card, anchor, q);
    const key = 'ia-sb-res-' + id + '-0';
    try { GM_setValue('ia-sb-job', JSON.stringify({ id, urls: [q.url], at: Date.now() })); } catch (e) { /* ignore */ }
    try {
      sbCur.lid = GM_addValueChangeListener(key, (n, o, v) => {
        if (!sbCur || sbCur.id !== id || !v) return;
        let r; try { r = JSON.parse(v); } catch (e) { return; }
        if (!r || r.state === 'searching') return;
        const items = Array.isArray(r.items) ? r.items : [];
        sbStop();
        sbRender(card, anchor, q, items, r.state);
      });
    } catch (e) { /* ignore */ }
    try { sbCur.tab = GM_openInTab(q.url, { active: false, insert: true, setParent: true }); } catch (e) { window.open(q.url, '_blank', 'noopener'); }
    sbCur.timer = setTimeout(() => {
      if (!sbCur || sbCur.id !== id) return;
      sbStop();
      sbRender(card, anchor, q, [], 'timeout');
    }, 100000);
  }
  function sbRender(card, anchor, q, items, state) {
    const sorted = items.slice().sort((a, b) => {
      const ka = a.price ? (a.price.kind === 'award' ? 0 : 1) : 2, kb = b.price ? (b.price.kind === 'award' ? 0 : 1) : 2;
      return ka - kb || (a.miles - b.miles) || (a.taxes - b.taxes) || (a.cash - b.cash);
    });
    let html = sbHead(q);
    if (!sorted.length) {
      const why = state === 'signedout' ? 'Basis looks signed out. Open Basis, sign in, then press ↻.'
        : state === 'timeout' ? 'Basis did not answer in time. Press ↻ to try again.'
          : 'No results for this date (±1 day). Try another date or class.';
      html += '<div class="ia-sb-st ia-sb-st--warn">' + sbEsc(why) + '</div>';
      card.innerHTML = html;
      sbWireHead(card, anchor, q);
      return;
    }
    html += '<div class="ia-sb-st"><i class="ia-sb-dot" aria-hidden="true"></i>' + sorted.length + ' result' + (sorted.length === 1 ? '' : 's') + ' · cheapest first · searched just now</div><div class="ia-sb-list">';
    sorted.forEach((x, i) => {
      const a = sbWhen(x.dep), b = sbWhen(x.arr);
      const plus = a.ymd && b.ymd && b.ymd > a.ymd ? '+1' : '';
      const stops = x.stops === 0 ? 'nonstop' : x.stops + ' stop' + (x.stops > 1 ? 's' : '');
      const cab = x.cabin ? x.cabin.charAt(0).toUpperCase() + x.cabin.slice(1).toLowerCase() : '';
      const priceTop = x.miles ? x.miles.toLocaleString('en-US') + ' mi' : (x.cash ? '$' + Math.round(x.cash).toLocaleString('en-US') : '—');
      const priceSub = x.miles ? '+ $' + x.taxes.toFixed(2) + ' taxes · ' + sbEsc(x.programName || x.program) : (x.cash ? 'per person · cash' : '');
      const why = x.problem ? x.problem : (!x.price ? (x.miles ? 'Program not in the BO' : 'Price not found') : '');
      html += '<div class="ia-sb-row' + (i >= 12 ? ' is-more' : '') + '" data-i="' + i + '"' + (i >= 12 ? ' hidden' : '') + '>'
        + '<div class="ia-sb-l"><div class="ia-sb-fl">' + sbEsc(x.flights.join(' · ')) + ' <span>' + sbEsc(x.route.join(' → ')) + '</span></div>'
        + '<div class="ia-sb-sub">' + sbEsc(a.day) + ' · ' + sbEsc(a.time) + ' → ' + sbEsc(b.time) + plus + ' · ' + sbEsc(stops) + (x.mins ? ' · ' + sbDur(x.mins) : '') + (cab ? ' · ' + sbEsc(cab) : '') + '</div></div>'
        + '<div class="ia-sb-r"><div class="ia-sb-price">' + sbEsc(priceTop) + '</div><div class="ia-sb-tax">' + priceSub + '</div></div>'
        + '<div class="ia-sb-foot">' + (x.seats ? '<span class="ia-sb-seat">' + x.seats + (x.seats <= 2 ? ' seat' + (x.seats === 1 ? '' : 's') + ' left' : ' seats') + '</span>' : '')
        + (x.rush ? '<span class="ia-sb-seat ia-sb-seat--rush">Rush</span>' : '')
        + '<span class="ia-sb-msg' + (why ? ' err' : '') + '">' + sbEsc(why) + '</span>'
        + '<button type="button" class="ia-sb-btn ia-sb-gds"' + (x.problem ? ' disabled' : '') + '>GDS</button>'
        + '<button type="button" class="ia-sb-btn pri ia-sb-add"' + (why ? ' disabled' : '') + '>Add to lead</button></div></div>';
    });
    html += '</div>';
    if (sorted.length > 12) html += '<button type="button" class="ia-sb-btn ia-sb-more">Show all ' + sorted.length + '</button>';
    card.innerHTML = html;
    sbWireHead(card, anchor, q);
    const more = card.querySelector('.ia-sb-more');
    if (more) more.addEventListener('click', (e) => { e.stopPropagation(); card.querySelectorAll('.ia-sb-row.is-more').forEach((r) => { r.hidden = false; }); more.remove(); });
    card.querySelectorAll('.ia-sb-row').forEach((row) => {
      const x = sorted[+row.dataset.i];
      const msg = row.querySelector('.ia-sb-msg');
      const say = (t, cls) => { msg.className = 'ia-sb-msg' + (cls ? ' ' + cls : ''); msg.textContent = t; };
      row.querySelector('.ia-sb-gds').addEventListener('click', (e) => {
        e.stopPropagation();
        try { if (typeof GM_setClipboard === 'function') GM_setClipboard(x.text); else navigator.clipboard.writeText(x.text); say('✓ GDS copied', 'ok'); } catch (err) { say('Could not copy', 'err'); }
      });
      const add = row.querySelector('.ia-sb-add');
      add.addEventListener('click', (e) => { e.stopPropagation(); sbAdd(x, add, say); });
    });
  }
  // Add to lead: the same send-to-lead helper the flight-site pop-up uses.
  function sbAdd(x, btn, say) {
    const m = location.pathname.match(/\/leads\/(\d{6})/);
    const leadId = m && m[1];
    if (!leadId) { say('Open the lead first', 'err'); return; }
    btn.disabled = true;
    say('Contacting BO…');
    const jobId = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const statusKey = 'js-sendjob-status-' + jobId;
    const decisionKey = 'js-sendjob-decision-' + jobId;
    let sellOn = true;
    try { sellOn = GM_getValue('js-sell-on', true) !== false; } catch (e) { sellOn = true; }
    const ending = [88, 89, 90, 91, 92][Math.floor(Math.random() * 5)];
    let lid = null, ended = false;
    const finish = (ok, t) => {
      if (ended) return;
      ended = true;
      clearTimeout(overall);
      if (lid != null && typeof GM_removeValueChangeListener === 'function') { try { GM_removeValueChangeListener(lid); } catch (e) { /* ignore */ } }
      try { GM_setValue(statusKey, null); GM_setValue(decisionKey, null); GM_setValue('js-sendjob-' + jobId, null); } catch (e) { /* ignore */ }
      say(t, ok ? 'ok' : 'err');
      btn.disabled = false;
      if (ok) btn.textContent = 'Add again';
    };
    const overall = setTimeout(() => finish(false, 'BO busy — try again'), 90000);
    try { GM_setValue('js-sendjob-' + jobId, JSON.stringify({ id: jobId, leadId, gds: x.text, createdAt: Date.now() })); } catch (e) { finish(false, 'Could not start'); return; }
    lid = GM_addValueChangeListener(statusKey, (n, o, v) => {
      let st; try { st = JSON.parse(v || 'null'); } catch (e) { return; }
      if (!st) return;
      if (st.phase === 'lead') {
        const pax = st.pax || { adults: 1, children: 0, infants: 0 };
        const p = x.price;
        let fill;
        if (p.kind === 'cash') {
          fill = { mode: 'cash', ADT: p.perPerson, CHD: p.perPerson, INF: x.inf.cash };
        } else {
          const full = (pax.adults || 0) + (pax.children || 0);
          const parts = p.parts.map((pp) => ({ miles: pp.points * full + x.inf.miles * (pax.infants || 0), taxes: Math.round(pp.taxesPerPerson * (full + (pax.infants || 0)) * 100) / 100, program: pp.program }));
          fill = Object.assign({ mode: 'award', parts }, parts[0]);
          if (x.rush) fill.rush = x.rush;
        }
        fill.flags = [];
        if (sellOn) {
          if (p.kind === 'cash') { const t = p.perPerson * 1.1; let v = Math.floor(t / 100) * 100 + ending; if (v < t) v += 100; fill.sell = { value: v, ending }; }
          else fill.sell = { value: null, ending };
        }
        try { GM_setValue(decisionKey, JSON.stringify({ go: true, fill })); } catch (e) { /* ignore */ }
      } else if (st.phase === 'claimed') say('Opening lead ' + leadId + '…');
      else if (st.phase === 'saving') say('Adding…');
      else if (st.phase === 'selling') say('Setting sell price…');
      else if (st.phase === 'done') {
        const sv = st.sell && st.sell.ADT;
        finish(true, '✓ Added' + (st.optionId ? ' #' + st.optionId : '') + (sv ? ' · Sell $' + Number(sv).toLocaleString('en-US') : ''));
      } else if (st.phase === 'error') finish(false, st.message ? String(st.message).slice(0, 60) : 'Failed');
    });
    try { GM_setValue('js-sendjob-request', JSON.stringify({ id: jobId, leadId, t: Date.now() })); } catch (e) { /* ignore */ }
  }

  GM_addStyle(`
    .ia-sb-acts { align-items: center; border-top: 1px dashed var(--ias-line2); padding-top: 8px; margin-top: 2px; }
    .ia-sb-acts__l { font: 700 11px/1.2 Inter, 'Segoe UI', system-ui, sans-serif; color: var(--ias-sec); margin-right: auto; }
    .ia-sb { margin: 8px; padding: 12px; border-radius: 16px; background: var(--ias-field); border: 1px solid var(--ias-line); color: var(--ias-text);
      font: 500 12.5px/1.4 Inter, 'Segoe UI', system-ui, sans-serif; display: grid; gap: 10px; box-shadow: var(--ias-chipshadow); }
    .ia-sb--nova { font-family: ${IA_NOVA_FONT}; border-radius: 22px; }
    .ia-sb-h { display: flex; align-items: center; gap: 10px; }
    .ia-sb-star { width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center; background: var(--ias-acc); color: var(--ias-onacc); font-size: 14px; flex: none; }
    .ia-sb-ht { display: grid; gap: 1px; min-width: 0; margin-right: auto; }
    .ia-sb-t { font: 700 13px/1.2 Inter, 'Segoe UI', system-ui, sans-serif; color: var(--ias-title); letter-spacing: -.01em; }
    .ia-sb--nova .ia-sb-t { font-family: ${IA_NOVA_DISPLAY}; font-weight: 600; letter-spacing: -.02em; }
    .ia-sb-meta { color: var(--ias-muted); font-size: 11.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .ia-sb--nova .ia-sb-meta { font-family: ${IA_NOVA_MONO}; font-size: 10.5px; letter-spacing: .02em; }
    .ia-sb-ic { width: 30px; height: 30px; border-radius: 50%; border: 0; display: grid; place-items: center; background: var(--ias-chip); color: var(--ias-title);
      box-shadow: inset 0 0 0 1.5px var(--ias-line); font-size: 15px; cursor: pointer; transition: transform .25s cubic-bezier(.34,1.4,.64,1); flex: none; }
    .ia-sb-ic:active { transform: scale(.88); }
    .ia-sb-st { display: flex; align-items: center; gap: 8px; color: var(--ias-sec); font-size: 12px; font-weight: 600; }
    .ia-sb-st--warn { color: var(--ias-bad); }
    .ia-sb-dot { width: 8px; height: 8px; border-radius: 50%; background: #22c55e; flex: none; }
    .ia-sb-spin { width: 14px; height: 14px; border-radius: 50%; border: 2px solid var(--ias-line2); border-top-color: var(--ias-acc); animation: ia-sb-spin .8s linear infinite; flex: none; }
    @keyframes ia-sb-spin { to { transform: rotate(360deg); } }
    .ia-sb-list { display: grid; gap: 8px; max-height: 560px; overflow: auto; overscroll-behavior: contain; }
    .ia-sb-row { display: grid; grid-template-columns: 1fr auto; gap: 2px 12px; padding: 10px 12px; border-radius: 14px; background: var(--ias-bg); border: 1px solid var(--ias-line); animation: ia-sb-in .35s cubic-bezier(.2,.8,.2,1) both; }
    .ia-sb-row[hidden] { display: none; }
    @keyframes ia-sb-in { from { opacity: 0; transform: translateY(6px); } }
    .ia-sb-l { min-width: 0; }
    .ia-sb-fl { font-weight: 800; color: var(--ias-title); }
    .ia-sb-fl span { font-weight: 600; color: var(--ias-sec); }
    .ia-sb-sub { color: var(--ias-muted); font-size: 11.5px; }
    .ia-sb-r { text-align: right; }
    .ia-sb-price { font: 700 14px/1.2 Inter, 'Segoe UI', system-ui, sans-serif; color: var(--ias-title); white-space: nowrap; }
    .ia-sb--nova .ia-sb-price { font-family: ${IA_NOVA_MONO}; font-weight: 500; }
    .ia-sb-tax { color: var(--ias-muted); font-size: 11.5px; white-space: nowrap; }
    .ia-sb-foot { grid-column: 1 / -1; display: flex; align-items: center; gap: 6px; margin-top: 6px; flex-wrap: wrap; }
    .ia-sb-seat { padding: 3px 9px; border-radius: 999px; background: var(--ias-chip); box-shadow: inset 0 0 0 1px var(--ias-line); font-size: 11px; font-weight: 700; color: var(--ias-sec); }
    .ia-sb-seat--rush { color: #ea580c; }
    .ia-sb-msg { margin-left: auto; font-size: 11.5px; font-weight: 700; color: var(--ias-sec); }
    .ia-sb-msg.ok { color: #16a34a; } .ia-sb-msg.err { color: var(--ias-bad); }
    .ia-sb-btn { min-height: 30px; padding: 0 14px; border-radius: 999px; border: 0; background: var(--ias-chip); color: var(--ias-title); box-shadow: inset 0 0 0 1.5px var(--ias-line2);
      font-weight: 700; font-size: 12px; line-height: 1; font-family: inherit; cursor: pointer; transition: transform .25s cubic-bezier(.34,1.4,.64,1), opacity .2s; }
    .ia-sb-btn.pri { background: var(--ias-acc); color: var(--ias-onacc); box-shadow: none; }
    .ia-sb-btn:active { transform: scale(.94); }
    .ia-sb-btn:disabled { opacity: .45; cursor: default; transform: none; }
    .ia-sb-more { justify-self: center; }
  `);

  // Search links open in a new tab behind the BO, so you stay on the lead.
  const srchOpen = (url) => srchOpenBg(url);
  const srchOpenBg = (url) => {
    try { if (typeof GM_openInTab === 'function') { GM_openInTab(url, { active: false, insert: true, setParent: true }); return; } } catch (e) { /* fall back */ }
    window.open(url, '_blank', 'noopener');
  };

  let srchMenu = null;
  function srchCloseMenu() {
    if (srchMenu) { srchMenu.el.remove(); if (srchMenu.btn) srchMenu.btn.classList.remove('is-open'); srchMenu = null; }
  }
  function srchShowMenu(btn, title, items) {
    const again = srchMenu && srchMenu.btn === btn;
    srchCloseMenu();
    if (again) return; // second click on the same button closes it
    const el = document.createElement('div');
    el.className = 'ia-fxp-menu ia-fxp-menu--' + (btn.dataset.kind || 'x');
    const h = document.createElement('div');
    h.className = 'ia-fxp-menu-h';
    h.textContent = title;
    el.appendChild(h);
    items.forEach((it) => {
      const row = document.createElement('div');
      row.className = 'ia-fxp-menu-i';
      const a = document.createElement('span');
      a.textContent = it.label;
      const b = document.createElement('small');
      b.textContent = it.selected ? '\u2713' : (it.note || '');
      if (it.selected) row.classList.add('is-sel');
      if (it.toggle) {
        // Checkbox row: ticks on and off, the menu stays open.
        const box = document.createElement('span');
        box.className = 'ia-fxp-chk';
        const paint = () => { const on = it.checked(); box.classList.toggle('on', on); box.textContent = on ? '\u2713' : ''; row.classList.toggle('is-off', !on); };
        paint();
        row.classList.add('ia-fxp-menu-c');
        a.prepend(box);
        row.append(a, b);
        row.addEventListener('click', (e) => { e.stopPropagation(); it.toggle(); paint(); });
        el.appendChild(row);
        return;
      }
      row.append(a, b);
      const go = (e) => {
        e.stopPropagation();
        if (it.pick) { srchCloseMenu(); it.pick(); return; }
        const urls = it.urls ? it.urls() : [it.url()];
        urls.forEach((u) => srchOpen(u));
        // Ctrl (Control or Command on a Mac) or Shift held: keep the menu open to open more.
        if (e.ctrlKey || e.metaKey || e.shiftKey) { row.classList.add('is-opened'); b.textContent = '\u2713 opened'; return; }
        srchCloseMenu();
      };
      row.addEventListener('click', go);
      // On a Mac, Control+click counts as a right-click, so catch it here.
      row.addEventListener('contextmenu', (e) => { if (IA_MAC && e.ctrlKey) { e.preventDefault(); go(e); } });
      el.appendChild(row);
    });
    document.body.appendChild(el);
    const r = btn.getBoundingClientRect();
    const w = el.offsetWidth;
    el.style.left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8)) + 'px';
    el.style.top = (r.bottom + 4) + 'px';
    btn.classList.add('is-open');
    srchMenu = { el, btn };
  }
  if (window.top === window) {
    document.addEventListener('mousedown', (e) => { if (srchMenu && !srchMenu.el.contains(e.target) && !srchMenu.btn.contains(e.target)) srchCloseMenu(); }, true);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') srchCloseMenu(); });
    // Scrolling closes the small menus; the Basis box stays and follows its button.
    window.addEventListener('scroll', (e) => {
      if (!srchMenu) return;
      if (!srchMenu.multi) { srchCloseMenu(); return; }
      if (e.target && e.target.nodeType === 1 && srchMenu.el.contains(e.target)) return;
      const r = srchMenu.btn.getBoundingClientRect();
      srchMenu.el.style.top = (r.bottom + 4) + 'px';
      srchMenu.el.style.left = Math.max(8, Math.min(r.left, window.innerWidth - srchMenu.el.offsetWidth - 8)) + 'px';
    }, true);
  }

  const srchState = { cab: null, flex: 0 };
  // What "Open all" opens (ticked in its ▾ menu). Remembered.
  const FXP_OPENALL = [['g', 'Google', ''], ['e', 'ELR', ''], ['m', 'Matrix', ''], ['py', 'PointsYeah', 'each leg'], ['fb', 'Basis', 'each leg'], ['k', 'Kayak', '']];
  function srchOpenAllSet() {
    try { const v = JSON.parse(GM_getValue('js-fxp-openall', 'null')); if (Array.isArray(v)) return v; } catch (e) { /* default */ }
    return ['m', 'k'];
  }
  function srchSaveOpenAll(list) { try { GM_setValue('js-fxp-openall', JSON.stringify(list)); } catch (e) { /* ignore */ } }

  // Editing the remark of a multi-city lead rebuilds its search panel.
  let srchRemarkTimer = null;
  document.addEventListener('input', (e) => {
    if (!e.target || !e.target.matches || !e.target.matches('textarea.lead-remark-text')) return;
    clearTimeout(srchRemarkTimer);
    srchRemarkTimer = setTimeout(() => { try { wireSearchPanels(); } catch (x) { /* ignore */ } }, 400);
  }, true);
  function wireSearchPanels() {
    if (window.top !== window) return;
    document.querySelectorAll('.kayak-offers').forEach((box) => {
      const body = box.querySelector(':scope > .kayak-offers-body');
      const foot = box.querySelector(':scope > .kayak-offers-footer');
      if (!body || !foot) return;
      // Re-read the lead each time the BO re-renders the box (its Matrix
      // link carries the route, dates and passengers).
      const fresh = srchLeadFromBox(box) || srchLeadFromRemark() || srchLeadFromApi();
      if (fresh) {
        // The BO switched this box to other data (another lead, new dates):
        // rebuild the panel for it, with that lead's own cabin.
        const key = JSON.stringify(fresh);
        if (box._fxpKey !== key) {
          body.querySelectorAll(':scope > .ia-fxp-panel').forEach((n) => n.remove());
          foot.querySelectorAll(':scope > .ia-fxp-foot').forEach((n) => n.remove());
          box._fxpCab = fresh.cabin || 'B';
        }
        box._fxpKey = key;
        box._fxpLead = fresh;
      }
      const lead = box._fxpLead;
      if (!lead) return;
      box.classList.add('ia-fxp');
      if (body.querySelector(':scope > .ia-fxp-panel') && foot.querySelector(':scope > .ia-fxp-foot')) return;
      body.querySelectorAll(':scope > .ia-fxp-panel').forEach((n) => n.remove());
      foot.querySelectorAll(':scope > .ia-fxp-foot').forEach((n) => n.remove());
      if (!box._fxpCab) box._fxpCab = lead.cabin || 'B';
      const L = () => box._fxpLead;
      const cab = () => box._fxpCab;
      const flex = () => srchState.flex;

      const panel = document.createElement('div');
      panel.className = 'ia-fxp-panel';
      const mk = (label, kind, onClick) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'ia-fxp-b ia-fxp-' + kind;
        b.dataset.kind = kind;
        b.textContent = label;
        b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); onClick(b); });
        panel.appendChild(b);
        return b;
      };
      mk('Google ↗', 'g', () => srchOpen(srchGoogle(L(), false, cab())));
      mk('ELR ↗', 'e', () => srchOpen(srchGoogle(L(), true, cab())));
      mk('Matrix ▾', 'm', (b) => {
        const lead2 = L();
        const items = [{ label: srchCabinLabel(cab()), note: 'regular search', url: () => srchMatrix(L(), cab(), null, null, flex()) }];
        if (lead2.segments.length > 1 || lead2.segments[0].returnDate) {
          items.push({ label: 'Business Outbound, Premium Inbound', note: '', url: () => srchMatrix(L(), null, 'B', 'W', flex()) });
          items.push({ label: 'Premium Outbound, Business Inbound', note: '', url: () => srchMatrix(L(), null, 'W', 'B', flex()) });
        } else if (['B', 'W', 'F'].includes(cab()) && lead2.segments[0].departureDate) {
          // One-way: search a round trip, outbound in the picked cabin and the
          // return in Economy, 90 days after departure.
          const ret = srchAddDays(lead2.segments[0].departureDate, 90);
          items.push({ label: srchCabinLabel(cab()) + ' Outbound, Economy Inbound', note: 'return ' + srchFmt(ret), url: () => {
            const l = JSON.parse(JSON.stringify(L()));
            l.segments[0].returnDate = srchAddDays(l.segments[0].departureDate, 90);
            return srchMatrix(l, null, cab(), 'Y', flex());
          } });
        }
        srchShowMenu(b, 'ITA Matrix', items);
      });
      const legMenu = (b, title, build) => {
        const legs = srchLegs(L()).filter((l) => l.date);
        if (legs.length === 1) { srchOpen(build(legs[0])); return; }
        const rows = legs.map((lg) => ({ label: lg.label, note: lg.origin + '→' + lg.destination + ' · ' + srchFmt(lg.date), url: () => build(lg) }));
        // One row that opens every leg at once.
        rows.unshift({ label: legs.length === 2 ? 'Both' : 'All ' + legs.length + ' legs', note: 'opens ' + legs.length + ' tabs', urls: () => legs.map((lg) => build(lg)) });
        srchShowMenu(b, title + ' \u00b7 ' + IA_MOD + '+click to pick more', rows);
      };
      mk('PointsYeah ▾', 'py', (b) => legMenu(b, 'PointsYeah', (lg) => srchPointsYeah(L(), lg, flex(), cab())));
      // Basis opens the multi-airport box straight away (its Outbound /
      // Return / Round trip buttons cover the single searches too).
      mk('Basis ▾', 'fb', (b) => srchMultiBox(b, L(), cab(), flex()));
      mk('Kayak ↗', 'k', () => srchOpen(srchKayak(L(), flex(), cab())));
      if (lead.fromRemark) {
        const note = document.createElement('div');
        note.className = 'ia-fxp-note' + (lead.warn.length ? ' is-warn' : '');
        note.textContent = (lead.warn.length ? '\u26a0 ' + lead.warn.join(' \u00b7 ') + ' \u2014 ' : '') + 'Multi-city from the remark: '
          + lead.segments.map((x) => x.origin + '\u2192' + x.destination + ' ' + srchFmt(x.departureDate)).join(' \u00b7 ');
        note.title = 'Read from the lead\u2019s remark. Edit the remark and this updates.';
        panel.appendChild(note);
      }
      body.appendChild(panel);

      const fwrap = document.createElement('div');
      fwrap.className = 'ia-fxp-foot';
      const left = document.createElement('div');
      left.className = 'ia-fxp-foot-l';
      // Cabin and date-range pickers, in the panel's own menu style.
      const picker = (kind, title, opts, get, set) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'ia-fxp-pick';
        b.dataset.kind = kind;
        const show = () => { const o = opts.find((x) => x[0] === get()); b.textContent = (o ? o[1] : opts[0][1]) + ' \u25be'; };
        show();
        b.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          srchShowMenu(b, title, opts.map(([v, t]) => ({ label: t, selected: v === get(), pick: () => { set(v); show(); } })));
        });
        ['mousedown'].forEach((t) => b.addEventListener(t, (e) => e.stopPropagation()));
        return b;
      };
      const selCab = picker('cab', 'Cabin', [['B', 'Business'], ['W', 'Premium'], ['F', 'First'], ['Y', 'Economy']], () => box._fxpCab, (v) => { box._fxpCab = v; });
      const selFlex = picker('flex', 'Dates', [[0, 'Fixed'], [1, '\u00b11 day'], [2, '\u00b12 days'], [3, '\u00b13 days'], [5, '\u00b15 days'], [7, '\u00b17 days']], () => srchState.flex, (v) => { srchState.flex = v; });
      // Fast Search: Sabre JR search for this lead, sent straight to the
      // terminal (opened if closed), after I. Exact dates only: JR has no
      // ±days field, so the date range picker doesn't apply to it.
      const fs = document.createElement('button');
      fs.type = 'button';
      fs.className = 'ia-fxp-fs';
      fs.textContent = 'FS';
      const fsCmd = () => srchJR(L(), cab());
      const fsTitle = () => {
        const c = fsCmd();
        fs.title = 'Fast Search in the terminal (I, then ' + (c || 'JR') + ')' + (flex() > 0 ? '\nFS searches the exact dates \u2014 JR has no \u00b1days' : '');
      };
      fs.addEventListener('mouseenter', fsTitle);
      fs.addEventListener('mousedown', (e) => e.stopPropagation());
      let fsBusy = false;
      const fsFlash = (t, ms) => { fs.textContent = t; setTimeout(() => { fs.textContent = 'FS'; fs.classList.remove('is-busy'); fsBusy = false; }, ms || 1600); };
      fs.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (fsBusy) return;
        const cmd = fsCmd();
        if (!cmd) { fsBusy = true; fsFlash('No dates'); return; }
        fsBusy = true;
        fs.classList.add('is-busy');
        fs.textContent = '\u2026';
        const r = __iaTerm.run ? await __iaTerm.run(cmd) : { ok: false, msg: 'no-terminal' };
        if (r.ok) { fsFlash('\u2713 Sent'); return; }
        if (r.msg === 'no-terminal') {
          try { GM_setClipboard(cmd, 'text'); } catch (err) { /* ignore */ }
          fsFlash('Copied', 1800);
          return;
        }
        fsFlash(r.msg === 'busy' ? 'Busy' : r.msg === 'no-reply' ? 'No reply' : '\u2715', 1800);
      });
      left.append(selCab, selFlex, fs);
      const all = document.createElement('button');
      all.type = 'button';
      all.className = 'ia-fxp-all';
      all.title = 'Opens the sites ticked in \u25be in background tabs \u2014 you stay here';
      all.textContent = 'Open all ↗';
      all.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const on = srchOpenAllSet();
        const legs = srchLegs(L()).filter((l) => l.date);
        const urls = [];
        FXP_OPENALL.forEach(([k]) => {
          if (!on.includes(k)) return;
          if (k === 'g') urls.push(srchGoogle(L(), false, cab()));
          if (k === 'e') urls.push(srchGoogle(L(), true, cab()));
          if (k === 'm') urls.push(srchMatrix(L(), cab(), null, null, flex()));
          if (k === 'py') legs.forEach((lg) => urls.push(srchPointsYeah(L(), lg, flex(), cab())));
          if (k === 'fb') legs.forEach((lg) => urls.push(srchBasis(L(), lg, cab(), flex())));
          if (k === 'k') urls.push(srchKayak(L(), flex(), cab()));
        });
        if (!urls.length) { all.textContent = 'Nothing ticked'; setTimeout(() => { all.textContent = 'Open all ↗'; }, 1400); return; }
        urls.forEach((u) => srchOpenBg(u));
        all.textContent = '✓ Opened ' + urls.length;
        setTimeout(() => { all.textContent = 'Open all ↗'; }, 1400);
      });
      const allMenu = document.createElement('button');
      allMenu.type = 'button';
      allMenu.className = 'ia-fxp-allm';
      allMenu.dataset.kind = 'all';
      allMenu.title = 'Choose what Open all opens';
      allMenu.textContent = '\u25be';
      allMenu.addEventListener('mousedown', (e) => e.stopPropagation());
      allMenu.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        srchShowMenu(allMenu, 'Open all opens', FXP_OPENALL.map(([k, label, note]) => ({
          label, note,
          checked: () => srchOpenAllSet().includes(k),
          toggle: () => { const cur = srchOpenAllSet(); srchSaveOpenAll(cur.includes(k) ? cur.filter((x) => x !== k) : cur.concat(k)); },
        })));
      });
      const allWrap = document.createElement('span');
      allWrap.className = 'ia-fxp-allwrap';
      allWrap.append(all, allMenu);
      // Refresh: read the lead again from the BO (route, dates, passengers,
      // cabin) and rebuild the panel from scratch.
      const re = document.createElement('button');
      re.type = 'button';
      re.className = 'ia-fxp-re';
      re.title = 'Refresh — re-read this lead\u2019s route, dates, passengers and cabin';
      re.textContent = '\u21bb';
      re.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        srchCloseMenu();
        box._fxpLead = null;
        box._fxpKey = null;
        box._fxpCab = null;
        body.querySelectorAll(':scope > .ia-fxp-panel').forEach((n) => n.remove());
        foot.querySelectorAll(':scope > .ia-fxp-foot').forEach((n) => n.remove());
        wireSearchPanels();
        const nb = foot.querySelector('.ia-fxp-re');
        if (nb) { nb.classList.add('spin'); setTimeout(() => nb.classList.remove('spin'), 600); }
      });
      const right = document.createElement('div');
      right.className = 'ia-fxp-foot-r';
      right.append(re, allWrap);
      fwrap.append(left, right);
      foot.appendChild(fwrap);
    });
  }

  function wireMergeButtons() {
    if (window.top !== window) return;
    document.querySelectorAll('.lead-options-header-cell').forEach((cell) => {
      if (cell.dataset.jsMerge || !cell.querySelector('svg.feather-plus') || !cell.querySelector('svg.feather-eye')) return;
      cell.dataset.jsMerge = '1';
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'button btn btn-outline-secondary box px-2 py-1 text-theme-33 ml-2 ia-merge-btn';
      btn.title = 'Merge the selected options into one: each option its own ticket (1, 2, 3…) with its own cost — stops before Save';
      btn.textContent = 'Merge';
      btn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); mergeSelected(cell, btn); });
      cell.appendChild(btn);
    });
  }

  // Heads-up / rush tags on options that were added by "Send to lead".
  function renderOptionFlags() {
    let all = null;
    document.querySelectorAll('.lead-option').forEach((opt) => {
      const cb = opt.querySelector('input[id^="checkbox-switch-"]');
      if (!cb) return;
      const id = cb.id.replace('checkbox-switch-', '');
      const holder = opt.querySelector('.lead-option-segment') || opt.querySelector('.lead-option-price');
      if (!holder) return;
      // The BO reuses option cards for different options when its list
      // changes (e.g. a new option added on top), so a tag is only kept
      // while the card still shows the option it was made for.
      const old = holder.querySelector(':scope > .ia-optflags');
      if (old) { if (old.getAttribute('data-for') === id) return; old.remove(); }
      if (all === null) { try { all = JSON.parse(GM_getValue(OPTION_FLAGS_KEY, '{}')) || {}; } catch (e) { all = {}; } }
      const info = all[id];
      if (!info) return;
      const box = document.createElement('div');
      box.className = 'ia-optflags';
      box.setAttribute('data-for', id);
      if (info.rush) { const t = document.createElement('span'); t.className = 'ia-optflag ia-optflag--rush'; t.appendChild(worriedPip(17)); t.appendChild(document.createTextNode(info.rush)); box.appendChild(t); }
      // Child/infant heads-ups show on Pip's popover only, not in the BO.
      if (!info.rush) return;
      holder.insertBefore(box, holder.firstChild);
    });
  }

  GM_addStyle(`
    /* Same spot and look as the airport-change tag (above the option's
       segments). */
    .ia-optflags { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 4px 0; }
    .ia-optflag { background: #f59e0b; color: #1a1a1a; font-weight: 700; font-size: 12px; padding: 1px 7px; border-radius: 4px; font-family: system-ui, sans-serif; letter-spacing: .02em; }
    .ia-optflag--rush { background: #dc2626; color: #fff; display: inline-flex; align-items: center; gap: 4px; line-height: 16px; padding: 1px 7px 1px 2px; }
    .ia-worried { display: inline-block; flex: none; line-height: 0; }
    .ia-zero-box .ia-worried { display: block; width: fit-content; margin: 2px auto 10px; filter: drop-shadow(0 3px 4px rgba(0,0,0,.25)); }
    [data-ia-idcopy]:hover { text-decoration: underline dotted; }
    .ia-idcopied { color: #16a34a !important; transition: color .2s; }
    .ia-sell-pen { display: inline-flex; vertical-align: middle; margin-right: 4px; color: #94a3b8; opacity: .75; }
    .ia-sell-cell { cursor: pointer; }
    .ia-sell-cell:hover, .ia-sell-cell:hover .ia-sell-pen { color: #3b82f6; opacity: 1; }
    .ia-sell-input { width: 72px; text-align: right; font: inherit; padding: 0 4px; border: 1px solid #3b82f6; border-radius: 4px; background: #fff; color: #111; }
    .ia-sell-input.is-saving { opacity: .6; }
    /* Search panel in place of the BO's Kayak-price box */
    .kayak-offers.ia-fxp > .kayak-offers-body { max-height: none !important; height: auto !important; overflow: visible !important; }
    .kayak-offers.ia-fxp > .kayak-offers-body > :not(.ia-fxp-panel):not(.ia-sb) { display: none !important; }
    .kayak-offers.ia-fxp > .kayak-offers-footer > :not(.ia-fxp-foot) { display: none !important; }
    .ia-fxp-foot-r { display: flex; align-items: center; gap: 8px; }
    .ia-fxp-re { border: 0; background: transparent; color: inherit; opacity: .7; cursor: pointer; font-size: 15px; line-height: 1; padding: 2px 4px; border-radius: 4px; }
    .ia-fxp-re:hover { opacity: 1; background: rgba(148,163,184,.18); }
    .ia-fxp-re.spin { animation: jsFxpSpin .6s ease; }
    @keyframes jsFxpSpin { to { transform: rotate(360deg); } }
    .ia-fxp-panel { display: grid; grid-template-columns: repeat(3, 1fr); grid-auto-rows: 28px; gap: 6px; padding: 6px; }
    .ia-fxp-note { grid-column: 1 / -1; display: flex; align-items: center; padding: 0 8px; border-radius: 6px; background: rgba(59,130,246,.12); color: #bfdbfe; font: 600 11px system-ui, sans-serif; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ia-fxp-note.is-warn { background: rgba(245,158,11,.16); color: #fde68a; }
    .ia-fxp-b { border-radius: 6px; border: 1px solid #445071; background: rgba(15,20,35,.35); color: #e5e7eb; font: 800 11.5px/1 system-ui, sans-serif; cursor: pointer; white-space: nowrap; transition: background .15s, transform .1s; }
    .ia-fxp-b:hover { background: rgba(255,255,255,.07); }
    .ia-fxp-b:active { transform: translateY(1px); }
    .ia-fxp-g { border-color: #3b82f6; color: #bfdbfe; }
    .ia-fxp-e { border-color: #22c55e; color: #bbf7d0; }
    .ia-fxp-m { border-color: #a855f7; color: #e9d5ff; }
    .ia-fxp-py { border-color: #f59e0b; color: #fde68a; }
    .ia-fxp-fb { border-color: #8b5cf6; color: #ddd6fe; }
    .ia-fxp-k { border-color: #f97316; color: #fed7aa; }
    .ia-fxp-b.is-open { background: rgba(255,255,255,.12); }
    .ia-fxp-foot { display: flex; align-items: center; justify-content: space-between; width: 100%; gap: 8px; }
    .ia-fxp-foot-l { display: flex; gap: 6px; align-items: center; }
    .ia-fxp-fs { border: 0; border-radius: 6px; padding: 4px 11px; min-width: 40px; font: 800 11px system-ui, sans-serif; letter-spacing: .04em; color: #fff; cursor: pointer;
      background: linear-gradient(135deg, #f97316, #c2410c); box-shadow: 0 2px 8px rgba(249,115,22,.3); transition: box-shadow .15s, transform .1s, filter .15s; white-space: nowrap; }
    .ia-fxp-fs:hover { box-shadow: 0 4px 14px rgba(249,115,22,.55); filter: brightness(1.06); }
    .ia-fxp-fs:active { transform: translateY(1px); }
    .ia-fxp-fs.is-busy { filter: saturate(.7) brightness(.95); cursor: progress; }
    .ia-fxp-pick { border: 1px solid #445071; background: #1b2132; color: #e5e7eb; border-radius: 6px; padding: 4px 10px; font: 700 11px system-ui, sans-serif; cursor: pointer; min-width: 74px; text-align: left; transition: border-color .15s, background .15s; }
    .ia-fxp-pick:hover, .ia-fxp-pick.is-open { border-color: #7c8db5; background: #232a40; }
    .ia-fxp-menu.ia-fxp-menu--cab, .ia-fxp-menu.ia-fxp-menu--flex { min-width: 140px; }
    .ia-fxp-ma { width: max-content; max-width: calc(100vw - 16px); box-sizing: border-box; padding: 8px; }
    .ia-fxp-ma-row { display: flex; align-items: center; gap: 0; margin: 2px 0 8px; }
    .ia-fxp-ma-box { flex: 1 1 246px; min-width: 246px; box-sizing: border-box; overflow: hidden; display: flex; align-items: center; gap: 7px; height: 40px; padding: 0 10px; border: 1px solid #445071; border-radius: 9px; background: #232a3d; cursor: text; }
    .ia-fxp-ma-box:focus-within { border-color: #8b7cf6; }
    .ia-fxp-ma-ic { color: #9aa3ba; font-size: 13px; flex: none; }
    .ia-fxp-ma-chips { display: inline-flex; gap: 5px; flex: none; }
    .ia-fxp-ma-chip { display: inline-flex; align-items: center; gap: 4px; height: 24px; padding: 0 4px 0 9px; border-radius: 999px; background: #3a4258; color: #f1f5f9; font: 800 11.5px system-ui, sans-serif; letter-spacing: .04em; }
    .ia-fxp-ma-x { border: 0; background: transparent; color: #cbd5e1; cursor: pointer; font-size: 14px; line-height: 1; padding: 0 3px; border-radius: 50%; }
    .ia-fxp-ma-x:hover { color: #fff; background: rgba(255,255,255,.12); }
    .ia-fxp-ma-box input { flex: 1; min-width: 0; border: 0; outline: none; background: transparent; color: #e5e7eb; font: 700 13px system-ui, sans-serif; letter-spacing: .03em; text-transform: uppercase; }
    .ia-fxp-ma-box input::placeholder { color: #8b93a7; text-transform: none; font-weight: 500; letter-spacing: 0; }
    .ia-fxp-ma-sw { flex: none; width: 30px; height: 30px; margin: 0 6px; z-index: 1; border-radius: 50%; border: 1px solid #445071; background: #3a4258; color: #e5e7eb; cursor: pointer; font-size: 14px; line-height: 1; }
    .ia-fxp-ma-sw:hover { background: #4a5470; }
    .ia-fxp-ma-info { display: flex; align-items: center; flex-wrap: wrap; gap: 6px; padding: 0 0 8px; }
    .ia-fxp-ma-date { height: 28px; padding: 0 6px; border: 1px solid #445071; border-radius: 6px; background: #232a3d; color: #e5e7eb; font: 700 11.5px system-ui, sans-serif; color-scheme: dark; }
    .ia-fxp-ma-date:focus { outline: none; border-color: #8b7cf6; }
    .ia-fxp-ma-arrow { color: #9aa3ba; font-size: 12px; }
    .ia-fxp-ma-lbl { font: 800 11px Inter, 'Segoe UI', system-ui, sans-serif; color: var(--ias-sec, #9aa3ba); margin-right: 2px; }
    .ia-fxp-ma-pills.ia-fxp-ma-cab { margin-left: 0; }
    .ia-fxp-ma-pills { display: inline-flex; margin-left: auto; border: 1px solid #445071; border-radius: 6px; overflow: hidden; }
    .ia-fxp-ma-pills button { border: 0; border-left: 1px solid #2c3550; background: #1b2132; color: #c9cfe0; font: 700 11px system-ui, sans-serif; padding: 0 7px; height: 26px; cursor: pointer; }
    .ia-fxp-ma-pills button:first-child { border-left: 0; }
    .ia-fxp-ma-pills button:hover { background: #2c3550; }
    .ia-fxp-ma-pills button.on { background: #6d5bd0; color: #fff; }
    .ia-fxp-ma-acts { display: flex; gap: 6px; justify-content: flex-end; }
    .ia-fxp-ma-go { border: 1px solid #445071; background: #1b2132; color: #e5e7eb; border-radius: 6px; padding: 6px 10px; font: 700 12px system-ui, sans-serif; cursor: pointer; }
    .ia-fxp-ma-go:hover { border-color: #8b7cf6; }
    .ia-fxp-ma-go.is-main { background: #6d5bd0; border-color: #6d5bd0; color: #fff; }
    .ia-fxp-ma-err { color: #fca5a5; font-size: 11px; font-weight: 600; padding-top: 6px; min-height: 0; }
    .ia-fxp-ma-err:empty { display: none; }
    .ia-fxp-allwrap { display: inline-flex; align-items: center; gap: 2px; }
    .ia-fxp-allm { border: 0; background: transparent; color: #c4b5fd; cursor: pointer; font-size: 11px; padding: 3px 5px; border-radius: 4px; line-height: 1; }
    .ia-fxp-allm:hover, .ia-fxp-allm.is-open { background: rgba(148,163,184,.18); }
    .ia-fxp-menu.ia-fxp-menu--all { min-width: 170px; }
    .ia-fxp-menu-c span { display: inline-flex; align-items: center; gap: 8px; }
    .ia-fxp-menu-c.is-off span { color: #8b93a7; }
    .ia-fxp-chk { width: 14px; height: 14px; border-radius: 3px; border: 1.5px solid #5b6787; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 900; color: #fff; flex: none; }
    .ia-fxp-chk.on { background: #7c3aed; border-color: #7c3aed; }
    .ia-fxp-menu-i.is-sel { background: rgba(59,130,246,.18); color: #93c5fd; }
    .ia-fxp-menu-i.is-sel small { color: #93c5fd; font-weight: 800; }
    .ia-fxp-sel { border: 1px solid #445071; background: rgba(15,20,35,.45); color: #e5e7eb; border-radius: 5px; padding: 2px 6px; font: 700 11px system-ui, sans-serif; cursor: pointer; }
    .ia-fxp-all { background: none; border: 0; color: #c4b5fd; font: 800 12px system-ui, sans-serif; cursor: pointer; padding: 2px 4px; }
    .ia-fxp-all:hover { text-decoration: underline; }
    .ia-fxp-menu { position: fixed; z-index: 2147483000; min-width: 210px; background: #1b2132; border: 1px solid #445071; border-radius: 8px; padding: 5px; box-shadow: 0 12px 26px rgba(0,0,0,.5); font-family: system-ui, sans-serif; color: #e5e7eb; }
    .ia-fxp-menu--m { border-color: #6d4bb0; } .ia-fxp-menu--py { border-color: #b07a1a; } .ia-fxp-menu--fb { border-color: #6d5bd0; }
    .ia-fxp-menu-h { font-size: 9px; letter-spacing: .1em; text-transform: uppercase; color: #8b93a7; font-weight: 800; padding: 3px 7px 5px; }
    .ia-fxp-menu-i { display: flex; justify-content: space-between; gap: 14px; padding: 7px 8px; border-radius: 5px; font-size: 12px; font-weight: 700; cursor: pointer; }
    .ia-fxp-menu-i small { color: #8b93a7; font-weight: 600; }
    .ia-fxp-menu-i:hover { background: #2c3550; }
    .ia-zero-back { position: fixed; inset: 0; z-index: 2147483000; background: rgba(0,0,0,.45); display: flex; align-items: center; justify-content: center; }
    .ia-zero-box { width: 380px; max-width: calc(100vw - 32px); background: #0f172a; color: #e2e8f0; border: 1px solid #334155; border-radius: 12px; padding: 18px 18px 14px; box-shadow: 0 20px 50px rgba(0,0,0,.35); font-family: system-ui, sans-serif; border-top: 5px solid #dc2626; }
    .ia-zero-title { font-weight: 800; font-size: 16px; color: #b91c1c; margin-bottom: 8px; text-align: center; }
    .ia-zero-text { font-size: 13.5px; line-height: 1.45; margin-bottom: 14px; text-align: center; }
    .ia-zero-row { display: flex; gap: 8px; justify-content: flex-end; }
    .ia-zero-row button { border: 0; border-radius: 8px; padding: 8px 14px; font-weight: 700; font-size: 13px; cursor: pointer; }
    .ia-zero-no { background: #5b5bd6; color: #fff; }
    .ia-zero-yes { background: #1e293b; color: #f87171; }
    .ia-sell-input.is-bad { border-color: #dc2626; background: #fee2e2; }
    .ia-sell-saved { color: #16a34a !important; transition: color .3s; }
    .ia-sell-err { color: #dc2626 !important; }
    .ia-sell-toast { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); z-index: 2147483000; max-width: 640px; background: #0f172a; border: 1px solid #f87171; color: #fff; font: 600 13px system-ui, sans-serif; padding: 10px 14px; border-radius: 8px; box-shadow: 0 6px 20px rgba(0,0,0,.35); }
    .ia-merge-btn { font-size: 12px; font-weight: 600; white-space: nowrap; min-height: 34px; }
  `);

  // ------------------------------------------------------------------
  // Search panel in TBC Assistant colours. Follows the agent's mode
  // (dark / light / navy) and accent: the values are copied onto the page
  // as --ias-* variables whenever either setting changes.
  // ------------------------------------------------------------------
  function iaPaintSearchColours() {
    if (typeof iaPalette !== 'function') return;
    const p = iaPalette();
    const r = document.documentElement.style;
    const light = iaIsLight(p.mode);
    const set = {
      bg: p.bg, field: p.field, line: p.line, line2: p.line2, text: p.text, title: p.title, muted: p.muted, sec: p.sec,
      acc: p.pri, onacc: p.onpri, shadow: p.shadow, scheme: light ? 'light' : 'dark',
      glass: p.glass, edge: p.edge, inner: p.inner, chip: p.chip, chipshadow: p.chipshadow, sky: p.sky, bad: p.bad,
      'g': light ? '#2563eb' : '#60a5fa', 'e': light ? '#16a34a' : '#4ade80', 'm': light ? '#7c3aed' : '#c4b5fd',
      'py': light ? '#ca8a04' : '#facc15', 'fb': light ? '#3f3f46' : '#e8e8ed', 'k': light ? '#ea580c' : '#fb923c',
    };
    Object.keys(set).forEach((k) => r.setProperty('--ias-' + k, set[k]));
  }
  iaPaintSearchColours();
  try { ['ia-mode', 'bmo-theme'].forEach((k) => GM_addValueChangeListener(k, iaPaintSearchColours)); } catch (e) { /* ignore */ }

  GM_addStyle(`
    .kayak-offers.ia-fxp { background: var(--ias-bg) !important; border: 1px solid var(--ias-line) !important; border-radius: 12px !important; color: var(--ias-text) !important; }
    .kayak-offers.ia-fxp > .kayak-offers-footer { border-top: 1px solid var(--ias-line) !important; background: transparent !important; }
    .ia-fxp-panel { gap: 6px; padding: 8px; }
    .ia-fxp-b, .ia-fxp-b.ia-fxp-g, .ia-fxp-b.ia-fxp-e, .ia-fxp-b.ia-fxp-m, .ia-fxp-b.ia-fxp-py, .ia-fxp-b.ia-fxp-fb, .ia-fxp-b.ia-fxp-k {
      display: inline-flex; align-items: center; justify-content: center; gap: 6px; border-radius: 8px; border: 1px solid var(--ias-line2);
      background: transparent; color: var(--ias-text); font: 600 11.5px/1 Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-fxp-b::before { content: ''; width: 6px; height: 6px; border-radius: 50%; flex: none; background: var(--ias-text); }
    .ia-fxp-g::before { background: var(--ias-g); } .ia-fxp-e::before { background: var(--ias-e); } .ia-fxp-m::before { background: var(--ias-m); }
    .ia-fxp-py::before { background: var(--ias-py); } .ia-fxp-fb::before { background: var(--ias-fb); } .ia-fxp-k::before { background: var(--ias-k); }
    .ia-fxp-b:hover { background: var(--ias-field); border-color: var(--ias-muted); }
    .ia-fxp-b.is-open { background: var(--ias-field); border-color: var(--ias-acc); }
    .ia-fxp-pick, .ia-fxp-sel { border: 1px solid var(--ias-line2); background: transparent; color: var(--ias-sec); border-radius: 6px; font: 600 11px Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-fxp-pick:hover, .ia-fxp-pick.is-open { border-color: var(--ias-acc); background: var(--ias-field); }
    .ia-fxp-re { color: var(--ias-muted); }
    .ia-fxp-re:hover { color: var(--ias-title); background: var(--ias-field); }
    .ia-fxp-allwrap { background: var(--ias-acc); border-radius: 6px; padding: 0 2px 0 4px; }
    .ia-fxp-all, .ia-fxp-allm { color: var(--ias-onacc); font: 600 11.5px Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-fxp-all:hover { text-decoration: none; }
    .ia-fxp-allm:hover, .ia-fxp-allm.is-open { background: rgba(0,0,0,.12); }
    .ia-fxp-menu, .ia-fxp-menu--m, .ia-fxp-menu--py, .ia-fxp-menu--fb { background: var(--ias-field); border: 1px solid var(--ias-line2); border-radius: 10px; color: var(--ias-text); box-shadow: var(--ias-shadow); font-family: Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-fxp-menu-h { color: var(--ias-muted); text-transform: none; letter-spacing: 0; font-size: 11px; font-weight: 500; }
    .ia-fxp-menu-i { font-weight: 600; color: var(--ias-text); }
    .ia-fxp-menu-i small { color: var(--ias-muted); font-weight: 500; }
    .ia-fxp-menu-i:hover { background: var(--ias-bg); }
    .ia-fxp-menu-i.is-sel, .ia-fxp-menu-i.is-opened { background: color-mix(in srgb, var(--ias-acc) 14%, transparent); color: var(--ias-title); }
    .ia-fxp-menu-i.is-sel small, .ia-fxp-menu-i.is-opened small { color: var(--ias-acc); font-weight: 600; }
    .ia-fxp-chk { border-color: var(--ias-line2); color: var(--ias-onacc); }
    .ia-fxp-chk.on { background: var(--ias-acc); border-color: var(--ias-acc); }
    .ia-fxp-menu-c.is-off span { color: var(--ias-muted); }
    /* Basis multi-airport search box, in TBC Assistant colours */
    .ia-fxp-ma-box { border-color: var(--ias-line2) !important; background: var(--ias-bg) !important; border-radius: 10px !important; }
    .ia-fxp-ma-box:focus-within { border-color: var(--ias-acc) !important; }
    .ia-fxp-ma-ic { color: var(--ias-muted) !important; }
    .ia-fxp-ma-chip { background: var(--ias-field) !important; border: 1px solid var(--ias-line2); color: var(--ias-title) !important; font-family: Inter, 'Segoe UI', system-ui, sans-serif !important; }
    .ia-fxp-ma-x { color: var(--ias-muted) !important; }
    .ia-fxp-ma-x:hover { color: var(--ias-title) !important; background: var(--ias-line) !important; }
    .ia-fxp-ma-box input { color: var(--ias-title) !important; font-family: Inter, 'Segoe UI', system-ui, sans-serif !important; font-weight: 800 !important; }
    .ia-fxp-ma-box input::placeholder { color: var(--ias-muted) !important; font-weight: 600 !important; }
    .ia-fxp-ma-sw { border-color: var(--ias-line2) !important; background: var(--ias-field) !important; color: var(--ias-title) !important; }
    .ia-fxp-ma-sw:hover { border-color: var(--ias-acc) !important; }
    .ia-fxp-ma-date { border-color: var(--ias-line2) !important; background: var(--ias-bg) !important; color: var(--ias-title) !important; color-scheme: var(--ias-scheme) !important; font-family: Inter, 'Segoe UI', system-ui, sans-serif !important; }
    .ia-fxp-ma-date:focus { border-color: var(--ias-acc) !important; }
    .ia-fxp-ma-arrow { color: var(--ias-muted) !important; }
    .ia-fxp-ma-pills { border-color: var(--ias-line2) !important; border-radius: 7px !important; }
    .ia-fxp-ma-pills button { border-left-color: var(--ias-line2) !important; background: var(--ias-bg) !important; color: var(--ias-sec) !important; font-family: Inter, 'Segoe UI', system-ui, sans-serif !important; }
    .ia-fxp-ma-pills button:hover { background: var(--ias-field) !important; }
    .ia-fxp-ma-pills button.on { background: var(--ias-acc) !important; color: var(--ias-onacc) !important; }
    .ia-fxp-ma-go { border-color: var(--ias-line2) !important; background: transparent !important; color: var(--ias-text) !important; border-radius: 7px !important; font-family: Inter, 'Segoe UI', system-ui, sans-serif !important; font-weight: 800 !important; }
    .ia-fxp-ma-go:hover { border-color: var(--ias-acc) !important; }
    .ia-fxp-ma-go.is-main { background: var(--ias-acc) !important; border-color: var(--ias-acc) !important; color: var(--ias-onacc) !important; }
    .ia-fxp-ma-h { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .ia-fxp-ma-close { border: 0; background: transparent; color: var(--ias-muted); font: 800 16px/1 system-ui, sans-serif; padding: 0 2px; cursor: pointer; border-radius: 5px; }
    .ia-fxp-ma-close:hover { color: var(--ias-text); }
    .ia-fxp-ma-err { color: var(--ias-bad, #f87171) !important; }
  `);

  // Sky Glass look for the search panel and its menus.
  GM_addStyle(`
    .kayak-offers.ia-fxp { background: var(--ias-sky), var(--ias-glass) !important; -webkit-backdrop-filter: blur(18px) saturate(1.4); backdrop-filter: blur(18px) saturate(1.4);
      border: 1px solid var(--ias-edge) !important; border-radius: 18px !important; box-shadow: var(--ias-shadow), inset 0 1px 0 var(--ias-edge) !important; }
    .kayak-offers.ia-fxp > .kayak-offers-footer { border-top: 1px solid var(--ias-line) !important; }
    .ia-fxp-panel { gap: 6px; padding: 9px; }
    .ia-fxp-note { border-radius: 999px; background: color-mix(in srgb, var(--ias-acc) 14%, transparent); color: var(--ias-title); font-weight: 700; }
    .ia-fxp-note.is-warn { background: color-mix(in srgb, #f59e0b 22%, transparent); color: var(--ias-title); }
    .ia-fxp-b, .ia-fxp-b.ia-fxp-g, .ia-fxp-b.ia-fxp-e, .ia-fxp-b.ia-fxp-m, .ia-fxp-b.ia-fxp-py, .ia-fxp-b.ia-fxp-fb, .ia-fxp-b.ia-fxp-k {
      border-radius: 999px; border: 1px solid transparent; background: var(--ias-chip); box-shadow: var(--ias-chipshadow); color: var(--ias-title); font-weight: 800; }
    .ia-fxp-b::before { width: 7px; height: 7px; }
    .ia-fxp-b:hover { background: var(--ias-chip); border-color: var(--ias-acc); }
    .ia-fxp-b.is-open { background: var(--ias-chip); border-color: var(--ias-acc); }
    .ia-fxp-pick, .ia-fxp-sel { border: 1px solid transparent; background: var(--ias-chip); box-shadow: var(--ias-chipshadow); color: var(--ias-title); border-radius: 999px; font-weight: 800; }
    .ia-fxp-pick:hover, .ia-fxp-pick.is-open { border-color: var(--ias-acc); background: var(--ias-chip); }
    .ia-fxp-re { border-radius: 999px; background: var(--ias-chip); color: var(--ias-title); }
    .ia-fxp-re:hover { background: var(--ias-chip); color: var(--ias-acc); }
    .ia-fxp-allwrap { background: linear-gradient(135deg, color-mix(in srgb, var(--ias-acc) 78%, #fff), var(--ias-acc)); border-radius: 999px; padding: 0 4px 0 8px;
      box-shadow: 0 6px 14px color-mix(in srgb, var(--ias-acc) 30%, transparent); }
    .ia-fxp-all, .ia-fxp-allm { font-weight: 800; }
    .ia-fxp-allm { border-radius: 999px; }
    .ia-fxp-fs { border-radius: 999px; padding: 4px 12px; min-width: 40px; color: var(--ias-onacc); font: 800 11px Inter, 'Segoe UI', system-ui, sans-serif; letter-spacing: .05em;
      background: linear-gradient(180deg, color-mix(in srgb, var(--ias-acc) 78%, white), var(--ias-acc)); box-shadow: 0 2px 8px color-mix(in srgb, var(--ias-acc) 35%, transparent); }
    .ia-fxp-fs:hover { box-shadow: 0 4px 14px color-mix(in srgb, var(--ias-acc) 55%, transparent); filter: none; }
    .ia-fxp-foot { gap: 6px; }
    .ia-fxp-foot-l { gap: 5px; min-width: 0; }
    .ia-fxp-pick { min-width: 0; white-space: nowrap; padding: 4px 9px; }
    .ia-fxp-all, .ia-fxp-allm { white-space: nowrap; }
    .ia-fxp-fs { padding: 4px 10px; flex: none; }
    .ia-fxp-menu, .ia-fxp-menu--m, .ia-fxp-menu--py, .ia-fxp-menu--fb { background: var(--ias-sky), var(--ias-glass); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5);
      border: 1px solid var(--ias-edge); border-radius: 16px; box-shadow: var(--ias-shadow), inset 0 1px 0 var(--ias-edge); padding: 6px; }
    .ia-fxp-menu-h { font-weight: 700; }
    .ia-fxp-menu-i { border-radius: 10px; font-weight: 700; }
    .ia-fxp-menu-i:hover { background: var(--ias-chip); }
    .ia-fxp-chk { border-radius: 5px; }
    .ia-fxp-ma-box { border: 1px solid transparent !important; background: var(--ias-chip) !important; box-shadow: var(--ias-chipshadow); border-radius: 14px !important; }
    .ia-fxp-ma-box:focus-within { border-color: var(--ias-acc) !important; }
    .ia-fxp-ma-chip { background: var(--ias-inner) !important; border: 1px solid var(--ias-line2); border-radius: 999px !important; font-weight: 800 !important; }
    .ia-fxp-ma-sw { border: 1px solid transparent !important; background: var(--ias-chip) !important; box-shadow: var(--ias-chipshadow); }
    .ia-fxp-ma-date { border: 1px solid transparent !important; background: var(--ias-chip) !important; border-radius: 10px !important; font-weight: 700 !important; }
    .ia-fxp-ma-pills { border: 0 !important; border-radius: 999px !important; background: var(--ias-chip); padding: 2px; gap: 2px; }
    .ia-fxp-ma-pills button { border: 0 !important; background: transparent !important; border-radius: 999px !important; font-weight: 800 !important; }
    .ia-fxp-ma-pills button:hover { background: var(--ias-inner) !important; }
    .ia-fxp-ma-pills button.on { background: var(--ias-acc) !important; color: var(--ias-onacc) !important; }
    .ia-fxp-ma-go { border: 1px solid transparent !important; background: var(--ias-chip) !important; box-shadow: var(--ias-chipshadow); color: var(--ias-title) !important; border-radius: 12px !important; }
    .ia-fxp-ma-go:hover { border-color: var(--ias-acc) !important; }
    .ia-fxp-ma-go.is-main { background: linear-gradient(135deg, color-mix(in srgb, var(--ias-acc) 78%, #fff), var(--ias-acc)) !important; border-color: transparent !important; color: var(--ias-onacc) !important; }
  `);

  function scan() {
    document.querySelectorAll('.app-modal__container--price-quote').forEach(wireModal);
    renderOptionFlags();
    wireMergeButtons();
    wireSellEdit();
    wireSearchPanels();
    if (window.top === window) wireLeadIdCopy();
    wireTerminal();
    wireMilesTaxesSteppers();
    wireMileProgramAlignment();
  }

  // Shares PART 2/3/4's single observer instead of keeping its own —
  // see the comment where __jsEnsureSharedObserver is defined.
  __jsRegisterScan(scan);
  __jsEnsureSharedObserver();
  scan();
})();


// ====================================================================
// SECTION 3 · CRM leads list: "select all" checkbox per lead's options
// ====================================================================
(function () {
  'use strict';

  if (window.top !== window) return; // not inside hidden worker frames
  if (!location.hostname.includes('travelbusinessclass.com')) return;

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function setNativeChecked(el, value) {
    const proto = Object.getPrototypeOf(el);
    const setter = (Object.getOwnPropertyDescriptor(proto, 'checked') || {}).set
      || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'checked').set;
    setter.call(el, value);
  }

  // We only have two disconnected DOM samples for this feature — the
  // header cell itself, and one option's own checkbox cell — with no
  // confirmation of what wraps both of them, or whether the header cell
  // repeats once per lead or once for the whole list. Rather than guess
  // a specific wrapper class name and risk scoping to nothing (the same
  // failure mode as the CheapOair class-prefix mismatch), walk up from
  // the header cell to the NEAREST ancestor that actually contains at
  // least one option checkbox. That self-adjusts to either layout: if
  // the header repeats per lead, the nearest such ancestor is that
  // lead's own wrapper; if there's one header for the whole list, the
  // walk keeps going until it reaches the container that holds every
  // lead, which is the correct scope for a true page-wide select-all.
  function findScope(headerCell) {
    let node = headerCell.parentElement;
    while (node && node !== document.body) {
      if (node.querySelector('input[id^="checkbox-switch-"]')) return node;
      node = node.parentElement;
    }
    return document;
  }

  // ".lead-options-header-cell" turned out to be the generic header-cell
  // class for EVERY column in this row (PRICE, ITINERARY SEGMENTS, SOLD
  // all use it too), not something unique to the actions column — so
  // querying it alone wired up four separate checkboxes instead of one.
  // The actions-column header is the only one that actually contains the
  // eye/plus icon buttons, so require both of those to be present before
  // treating a header cell as the right one.
  function isActionsHeaderCell(headerCell) {
    return !!headerCell.querySelector('svg.feather-eye') && !!headerCell.querySelector('svg.feather-plus');
  }

  function wireHeaderCell(headerCell) {
    if (headerCell.dataset.selectAllWired) return;
    headerCell.dataset.selectAllWired = '1';

    const label = document.createElement('label');
    label.className = 'button btn btn-outline-secondary box p-2 text-theme-33 ml-2 --only';
    label.title = 'Select all options';
    label.style.cursor = 'pointer';
    label.style.display = 'inline-flex';
    label.style.alignItems = 'center';
    label.style.justifyContent = 'center';

    const master = document.createElement('input');
    master.type = 'checkbox';
    master.className = 'gds-lead-select-all w-3.5 h-3.5 !border !border-slate-100';
    master.style.margin = '0';
    label.appendChild(master);
    headerCell.appendChild(label);

    const scope = findScope(headerCell);

    // Disabled options (greyed out, can't be sold — like 4048006 in the
    // example) are excluded from both the toggle and the master's own
    // checked/indeterminate count, since they can never actually be
    // selected and shouldn't stop the master from showing "all checked"
    // once every SELECTABLE option is checked.
    function targets() {
      return Array.from(scope.querySelectorAll('input[id^="checkbox-switch-"]:not(:disabled)'));
    }

    function syncMasterFromTargets() {
      const boxes = targets();
      const checkedCount = boxes.filter((cb) => cb.checked).length;
      master.checked = boxes.length > 0 && checkedCount === boxes.length;
      master.indeterminate = checkedCount > 0 && checkedCount < boxes.length;
    }

    // Reflect whatever's already checked when this first wires up,
    // rather than always starting unchecked regardless of real state.
    syncMasterFromTargets();

    // The app appears to re-render each lead's row right after its own
    // checkbox toggles (most likely tied to the "N options selected"
    // bar animating in) — which replaces that row's DOM node. Looping
    // over a snapshot of targets() taken once at the start meant every
    // checkbox after the first was a stale reference to a node Vue had
    // already swapped out from under it, so only ONE selection actually
    // stuck per click — hence needing to click three times for three
    // leads. Re-querying the live DOM before each individual toggle,
    // with a short pause after each one for the re-render to land,
    // fixes that regardless of how many options are on the page.
    let toggling = false;
    master.addEventListener('change', async () => {
      if (toggling) return;
      toggling = true;
      const desired = master.checked;
      try {
        // eslint-disable-next-line no-constant-condition
        while (true) {
          const next = targets().find((cb) => cb.checked !== desired);
          if (!next) break;
          setNativeChecked(next, desired);
          // Only fire 'change'/'input' (notification events) — never a
          // synthetic 'click'. A dispatched 'click' event on a checkbox
          // triggers the browser's native toggle behavior same as a
          // real click, which would flip .checked a second time right
          // after we just set it, undoing this.
          next.dispatchEvent(new Event('input', { bubbles: true }));
          next.dispatchEvent(new Event('change', { bubbles: true }));
          await wait(60);
        }
      } finally {
        toggling = false;
        syncMasterFromTargets();
      }
    });

    // Keep the master in sync when a lead's own checkboxes change some
    // other way (clicked directly, or another part of the app toggles
    // one) — capture phase so this still sees the change even if some
    // other handler stops propagation before it bubbles.
    scope.addEventListener('change', (e) => {
      if (!e.target.matches || !e.target.matches('input[id^="checkbox-switch-"]')) return;
      if (toggling) return; // avoid fighting with our own in-flight loop above
      syncMasterFromTargets();
    }, true);
  }

  function scan() {
    document.querySelectorAll('.lead-options-header-cell').forEach((cell) => {
      if (isActionsHeaderCell(cell)) wireHeaderCell(cell);
    });
  }

  // Shares PART 2/3/4's single observer instead of keeping its own —
  // see the comment where __jsEnsureSharedObserver is defined.
  __jsRegisterScan(scan);
  __jsEnsureSharedObserver();
  scan();
})();

// ====================================================================
// SECTION 4 · CRM leads list: power dialer
// ====================================================================
// Chrome has an explicit, deliberate "anti-flood" protection for
// external-protocol launches (tel:, mailto:, etc.) — confirmed directly
// in Chromium's own source: the flag that allows a launch is reset to
// false the moment one fires, and only set back to true by a fresh,
// genuine user gesture. That means a script can never advance through
// a whole list and dial each number on its own; every single call has
// to be triggered by one real action from the person, not by a
// previous call finishing or a timer firing. So this is built as a
// "one action per call" power dialer: press Call, everything else
// happens automatically for THAT one call, then it's ready for the
// next press — not a hands-free auto-advance, because that specific
// thing isn't something a webpage script can do at all.
(function () {
  'use strict';

  // Experts don't work leads, so Pip and the whole power-dialer setup
  // have nothing for them — excluded on /experts/ specifically rather
  // than the whole domain, so this still runs on every other leads-list
  // path under this host.
  if (!location.hostname.includes('travelbusinessclass.com')) return;
  if (location.pathname.startsWith('/experts/')) return;
  if (window.top !== window) return; // no Pip / phone panel inside hidden worker frames
  if (!location.pathname.startsWith('/leads/')) return; // same pages as before the BO-wide match

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  const CALLED_STORAGE_PREFIX = 'auto-dialer-called-';
  const SKIPPED_STORAGE_PREFIX = 'auto-dialer-skipped-';
  // Second follow-up round (unlocked once every lead has had round 1).
  const CALLED2_STORAGE_PREFIX = 'auto-dialer-called2-';
  const SKIPPED2_STORAGE_PREFIX = 'auto-dialer-skipped2-';
  const ROUND_STORAGE_PREFIX = 'bmo-round-';
  const SUPER_STORAGE_PREFIX = 'bmo-super-';
  // Numbers that are never real leads — always skipped automatically.
  const BLOCKED_NUMBERS = ['10000000000'];
  // The masked format seen is "+1253****168" -- leading +digits, at
  // least one asterisk, trailing digits. The revealed format seen after
  // one click is "+12538860168" -- clean digits only, no asterisks.
  const PHONE_MASKED_RE = /^\+\d[\d*]*\*[\d*]*\d$/;
  const PHONE_REVEALED_RE = /^\+?\d{10,15}$/;

  // "Today" resets at 2pm GMT rather than local midnight, so called/
  // skipped leads, the started-today flag, and the reminder's wording
  // all flip over together at a fixed point in the day regardless of
  // whoever's local timezone is running this. Shifting the clock back
  // by 14 hours before reading off the date does this: anything from
  // 14:00 GMT onward lands on today's GMT date (a fresh bucket just
  // started), and anything before 14:00 GMT lands on yesterday's GMT
  // date (still inside the bucket that opened at 2pm the day before).
  function todayKey() {
    const shifted = new Date(Date.now() - 14 * 60 * 60 * 1000);
    return shifted.getUTCFullYear() + '-' + String(shifted.getUTCMonth() + 1).padStart(2, '0') + '-' + String(shifted.getUTCDate()).padStart(2, '0');
  }

  // Called (green) and skipped (yellow) are tracked as two separate
  // sets now, not one collapsed "done" state — a lead can be in at most
  // one of them at a time, but which one matters for the indicator
  // color and is worth keeping distinct in storage too.
  function getSet(prefix) {
    let raw;
    try { raw = GM_getValue(prefix + todayKey(), '[]'); } catch (e) { raw = '[]'; }
    try { return new Set(JSON.parse(raw)); } catch (e) { return new Set(); }
  }

  function saveSet(prefix, set) {
    GM_setValue(prefix + todayKey(), JSON.stringify(Array.from(set)));
  }

  // Which follow-up round today is on: 1 (first pass) or 2 (second pass,
  // unlocked once round 1 is finished). Resets with the 2pm GMT day.
  function getRound() {
    try { return GM_getValue(ROUND_STORAGE_PREFIX + todayKey(), 1) === 2 ? 2 : 1; } catch (e) { return 1; }
  }
  function setRound(n) {
    try { GM_setValue(ROUND_STORAGE_PREFIX + todayKey(), n); } catch (e) { /* best-effort */ }
    updateTodayStats();
  }

  // --- Today's numbers (calls, answered, skipped, round) --------------
  // Calls and answered are counted as they happen; skipped comes from the
  // day's skipped lists. Same 2pm GMT day as everything else.
  var STATS_PREFIX = 'ia-stats-';
  function getTodayStats() {
    try { const v = JSON.parse(GM_getValue(STATS_PREFIX + todayKey(), '{}')); return { calls: +v.calls || 0, answered: +v.answered || 0 }; } catch (e) { return { calls: 0, answered: 0 }; }
  }
  function bumpTodayStat(name) {
    const st = getTodayStats();
    st[name] = (st[name] || 0) + 1;
    try { GM_setValue(STATS_PREFIX + todayKey(), JSON.stringify(st)); } catch (e) { /* best-effort */ }
    updateTodayStats();
  }
  function updateTodayStats() {
    const el = iaWidget && iaWidget.querySelector('.ia-stats');
    if (!el) return;
    const st = getTodayStats();
    const skipped = getSet(SKIPPED_STORAGE_PREFIX).size + getSet(SKIPPED2_STORAGE_PREFIX).size;
    const set = (k, v) => { const n = el.querySelector('[data-stat="' + k + '"]'); if (n && n.textContent !== String(v)) n.textContent = String(v); };
    set('calls', st.calls);
    set('answered', st.answered);
    set('skipped', skipped);
    set('round', getRound());
  }

  function markCalled(leadId) {
    if (!leadId) return;
    const round2 = getRound() === 2;
    const skipPrefix = round2 ? SKIPPED2_STORAGE_PREFIX : SKIPPED_STORAGE_PREFIX;
    const callPrefix = round2 ? CALLED2_STORAGE_PREFIX : CALLED_STORAGE_PREFIX;
    const skipped = getSet(skipPrefix);
    if (skipped.delete(leadId)) saveSet(skipPrefix, skipped);
    const called = getSet(callPrefix);
    called.add(leadId);
    saveSet(callPrefix, called);
    updateAllRowIndicators();
  }

  function markSkipped(leadId) {
    if (!leadId) return;
    const skipPrefix = getRound() === 2 ? SKIPPED2_STORAGE_PREFIX : SKIPPED_STORAGE_PREFIX;
    const skipped = getSet(skipPrefix);
    skipped.add(leadId);
    saveSet(skipPrefix, skipped);
    updateAllRowIndicators();
    updateTodayStats();
  }

  function isCalledTwice(leadId) {
    return getSet(CALLED2_STORAGE_PREFIX).has(leadId);
  }

  // "Done" for whichever round is running.
  function isDoneThisRound(leadId) {
    if (getRound() === 2) return getSet(CALLED2_STORAGE_PREFIX).has(leadId) || getSet(SKIPPED2_STORAGE_PREFIX).has(leadId);
    return isDone(leadId);
  }

  function isCalled(leadId) {
    return getSet(CALLED_STORAGE_PREFIX).has(leadId);
  }

  function isSkipped(leadId) {
    return getSet(SKIPPED_STORAGE_PREFIX).has(leadId);
  }

  function isDone(leadId) {
    return isCalled(leadId) || isSkipped(leadId);
  }

  function getLeadId(row) {
    const link = row.querySelector('a[href^="/leads/"]');
    if (!link) return null;
    const m = link.getAttribute('href').match(/\/leads\/(\d+)/);
    return m ? m[1] : null;
  }

  function getLeadRows() {
    return Array.from(document.querySelectorAll('tbody tr')).filter((row) => getLeadId(row));
  }

  // Column order is user-configurable ("Configure columns" in the top
  // bar), so a fixed column-index assumption would be fragile — this
  // finds the phone cell by its distinctive content shape instead. The
  // email column uses the exact same wrapper classes (truncate
  // max-w-[115px] cursor-pointer), so content, not class name, is what
  // actually tells them apart. Matches either the masked or
  // already-revealed form, so this keeps working even on a lead someone
  // already clicked once earlier in the session.
  function findPhoneCell(row) {
    const candidates = row.querySelectorAll('td div.truncate.cursor-pointer');
    for (const el of candidates) {
      const text = el.textContent.trim();
      if (PHONE_MASKED_RE.test(text) || PHONE_REVEALED_RE.test(text)) return el;
    }
    return null;
  }

  function waitForRevealedNumber(cell, timeoutMs) {
    return new Promise((resolve) => {
      const check = () => {
        const text = cell.textContent.trim();
        if (PHONE_REVEALED_RE.test(text)) { resolve(text); return true; }
        return false;
      };
      if (check()) return;
      const obs = new MutationObserver(() => { if (check()) obs.disconnect(); });
      obs.observe(cell, { childList: true, characterData: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(null); }, timeoutMs || 2000);
    });
  }

  // Origin/destination have no distinctive class to key on in the
  // sample rows seen — position (first two <td> after the lead-id one)
  // is the only signal available for those two specifically, unlike the
  // phone/email cells above which have a reliable content shape to
  // match on instead.
  function getLeadInfo(row) {
    const leadId = getLeadId(row);
    const idLink = row.querySelector('a[href^="/leads/"]');
    const clientLink = row.querySelector('a[href^="/clients/edit/"]');
    let clientName = clientLink ? clientLink.textContent.trim() : '';
    // Confirmed from a real screenshot: this shows a bare "-" for some
    // leads instead of a name -- likely no linked client record for
    // that specific lead. Best guess without the underlying HTML to
    // check against: a link showing a placeholder in its visible text
    // while the real value sits in its title attribute (a tooltip) is
    // a common pattern, so that's tried next. If that isn't actually
    // where this site keeps it, the "Lead <id>" fallback below at
    // least never shows a bare, uninformative dash on the screen.
    if (!clientName || clientName === '-') {
      const titleAttr = clientLink && clientLink.getAttribute('title');
      const titleTrimmed = titleAttr ? titleAttr.trim() : '';
      clientName = (titleTrimmed && titleTrimmed !== '-') ? titleTrimmed : '';
    }
    // From / To found by their headers ("From", "To"), wherever an agent
    // has put those columns; the old fixed positions only as a fallback.
    // Only a 3-letter code counts ("???" or anything else is unknown).
    const cells = row.querySelectorAll('td');
    const code3 = (td) => { const x = td ? td.textContent.trim().toUpperCase() : ''; return /^[A-Z]{3}$/.test(x) ? x : ''; };
    const byHead = (re, i) => { const td = cellByHeader(row, re); return td ? code3(td) : code3(cells[i]); };
    const origin = byHead(/^\s*from\s*$/i, 1);
    const dest = byHead(/^\s*to\s*$/i, 2);
    return {
      leadId,
      href: idLink ? idLink.getAttribute('href') : ('/leads/' + leadId),
      clientName,
      origin,
      dest,
    };
  }

  // Only considers rows currently in the DOM — i.e. only the current
  // page. Returning null here doesn't necessarily mean every lead is
  // done; it can also mean this page is done and there's another page
  // to move to, which is what calls this check what to do next.
  // Leads whose "Time left" cell is empty have no timer running — Pip
  // passes over those (without marking them), so they're picked up again
  // if a timer starts later.
  // Column position counted in grid columns (a header like "PQs / SPQs"
  // can span two cells), so it lines up with the right row cell.
  function timeLeftColumnIndex(row) {
    const table = row.closest('table');
    if (!table) return -1;
    let col = 0;
    for (const th of table.querySelectorAll('thead tr:first-child th')) {
      if (/time\s*left/i.test(th.textContent)) return col;
      col += th.colSpan || 1;
    }
    return -1;
  }

  function hasTimerRunning(row) {
    const idx = timeLeftColumnIndex(row);
    if (idx < 0) return true; // no "Time left" column on this view — don't filter
    let col = 0;
    for (const td of row.children) {
      const span = td.colSpan || 1;
      if (idx >= col && idx < col + span) return !!td.textContent.trim();
      col += span;
    }
    return true;
  }

  // --- Quiet hours ---------------------------------------------------
  // The client's local time (the BO's "Local time" column on the list, or
  // the clock badge inside a lead). 22:00–07:59 there: auto dial passes
  // over the lead (not marked, so it's picked up once it's daytime), and a
  // call you start yourself asks first.
  function cellByHeader(row, re) {
    const table = row.closest('table');
    if (!table) return null;
    let idx = -1, col = 0;
    for (const th of table.querySelectorAll('thead tr:first-child th')) {
      if (re.test(th.textContent)) { idx = col; break; }
      col += th.colSpan || 1;
    }
    if (idx < 0) return null;
    col = 0;
    for (const td of row.children) {
      const span = td.colSpan || 1;
      if (idx >= col && idx < col + span) return td;
      col += span;
    }
    return null;
  }
  function rowLocalTime(row) {
    const td = row && cellByHeader(row, /local\s*time/i);
    const m = td && td.textContent.match(/\b(\d{1,2}):(\d{2})\b/);
    return m ? m[1].padStart(2, '0') + ':' + m[2] : null;
  }
  function leadPageLocalTime() {
    const b = Array.from(document.querySelectorAll('.badge')).find((el) => el.querySelector('svg.feather-clock') && /\b\d{1,2}:\d{2}\b/.test(el.textContent) && !el.closest('tr, .ia-widget'));
    const m = b && b.textContent.match(/\b(\d{1,2}):(\d{2})\b/);
    return m ? m[1].padStart(2, '0') + ':' + m[2] : null;
  }
  const isQuietTime = (t) => { if (!t) return false; const h = parseInt(t, 10); return h >= 22 || h < 8; };
  let quietSeenInScan = false;

  // Pip-style "call anyway?" box. Resolves true (call) or false (cancel).
  function confirmQuietCall(time) {
    return new Promise((resolve) => {
      document.querySelectorAll('.ia-quiet').forEach((n) => n.remove());
      const ov = document.createElement('div');
      ov.className = 'ia-quiet';
      const pal = iaPalette();
      ov.style.cssText = '--q-glass:' + pal.glass + ';--q-sky:' + pal.sky + ';--q-edge:' + pal.edge + ';--q-inner:' + pal.inner + ';--q-chip:' + pal.chip + ';--q-chipsh:' + pal.chipshadow + ';--q-title:' + pal.title + ';--q-sec:' + pal.sec + ';--q-acc:' + pal.pri + ';--q-onacc:' + pal.onpri + ';--q-shadow:' + pal.shadow;
      const card = document.createElement('div');
      card.className = 'ia-quiet__card';
      const scr = document.createElement('div');
      scr.className = 'ia-quiet__scr';
      const t1 = document.createElement('div');
      t1.className = 'ia-quiet__time';
      t1.textContent = time;
      const moon = document.createElement('span');
      moon.className = 'ia-quiet__moon';
      moon.textContent = '\u{1F319}';
      t1.prepend(moon);
      const pip = document.createElement('div');
      pip.className = 'ia-quiet__pip';
      try { pip.appendChild(iaPipNode(30, pal)); } catch (e) { /* no face is fine */ }
      scr.appendChild(pip);
      const t2 = document.createElement('div');
      t2.className = 'ia-quiet__msg';
      t2.textContent = 'It\u2019s night for this client (' + time + ' their time). Call anyway?';
      scr.append(t1, t2);
      const btns = document.createElement('div');
      btns.className = 'ia-quiet__btns';
      const no = document.createElement('button');
      no.type = 'button'; no.className = 'ia-quiet__no'; no.textContent = 'Cancel';
      const yes = document.createElement('button');
      yes.type = 'button'; yes.className = 'ia-quiet__yes'; yes.textContent = 'Call anyway';
      btns.append(no, yes);
      card.append(scr, btns);
      ov.appendChild(card);
      const done = (ok) => { document.removeEventListener('keydown', onKey, true); ov.remove(); resolve(ok); };
      const onKey = (e) => { if (e.key === 'Escape') { e.preventDefault(); done(false); } else if (e.key === 'Enter') { e.preventDefault(); done(true); } };
      no.addEventListener('click', (e) => { e.stopPropagation(); done(false); });
      yes.addEventListener('click', (e) => { e.stopPropagation(); done(true); });
      ov.addEventListener('click', (e) => { if (e.target === ov) done(false); });
      document.addEventListener('keydown', onKey, true);
      document.body.appendChild(ov);
      setTimeout(() => yes.focus(), 0);
    });
  }
  // For calls you start yourself: true = go ahead.
  async function quietOk(row) {
    const t = row ? rowLocalTime(row) : leadPageLocalTime();
    if (!isQuietTime(t)) return true;
    return confirmQuietCall(t);
  }

  function getNextPendingRowOnPage() {
    return getLeadRows().find((row) => {
      if (!hasTimerRunning(row) || isDoneThisRound(getLeadId(row))) return false;
      if (iaSkipOf(getLeadId(row)).call) return false; // you chose to skip calling it
      if (isQuietTime(rowLocalTime(row))) { quietSeenInScan = true; return false; }
      return true;
    }) || null;
  }

  // Prefers the specific numbered page-button matching (current page +
  // 1), read off the page-number input already used elsewhere on this
  // site — falls back to the chevron "next page" arrow if that specific
  // button isn't found, so this keeps working with either pagination
  // layout rather than depending on one exact structure.
  function findNextPageControl() {
    const pageInput = document.querySelector('.pagination-v2 input[type="number"]');
    const currentPage = pageInput ? parseInt(pageInput.value, 10) : null;
    if (currentPage) {
      const numberedBtn = Array.from(document.querySelectorAll('.pagination-v2__page'))
        .find((b) => b.textContent.trim() === String(currentPage + 1));
      if (numberedBtn && !numberedBtn.disabled) return numberedBtn;
    }
    const chevronBtn = Array.from(document.querySelectorAll('.pagination-v2 button'))
      .find((b) => b.querySelector('.feather-chevron-right') && !b.disabled);
    return chevronBtn || null;
  }

  function waitForRowsChanged(previousFirstLeadId, timeoutMs) {
    return new Promise((resolve) => {
      const check = () => {
        const rows = getLeadRows();
        if (rows.length && getLeadId(rows[0]) !== previousFirstLeadId) { resolve(true); return true; }
        return false;
      };
      if (check()) return;
      const obs = new MutationObserver(() => { if (check()) obs.disconnect(); });
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(false); }, timeoutMs || 3000);
    });
  }

  // Back to page 1 of the leads list (used when round 2 starts).
  async function goToFirstPage() {
    const pageInput = document.querySelector('.pagination-v2 input[type="number"]');
    const currentPage = pageInput ? parseInt(pageInput.value, 10) : 1;
    if (!currentPage || currentPage <= 1) return;
    const firstBtn = Array.from(document.querySelectorAll('.pagination-v2__page')).find((b) => b.textContent.trim() === '1');
    if (!firstBtn) return;
    const rows = getLeadRows();
    const previousFirstLeadId = rows.length ? getLeadId(rows[0]) : null;
    firstBtn.click();
    await waitForRowsChanged(previousFirstLeadId, 3000);
  }

  // The one that actually gets used from the panel — tries the current
  // page first, and only reaches for pagination once this page is
  // genuinely done, not before.
  // Walks forward page by page until it finds a lead still to call.
  // "Nothing left" is only concluded on the LAST page; a page that didn't
  // load in time is reported as such, never mistaken for "all done".
  let pendingScanState = 'ok'; // 'ok' | 'done' (last page reached) | 'pageFail'
  let levelUpArmed = false; // set once a full re-check found nothing left
  async function getNextPendingRow() {
    pendingScanState = 'ok';
    quietSeenInScan = false;
    for (let hops = 0; hops < 40; hops++) {
      const onPage = getNextPendingRowOnPage();
      if (onPage) { levelUpArmed = false; return onPage; }
      const nextBtn = findNextPageControl();
      if (!nextBtn) { pendingScanState = 'done'; return null; }
      const rows = getLeadRows();
      const previousFirstLeadId = rows.length ? getLeadId(rows[0]) : null;
      nextBtn.click();
      const changed = await waitForRowsChanged(previousFirstLeadId, 8000);
      if (!changed) { pendingScanState = 'pageFail'; return null; }
      await new Promise((r) => setTimeout(r, 400)); // let the new page's timers render
    }
    pendingScanState = 'pageFail';
    return null;
  }

  // --- Per-lead skip (right-click the lead's progress mark) ---------------
  // { leadId: { call: true } }, kept until you turn it back off.
  const IA_SKIP_KEY = 'ia-lead-skip';
  function iaSkips() { try { const o = JSON.parse(GM_getValue(IA_SKIP_KEY, '{}')); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
  function iaSkipOf(leadId) { return iaSkips()[String(leadId)] || {}; }
  function iaSetSkip(leadId, what, on) {
    const o = iaSkips();
    const id = String(leadId);
    const cur = Object.assign({}, o[id] || {});
    if (on) cur[what] = true; else delete cur[what];
    if (Object.keys(cur).length) o[id] = cur; else delete o[id];
    try { GM_setValue(IA_SKIP_KEY, JSON.stringify(o)); } catch (e) { /* best-effort */ }
    updateAllRowIndicators();
  }
  function openRowSkipMenu(row, x, y) {
    const id = getLeadId(row);
    if (!id) return;
    const sk = iaSkipOf(id);
    iaOpenMenu(x, y, [{ label: 'Skip calling this lead', on: !!sk.call, act: () => iaSetSkip(id, 'call', !sk.call) }], 'Lead #' + id);
  }

  // --- Row "called today" / "skipped today" indicator ---------------------
  function ensureRowIndicator(row) {
    const idCell = row.querySelector('td.group.table__td--link');
    if (!idCell) return null;
    // Speed: the layout check (getComputedStyle) runs once per cell, not on
    // every scan.
    if (idCell.style.position !== 'relative' && !idCell.dataset.jsPos) {
      if (getComputedStyle(idCell).position === 'static') idCell.style.position = 'relative';
      else idCell.dataset.jsPos = '1';
    }
    let dot = idCell.querySelector(':scope > .dialer-called-dot');
    if (!dot) {
      dot = document.createElement('span');
      dot.className = 'dialer-called-dot';
      dot.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const r = dot.closest('tr');
        if (r) openRowSkipMenu(r, e.clientX, e.clientY);
      });
      idCell.appendChild(dot);
    }
    return dot;
  }

  function updateAllRowIndicators() {
    const rows = getLeadRows();
    if (!rows.length) return;
    // Speed: each saved list is read once for the whole table (it used to
    // be re-read and re-parsed for every row, on every scan).
    const called = getSet(CALLED_STORAGE_PREFIX), called2 = getSet(CALLED2_STORAGE_PREFIX);
    const skipped = getSet(SKIPPED_STORAGE_PREFIX), skipped2 = getSet(SKIPPED2_STORAGE_PREFIX);
    const skips = iaSkips();
    rows.forEach((row) => {
      const dot = ensureRowIndicator(row);
      if (!dot) return;
      const leadId = getLeadId(row);
      const twice = called2.has(leadId);
      dot.classList.toggle('is-called2', twice);
      dot.classList.toggle('is-called', !twice && called.has(leadId));
      dot.classList.toggle('is-skipped', !twice && !called.has(leadId) && (skipped.has(leadId) || skipped2.has(leadId)));
      const sk = skips[String(leadId)] || {};
      dot.classList.toggle('is-nocall', !!sk.call);
      const tip = 'Right-click: skip calling this lead' + (sk.call ? '\n\u2022 Calling skipped' : '');
      if (dot.title !== tip) dot.title = tip;
    });
  }

  // ==========================================================================
  // Pip — the always-present, bottom-right dialer widget
  // ==========================================================================
  // Replaces both the old plain floating panel and the separate "Start Auto
  // Dialer" top-bar button. Pip himself is now the entry point: a small
  // round bubble sits bottom-right on every page under this domain at all
  // times, expanding into the full character on click. The four functional
  // actions map onto his actual body, matching where they'd sit on a real
  // Pip: the yellow cross is Call, the blue triangle is Skip, the green dot
  // is Double Dial, and the red circle — his main button, bottom right — is
  // Stop.
  let iaWidget = null;
  let iaMaximized = false;
  let dialerInitialized = false;


  // "Hi, <first name>!" on the LED panel under the screen, from the BO's
  // own "First Last #1234" style label. Remembered, so it shows on every page.
  const AGENT_NAME_KEY = 'bmo-first-name';
  function readAgentFirstName() {
    const el = Array.from(document.querySelectorAll('div.font-medium')).find((d) => /^\s*\S.*#\d+\s*$/.test(d.textContent) && d.children.length === 0);
    if (!el) return null;
    const first = el.textContent.trim().split(/\s+/)[0].replace(/[^\p{L}'-]/gu, '');
    return first || null;
  }
  function updateLedName() {
    let name = readAgentFirstName();
    try {
      if (name) { if (GM_getValue(AGENT_NAME_KEY, '') !== name) GM_setValue(AGENT_NAME_KEY, name); } else name = GM_getValue(AGENT_NAME_KEY, '');
    } catch (e) { /* ignore */ }
    const led = iaWidget && iaWidget.querySelector('.ia-led');
    // The signed-in agent's own first name, e.g. "Hi Elena!".
    if (name && (name === name.toUpperCase() || name === name.toLowerCase())) name = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
    const text = name ? 'Hi ' + name + '!' : 'Hi there!';
    if (led && led.textContent !== text) {
      led.textContent = text;
      led.removeAttribute('textLength');
      led.removeAttribute('lengthAdjust');
      let w = 0;
      try { w = led.getComputedTextLength(); } catch (e) { w = 0; }
      if (w > 51 || (!w && text.length > 11)) { led.setAttribute('textLength', '51'); led.setAttribute('lengthAdjust', 'spacingAndGlyphs'); }
    }
  }
  setInterval(updateLedName, 3000);

  function ensureBmo() {
    if (iaWidget && document.body.contains(iaWidget)) return iaWidget;
    iaWidget = document.createElement('div');
    iaWidget.className = 'ia-widget ia-mode-' + iaMode();
    setTimeout(updateLedName, 0);
    iaWidget.innerHTML = `
      <div class="ia-levelup" aria-hidden="true">
        <div class="ia-levelup__text">Round 1 complete \u00B7 Round 2 unlocked</div>
      </div>
      <div class="ia-reminder" style="display:none;">
        <div class="ia-reminder__text"></div>
        <button type="button" class="ia-reminder__dismiss">&times;</button>
      </div>
      <div class="ia-bubble" title="Open TBC Assistant">
        <div class="ia-mini"><svg class="pip" viewBox="10 10 76 80" width="50" height="53" overflow="visible" aria-hidden="true"><path class="pip-body" d="M22 70 L22 38 Q22 26 34 26 L62 26 Q74 26 74 38 L74 62 Q74 74 62 74 L40 74 L30 84 L31 74 Q22 73 22 70 Z"/><path class="pip-hs-arc" d="M18 50 Q18 14 48 14 Q78 14 78 50"/><rect class="pip-hs" x="14" y="44" width="8" height="14" rx="3"/><rect class="pip-hs" x="74" y="44" width="8" height="14" rx="3"/><g class="pip-f pip-f-idle"><circle class="pip-eye" cx="40" cy="47" r="3.8"/><circle class="pip-eye" cx="56" cy="47" r="3.8"/><path class="pip-line" d="M41 57 Q48 63 55 57"/></g><g class="pip-f pip-f-call"><path class="pip-mic" d="M18 56 Q20 68 34 66"/><circle class="pip-hs" cx="35" cy="66" r="2.6"/><path class="pip-line" d="M37 47 Q40 44 43 47"/><path class="pip-line" d="M53 47 Q56 44 59 47"/><ellipse class="pip-eye" cx="48" cy="59" rx="5" ry="4"/><path class="pip-wave" d="M84 34 Q88 40 84 46 M88 30 Q95 40 88 50"/></g></svg><span class="ia-dot ia-mini__dot"></span></div>
      </div>
      <div class="ia-full ia-panel">
        <div class="ia-head">
          <svg class="pip" viewBox="10 10 76 80" width="30" height="32" overflow="visible" aria-hidden="true"><path class="pip-body" d="M22 70 L22 38 Q22 26 34 26 L62 26 Q74 26 74 38 L74 62 Q74 74 62 74 L40 74 L30 84 L31 74 Q22 73 22 70 Z"/><path class="pip-hs-arc" d="M18 50 Q18 14 48 14 Q78 14 78 50"/><rect class="pip-hs" x="14" y="44" width="8" height="14" rx="3"/><rect class="pip-hs" x="74" y="44" width="8" height="14" rx="3"/><g class="pip-f pip-f-idle"><circle class="pip-eye" cx="40" cy="47" r="3.8"/><circle class="pip-eye" cx="56" cy="47" r="3.8"/><path class="pip-line" d="M41 57 Q48 63 55 57"/></g><g class="pip-f pip-f-call"><path class="pip-mic" d="M18 56 Q20 68 34 66"/><circle class="pip-hs" cx="35" cy="66" r="2.6"/><path class="pip-line" d="M37 47 Q40 44 43 47"/><path class="pip-line" d="M53 47 Q56 44 59 47"/><ellipse class="pip-eye" cx="48" cy="59" rx="5" ry="4"/><path class="pip-wave" d="M84 34 Q88 40 84 46 M88 30 Q95 40 88 50"/></g></svg>
          <div class="ia-head__txt">
            <div class="ia-head__title">TBC Assistant</div>
            <div class="ia-hs ia-head__greet" data-k="S"><span class="ia-led"></span></div>
          </div>
          <span class="ia-dot" title="Status"></span>
          <span class="ia-btn ia-iconbtn ia-cb-btn" title="Callbacks"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M5 4 2.5 6.5M19 4l2.5 2.5"/></svg><span class="ia-cb-badge" hidden></span></span>
          <span class="ia-btn ia-iconbtn ia-mode-btn" title="Change look"><svg class="ia-ico ia-ico-dark" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 13.2A8.5 8.5 0 1 1 10.8 3.5a6.6 6.6 0 0 0 9.7 9.7z"/></svg><svg class="ia-ico ia-ico-light" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/></svg><svg class="ia-ico ia-ico-navy" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 8.5c3-3 6 3 9 0s6 3 9 0M3 15.5c3-3 6 3 9 0s6 3 9 0"/></svg></span>
          <span class="ia-btn ia-btn-theme ia-iconbtn" title="Change accent color"><span class="ia-swatch"></span></span>
          <span class="ia-iconbtn ia-min" title="Minimize">\u2013</span>
        </div>
        <div class="ia-card">
          <div class="ia-face ia-idle">
            <span class="ia-idle__icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12h4l3-8 4 16 3-8h4"/></svg></span>
            <div class="ia-idle__t">Ready</div>
            <div class="ia-idle__s">Press Call to start your follow-up</div>
          </div>
          <div class="ia-screen-info" style="display:none;">
            <span class="ia-btn ia-iconbtn ia-cb-card" title="Set a callback for this lead"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M5 4 2.5 6.5M19 4l2.5 2.5"/></svg></span>
            <div class="ia-screen-info__label"></div>
            <a class="ia-screen-info__client" target="_blank" rel="noopener"></a>
            <div class="ia-screen-info__route"></div>
            <div class="ia-card-foot"><div class="ia-screen-info__status"></div><div class="ia-progress"></div></div>
          </div>
        </div>
        <div class="ia-stats" title="Today, since 2pm GMT">
          <span><b data-stat="calls">0</b> calls</span>
          <span><b data-stat="answered" class="ia-stat-ok">0</b> answered</span>
          <span><b data-stat="skipped" class="ia-stat-skip">0</b> skipped</span>
          <span class="ia-stat-round">Round <b data-stat="round">1</b></span>
        </div>
        <button type="button" class="ia-btn ia-btn-call ia-call"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg><span>Call</span></button>
        <div class="ia-row">
          <button type="button" class="ia-btn ia-btn-skip ia-sec" title="Skip this lead"><svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6 6l8.5 6L6 18zM16 6h2v12h-2z"/></svg><span>Skip</span></button>
          <button type="button" class="ia-btn ia-btn-doubledial ia-sec" title="Redial the last number"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/></svg><span>Redial</span></button>
          <button type="button" class="ia-btn ia-btn-stop ia-stop" title="Stop"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="5" y="5" width="14" height="14" rx="2.5"/></svg><span>Stop</span></button>
        </div>
        <div class="ia-toggles">
          <div class="ia-hs ia-dd-toggle ia-toggle ia-toggle--dd" data-k="D" title="Redial each unanswered lead once automatically">
            <span>Double-dial</span><span class="ia-switch"><span></span></span>
          </div>
        </div>
        <div class="ia-hs ia-foot" data-k="P">\u00A9 TBC Assistant</div>
      </div>
    `;
    document.body.appendChild(iaWidget);

    // Suppressed after a genuine drag (see initDrag) so releasing
    // the mouse after moving him doesn't also fire this as a click and
    // immediately maximize him.
    iaWidget.querySelector('.ia-bubble').addEventListener('click', () => {
      if (iaWasDragged) return;
      if (!iaMaximized) maximizeBmo();
    });
    iaWidget.querySelector('.ia-btn-call').addEventListener('click', (e) => { e.stopPropagation(); handleCallClick(); });
    iaWidget.querySelector('.ia-btn-skip').addEventListener('click', (e) => { e.stopPropagation(); handleSkipClick(); });
    iaWidget.querySelector('.ia-btn-doubledial').addEventListener('click', (e) => { e.stopPropagation(); handleDoubleDialClick(); });
    iaWidget.querySelector('.ia-btn-stop').addEventListener('click', (e) => { e.stopPropagation(); handleStopClick(); });
    iaWidget.querySelector('.ia-btn-theme').addEventListener('click', (e) => { e.stopPropagation(); toggleTheme(); });
    iaWidget.querySelector('.ia-reminder__dismiss').addEventListener('click', (e) => { e.stopPropagation(); dismissReminder(); });
    iaWidget.querySelector('.ia-cb-btn').addEventListener('click', (e) => { e.stopPropagation(); if (iaWasDragged) return; cbOpenList(e.currentTarget); });
    iaWidget.querySelector('.ia-cb-card').addEventListener('click', (e) => { e.stopPropagation(); if (iaWasDragged) return; cbOpenPicker(e.currentTarget, cbPanelLeadInfo()); });
    // Minimizes on a click anywhere on Pip himself EXCEPT the four
    // buttons — scoped to just his own element now, not the whole page,
    // so clicking elsewhere (the leads table, etc.) no longer closes him.
    iaWidget.querySelector('.ia-full').addEventListener('click', (e) => {
      if (iaWasDragged) return; // releasing a drag isn't a "click to minimize"
      if (e.target.closest && e.target.closest('.ia-btn')) return;
      minimizeBmo();
    });
    iaWidget.querySelectorAll('.ia-hs').forEach((el) => {
      el.addEventListener('click', (e) => {
        e.stopPropagation(); // a tap here shouldn't also minimize him
        if (iaWasDragged || !iaMaximized) return;
        if (el.getAttribute('data-k') === 'D') toggleDoubleDialMode();
        registerGoldTap(el.getAttribute('data-k'));
      });
    });
    applyTheme(getStoredTheme());
    applySuperState();
    applyDoubleDialState();
    updateTodayStats();
    setInterval(updateTodayStats, 30000); // picks up the 2pm GMT reset and other tabs
    const modeBtn = iaWidget.querySelector('.ia-mode-btn');
    if (modeBtn) modeBtn.addEventListener('click', (e) => { e.stopPropagation(); cycleMode(); });
    applyMode();
    try { GM_addValueChangeListener('ia-mode', () => applyMode()); } catch (e) { /* ignore */ }
    applyStoredPosition();
    initDrag();

    return iaWidget;
  }

  // --- Dragging Pip — minimized bubble OR maximized body — with a floaty
  // "air resistance" trail ---------------------------------------------
  // Rendered position eases toward the cursor each frame (lerp) so he
  // trails behind, and leans opposite that lag. When maximized, his whole
  // body is a drag handle except the buttons and the client link; a plain
  // click (no movement) still minimizes as before.
  const POSITION_STORAGE_KEY = 'bmo-position';
  const PANEL_W = 280;
  const PANEL_H = 331;
  const BUBBLE_W = 96;
  const BUBBLE_H = 76;
  let iaWasDragged = false;
  let dragState = null;

  // --- "Shaken viciously" -> dead face --------------------------------
  // Tracked off the same eased position dragTick already renders every
  // frame (not raw mousemove events), so it reflects actual on-screen
  // back-and-forth motion rather than raw, possibly-jittery input.
  // Counts rapid left-right direction reversals; enough of them close
  // together (a real shake) flips Pip to a dead face for 2 seconds,
  // whether he's currently maximized or minimized.
  let shakeLastX = null;
  let shakeLastDirSign = null;
  let shakeReversalCount = 0;
  let shakeWindowStart = 0;
  let deadFaceTimer = null;
  const SHAKE_MIN_STEP = 3; // px per frame — ignores sub-pixel jitter
  const SHAKE_WINDOW_MS = 900; // reversals must land within this span
  const SHAKE_REVERSALS_NEEDED = 5;

  function resetShakeTracking() {
    shakeLastX = null;
    shakeLastDirSign = null;
    shakeReversalCount = 0;
    shakeWindowStart = 0;
  }

  function triggerDeadFace() {
    if (!iaWidget) return;
    iaWidget.classList.add('ia-widget--dead');
    if (deadFaceTimer) clearTimeout(deadFaceTimer);
    deadFaceTimer = setTimeout(() => {
      if (iaWidget) iaWidget.classList.remove('ia-widget--dead');
      deadFaceTimer = null;
    }, 2000);
  }

  function trackShake(x) {
    if (shakeLastX == null) { shakeLastX = x; return; }
    const step = x - shakeLastX;
    shakeLastX = x;
    if (Math.abs(step) < SHAKE_MIN_STEP) return;
    const sign = step > 0 ? 1 : -1;
    if (shakeLastDirSign != null && sign !== shakeLastDirSign) {
      const now = Date.now();
      if (!shakeWindowStart || now - shakeWindowStart > SHAKE_WINDOW_MS) {
        shakeWindowStart = now;
        shakeReversalCount = 0;
      }
      shakeReversalCount++;
      if (shakeReversalCount >= SHAKE_REVERSALS_NEEDED) {
        triggerDeadFace();
        shakeReversalCount = 0;
        shakeWindowStart = 0;
      }
    }
    shakeLastDirSign = sign;
  }

  function getStoredPosition() {
    try {
      const raw = GM_getValue(POSITION_STORAGE_KEY, null);
      const parsed = raw ? JSON.parse(raw) : null;
      if (parsed && typeof parsed.x === 'number' && typeof parsed.y === 'number') return parsed;
    } catch (e) { /* ignore */ }
    return null;
  }

  function isShowingFull() {
    return iaMaximized || (iaWidget && iaWidget.classList.contains('ia-widget--peeking'));
  }

  // The widget box is always 280x331, but when minimized only the bubble
  // in its bottom-right corner is visible. Clamping the whole box kept the
  // bubble from ever reaching the top/left screen edges, so clamp to
  // whatever is actually showing instead.
  function clampToViewport(x, y) {
    const full = isShowingFull();
    const minX = full ? 0 : -(PANEL_W - BUBBLE_W);
    const minY = full ? 0 : -(PANEL_H - BUBBLE_H);
    const maxX = Math.max(minX, window.innerWidth - PANEL_W);
    const maxY = Math.max(minY, window.innerHeight - PANEL_H);
    return { x: Math.min(Math.max(minX, x), maxX), y: Math.min(Math.max(minY, y), maxY) };
  }

  function applyStoredPosition() {
    const pos = getStoredPosition();
    if (!pos || !iaWidget) return;
    const clamped = clampToViewport(pos.x, pos.y);
    iaWidget.style.left = clamped.x + 'px';
    iaWidget.style.top = clamped.y + 'px';
    iaWidget.style.right = 'auto';
    iaWidget.style.bottom = 'auto';
  }

  // Opening him from a bubble parked near the top/left edge would spill
  // the full body off-screen — slide him back in.
  function reclampToViewport(animate) {
    if (!iaWidget || !iaWidget.style.left || dragState) return; // default corner is always on-screen
    const x = parseFloat(iaWidget.style.left);
    const y = parseFloat(iaWidget.style.top);
    const c = clampToViewport(x, y);
    if (c.x === x && c.y === y) return;
    if (animate) {
      iaWidget.style.transition = 'left .35s cubic-bezier(.34,1.56,.64,1), top .35s cubic-bezier(.34,1.56,.64,1)';
      setTimeout(() => { if (iaWidget && !dragState) iaWidget.style.transition = ''; }, 400);
    }
    iaWidget.style.left = c.x + 'px';
    iaWidget.style.top = c.y + 'px';
  }

  window.addEventListener('resize', () => reclampToViewport(false));

  function isDragHandle(target) {
    if (!target || !target.closest) return false;
    if (target.closest('.ia-btn, .ia-screen-info__client, .ia-reminder, .ia-cbdue')) return false;
    if (target.closest('.ia-bubble')) return !iaMaximized;
    if (target.closest('.ia-full')) return iaMaximized;
    return false;
  }

  function initDrag() {
    iaWidget.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return; // left button only
      if (!isDragHandle(e.target)) return;
      e.preventDefault();

      // Re-grabbing mid-settle: stop the old ease loop and pick up from
      // where he currently is.
      if (dragState && dragState.animFrame) cancelAnimationFrame(dragState.animFrame);

      let left, top;
      if (iaWidget.style.left) {
        left = parseFloat(iaWidget.style.left);
        top = parseFloat(iaWidget.style.top);
      } else {
        const rect = iaWidget.getBoundingClientRect();
        left = rect.left;
        top = rect.top;
      }
      // Switch from right/bottom anchoring to left/top on first grab.
      iaWidget.style.left = left + 'px';
      iaWidget.style.top = top + 'px';
      iaWidget.style.right = 'auto';
      iaWidget.style.bottom = 'auto';
      iaWidget.style.transition = 'none';

      const grabOffsetX = e.clientX - left;
      const grabOffsetY = e.clientY - top;
      // Tilt pivots around the point actually being held, so dragging the
      // big maximized body leans naturally instead of swinging around a
      // fixed spot near the bubble.
      iaWidget.style.transformOrigin = grabOffsetX + 'px ' + grabOffsetY + 'px';
      iaWidget.classList.add('ia-widget--dragging');
      resetShakeTracking();

      preOpenPos = null; // moved by hand: stay where dropped
      dragState = {
        startClientX: e.clientX,
        startClientY: e.clientY,
        grabOffsetX,
        grabOffsetY,
        targetX: left,
        targetY: top,
        currentX: left,
        currentY: top,
        moved: false,
      };
      document.addEventListener('mousemove', onDragMove);
      document.addEventListener('mouseup', onDragEnd);
    });
  }

  // --- Easter egg: slam Pip into a screen edge fast and his screen cracks
  // for a moment. Measures how fast the mouse is moving at the instant he
  // first hits the edge (rather than sliding along it).
  const CRACK_SPEED_PX_PER_MS = 3;
  const CRACK_SHOW_MS = 2600;
  let crackTimer = null;
  let lastCrackAt = 0;

  function triggerCrack() {
    if (!iaWidget || Date.now() - lastCrackAt < 4000) return;
    lastCrackAt = Date.now();
    iaWidget.classList.remove('ia-widget--cracked');
    void iaWidget.offsetWidth;
    iaWidget.classList.add('ia-widget--cracked');
    if (crackTimer) clearTimeout(crackTimer);
    crackTimer = setTimeout(() => { if (iaWidget) iaWidget.classList.remove('ia-widget--cracked'); }, CRACK_SHOW_MS);
  }

  function onDragMove(e) {
    if (!dragState) return;
    const totalDx = e.clientX - dragState.startClientX;
    const totalDy = e.clientY - dragState.startClientY;
    if (Math.abs(totalDx) > 4 || Math.abs(totalDy) > 4) dragState.moved = true;

    const now = performance.now();
    if (dragState.lastMoveT) {
      const dt = Math.max(1, now - dragState.lastMoveT);
      const speed = Math.hypot(e.clientX - dragState.lastMoveX, e.clientY - dragState.lastMoveY) / dt;
      dragState.speed = dragState.speed ? dragState.speed * 0.5 + speed * 0.5 : speed;
    }
    dragState.lastMoveT = now;
    dragState.lastMoveX = e.clientX;
    dragState.lastMoveY = e.clientY;

    const rawX = e.clientX - dragState.grabOffsetX;
    const rawY = e.clientY - dragState.grabOffsetY;
    const clampedNow = clampToViewport(rawX, rawY);
    const atEdge = clampedNow.x !== rawX || clampedNow.y !== rawY;
    if (atEdge && !dragState.wasAtEdge && (dragState.speed || 0) > CRACK_SPEED_PX_PER_MS) triggerCrack();
    dragState.wasAtEdge = atEdge;

    const clamped = clampedNow;
    dragState.targetX = clamped.x;
    dragState.targetY = clamped.y;
    if (!dragState.animFrame) dragState.animFrame = requestAnimationFrame(dragTick);
  }

  function dragTick() {
    if (!dragState) return;
    dragState.animFrame = null;
    const dx = dragState.targetX - dragState.currentX;
    const dy = dragState.targetY - dragState.currentY;
    dragState.currentX += dx * 0.22;
    dragState.currentY += dy * 0.22;

    iaWidget.style.left = dragState.currentX + 'px';
    iaWidget.style.top = dragState.currentY + 'px';

    // Leans INTO the direction of travel -- dragging right leans
    // clockwise, dragging left leans counter-clockwise (CSS rotate()'s
    // positive direction is clockwise on screen). dx here is how far
    // ahead the target is of the eased/rendered position -- i.e. the
    // direction and rough magnitude of the current motion -- so no sign
    // flip is needed, unlike the old "trail behind" lean this replaced.
    const tilt = Math.max(-18, Math.min(18, dx * 0.7));
    iaWidget.style.transform = 'rotate(' + tilt.toFixed(2) + 'deg)';

    trackShake(dragState.currentX);

    if (Math.abs(dx) > 0.4 || Math.abs(dy) > 0.4) {
      dragState.animFrame = requestAnimationFrame(dragTick);
    } else if (dragState.settling) {
      finishDragSettle();
    }
  }

  function finishDragSettle() {
    iaWidget.style.left = dragState.targetX + 'px';
    iaWidget.style.top = dragState.targetY + 'px';
    iaWidget.style.transition = 'transform .4s ease';
    iaWidget.style.transform = 'rotate(0deg)';
    try { GM_setValue(POSITION_STORAGE_KEY, JSON.stringify({ x: dragState.targetX, y: dragState.targetY })); } catch (e) { /* best-effort */ }
    dragState = null;
    setTimeout(() => {
      if (!iaWidget || dragState) return; // a new drag already started — leave its settings alone
      iaWidget.style.transition = '';
      iaWidget.style.transformOrigin = '';
    }, 400);
  }

  function onDragEnd() {
    document.removeEventListener('mousemove', onDragMove);
    document.removeEventListener('mouseup', onDragEnd);
    if (!dragState) return;
    iaWidget.classList.remove('ia-widget--dragging');
    // Swallow only the click that immediately follows this mouseup. The
    // reset is deferred so a release outside Pip (where no click fires)
    // can't leave the flag stuck and eat the next real click.
    iaWasDragged = dragState.moved;
    setTimeout(() => { iaWasDragged = false; }, 0);
    dragState.settling = true;
    if (!dragState.animFrame) finishDragSettle();
  }

  // The left of the two decorative pill buttons doubles as a skin-color
  // toggle now — everything themeable (body, screen, arms, speaker, both
  // pills, screen text) reads its color from a CSS custom property, so
  // applying a theme class here fades the whole character between
  // palettes via CSS transition rather than needing a JS-driven
  // animation. Cycles through all three rather than just flipping
  // between two.
  const THEME_STORAGE_KEY = 'bmo-theme';
  const THEME_CYCLE = ['midnight', 'teal', 'pink', 'black'];

  // All skins (incl. gold + rainbow) are unlocked in TBC Assistant.
  const isOwner = true;

  function themeCycle() {
    return isOwner ? THEME_CYCLE.concat('gold', 'rainbow') : THEME_CYCLE;
  }

  function checkOwner() { /* no owner check in TBC Assistant */ }

  // Regular users only ever have the three normal colors saved/cycled;
  // gold and rainbow are never saved for them, so they never come back on
  // their own after a reload.
  function getStoredTheme() {
    let t;
    try { t = GM_getValue(THEME_STORAGE_KEY, 'midnight'); } catch (e) { t = 'midnight'; }
    return themeCycle().includes(t) ? t : 'midnight';
  }

  let rainbowTheme = false; // rainbow picked as the skin (owner) or via the secret combo
  function applyTheme(name) {
    if (!iaWidget) return;
    iaWidget.classList.remove('ia-widget--midnight', 'ia-widget--pink', 'ia-widget--black', 'ia-widget--gold');
    if (name === 'midnight') iaWidget.classList.add('ia-widget--midnight');
    else if (name === 'pink') iaWidget.classList.add('ia-widget--pink');
    else if (name === 'black') iaWidget.classList.add('ia-widget--black');
    else if (name === 'gold') iaWidget.classList.add('ia-widget--gold');
    // 'teal' is the unmarked default -- no class needed for it. Rainbow
    // sits on top of the teal base.
    rainbowTheme = name === 'rainbow';
    if (typeof applySuperState === 'function') applySuperState();
  }

  function getCurrentTheme() {
    if (!iaWidget) return 'teal';
    if (rainbowTheme) return 'rainbow';
    if (iaWidget.classList.contains('ia-widget--midnight')) return 'midnight';
    if (iaWidget.classList.contains('ia-widget--pink')) return 'pink';
    if (iaWidget.classList.contains('ia-widget--black')) return 'black';
    if (iaWidget.classList.contains('ia-widget--gold')) return 'gold';
    return 'teal';
  }

  function toggleTheme() {
    if (!iaWidget) return;
    // Super Pip earned today: the rainbow is locked in until the 2pm GMT
    // reset. The color button just gives a little "locked" wiggle.
    if (superLocked()) { showLockedWiggle(); return; }
    const cycle = themeCycle();
    const current = getCurrentTheme();
    // A secret skin entered by combo (not part of this user's cycle) just
    // drops back to the regular saved color.
    if (!cycle.includes(current)) { applyTheme(getStoredTheme()); return; }
    const next = cycle[(cycle.indexOf(current) + 1) % cycle.length];
    applyTheme(next);
    try { GM_setValue(THEME_STORAGE_KEY, next); } catch (e) { /* best-effort */ }
  }

  // Colors are never locked any more: Super Pip only takes over while
  // he's actively calling, and your own color comes back when stopped.
  function superLocked() {
    return false;
  }

  function showLockedWiggle() {
    const pill = iaWidget && iaWidget.querySelector('.ia-btn-theme');
    if (!pill) return;
    pill.classList.remove('ia-locked-wiggle');
    void pill.getBBox();
    pill.classList.add('ia-locked-wiggle');
  }

  // --- "Level up" celebration --------------------------------------------
  let levelUpTimer = null;
  function playLevelUp(withSubtitle) {
    const el = ensureBmo();
    const wasMaximized = iaMaximized;
    // If he's minimized, briefly show the full Pip so the moment is seen.
    if (!wasMaximized) el.classList.add('ia-widget--peeking');
    el.classList.toggle('ia-widget--levelup-sub', !!withSubtitle);
    el.classList.remove('ia-widget--levelup');
    void el.offsetWidth;
    el.classList.add('ia-widget--levelup');
    triggerWave();
    if (levelUpTimer) clearTimeout(levelUpTimer);
    levelUpTimer = setTimeout(() => {
      el.classList.remove('ia-widget--levelup');
      if (!wasMaximized && !iaMaximized) el.classList.remove('ia-widget--peeking');
    }, 2600);
  }

  // --- Secret gold skin ------------------------------------------------
  // Shown only when three of Pip's plain, decorative body parts are
  // tapped in one exact order while he's open. Only a salted SHA-256 hash
  // of that order lives in this file, never the order itself, so reading
  // the source doesn't reveal it. Taps more than 1.5s apart restart the
  // attempt, and a wrong attempt shows nothing. Entering the combo again
  // while gold turns it back off.
  const GOLD_HASH = '6c766247760cab576302d8288cf9a7b6fae65b63e27a612deaa12c8b6c7f9462';
  // Second secret combo (same taps, different order): rainbow skin.
  const RAINBOW_HASH = '9aac100df7916bdeb49a9a19766cd754ab1125401ef647ccc9b8406b9884e73e';
  const GOLD_SEQ_LEN = 8;
  let goldTaps = '';
  let goldLastTap = 0;

  async function sha256Hex(text) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  async function registerGoldTap(k) {
    const now = Date.now();
    if (now - goldLastTap > 1500) goldTaps = '';
    goldLastTap = now;
    goldTaps = (goldTaps + k).slice(-GOLD_SEQ_LEN);
    if (goldTaps.length < GOLD_SEQ_LEN) return;
    let h, hr;
    try {
      h = await sha256Hex('ia-gold:' + goldTaps);
      hr = await sha256Hex('ia-rainbow:' + goldTaps);
    } catch (e) { return; }
    if ((hr === RAINBOW_HASH || h === GOLD_HASH) && superLocked()) { goldTaps = ''; showLockedWiggle(); return; }
    if (hr === RAINBOW_HASH) {
      goldTaps = '';
      if (getCurrentTheme() === 'rainbow') { applyTheme(getStoredTheme() === 'rainbow' ? 'teal' : getStoredTheme()); return; }
      applyTheme('rainbow'); // deliberately not saved
      triggerWave();
      return;
    }
    if (h !== GOLD_HASH) return;
    goldTaps = '';
    if (getCurrentTheme() === 'gold') { applyTheme(getStoredTheme() === 'gold' ? 'teal' : getStoredTheme()); return; }
    applyTheme('gold'); // deliberately not saved
    iaWidget.classList.add('ia-widget--gold-unlock');
    setTimeout(() => iaWidget && iaWidget.classList.remove('ia-widget--gold-unlock'), 1600);
    triggerWave();
  }

  function triggerWave() {
    if (!iaWidget) return;
    ['.ia-arm-left', '.ia-arm-right'].forEach((sel) => {
      const arm = iaWidget.querySelector(sel);
      if (!arm) return;
      arm.classList.remove('ia-waving');
      void arm.getBBox && arm.getBBox(); // restart the CSS animation (SVG-safe reflow trigger)
      arm.classList.add('ia-waving');
    });
  }

  // Used when Pip is currently minimized and the hourly reminder becomes
  // due — briefly shows the full character just long enough to fade the
  // arms in, wave, and fade them out again, then returns to the
  // minimized bubble. Deliberately non-interactive (see the
  // .ia-widget--peeking CSS) and never touches iaMaximized, so this is
  // purely a visual nudge, not Pip actually opening.
  let peekTimeout = null;
  function peekAndWave() {
    const el = ensureBmo();
    if (iaMaximized) { triggerWave(); return; }
    el.classList.add('ia-widget--peeking');
    reclampToViewport(true);
    triggerWave();
    if (peekTimeout) clearTimeout(peekTimeout);
    peekTimeout = setTimeout(() => {
      if (!iaMaximized) el.classList.remove('ia-widget--peeking');
    }, 2300); // just past the 2.2s wave animation, so the peek doesn't cut off mid-wave
  }

  // Where the bubble sat before opening — if opening had to slide Pip
  // into view, minimizing glides him back there in the same motion
  // (instead of shrinking first and jumping afterwards).
  let preOpenPos = null;
  async function maximizeBmo() {
    iaMaximized = true;
    const el = ensureBmo();
    preOpenPos = el.style.left ? { left: el.style.left, top: el.style.top } : null;
    el.classList.add('ia-widget--maximized');
    reclampToViewport(true);
    triggerWave();
    if (!dialerInitialized) {
      dialerInitialized = true;
      updateAllRowIndicators();
      // Labeled "Up next", not "Currently calling" -- nobody has been
      // dialed yet at this point, and the label needs to say so.
      renderPanelForRow(await getNextPendingRow(), false);
    }
  }

  function minimizeBmo() {
    iaMaximized = false;
    if (!iaWidget) return;
    const back = preOpenPos;
    preOpenPos = null;
    if (back && !dragState && (iaWidget.style.left !== back.left || iaWidget.style.top !== back.top)) {
      iaWidget.style.transition = 'left .35s cubic-bezier(.34,1.56,.64,1), top .35s cubic-bezier(.34,1.56,.64,1)';
      iaWidget.style.left = back.left;
      iaWidget.style.top = back.top;
      setTimeout(() => { if (iaWidget && !dragState) iaWidget.style.transition = ''; }, 400);
    }
    iaWidget.classList.remove('ia-widget--maximized');
  }

  // First press while Pip is running: stop, and clearly show it stopped
  // (Pip stays open). A press when he's not running minimizes him.
  function handleStopClick() {
    if (isAutoActive()) {
      stopAutoRun();
      showStopped();
      return;
    }
    minimizeBmo();
  }

  function isAutoActive() {
    return autoRunning || awaitingCallEnd || !!autoNextTimer || pendingAutoNext;
  }

  function showStopped() {
    const el = ensureBmo();
    if (!currentPanelRow) {
      el.querySelector('.ia-face').style.display = 'none';
      el.querySelector('.ia-screen-info').style.display = '';
      el.querySelector('.ia-screen-info__label').textContent = 'Auto-dial';
      const clientEl = el.querySelector('.ia-screen-info__client');
      clientEl.textContent = 'Stopped';
      clientEl.removeAttribute('href');
      el.querySelector('.ia-screen-info__route').textContent = '';
    }
    setPanelStatus('\u25A0 Stopped \u2014 press Stop again to close');
    el.classList.remove('ia-widget--stop-flash');
    void el.offsetWidth;
    el.classList.add('ia-widget--stop-flash');
  }

  // ==========================================================================
  // RingCentral Embeddable — call-status watcher for the auto-dialer
  // ==========================================================================
  // Pip still dials the normal way (tel: links -> your RingCentral app). The
  // RingCentral panel is used ONLY to watch call status: it reports every
  // active call on your RingCentral account, on any device, so Pip can tell
  // when a call ends. Once you press Call, Pip stays "running" — every time
  // a call ends he waits a few seconds, then dials the next lead by himself
  // — until you press Stop.
  //
  // Chrome may refuse a tel: link that isn't triggered by a real click. If
  // no call shows up within a few seconds of an automatic dial, Pip assumes
  // Chrome blocked it and waits for you to press Call for that one lead.
  // Root cause of calls only working while signed into the widget:
  // RingCentral's adapter.js script runs INSIDE the BO page and takes over
  // tel: phone links there — signed out, it swallowed them, so neither the
  // BO's own phone links nor Pip's reached the Windows app. So adapter.js
  // is no longer used at all. The RingCentral phone is loaded as a plain
  // iframe instead: it lives in its own sealed-off box, can't touch anything
  // on the BO page, and still reports call status to Pip.
  const RC_APP_URL = 'https://apps.ringcentral.com/integration/ringcentral-embeddable/latest/app.html';
  const AUTO_NEXT_DELAY_SEC = 4;
  const CALL_APPEAR_TIMEOUT_MS = 12000;
  const pageWin = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

  let autoRunning = false;      // set by pressing Call, cleared by Stop
  let awaitingCallEnd = false;  // Pip dialed and is watching for that call
  let callSeen = false;         // RingCentral has reported that call as live
  let callAppearTimer = null;
  let autoNextTimer = null;
  let autoNextCountdown = null;
  let pendingAutoNext = false;  // next dial is waiting for your own call to end
  let iaCallDigits = null;     // number Pip is currently calling (last 10 digits)
  let iaCallConnectedAt = 0;   // when Pip's current call connected (0 = never)
  // A follow-up call that's been going (ringing or connected) for 3:30 means
  // someone's on the line who needs help: the run stops, mid-call.
  const LONG_CALL_SEC = 210;
  let longCallTimer = null;
  function clearLongCall() { if (longCallTimer) { clearTimeout(longCallTimer); longCallTimer = null; } }
  function armLongCall() {
    if (longCallTimer || !autoRunning) return;
    longCallTimer = setTimeout(() => {
      longCallTimer = null;
      if (!autoRunning || !awaitingCallEnd || !callSeen) return;
      stopAutoRun();
      setPanelStatus('Long call \u2014 follow-up stopped');
      playLongCallPop();
    }, LONG_CALL_SEC * 1000);
  }
  // Two soft rising "pops", made on the spot (no sound file).
  function playLongCallPop() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const ctx = playLongCallPop.ctx || (playLongCallPop.ctx = new AC());
      if (ctx.state === 'suspended') ctx.resume();
      const t0 = ctx.currentTime + 0.02;
      [[0, 500, 1100], [0.12, 650, 1400]].forEach(([at, f0, f1]) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(f0, t0 + at);
        o.frequency.linearRampToValueAtTime(f1, t0 + at + 0.09);
        g.gain.setValueAtTime(0.0001, t0 + at);
        g.gain.exponentialRampToValueAtTime(0.22, t0 + at + 0.004);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + 0.12);
        o.connect(g); g.connect(ctx.destination);
        o.start(t0 + at); o.stop(t0 + at + 0.14);
      });
    } catch (e) { /* no sound is fine */ }
  }
  let leadRedialed = false;     // double-dial: this lead already got its 2nd call
  // Every live call RingCentral reports on your account: key -> { mine, seen }
  const activeCalls = new Map();
  const DOUBLE_DIAL_KEY = 'bmo-double-dial';
  const DOUBLE_DIAL_DELAY_SEC = 3;
  const ANSWERED_AFTER_SEC = 60; // connected longer than this = someone answered

  function digitsOf(n) { return String(n || '').replace(/\D/g, '').slice(-10); }

  function doubleDialOn() {
    try { return !!GM_getValue(DOUBLE_DIAL_KEY, false); } catch (e) { return false; }
  }
  function applyDoubleDialState() {
    if (iaWidget) iaWidget.classList.toggle('ia-widget--dd-on', doubleDialOn());
  }
  function toggleDoubleDialMode() {
    try { GM_setValue(DOUBLE_DIAL_KEY, !doubleDialOn()); } catch (e) { /* best-effort */ }
    applyDoubleDialState();
  }

  // --- Look: Nova / Nova Night / Dark / Light / Navy ------------------------
  function applyMode() {
    if (!iaWidget) return;
    const m = iaMode();
    Object.keys(IA_MODES).forEach((x) => iaWidget.classList.toggle('ia-mode-' + x, x === m));
    iaWidget.classList.toggle('ia-nova', iaIsNova(m));
    iaCalmClass();
    const menu = iaWidget.querySelector('.ia-looks');
    if (menu) menu.querySelectorAll('.ia-look').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.look === m)));
  }
  function setLook(m) {
    try { GM_setValue('ia-mode', m); } catch (e) { /* best-effort */ }
    applyMode();
    try { if (typeof iaPaintSearchColours === 'function') iaPaintSearchColours(); } catch (e) { /* ignore */ }
    try { if (typeof paintCallVars === 'function') paintCallVars(); } catch (e) { /* ignore */ }
  }
  function closeLooks() {
    const menu = iaWidget && iaWidget.querySelector('.ia-looks');
    if (menu) menu.remove();
    document.removeEventListener('mousedown', looksOutside, true);
  }
  function looksOutside(e) {
    const menu = iaWidget && iaWidget.querySelector('.ia-looks');
    if (!menu || menu.contains(e.target) || e.target.closest('.ia-mode-btn')) return;
    closeLooks();
  }
  // The moon button opens a small menu with every look.
  function cycleMode() {
    if (!iaWidget) return;
    if (iaWidget.querySelector('.ia-looks')) { closeLooks(); return; }
    const panel = iaWidget.querySelector('.ia-panel');
    if (!panel) return;
    const menu = document.createElement('div');
    menu.className = 'ia-looks';
    menu.setAttribute('role', 'menu');
    const hd = document.createElement('div');
    hd.className = 'ia-looks__hd';
    hd.textContent = 'Look';
    menu.appendChild(hd);
    IA_LOOKS.forEach(([key, label]) => {
      const pal = IA_MODES[key];
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'ia-look';
      b.dataset.look = key;
      b.setAttribute('role', 'menuitemradio');
      const dots = document.createElement('span');
      dots.className = 'ia-look__dots';
      const accent = pal.acc || (IA_ACCENTS.midnight[['dark', 'light', 'navy'].indexOf(key)] || '#7c7cf8');
      [pal.bg, pal.title, accent].forEach((c) => { const i = document.createElement('i'); i.style.background = c; dots.appendChild(i); });
      const t = document.createElement('span');
      t.textContent = label;
      b.appendChild(dots); b.appendChild(t);
      if (key === 'calm') { const sm = document.createElement('small'); sm.textContent = 'Main'; b.appendChild(sm); }
      b.addEventListener('click', (e) => { e.stopPropagation(); setLook(key); closeLooks(); });
      b.addEventListener('mousedown', (e) => e.stopPropagation());
      menu.appendChild(b);
    });
    menu.addEventListener('mousedown', (e) => e.stopPropagation());
    menu.addEventListener('click', (e) => e.stopPropagation());
    menu.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.stopPropagation(); closeLooks(); } });
    panel.appendChild(menu);
    applyMode();
    const cur = menu.querySelector('[aria-checked="true"]');
    if (cur) try { cur.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
    document.addEventListener('mousedown', looksOutside, true);
  }
  // Pip's face while Pip's own call is live.
  function setOnCall(on) {
    if (iaWidget) iaWidget.classList.toggle('ia-widget--oncall', !!on);
  }
  function manualCallActive() {
    const now = Date.now();
    for (const [k, c] of activeCalls) {
      if (now - c.seen > 4 * 60 * 60 * 1000) { activeCalls.delete(k); continue; } // stale
      if (!c.mine) return true;
    }
    return false;
  }

  function loadRingCentral() {
    if (document.getElementById('ia-rc-panel') || !document.body) return;
    const panel = document.createElement('div');
    panel.id = 'ia-rc-panel';
    const frame = document.createElement('iframe');
    frame.id = 'rc-widget-adapter-frame';
    frame.src = RC_APP_URL;
    frame.setAttribute('allow', 'microphone; autoplay; clipboard-read; clipboard-write');
    panel.appendChild(frame);
    document.body.appendChild(panel);
  }

  function rcContainer() {
    return document.getElementById('ia-rc-panel');
  }

  // --- Where calls go: RingCentral website or Windows app ---------------
  // One saved choice per user, changed from any call icon's right-click
  // menu. Used by the call icons and by Pip's Call / 2X / auto-dial.
  //  - Windows app: the usual tel: link, which opens the RingCentral app.
  //  - Website: the number goes to an open RingCentral tab (SECTION 10), which
  //    dials it from its dialpad right away. With no RingCentral tab open,
  //    RingCentral's own call link opens in a background tab instead.
  const CALL_MODE_KEY = 'ia-call-mode';
  const RC_TABS_KEY = 'ia-rc-tabs';
  const RC_DIAL_KEY = 'ia-rc-dial';
  const RC_ACK_KEY = 'ia-rc-ack';
  function callMode() {
    try { return GM_getValue(CALL_MODE_KEY, 'app') === 'web' ? 'web' : 'app'; } catch (e) { return 'app'; }
  }
  function setCallMode(m) {
    try { GM_setValue(CALL_MODE_KEY, m === 'web' ? 'web' : 'app'); } catch (e) { /* best-effort */ }
  }
  function toE164(n) {
    const d = String(n || '').replace(/\D/g, '');
    if (!d) return '';
    return '+' + (d.length === 10 ? '1' + d : d);
  }
  function rcWebLink(n) {
    return 'https://app.ringcentral.com/redirect?target=/r/call?number=' + n;
  }
  function rcTabs() {
    let all = {};
    try { all = JSON.parse(GM_getValue(RC_TABS_KEY, '{}')) || {}; } catch (e) { all = {}; }
    const now = Date.now();
    return Object.keys(all).map((id) => Object.assign({ id }, all[id])).filter((x) => x && now - x.t < 6000);
  }
  // The RingCentral tab to dial from: the one you used last, a normal tab
  // before a call-link tab.
  function pickRcTab() {
    const tabs = rcTabs().sort((a, b) => (a.helper - b.helper) || (b.focus - a.focus));
    return tabs[0] || null;
  }

  const rcPending = new Map(); // rid -> { got, settle }
  GM_addValueChangeListener(RC_ACK_KEY, (key, oldV, v) => {
    let a;
    try { a = JSON.parse(v); } catch (e) { return; }
    const p = a && rcPending.get(a.rid);
    if (!p) return;
    if (a.stage === 'got') { p.got = true; return; }
    p.settle(a.stage === 'ok');
  });
  function askRcTab(tab, n) {
    return new Promise((resolve) => {
      const rid = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      let finished = false;
      const p = { got: false, settle: (ok) => { if (finished) return; finished = true; rcPending.delete(rid); resolve(ok ? 'ok' : 'fail'); } };
      rcPending.set(rid, p);
      try { GM_setValue(RC_DIAL_KEY, JSON.stringify({ rid, n, to: tab.id, t: Date.now() })); } catch (e) { p.settle(false); return; }
      // No answer at all -> that tab is gone; it answered but never finished
      // -> assume it's dialing (never risk calling the lead twice).
      setTimeout(() => { if (!p.got) p.settle(false); }, 1500);
      setTimeout(() => { if (!finished) { finished = true; rcPending.delete(rid); resolve('busy'); } }, 9000);
    });
  }

  // A tab opened just to run the call link. Closed once the call is up when
  // another RingCentral tab is open (the call carries on there); kept when
  // it's the only one, so it becomes your RingCentral tab.
  let rcHelper = null; // { tab, digits }
  function closeRcHelper() {
    const h = rcHelper;
    rcHelper = null;
    if (h && h.tab && !h.tab.closed) { try { h.tab.close(); } catch (e) { /* ignore */ } }
  }
  function otherRcTabOpen() {
    return rcTabs().some((x) => !x.helper);
  }
  function openRcHelper(n) {
    closeRcHelper();
    let tab = null;
    try { tab = GM_openInTab(rcWebLink(n), { active: false, insert: true, setParent: true }); } catch (e) { tab = null; }
    if (!tab) { window.open(rcWebLink(n), '_blank'); return; }
    const h = { tab, digits: digitsOf(n) };
    rcHelper = h;
    // In case the call never shows up in Pip's call watcher (e.g. it
    // isn't loaded on this page).
    setTimeout(() => { if (rcHelper === h && otherRcTabOpen()) closeRcHelper(); }, 40000);
  }
  // Called from the call watcher with every call RingCentral reports.
  function rcHelperSawCall(digits, live) {
    if (!rcHelper || !digits || digits !== rcHelper.digits) return;
    if (!otherRcTabOpen()) { if (!live) rcHelper = null; return; } // it's your only RingCentral tab now: keep it
    const h = rcHelper;
    setTimeout(() => { if (rcHelper === h) closeRcHelper(); }, live ? 2500 : 0);
  }

  async function webCall(n) {
    const tab = pickRcTab();
    if (tab) {
      const r = await askRcTab(tab, n);
      if (r === 'ok' || r === 'busy') return;
    }
    openRcHelper(n);
  }

  // Places a call to `number` the way the user chose.
  function placeCall(number) {
    if (callMode() === 'web') {
      const n = toE164(number);
      if (n) webCall(n);
      return;
    }
    // Windows app: the same tel: link Pip has always used (it opens in
    // whatever app is set up for phone links, normally RingCentral).
    window.location.href = 'tel:' + number;
  }

  // --- Call icon next to every phone number ------------------------------
  // The BO's own phone icon, after each number on the leads list and on a
  // lead's page. Left click: reveal the number if it's still masked, call
  // it (website or Windows app, as chosen) and mark the lead called. Right
  // click: choose where calls go; saved for this user everywhere.
  const PHONE_ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>';
  // A revealed number in any format the BO shows it in ("+16785550523",
  // "+1 678 555 0523", "(678) 555-0523"…) -> "+16785550523"; masked -> null.
  function revealedNumber(t) {
    t = String(t || '').trim();
    if (!t || t.includes('*') || /[a-z]/i.test(t)) return null;
    const d = t.replace(/\D/g, '');
    if (d.length < 10 || d.length > 15) return null;
    return '+' + (d.length === 10 ? '1' + d : d);
  }
  const isPhoneText = (t) => PHONE_MASKED_RE.test(String(t).replace(/\s+/g, '')) || !!revealedNumber(t);
  // Watches the number's surroundings, not just the box: the BO may swap
  // the box for a new one when it reveals the number.
  function waitForNumber(box, ms) {
    return new Promise((resolve) => {
      const area = box.parentElement || box;
      const check = () => {
        if (box.isConnected) return revealedNumber(box.textContent);
        const b = area.querySelector('div.truncate.cursor-pointer');
        return b ? revealedNumber(b.textContent) : null;
      };
      const now = check();
      if (now) { resolve(now); return; }
      const obs = new MutationObserver(() => { const n = check(); if (n) { obs.disconnect(); resolve(n); } });
      obs.observe(area, { childList: true, characterData: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(check()); }, ms || 2500);
    });
  }
  const onLeadPage = (box) => !box.closest('tr');
  // The number boxes: "truncate cursor-pointer" divs holding a phone number
  // (leads list: in a table cell; lead page: "ml-2 … truncate").
  function phoneBoxFor(el) {
    const box = el && el.closest && el.closest('div.truncate.cursor-pointer');
    return box && isPhoneText(box.textContent.trim()) ? box : null;
  }
  function leadIdForBox(box) {
    const row = box.closest('tr');
    const fromRow = row && getLeadId(row);
    if (fromRow) return fromRow;
    const m = location.pathname.match(/^\/leads\/(\d+)/);
    return m ? m[1] : null;
  }

  // The number box next to an icon right now (the BO may have replaced
  // the one the icon was added for, e.g. when it revealed the number).
  function boxForIcon(icon, fallback) {
    const prev = icon.previousElementSibling;
    if (prev && prev.matches('div.truncate.cursor-pointer') && isPhoneText(prev.textContent)) return prev;
    if (fallback && fallback.isConnected) return fallback;
    const scope = icon.parentElement;
    const list = scope ? Array.from(scope.querySelectorAll('div.truncate.cursor-pointer')).filter((b) => isPhoneText(b.textContent)) : [];
    return list[0] || null;
  }

  async function callFromIcon(oldBox, icon) {
    const box = boxForIcon(icon, oldBox);
    if (!box) return;
    if (icon.classList.contains('is-busy')) return;
    icon.classList.add('is-busy');
    try {
      let number = revealedNumber(box.textContent);
      if (!number) {
        box.click(); // the BO's own reveal
        number = await waitForNumber(box, 2500);
      }
      if (!number || BLOCKED_NUMBERS.includes(String(number).replace(/\D/g, ''))) {
        icon.classList.add('is-fail');
        setTimeout(() => icon.classList.remove('is-fail'), 1200);
        return;
      }
      if (!(await quietOk(box.closest('tr')))) return;
      callAndShowOnBmo(box, number);
      icon.classList.add('is-ok');
      setTimeout(() => icon.classList.remove('is-ok'), 1500);
    } finally {
      setTimeout(() => icon.classList.remove('is-busy'), 800);
    }
  }

  // A call from an icon (or the number menu) goes through Pip like his own
  // calls: he shows that lead as "Currently calling", watches the call, and
  // 2X / double dial redial it.
  function callAndShowOnBmo(box, number) {
    const row = box.closest('tr');
    const leadId = leadIdForBox(box);
    clearAutoNext(); // a countdown to the next lead gives way to this call
    leadRedialed = false;
    dialNumber(number, true);
    const info = row ? getLeadInfo(row) : { leadId, href: location.pathname, clientName: '', origin: '', dest: '' };
    lastCalledInfo = Object.assign({ number }, info);
    lastCalledRow = row || null;
    updateDoubleDialButton();
    markCalled(leadId);
    if (row) {
      renderPanelForRow(row, true);
    } else {
      // A lead's own page: no list row, so his screen is filled in directly.
      const el = ensureBmo();
      el.querySelector('.ia-face').style.display = 'none';
      el.querySelector('.ia-screen-info').style.display = '';
      el.querySelector('.ia-screen-info__label').textContent = 'Currently calling';
      const c = el.querySelector('.ia-screen-info__client');
      c.textContent = 'Lead ' + (leadId || '');
      c.href = info.href;
      el.querySelector('.ia-screen-info__route').textContent = number;
    }
    setPanelStatus(awaitingCallEnd ? 'Dialing\u2026' : '');
  }

  // Colours for the call icons and menus: the same palette as the panel,
  // set on the page so they follow the mode and accent the agent picked.
  function paintCallVars() {
    let p;
    try { p = iaPalette(); } catch (e) { return; }
    const st = document.documentElement.style;
    const v = { acc: p.pri, onacc: p.onpri, text: p.text, title: p.title, muted: p.muted, ok: p.ok, bad: p.bad,
      glass: p.glass, edge: p.edge, inner: p.inner, chip: p.chip, chipshadow: p.chipshadow, shadow: p.shadow, sky: p.sky };
    Object.keys(v).forEach((k) => { if (st.getPropertyValue('--ia-cl-' + k) !== v[k]) st.setProperty('--ia-cl-' + k, v[k]); });
  }

  let callMenu = null;
  function closeCallMenu() {
    if (callMenu) { callMenu.remove(); callMenu = null; }
  }
  function openCallMenu(x, y) {
    closeCallMenu();
    const m = document.createElement('div');
    paintCallVars();
    m.className = 'ia-call-menu';
    m.setAttribute('role', 'menu');
    const mh = document.createElement('div');
    mh.className = 'ia-call-menu-h';
    mh.textContent = 'Calls go to';
    m.appendChild(mh);
    [['app', (IA_MAC ? 'Mac' : 'Windows') + ' app (RingCentral)'], ['web', 'RingCentral website']].forEach(([v, label]) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'menuitemradio');
      b.setAttribute('aria-checked', String(callMode() === v));
      b.className = 'ia-call-menu-item' + (callMode() === v ? ' is-on' : '');
      const tick = document.createElement('span');
      tick.className = 'ia-call-menu-tick';
      tick.textContent = callMode() === v ? '✓' : '';
      const t = document.createElement('span');
      t.textContent = label;
      b.append(tick, t);
      b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); setCallMode(v); closeCallMenu(); });
      m.appendChild(b);
    });
    document.body.appendChild(m);
    m.style.left = Math.max(8, Math.min(x, window.innerWidth - m.offsetWidth - 8)) + 'px';
    m.style.top = Math.max(8, Math.min(y, window.innerHeight - m.offsetHeight - 8)) + 'px';
    callMenu = m;
  }
  // A small right-click menu in the same look as the call menu.
  // items: [{ label, on (tick when true), act }]
  function iaOpenMenu(x, y, items, title) {
    closeCallMenu();
    paintCallVars();
    const m = document.createElement('div');
    m.className = 'ia-call-menu';
    m.setAttribute('role', 'menu');
    if (title) { const h = document.createElement('div'); h.className = 'ia-call-menu-h'; h.textContent = title; m.appendChild(h); }
    items.forEach((it) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'menuitemcheckbox');
      b.setAttribute('aria-checked', String(!!it.on));
      b.className = 'ia-call-menu-item' + (it.on ? ' is-on' : '');
      const tick = document.createElement('span');
      tick.className = 'ia-call-menu-tick';
      tick.textContent = it.on ? '\u2713' : '';
      const tx = document.createElement('span');
      tx.textContent = it.label;
      b.append(tick, tx);
      b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); closeCallMenu(); it.act(); });
      m.appendChild(b);
    });
    document.body.appendChild(m);
    m.style.left = Math.max(8, Math.min(x, window.innerWidth - m.offsetWidth - 8)) + 'px';
    m.style.top = Math.max(8, Math.min(y, window.innerHeight - m.offsetHeight - 8)) + 'px';
    callMenu = m;
  }
  document.addEventListener('mousedown', (e) => { if (callMenu && !callMenu.contains(e.target)) closeCallMenu(); }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeCallMenu(); }, true);
  window.addEventListener('scroll', closeCallMenu, true);
  window.addEventListener('blur', closeCallMenu);

  function addCallIcons() {
    paintCallVars();
    document.querySelectorAll('div.truncate.cursor-pointer').forEach((box) => {
      if (!isPhoneText(box.textContent.trim())) return;
      const next = box.nextElementSibling;
      if (next && next.classList.contains('ia-callicon')) {
        if (!onLeadPage(box)) box.classList.add('ia-callicon-host'); // a re-drawn box loses our class
        return;
      }
      const icon = document.createElement('span');
      icon.className = 'ia-callicon';
      icon.setAttribute('role', 'button');
      icon.tabIndex = 0;
      icon.title = 'Call (right-click: where calls go)';
      setMarkupSafe(icon, PHONE_ICON_SVG);
      if (onLeadPage(box)) {
        // Inside a lead: a small "Call now" button instead of the bare icon.
        icon.classList.add('ia-callicon--pill');
        const t = document.createElement('span');
        t.textContent = 'Call now';
        icon.appendChild(t);
      }
      icon.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); callFromIcon(box, icon); });
      icon.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); callFromIcon(box, icon); } });
      icon.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); openCallMenu(e.clientX, e.clientY); });
      ['mousedown', 'mouseup', 'dblclick'].forEach((t) => icon.addEventListener(t, (e) => e.stopPropagation()));
      // Same line as the number, in a fixed spot: the number gets a steady
      // width (and same-width digits), so the icon doesn't shift from row to
      // row or when the number is revealed.
      if (!onLeadPage(box)) box.classList.add('ia-callicon-host');
      box.insertAdjacentElement('afterend', icon);
    });
  }
  function setMarkupSafe(el, markup) {
    const doc = new DOMParser().parseFromString(markup, 'image/svg+xml');
    el.appendChild(document.importNode(doc.documentElement, true));
  }

  // Inside a lead, one click on the number (the BO reveals it on that same
  // click) opens a small menu: Call now / Copy.
  function liveBoxIn(area, box) {
    return box.isConnected ? box : ((area && area.querySelector('div.truncate.cursor-pointer')) || null);
  }
  async function copyNumber(box, area) {
    const n = await waitForNumber(liveBoxIn(area, box) || box, 2500);
    if (!n) return;
    try { GM_setClipboard(n, 'text'); } catch (err) { return; }
    const live = liveBoxIn(area, box) || area || box;
    const r = live.getBoundingClientRect();
    paintCallVars();
    const tip = document.createElement('div');
    tip.className = 'ia-num-copied';
    tip.textContent = 'Copied';
    tip.style.left = (r.left + r.width / 2) + 'px';
    tip.style.top = (r.top - 6) + 'px';
    document.body.appendChild(tip);
    setTimeout(() => tip.remove(), 1100);
  }
  function openNumberMenu(box, x, y) {
    closeCallMenu();
    paintCallVars();
    const area = box.parentElement;
    const m = document.createElement('div');
    m.className = 'ia-call-menu ia-num-menu';
    m.setAttribute('role', 'menu');
    const item = (label, svg, fn) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'menuitem');
      b.className = 'ia-call-menu-item';
      const ic = document.createElement('span');
      ic.className = 'ia-call-menu-tick ia-num-menu-ic';
      if (svg) setMarkupSafe(ic, svg);
      const t = document.createElement('span');
      t.textContent = label;
      b.append(ic, t);
      b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); closeCallMenu(); fn(); });
      m.appendChild(b);
    };
    item('Call now', PHONE_ICON_SVG, () => {
      const live = liveBoxIn(area, box);
      const icon = live && live.nextElementSibling && live.nextElementSibling.classList.contains('ia-callicon') ? live.nextElementSibling : null;
      if (live && icon) callFromIcon(live, icon);
      else if (live) waitForNumber(live, 2500).then(async (n) => { if (n && await quietOk(live.closest('tr'))) callAndShowOnBmo(live, n); });
    });
    item('Copy number', COPY_ICON_SVG, () => copyNumber(box, area));
    document.body.appendChild(m);
    m.style.left = Math.max(8, Math.min(x, window.innerWidth - m.offsetWidth - 8)) + 'px';
    m.style.top = Math.max(8, Math.min(y, window.innerHeight - m.offsetHeight - 8)) + 'px';
    callMenu = m;
  }
  const COPY_ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
  document.addEventListener('click', (e) => {
    if (!e.isTrusted || e.detail > 1) return;
    const box = phoneBoxFor(e.target);
    if (!box || !onLeadPage(box)) return;
    const r = box.getBoundingClientRect();
    setTimeout(() => openNumberMenu(box, r.left, r.bottom + 6), 0); // after the BO's own reveal click
  }, true);

  // The BO's own double-click-to-call (which hands the number to Windows'
  // default phone app) is switched off: Pip places every call.
  function blockBoDoubleClickCall(e) {
    if (e.type === 'click' && e.detail < 2) return;
    if (!phoneBoxFor(e.target)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  }
  window.addEventListener('dblclick', blockBoDoubleClickCall, true);
  window.addEventListener('click', blockBoDoubleClickCall, true);
  // …and any tel: link the BO creates.
  window.addEventListener('click', (e) => {
    const a = e.target && e.target.closest && e.target.closest('a[href^="tel:"]');
    if (a) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);

  GM_addStyle(`
    .ia-callicon-host { display: inline-block !important; vertical-align: middle; min-width: 12.5ch; font-variant-numeric: tabular-nums; }
    .ia-callicon { display: inline-flex; align-items: center; justify-content: center; vertical-align: middle; margin-left: 6px; width: 24px; height: 24px; box-sizing: border-box; border-radius: 9px; cursor: pointer; flex: none;
      color: var(--ia-cl-acc, #1f5cff); background: color-mix(in srgb, var(--ia-cl-acc, #1f5cff) 14%, #fff); border: 1px solid color-mix(in srgb, var(--ia-cl-acc, #1f5cff) 40%, transparent); }
    .ia-callicon:hover, .ia-callicon:focus-visible { background: color-mix(in srgb, var(--ia-cl-acc, #1f5cff) 24%, #fff); outline: none; }
    .ia-callicon svg { width: 13px; height: 13px; display: block; }
    .ia-callicon.is-busy { opacity: .7; }
    .ia-callicon--pill { width: auto; height: 18px; max-height: 18px; gap: 4px; padding: 0 9px 0 7px; margin: 0 0 0 8px; border-radius: 999px; line-height: 18px; font-size: 11px; font-weight: 800; white-space: nowrap;
      color: var(--ia-cl-onacc, #fff); background: linear-gradient(180deg, color-mix(in srgb, var(--ia-cl-acc, #1f5cff) 82%, #fff), var(--ia-cl-acc, #1f5cff)); border: 0; }
    .ia-callicon--pill svg { width: 11px; height: 11px; }
    .ia-callicon--pill:hover, .ia-callicon--pill:focus-visible { background: var(--ia-cl-acc, #1f5cff); filter: brightness(1.08); }
    .ia-callicon.is-ok { color: var(--ia-cl-ok, #12a150); border-color: var(--ia-cl-ok, #12a150); background: color-mix(in srgb, var(--ia-cl-ok, #12a150) 18%, #fff); }
    .ia-callicon--pill.is-ok { color: #fff; background: var(--ia-cl-ok, #12a150); }
    .ia-callicon.is-fail { color: var(--ia-cl-bad, #dc2626); border-color: var(--ia-cl-bad, #dc2626); background: color-mix(in srgb, var(--ia-cl-bad, #dc2626) 14%, #fff); }
    .ia-num-copied { position: fixed; z-index: 2147483000; transform: translate(-50%, -100%); padding: 3px 9px; border-radius: 8px; font: 800 11px Inter, 'Segoe UI', system-ui, sans-serif; white-space: nowrap; pointer-events: none;
      color: var(--ia-cl-title, #fff); background: var(--ia-cl-glass, #1f2937); border: 1px solid var(--ia-cl-edge, transparent); box-shadow: var(--ia-cl-chipshadow, none); -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px); }
    .ia-call-menu { position: fixed; z-index: 2147483000; min-width: 230px; padding: 6px; display: grid; gap: 2px; box-sizing: border-box; border-radius: 14px; font: 700 13px Inter, 'Segoe UI', system-ui, sans-serif; text-align: left;
      color: var(--ia-cl-text, #111827); background: var(--ia-cl-sky, none), var(--ia-cl-glass, #fff); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5);
      border: 1px solid var(--ia-cl-edge, rgba(0,0,0,.12)); box-shadow: var(--ia-cl-shadow, 0 8px 24px rgba(0,0,0,.18)), inset 0 1px 0 var(--ia-cl-inner, transparent); }
    .ia-call-menu-h { padding: 4px 8px 6px; font-size: 11px; font-weight: 800; letter-spacing: .06em; text-transform: uppercase; color: var(--ia-cl-muted, #6b7280); }
    .ia-call-menu-item { display: flex; align-items: center; gap: 8px; width: 100%; padding: 8px 10px; border: 0; border-radius: 10px; background: transparent; color: inherit; font: inherit; text-align: left; cursor: pointer; }
    .ia-call-menu-item:hover, .ia-call-menu-item:focus-visible { background: var(--ia-cl-chip, rgba(127,127,127,.14)); outline: none; }
    .ia-call-menu-item.is-on { background: var(--ia-cl-chip, rgba(127,127,127,.14)); box-shadow: var(--ia-cl-chipshadow, none); }
    .ia-call-menu-tick { width: 14px; color: var(--ia-cl-ok, #16a34a); font-weight: 800; }
    .ia-num-menu { min-width: 170px; }
    .ia-num-menu-ic { color: var(--ia-cl-acc, #1f5cff); display: inline-flex; }
    .ia-num-menu-ic svg { width: 14px; height: 14px; }
  `);

  // Places Pip's call (website or Windows app, as chosen) and starts
  // watching RingCentral's call status for that call. The widget never
  // places calls; it only reports their status.
  function dialNumber(number, byRealClick) {
    bumpTodayStat('calls');
    placeCall(number);
    if (!rcContainer()) return; // no status watcher -> old one-click-per-call mode
    awaitingCallEnd = true;
    callSeen = false;
    iaCallDigits = digitsOf(number);
    iaCallConnectedAt = 0;
    clearLongCall();
    if (callAppearTimer) clearTimeout(callAppearTimer);
    callAppearTimer = setTimeout(() => {
      callAppearTimer = null;
      if (!awaitingCallEnd || callSeen) return;
      awaitingCallEnd = false;
      setPanelStatus(byRealClick || callMode() === 'web' ? 'No call detected' : 'Chrome blocked auto-dial \u2014 press Call');
    }, callMode() === 'web' ? CALL_APPEAR_TIMEOUT_MS + 15000 : CALL_APPEAR_TIMEOUT_MS); // a call link can take a moment to load
  }

  function clearAutoNext() {
    countingToNext = false;
    if (autoNextTimer) { clearTimeout(autoNextTimer); autoNextTimer = null; }
    if (autoNextCountdown) { clearInterval(autoNextCountdown); autoNextCountdown = null; }
  }

  function stopAutoRun() {
    setOnCall(false);
    autoRunning = false;
    clearLongCall();
    awaitingCallEnd = false;
    callSeen = false;
    pendingAutoNext = false;
    iaCallDigits = null;
    if (callAppearTimer) { clearTimeout(callAppearTimer); callAppearTimer = null; }
    clearAutoNext();
    if (iaWidget) iaWidget.classList.remove('ia-widget--running');
    if (typeof applySuperState === 'function') applySuperState();
    if (currentPanelRow) {
      if (!currentRowDialed) setPanelLabel('Up next'); // drop a stopped countdown from the label
      setPanelStatus('Stopped');
    }
  }

  function startAutoRun() {
    if (!rcContainer()) return; // can't detect call ends without RingCentral
    autoRunning = true;
    if (iaWidget) iaWidget.classList.add('ia-widget--running');
    if (typeof applySuperState === 'function') applySuperState();
  }

  function onCallEnded() {
    clearLongCall();
    setOnCall(false);
    if (!awaitingCallEnd || !callSeen) return; // not a call Pip is watching
    awaitingCallEnd = false;
    callSeen = false;
    const answered = iaCallConnectedAt && (Date.now() - iaCallConnectedAt) / 1000 > ANSWERED_AFTER_SEC;
    iaCallDigits = null;
    if (answered) bumpTodayStat('answered');
    if (!autoRunning) { setPanelStatus('Call ended'); return; }

    // Double dial: unanswered calls get one immediate second try -- always
    // to the lead Pip just called (still on screen), never the next one.
    if (doubleDialOn() && !leadRedialed && !answered && lastCalledInfo) {
      leadRedialed = true;
      showLastCalledLead();
      startCountdown(DOUBLE_DIAL_DELAY_SEC, 'Redialing in ', () => { dialNumber(lastCalledInfo.number, false); setPanelLabel('Redialing'); setPanelStatus('Dialing\u2026'); }, setPanelLabel);
      return;
    }
    scheduleNextLead();
  }

  // Puts the lead Pip called last back on screen as the one being called
  // (used by both redials, so a redial never shows the next lead).
  function showLastCalledLead() {
    countingToNext = false;
    if (lastCalledRow && document.body.contains(lastCalledRow)) renderPanelForRow(lastCalledRow, true);
  }

  // Call ended: Pip moves on to the next lead right away and shows it with
  // a countdown, so you can see who's next and Skip or Call before it dials.
  let countingToNext = false;
  async function scheduleNextLead() {
    if (manualCallActive()) {
      clearAutoNext();
      pendingAutoNext = true;
      setPanelStatus('Paused \u2014 you\u2019re on a call');
      return;
    }
    pendingAutoNext = false;
    clearAutoNext();
    if (currentRowDialed) {
      setPanelStatus('Finding next lead\u2026');
      const next = await getNextPendingRow();
      if (!autoRunning || awaitingCallEnd || callInFlight) return; // stopped or redialed meanwhile
      if (!next) { handleCallClick(true); return; } // nothing left: the normal end-of-list flow
      renderPanelForRow(next, false);
    }
    startNextCountdown();
  }
  function startNextCountdown() {
    startCountdown(AUTO_NEXT_DELAY_SEC, 'Calling next in ', () => { countingToNext = false; handleCallClick(true); }, setPanelLabel);
    countingToNext = true; // after startCountdown, which clears it
  }

  function setPanelLabel(text) {
    const l = iaWidget && iaWidget.querySelector('.ia-screen-info__label');
    if (l) l.textContent = text;
  }

  function startCountdown(seconds, label, action, show) {
    clearAutoNext();
    const out = show || setPanelStatus;
    let left = seconds;
    out(label + left + 's');
    autoNextCountdown = setInterval(() => {
      left -= 1;
      if (left > 0) out(label + left + 's');
    }, 1000);
    autoNextTimer = setTimeout(() => {
      clearAutoNext();
      if (!autoRunning) return;
      // Never dial over a call you placed yourself — wait for it to end.
      if (manualCallActive()) { pendingAutoNext = true; setPanelStatus('Paused \u2014 you\u2019re on a call'); return; }
      action();
    }, seconds * 1000);
  }

  // Your own call started/ended: pause or resume the auto-dialer.
  function onManualCallsChanged() {
    if (manualCallActive()) {
      if (autoNextTimer) { clearAutoNext(); pendingAutoNext = true; }
      if (pendingAutoNext || autoRunning) setPanelStatus('Paused \u2014 you\u2019re on a call');
    } else if (pendingAutoNext && autoRunning && !awaitingCallEnd) {
      scheduleNextLead();
    }
  }

  // Tracks EVERY call on your RingCentral account, and tells Pip's own
  // call (outbound to the number he just dialed) apart from calls you make
  // or take yourself. Your own calls pause the auto-dialer until they end.
  pageWin.addEventListener('message', (e) => {
    const d = e.data;
    if (!d || typeof d.type !== 'string' || d.type.indexOf('rc-') !== 0) return;
    if (!d.call) return;
    const call = d.call;
    let st = call.telephonyStatus;
    if (d.type === 'rc-call-start-notify') st = 'CallConnected';
    if (d.type === 'rc-call-end-notify') st = 'NoCall';
    if (!st) return;
    const toDigits = digitsOf((call.to && (call.to.phoneNumber || call.to.extensionNumber)) || call.toNumber);
    const key = call.sessionId || call.telephonySessionId || call.id || call.partyId || ((call.direction || '') + toDigits);
    const known = activeCalls.get(key);
    const live = st === 'Ringing' || st === 'CallConnected' || st === 'OnHold' || st === 'Proceeding';
    if (call.direction !== 'Inbound') rcHelperSawCall(toDigits, live);

    if (live) {
      let mine = known ? known.mine : false;
      if (!known && awaitingCallEnd && call.direction !== 'Inbound') {
        // Pip's call: outbound to the number he dialed (or, if RingCentral
        // doesn't say the number, the first outbound call after he dialed).
        mine = toDigits ? toDigits === iaCallDigits : !callSeen;
      }
      activeCalls.set(key, { mine, seen: Date.now() });
      if (mine) {
        callSeen = true;
        armLongCall(); // timed from the first sign of the call, ringing or connected
        setOnCall(true);
        if (st === 'CallConnected' && !iaCallConnectedAt) iaCallConnectedAt = Date.now();
        if (!manualCallActive()) setPanelStatus(st === 'Ringing' ? 'Ringing\u2026' : st === 'OnHold' ? 'On hold' : 'On call');
      } else {
        onManualCallsChanged();
      }
    } else if (st === 'NoCall') {
      activeCalls.delete(key);
      const wasMine = known ? known.mine : (awaitingCallEnd && callSeen && (!toDigits || toDigits === iaCallDigits));
      if (wasMine) onCallEnded();
      else onManualCallsChanged();
    }
  });

  loadRingCentral();

  // --- Merge RingCentral into the CRM's own floating phone widget -------
  // RingCentral's own floating badge is hidden. Clicking the CRM's phone
  // button opens RingCentral's panel fully expanded beside it (the CRM
  // button acts as the minimized state), and clicking it again or pressing
  // Esc hides it. Hidden, the panel keeps running so call status still
  // reaches Pip. The CRM widget's drag handle still moves it.
  const RC_PANEL_W = 300;
  const RC_PANEL_H = 500;
  let rcPanelOpen = false;
  let allowRcToggle = false; // lets our own expand-click through the interceptor below
  let rcReopenBlockedUntil = 0;

  function closeRcPanelFromToggle() {
    rcReopenBlockedUntil = Date.now() + 500;
    if (rcPanelOpen) setRcPanelOpen(false);
  }

  function expandRcIfMinimized(c) {
    const header = c.querySelector('.Adapter_header');
    const minimized = c.classList.contains('Adapter_minimized') || (header && header.classList.contains('Adapter_minimized'));
    if (!minimized) return;
    const toggle = c.querySelector('.Adapter_toggle');
    if (!toggle) return;
    allowRcToggle = true;
    try { toggle.click(); } finally { allowRcToggle = false; }
  }

  function positionRcPanel() {
    const c = rcContainer();
    const host = document.querySelector('.floating-chat-widget');
    if (!c || !host) return;
    const r = host.getBoundingClientRect();
    const gap = 8;
    // Prefer opening above the button; drop below it if there's no room.
    let top = r.top - RC_PANEL_H - gap;
    if (top < 8) top = Math.min(r.bottom + gap, window.innerHeight - RC_PANEL_H - 8);
    let left = r.right - RC_PANEL_W;
    left = Math.max(8, Math.min(left, window.innerWidth - RC_PANEL_W - 8));
    top = Math.max(8, top);
    c.style.setProperty('left', left + 'px', 'important');
    c.style.setProperty('top', top + 'px', 'important');
    c.style.setProperty('right', 'auto', 'important');
    c.style.setProperty('bottom', 'auto', 'important');
    // RingCentral stores its own drag offset as an inline !important
    // transform; clear it so the panel sits exactly where it's placed.
    c.style.setProperty('transform', 'none', 'important');
  }

  // Open/closed state lives on <html>, NOT on RingCentral's own element.
  // Root cause of the flicker: RingCentral rewrites its element's whole
  // class list every time it minimizes/expands, which wiped the classes
  // this script had put there — so the panel briefly fell back to
  // RingCentral's own visible state, then got hidden again on the next
  // check. RingCentral never touches <html>, so this can't be undone.
  function setRcPanelOpen(open) {
    rcPanelOpen = open;
    document.documentElement.setAttribute('data-ia-rc', open ? 'open' : 'closed');
    const c = rcContainer();
    if (!c) return;
    expandRcIfMinimized(c); // always keep it expanded underneath
    if (open) positionRcPanel();
  }

  // Clicking the CRM phone widget does BOTH: the CRM's own click still
  // goes through untouched (whatever it normally opens still opens), and
  // the RingCentral panel is toggled alongside it.
  document.addEventListener('click', (e) => {
    const content = e.target.closest && e.target.closest('.floating-chat-widget__content');
    if (!content || !rcContainer()) return; // RingCentral not loaded -> CRM widget works as normal
    if (!rcPanelOpen && Date.now() < rcReopenBlockedUntil) return; // stray click right after closing
    setRcPanelOpen(!rcPanelOpen);
  }, true);

  // RingCentral's own minimize button: instead of collapsing into its own
  // mini bar, close the panel back into the CRM phone button. Capture
  // phase runs before RingCentral's handler, so its minimize never fires.
  // RingCentral reacts to press events, not only clicks, so every press
  // event on its minimize button is swallowed at the window level (the
  // earliest point), and the click itself acts exactly like clicking the
  // CRM phone widget.
  ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'touchstart', 'touchend', 'click'].forEach((type) => {
    window.addEventListener(type, (e) => {
      if (allowRcToggle) return;
      const toggle = e.target && e.target.closest && e.target.closest('#ia-rc-panel .Adapter_toggle');
      if (!toggle) return;
      e.preventDefault();
      e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      // Always an explicit close (never a flip), so a repeated event
      // can't close it and then reopen it straight away.
      if (type === 'click' || type === 'pointerup' || type === 'touchend') closeRcPanelFromToggle();
    }, true);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && rcPanelOpen) setRcPanelOpen(false);
  });

  window.addEventListener('resize', () => { if (rcPanelOpen) positionRcPanel(); });

  // Take over RingCentral's panel as soon as it appears, keep it expanded,
  // and keep it glued to the CRM button if that button is dragged.
  __jsRegisterScan(() => {
    if (!rcContainer()) loadRingCentral();
    const c = rcContainer();
    if (!c) return;
    if (!document.documentElement.hasAttribute('data-ia-rc')) { setRcPanelOpen(false); return; }
    const header = c.querySelector('.Adapter_header');
    const minimized = c.classList.contains('Adapter_minimized') || (header && header.classList.contains('Adapter_minimized'));
    if (minimized) {
      // RingCentral minimized itself anyway -> same as clicking the CRM
      // widget: close the panel, and quietly re-expand it underneath.
      if (rcPanelOpen) setRcPanelOpen(false);
      else expandRcIfMinimized(c);
    }
    if (rcPanelOpen) positionRcPanel();
  });

  GM_addStyle(`
    #ia-rc-panel {
      position: fixed;
      width: ${RC_PANEL_W}px;
      height: ${RC_PANEL_H}px;
      z-index: 99998;
      background: #fff;
      overflow: hidden;
    }
    #ia-rc-panel iframe { width: 100%; height: 100%; border: 0; display: block; }
    html:not([data-ia-rc="open"]) #ia-rc-panel {
      visibility: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    }
    html[data-ia-rc="closed"] #ia-rc-panel {
      visibility: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    }
    html[data-ia-rc="open"] #ia-rc-panel {
      visibility: visible !important;
      opacity: 1 !important;
      box-shadow: 0 10px 30px rgba(0,0,0,.35) !important;
      border-radius: 10px !important;
    }

  `);


  // ==========================================================================
  // RC tab: live RingCentral texts + composer with follow-up templates
  // ==========================================================================
  // Replaces the BO's "You can only view this chat" bar with a composer.
  // Texts are read from the RingCentral panel's own conversation screen
  // (opened for this lead with RingCentral's "open conversation" command),
  // so ones the BO hasn't synced yet show right away, in the BO's own bubble
  // style. Send types into RingCentral's own message box and presses its own
  // Send button. Signed out -> "Sign in to RingCentral" opens its sign-in.
  const SMS_TPL_KEY = 'js-sms-templates';
  const SMS_RC_ORIGIN = 'https://apps.ringcentral.com';
  const SMS_OLD_TPL = [
    { name: 'Follow-up 1', text: 'Hey {client}, {agent} here from Travel Business Class regarding your flight to {destination}. I\u2019ve got you some really good discounted business class deals with major airlines and wanted to confirm some information with you to see which one will work best. When is the best time to talk?' },
    { name: 'Follow-up 2', text: 'Hi, just following up on my message regarding your flight to {destination}. I found a couple of business class options that look pretty good for your trip. Would you have a few minutes today for me to run them by you?' },
    { name: 'Follow-up 3', text: 'Hey, just wanted to catch you before I close out your flight request. I still have some good business class fares available with major airlines. What time would be easiest for me to reach you?' },
    { name: 'Follow-up 4', text: 'Hi again! I wanted to check in and see if you\u2019re still looking at options for your flight to {destination}. I\u2019d be happy to go over the best fares I\u2019m seeing and see if we can find something that makes sense for you. When would be a good time to connect?' },
  ];
  // 2.16.0: one text only, "SMS Introduction" (Follow-up 1's wording).
  const SMS_DEFAULT_TPL = [
    { name: 'SMS Introduction', text: SMS_OLD_TPL[0].text },
  ];
  const SMS_CITY = (() => {
    const m = {};
    ('ATL Atlanta|AUS Austin|BNA Nashville|BOS Boston|BWI Baltimore|CLT Charlotte|CLE Cleveland|CMH Columbus|CVG Cincinnati|DCA Washington|IAD Washington|DEN Denver|DFW Dallas|DAL Dallas|DTW Detroit|EWR New York|JFK New York|LGA New York|FLL Fort Lauderdale|HNL Honolulu|OGG Maui|KOA Kona|LIH Kauai|IAH Houston|HOU Houston|IND Indianapolis|JAX Jacksonville|LAS Las Vegas|LAX Los Angeles|BUR Los Angeles|SNA Orange County|MCI Kansas City|MCO Orlando|MDW Chicago|ORD Chicago|MIA Miami|MSP Minneapolis|MSY New Orleans|OAK Oakland|PDX Portland|PHL Philadelphia|PHX Phoenix|PIT Pittsburgh|RDU Raleigh|SAN San Diego|SAT San Antonio|SEA Seattle|SFO San Francisco|SJC San Jose|SLC Salt Lake City|SMF Sacramento|STL St. Louis|TPA Tampa|ANC Anchorage|RSW Fort Myers|PBI West Palm Beach|SJU San Juan|' +
     'YYZ Toronto|YUL Montreal|YVR Vancouver|YYC Calgary|YOW Ottawa|YEG Edmonton|YHZ Halifax|' +
     'MEX Mexico City|CUN Cancun|GDL Guadalajara|MTY Monterrey|SJD Los Cabos|PVR Puerto Vallarta|' +
     'LHR London|LGW London|LCY London|STN London|MAN Manchester|EDI Edinburgh|GLA Glasgow|DUB Dublin|SNN Shannon|CDG Paris|ORY Paris|NCE Nice|LYS Lyon|MRS Marseille|' +
     'AMS Amsterdam|BRU Brussels|FRA Frankfurt|MUC Munich|BER Berlin|DUS Dusseldorf|HAM Hamburg|ZRH Zurich|GVA Geneva|VIE Vienna|PRG Prague|BUD Budapest|WAW Warsaw|KRK Krakow|' +
     'CPH Copenhagen|ARN Stockholm|OSL Oslo|HEL Helsinki|KEF Reykjavik|MAD Madrid|BCN Barcelona|AGP Malaga|PMI Palma de Mallorca|IBZ Ibiza|LIS Lisbon|OPO Porto|' +
     'FCO Rome|CIA Rome|MXP Milan|LIN Milan|VCE Venice|FLR Florence|NAP Naples|BLQ Bologna|PSA Pisa|CTA Catania|PMO Palermo|' +
     'ATH Athens|JTR Santorini|JMK Mykonos|HER Crete|SKG Thessaloniki|IST Istanbul|SAW Istanbul|AYT Antalya|DBV Dubrovnik|SPU Split|ZAG Zagreb|OTP Bucharest|SOF Sofia|BEG Belgrade|TLV Tel Aviv|' +
     'DXB Dubai|AUH Abu Dhabi|DOH Doha|BAH Bahrain|KWI Kuwait|MCT Muscat|RUH Riyadh|JED Jeddah|AMM Amman|BEY Beirut|CAI Cairo|HRG Hurghada|SSH Sharm El Sheikh|CMN Casablanca|RAK Marrakech|TUN Tunis|' +
     'JNB Johannesburg|CPT Cape Town|NBO Nairobi|ADD Addis Ababa|LOS Lagos|ACC Accra|DAR Dar es Salaam|ZNZ Zanzibar|MRU Mauritius|SEZ Seychelles|' +
     'DEL Delhi|BOM Mumbai|BLR Bangalore|MAA Chennai|HYD Hyderabad|CCU Kolkata|COK Kochi|GOI Goa|AMD Ahmedabad|CMB Colombo|MLE Maldives|KTM Kathmandu|DAC Dhaka|KHI Karachi|LHE Lahore|ISB Islamabad|' +
     'BKK Bangkok|DMK Bangkok|HKT Phuket|CNX Chiang Mai|SIN Singapore|KUL Kuala Lumpur|CGK Jakarta|DPS Bali|MNL Manila|CEB Cebu|SGN Ho Chi Minh City|HAN Hanoi|DAD Da Nang|PNH Phnom Penh|REP Siem Reap|' +
     'HKG Hong Kong|MFM Macau|TPE Taipei|PEK Beijing|PKX Beijing|PVG Shanghai|SHA Shanghai|CAN Guangzhou|SZX Shenzhen|CTU Chengdu|ICN Seoul|GMP Seoul|NRT Tokyo|HND Tokyo|KIX Osaka|ITM Osaka|NGO Nagoya|FUK Fukuoka|CTS Sapporo|OKA Okinawa|' +
     'SYD Sydney|MEL Melbourne|BNE Brisbane|PER Perth|ADL Adelaide|OOL Gold Coast|CNS Cairns|AKL Auckland|CHC Christchurch|ZQN Queenstown|WLG Wellington|NAN Fiji|PPT Tahiti|' +
     'GRU Sao Paulo|GIG Rio de Janeiro|EZE Buenos Aires|SCL Santiago|LIM Lima|CUZ Cusco|BOG Bogota|MDE Medellin|CTG Cartagena|UIO Quito|GYE Guayaquil|PTY Panama City|SJO San Jose|LIR Liberia|' +
     'MBJ Montego Bay|KIN Kingston|NAS Nassau|PUJ Punta Cana|SDQ Santo Domingo|AUA Aruba|CUR Curacao|SXM St. Maarten|BGI Barbados|UVF St. Lucia|POS Port of Spain|HAV Havana|GCM Grand Cayman|BDA Bermuda|' +
     'NYC New York|LON London|PAR Paris|ROM Rome|MIL Milan|TYO Tokyo|OSA Osaka|SEL Seoul|WAS Washington|CHI Chicago|BJS Beijing|STO Stockholm|BUE Buenos Aires|SAO Sao Paulo|RIO Rio de Janeiro|YTO Toronto|YMQ Montreal|MOW Moscow|SVO Moscow')
      .split('|').forEach((p) => { const i = p.indexOf(' '); m[p.slice(0, i)] = p.slice(i + 1); });
    return m;
  })();

  // 2.16.0, once per computer: the four text templates become one. Everyone
  // keeps their own wording: template 1 if they edited it, otherwise the
  // first of 2-4 they edited, otherwise the standard Follow-up 1 text. A
  // button name they chose themselves stays; otherwise "SMS Introduction".
  // Sent ticks: the kept template's ticks become the one template's. The
  // saved history is only ever added to, never trimmed.
  let smsOneDone = false;
  function smsOneTemplate() {
    if (smsOneDone) return;
    smsOneDone = true;
    let t = null;
    try { t = JSON.parse(GM_getValue(SMS_TPL_KEY, 'null')); } catch (e) { t = null; }
    if (Array.isArray(t) && t.length === 1) return; // already done
    let pick = 0, src = null;
    if (Array.isArray(t)) {
      const edited = (i) => !!(t[i] && typeof t[i].text === 'string' && t[i].text.trim() && SMS_OLD_TPL[i] && t[i].text.trim() !== SMS_OLD_TPL[i].text.trim());
      const i = [0, 1, 2, 3].find(edited);
      if (i != null) pick = i;
      src = t[pick] || null;
    }
    const ownName = src && src.name && !/^\s*follow-up\s*\d*\s*$/i.test(String(src.name)) ? String(src.name) : '';
    const keepText = src && typeof src.text === 'string' && src.text.trim() && (pick > 0 || src.text.trim() !== SMS_OLD_TPL[0].text.trim());
    const one = [{ name: ownName || SMS_DEFAULT_TPL[0].name, text: keepText ? src.text : SMS_DEFAULT_TPL[0].text }];
    try { GM_setValue(SMS_TPL_KEY, JSON.stringify(one)); } catch (e) { /* best-effort */ }
    if (pick > 0) {
      try {
        const o = JSON.parse(GM_getValue('js-sms-sent', '{}')) || {};
        Object.keys(o).forEach((id) => { const l = Array.isArray(o[id]) ? o[id].map(Number) : []; if (l.includes(pick) && !l.includes(0)) o[id] = l.concat(0); });
        GM_setValue('js-sms-sent', JSON.stringify(o));
      } catch (e) { /* best-effort */ }
      try {
        const o = JSON.parse(GM_getValue('ia-sent-times', '{}')) || {};
        if (o && o.t && typeof o.t === 'object') {
          Object.keys(o.t).forEach((id) => { const v = o.t[id] && o.t[id][pick]; if (v && !o.t[id][0]) o.t[id][0] = v; });
          GM_setValue('ia-sent-times', JSON.stringify(o));
        }
      } catch (e) { /* best-effort */ }
    }
  }
  function smsTemplates() {
    smsOneTemplate();
    let t = null;
    try { t = JSON.parse(GM_getValue(SMS_TPL_KEY, 'null')); } catch (e) { t = null; }
    if (!Array.isArray(t) || t.length !== SMS_DEFAULT_TPL.length) t = SMS_DEFAULT_TPL.map((x, i) => (t && t[i] && typeof t[i].text === 'string') ? { name: String(t[i].name || x.name), text: t[i].text } : Object.assign({}, x));
    return t;
  }
  function saveSmsTemplates(t) { try { GM_setValue(SMS_TPL_KEY, JSON.stringify(t)); } catch (e) { /* best-effort */ } }

  function smsAgentName() {
    const el = document.querySelector('.customer-bar-agent-name');
    const n = el && el.textContent.trim();
    if (n) return n;
    const lbl = Array.from(document.querySelectorAll('div.font-medium')).find((d) => /#\d+\s*$/.test(d.textContent) && d.children.length === 0);
    return lbl ? lbl.textContent.replace(/#\d+\s*$/, '').trim() : '';
  }

  function smsLeadDestCode(leadId) {
    const tag = Array.from(document.querySelectorAll('span')).find((sp) => sp.textContent.trim() === '#' + leadId);
    let root = tag;
    for (let i = 0; i < 12 && root; i++) {
      root = root.parentElement;
      if (root && root.querySelectorAll('.text-base.leading-6.font-semibold').length >= 2) break;
    }
    const codes = root ? Array.from(root.querySelectorAll('.text-base.leading-6.font-semibold')).map((e) => e.textContent.trim()).filter((c) => /^[A-Z]{3}$/.test(c)) : [];
    return codes.length >= 2 ? codes[1] : (codes[0] || '');
  }
  function smsDestination(leadId) {
    const code = smsLeadDestCode(leadId);
    return SMS_CITY[code] || code;
  }

  // The client's name on the lead (click-to-copy name), else from the chat.
  function smsClientName(chat) {
    const cp = Array.from(document.querySelectorAll('span')).find((sp) => sp.classList.contains('cursor-[copy]') && /^[\p{L}][\p{L} .'-]*$/u.test(sp.textContent.trim()));
    if (cp) return cp.textContent.trim();
    const a = chat.querySelector('.chat__message--not-me:not(.chat__message--system):not(.ia-sms-msg) .chat__message__author');
    if (a) return a.textContent.replace(/\+[\d*]+/, '').trim();
    const d = chat.querySelector('.chat__system-message__description');
    const m = d && d.textContent.match(/\(([^)]+)\)/);
    return m ? m[1].trim() : '';
  }
  function smsMaskedNumber(chat) {
    const el = chat.querySelector('.chat__message__author, .chat__system-message__description');
    const m = el && el.textContent.match(/\+[\d*]{6,}/);
    if (m) return m[0];
    const cell = smsPhoneCell();
    return cell ? cell.textContent.trim() : '';
  }

  function smsFill(text, leadId, chat) {
    const client = smsClientName(chat).split(/\s+/)[0] || '';
    return text
      .replace(/\{agent\}/gi, smsAgentName())
      .replace(/\{destination\}/gi, smsDestination(leadId) || 'your destination')
      .replace(/\{client\}/gi, client || 'there')
      .replace(/[ \t]{2,}/g, ' ');
  }

  // The lead's phone number on the page. Any country, any format
  // ("+1302****569", "+52 55 3233 7745", "(302) 312-4569"...). Masked until
  // clicked once. The click-to-reveal element in the customer bar is
  // preferred; anything clickable that looks like a phone number is next.
  const SMS_PHONE_LIKE = /^\+?[\d*][\d*\s().-]{5,}[\d*]$/;
  function smsPhoneText(el) { return (el.textContent || '').replace(/ /g, ' ').trim(); }
  function smsLooksPhone(t) { return SMS_PHONE_LIKE.test(t) && t.replace(/[^\d*]/g, '').length >= 7 && t.replace(/[^\d*]/g, '').length <= 16; }
  function smsIsRevealed(t) { return smsLooksPhone(t) && t.indexOf('*') < 0; }
  function smsPhoneCell() {
    const all = Array.from(document.querySelectorAll('.cursor-pointer')).filter((el) => el.children.length === 0 && smsLooksPhone(smsPhoneText(el)) && !el.closest('.chat, .ia-sms, .ia-widget, table'));
    return all.find((el) => el.classList.contains('truncate') && el.classList.contains('ml-2'))
      || all.find((el) => el.classList.contains('truncate'))
      || all[0] || null;
  }
  function smsNormalizeNumber(t) {
    const d = String(t || '').replace(/\D/g, '');
    if (!d) return null;
    if (/^\s*\+/.test(t)) return '+' + d;
    if (d.length === 10) return '+1' + d; // US/Canada written without +1
    if (d.length === 11 && d.charAt(0) === '1') return '+' + d;
    return '+' + d;
  }
  const smsNumbers = new Map(); // leadId -> full number (this page session only)
  async function smsRevealNumber(leadId) {
    if (smsNumbers.has(leadId)) return smsNumbers.get(leadId);
    let t = null;
    for (let attempt = 0; attempt < 2 && !t; attempt++) {
      const cell = smsPhoneCell();
      if (!cell) {
        const tel = document.querySelector('a[href^="tel:"]');
        if (tel) t = decodeURIComponent(tel.getAttribute('href').slice(4));
        break;
      }
      const now = smsPhoneText(cell);
      if (smsIsRevealed(now)) { t = now; break; }
      cell.click();
      const end = Date.now() + 6000;
      while (Date.now() < end) {
        await new Promise((r) => setTimeout(r, 150));
        const c2 = smsPhoneCell();
        const v = c2 ? smsPhoneText(c2) : '';
        if (smsIsRevealed(v)) { t = v; break; }
      }
    }
    const num = smsNormalizeNumber(t);
    if (!num) return null;
    smsNumbers.set(leadId, num);
    return num;
  }

  // --- Bridge to the RingCentral panel (PART 8 answers inside it) ------
  let smsReqSeq = 0;
  const smsPending = new Map();
  function smsRc(op, args, timeoutMs) {
    return new Promise((resolve) => {
      const frame = document.getElementById('rc-widget-adapter-frame');
      if (!frame || !frame.contentWindow) { resolve({ ok: false, error: 'loading' }); return; }
      const id = 'sms' + (++smsReqSeq) + '-' + Date.now();
      const timer = setTimeout(() => { smsPending.delete(id); resolve({ ok: false, error: 'loading' }); }, timeoutMs || 15000);
      smsPending.set(id, (res) => { clearTimeout(timer); resolve(res); });
      try { frame.contentWindow.postMessage(Object.assign({ __jsSms: 1, id, op }, args || {}), SMS_RC_ORIGIN); } catch (e) { clearTimeout(timer); smsPending.delete(id); resolve({ ok: false, error: 'loading' }); }
    });
  }
  pageWin.addEventListener('message', (e) => {
    if (e.origin !== SMS_RC_ORIGIN) return;
    const d = e.data;
    if (!d || typeof d !== 'object') return;
    if (d.__jsSmsRes && smsPending.has(d.id)) { const cb = smsPending.get(d.id); smsPending.delete(d.id); cb(d); return; }
    if (d.type === 'rc-login-status-notify') { smsStatus = null; smsRefreshAll(true); return; }
    if (d.type === 'rc-message-updated-notify' || d.type === 'rc-inbound-message-notify') smsRefreshAll(false);
  });
  function smsRcCommand(msg) {
    const frame = document.getElementById('rc-widget-adapter-frame');
    if (frame && frame.contentWindow) frame.contentWindow.postMessage(msg, SMS_RC_ORIGIN);
  }
  // Opens this number's conversation in the RingCentral panel (leaving any
  // other screen first, so the conversation shown is always a fresh one).
  async function smsRcOpen(num, text) {
    smsRcCommand({ type: 'rc-adapter-navigate-to', path: '/messages' });
    await new Promise((r) => setTimeout(r, 350));
    await smsRc('mark', {}, 4000);
    const m = { type: 'rc-adapter-new-sms', phoneNumber: num, conversation: true };
    if (text) m.text = text;
    smsRcCommand(m);
  }
  // Reads the conversation. Re-opens it only when it isn't already the one
  // on the RingCentral screen, and never while you're using the floating
  // panel yourself (unless asked to, e.g. when the RC tab is opened).
  async function smsRcRead(num, mayOpen) {
    const r = await smsRc('read', { phone: num }, 8000);
    if (r.ok && r.data && r.data.match) return r;
    const panelOpen = document.documentElement.getAttribute('data-ia-rc') === 'open';
    if (!mayOpen && panelOpen) return r.ok ? { ok: true, data: { list: null } } : r;
    if (!r.ok && r.error !== 'nopanel') return r;
    await smsRcOpen(num);
    return smsRc('read', { phone: num, fresh: true }, 30000);
  }

  // RingCentral status: { signedIn } (read from the panel itself)
  let smsStatus = null;
  let smsStatusAt = 0;
  async function smsGetStatus(force) {
    if (!force && smsStatus && smsStatus.signedIn && Date.now() - smsStatusAt < 60 * 1000) return smsStatus;
    const r = await smsRc('status', {}, 3000);
    if (r.ok) { smsStatus = r.data; smsStatusAt = Date.now(); return smsStatus; }
    return { signedIn: false, loading: true };
  }

  // --- Rendering -------------------------------------------------------
  function smsEsc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function smsNorm(s) { return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
  function smsTime(iso) { const d = new Date(iso); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
  function smsDay(iso) { return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }
  function smsInitials(name) { const p = String(name || '').trim().split(/\s+/).filter(Boolean); return ((p[0] || '?')[0] + (p[1] ? p[1][0] : '')).toUpperCase(); }

  // Messages the BO already shows (so RingCentral's copy isn't doubled).
  function smsBoCounts(chat) {
    const counts = new Map();
    chat.querySelectorAll('.chat__message:not(.chat__message--system):not(.ia-sms-msg)').forEach((m) => {
      const part = m.querySelector('.chat__message__part');
      if (!part) return;
      const k = (m.classList.contains('chat__message--my-side') ? 'O|' : 'I|') + smsNorm(part.textContent);
      counts.set(k, (counts.get(k) || 0) + 1);
    });
    return counts;
  }

  // RingCentral texts the BO hasn't shown yet, oldest first. Only ones
  // newer than the last text both sides agree on, so nothing lands out of
  // order under the BO's history.
  function smsUnsynced(chat, list) {
    const counts = smsBoCounts(chat);
    const sorted = list.slice().sort((a, b) => new Date(a.time) - new Date(b.time));
    let lastMatched = -1;
    const flags = sorted.map((m, i) => {
      const k = (m.dir === 'Outbound' ? 'O|' : 'I|') + smsNorm(m.text);
      const c = counts.get(k) || 0;
      if (c > 0) { counts.set(k, c - 1); lastMatched = i; return true; }
      return false;
    });
    return sorted.filter((m, i) => !flags[i] && i > lastMatched);
  }

  function smsScopeAttr(chat, sel) {
    const el = chat.querySelector(sel);
    if (!el) return '';
    return Array.from(el.attributes).filter((a) => /^data-v-/.test(a.name)).map((a) => a.name + '=""').join(' ');
  }

  function smsBubble(m, ctx) {
    const mine = m.dir === 'Outbound';
    const state = m.state === 'sending' ? ' <span class="ia-sms-state">Sending…</span>'
      : m.state === 'failed' ? ' <span class="ia-sms-state ia-sms-state--err" title="' + smsEsc(m.error || '') + '">Not sent — click to retry</span>'
      : (m.status === 'SendingFailed' || m.status === 'DeliveryFailed') ? ' <span class="ia-sms-state ia-sms-state--err">Failed</span>' : '';
    const author = mine ? smsEsc(ctx.agent) : smsEsc((ctx.client ? ctx.client + ' ' : '') + ctx.masked);
    const avatar = mine ? '' : '<div class="rounded-full flex items-center justify-center font-bold chat__message__avatar" style="background: rgb(243, 156, 18); color: rgb(255, 255, 255); width: 24px; height: 24px;">' + smsEsc(smsInitials(ctx.client)) + '</div>';
    return '<div class="chat__message ' + (mine ? 'chat__message--my-side' : 'chat__message--not-me') + ' chat__message--last-in-group ia-sms-msg' + (m.state ? ' ia-sms-msg--' + m.state : '') + '" data-ia-local="' + smsEsc(m.localId || '') + '">'
      + '<div class="chat__message__body"><div class="chat__message__author">' + author + '<span class="ia-sms-tag">RC</span></div>'
      + '<div class="chat__message__text"><span class="chat__message__part">' + smsEsc(m.text) + '</span><span class="chat__message__time"> ' + smsTime(m.time) + state + ' </span></div></div>'
      + avatar + '</div>';
  }

  const smsLocal = new Map(); // leadId -> messages typed here that RC hasn't listed yet

  // Which history the RC tab shows: 'rc' = your full RingCentral chat
  // (default), 'bo' = the BO's own history (calls, summaries) plus any
  // RingCentral texts the BO hasn't synced yet. Remembered.
  const SMS_VIEW_KEY = 'js-sms-view';
  function smsView() { try { return GM_getValue(SMS_VIEW_KEY, 'rc') === 'bo' ? 'bo' : 'rc'; } catch (e) { return 'rc'; } }

  // Where texts go: the BO's message list, or, on a lead the BO has no
  // history for ("No messages"), a list of our own in the chat area.
  function smsMessageBox(chat) {
    const own = chat.querySelector('.chat__messages');
    if (own) { const extra = chat.querySelector(':scope .ia-sms-ownbox'); if (extra && extra !== own) extra.remove(); return own; }
    let box = chat.querySelector('.ia-sms-ownbox');
    if (box && box.isConnected) return box;
    const host = chat.querySelector('.chat__body') || chat.querySelector('.chat__body-wrapper') || chat.querySelector('.chat__screen');
    if (!host) return null;
    box = document.createElement('div');
    box.className = 'ia-sms-ownbox';
    const bar = host.classList.contains('chat__screen') ? host.querySelector(':scope > .chat__input') : null;
    if (bar) host.insertBefore(box, bar); else host.appendChild(box);
    return box;
  }
  // The BO's own "No messages" placeholder is hidden while texts show.
  function smsToggleEmpty(chat, hasTexts) {
    chat.querySelectorAll('.chat__screen *').forEach((el) => {
      if (el.children.length || el.closest('.ia-sms, .ia-sms-live, .ia-sms-ownbox')) return;
      if (/^no messages\.?$/i.test(el.textContent.trim())) el.classList.toggle('ia-sms-hidden', hasTexts);
    });
  }

  function smsRenderLive(chat, leadId, list) {
    const box = smsMessageBox(chat);
    if (!box) return;
    const rcView = smsView() === 'rc';
    chat.classList.toggle('ia-sms-rcview', rcView);
    const tg = chat.querySelector('.js-sms-view');
    if (tg) tg.textContent = rcView ? 'Show BO history' : 'Show RingCentral chat';
    let live = box.querySelector(':scope > .ia-sms-live');
    const shown = rcView ? (list || []) : smsUnsynced(chat, list || []);
    // A text sent from here stays as its own bubble until RingCentral lists it.
    const outs = (list || []).filter((x) => x.dir === 'Outbound');
    const lastOut = outs[outs.length - 1];
    const listedByRc = (m) => (lastOut && smsNorm(lastOut.text) === smsNorm(m.text)) || outs.some((x) => smsNorm(x.text) === smsNorm(m.text) && new Date(x.time) >= new Date(m.time) - 600000);
    const locals = (smsLocal.get(leadId) || []).filter((m) => m.state !== 'sent' || !listedByRc(m));
    smsLocal.set(leadId, locals);
    const all = shown.concat(locals).sort((a, b) => new Date(a.time) - new Date(b.time));
    const ctx = { agent: smsAgentName(), client: smsClientName(chat), masked: smsMaskedNumber(chat) };
    const dayAttr = smsScopeAttr(chat, '.chat__day');
    const innerAttr = smsScopeAttr(chat, '.chat__day__inner');
    const days = Array.from(chat.querySelectorAll('.chat__day__inner:not(.ia-sms-day)'));
    let lastDay = rcView ? '' : (days.length ? days[days.length - 1].textContent.trim() : '');
    let html = '';
    all.forEach((m) => {
      const d = smsDay(m.time);
      if (d !== lastDay) { html += '<div ' + dayAttr + ' class="chat__day"><div ' + innerAttr + ' class="chat__day__inner ia-sms-day">' + d + '</div></div>'; lastDay = d; }
      html += smsBubble(m, ctx);
    });
    if (rcView) {
      const note = chat.__jsSmsNote || (list == null ? 'Loading your RingCentral chat\u2026' : (!html ? 'No texts with this number in RingCentral yet' : ''));
      if (note && !(list && list.length) && !all.length) html = '<div class="ia-sms-note">' + smsEsc(note) + '</div>';
    }
    smsUpdateChips(chat, leadId);
    smsToggleEmpty(chat, !!html);
    if (!html) { if (live) live.remove(); return; }
    if (!live) {
      live = document.createElement('div');
      live.className = 'ia-sms-live';
      live.addEventListener('click', (e) => {
        const b = e.target.closest('.ia-sms-msg--failed');
        if (!b) return;
        const lid = b.getAttribute('data-ia-local');
        const m = (smsLocal.get(leadId) || []).find((x) => x.localId === lid);
        if (m) smsSend(chat, leadId, m.text, m);
      });
    }
    const summary = Array.from(box.children).find((c) => c !== live && c.classList.contains('mt-5') && c.querySelector('button'));
    if (summary) { if (live.nextSibling !== summary || live.parentNode !== box) box.insertBefore(live, summary); }
    else if (live.parentNode !== box || box.lastElementChild !== live) box.appendChild(live);
    if (live.getAttribute('data-ia-html') !== String(html.length) + '|' + html.slice(-80)) {
      live.innerHTML = html;
      live.setAttribute('data-ia-html', String(html.length) + '|' + html.slice(-80));
      const scroller = chat.querySelector('.chat__body');
      if (scroller) scroller.scrollTop = scroller.scrollHeight;
    }
  }

  // --- Composer --------------------------------------------------------
  function smsComposerHtml() {
    const t = smsTemplates();
    return '<div class="ia-sms-chips">' + t.map((x, i) => '<span class="ia-sms-chip" data-i="' + i + '" title="' + smsEsc(x.text) + '"><span class="ia-sms-chip__tick" hidden>\u2713</span><span class="ia-sms-chip__name">' + smsEsc(x.name) + '</span><span class="ia-sms-chip__edit" title="Edit template">✎</span></span>').join('') + '</div>'
      + '<div class="ia-sms-editor" hidden><input class="ia-sms-ed-name" maxlength="24"><textarea class="ia-sms-ed-text" rows="3"></textarea>'
      + '<div class="ia-sms-ed-row"><span class="ia-sms-hint">{agent} · {destination} · {client}</span><button type="button" class="ia-sms-btn ia-sms-ed-reset">Reset</button><button type="button" class="ia-sms-btn ia-sms-ed-cancel">Cancel</button><button type="button" class="ia-sms-btn ia-sms-btn--go ia-sms-ed-save">Save</button></div></div>'
      + '<div class="ia-sms-row"><textarea class="ia-sms-text" rows="2" placeholder="Type a message…"></textarea><button type="button" class="ia-sms-btn ia-sms-btn--go ia-sms-send">Send</button></div>'
      + '<div class="ia-sms-foot"><span class="ia-sms-status"></span><span class="ia-sms-via">via RingCentral \u00B7 ' + IA_MOD + '+Enter to send</span><button type="button" class="js-sms-view"></button></div>';
  }

  function smsSetStatusLine(comp, text, err) {
    const s = comp.querySelector('.ia-sms-status');
    s.textContent = text || '';
    s.classList.toggle('ia-sms-status--err', !!err);
  }

  async function smsApplyStatus(comp, force) {
    const st = await smsGetStatus(force);
    const btn = comp.querySelector('.ia-sms-send');
    comp.dataset.signed = st.signedIn ? '1' : '';
    if (!st.signedIn) {
      btn.textContent = st.loading ? 'RingCentral loading\u2026' : 'Sign in to RingCentral';
      btn.classList.add('ia-sms-btn--signin');
      smsSetStatusLine(comp, st.loading ? '' : 'RingCentral is signed out', !st.loading);
      return st;
    }
    btn.textContent = 'Send';
    btn.classList.remove('ia-sms-btn--signin');
    if (comp.querySelector('.ia-sms-status').textContent === 'RingCentral is signed out') smsSetStatusLine(comp, '');
    return st;
  }

  async function smsLoad(chat, leadId, quiet, mayOpen) {
    const comp = chat.querySelector('.ia-sms');
    if (!comp || comp.dataset.busy) return;
    const st = await smsApplyStatus(comp, false);
    chat.__jsSmsNote = st.signedIn || st.loading ? '' : 'Sign in to RingCentral to see the chat';
    if (!st.signedIn) {
      smsRenderLive(chat, leadId, chat.__jsSmsList);
      // RingCentral still starting up: try again shortly.
      if (st.loading && (chat.__jsSmsRetry = (chat.__jsSmsRetry || 0) + 1) < 60) setTimeout(() => smsLoad(chat, leadId, quiet, mayOpen), 2000);
      return;
    }
    chat.__jsSmsRetry = 0;
    const num = await smsRevealNumber(leadId);
    if (!num) {
      if (!quiet) smsSetStatusLine(comp, 'Couldn\u2019t read the lead\u2019s phone number', true);
      chat.__jsSmsNote = 'Couldn\u2019t read the lead\u2019s phone number';
      smsRenderLive(chat, leadId, chat.__jsSmsList);
      return;
    }
    const r = await smsRcRead(num, mayOpen);
    if (!r.ok) {
      if (r.error === 'signedout') { smsStatus = null; smsApplyStatus(comp, true); return; }
      if (!quiet) smsSetStatusLine(comp, 'Couldn\u2019t load the RingCentral conversation', true);
      if (!chat.__jsSmsList) { chat.__jsSmsNote = 'Couldn\u2019t load the RingCentral conversation \u2014 it will retry'; smsRenderLive(chat, leadId, chat.__jsSmsList); }
      return;
    }
    if (!r.data || !r.data.list) return; // you're using the RC panel: keep what's shown
    if (comp.querySelector('.ia-sms-status--err')) smsSetStatusLine(comp, '');
    chat.__jsSmsList = r.data.list;
    chat.__jsSmsNote = '';
    smsRenderLive(chat, leadId, r.data.list);
  }

  async function smsSend(chat, leadId, text, retryOf) {
    const comp = chat.querySelector('.ia-sms');
    if (!comp || comp.dataset.busy) return;
    text = String(text || '').trim();
    if (!text) return;
    comp.dataset.busy = '1';
    const btn = comp.querySelector('.ia-sms-send');
    btn.disabled = true;
    try {
      const st = await smsApplyStatus(comp, true);
      if (!st.signedIn) return;
      const num = await smsRevealNumber(leadId);
      if (!num) { smsSetStatusLine(comp, 'Couldn\u2019t read the lead\u2019s phone number', true); return; }
      const locals = smsLocal.get(leadId) || [];
      const msg = retryOf || { localId: 'l' + Date.now(), dir: 'Outbound', text, time: new Date().toISOString() };
      msg.state = 'sending';
      msg.time = new Date().toISOString();
      if (!retryOf) { locals.push(msg); smsLocal.set(leadId, locals); comp.querySelector('.ia-sms-text').value = ''; smsGrow(comp.querySelector('.ia-sms-text')); }
      smsRenderLive(chat, leadId, chat.__jsSmsList);
      await smsRcOpen(num, text);
      const r = await smsRc('send', { phone: num, text }, 45000);
      if (r.ok) {
        msg.state = 'sent';
        smsSetStatusLine(comp, 'Sent via RingCentral \u2713');
        if (comp.dataset.tpl && smsKey(text).indexOf(comp.dataset.tplKey) === 0) smsRememberSent(leadId, +comp.dataset.tpl);
        setTimeout(() => { if (comp.querySelector('.ia-sms-status').textContent.indexOf('Sent') === 0) smsSetStatusLine(comp, ''); }, 4000);
        if (r.data && r.data.list) chat.__jsSmsList = r.data.list;
      } else if (r.error === 'unconfirmed' || r.error === 'loading') {
        // Might have gone out: never offer a one-click resend for this one.
        msg.state = 'sent';
        smsSetStatusLine(comp, r.message || 'RingCentral didn\u2019t confirm \u2014 check the RC panel before resending', true);
      } else {
        msg.state = 'failed';
        msg.error = r.message || '';
        smsSetStatusLine(comp, r.message || 'Not sent', true);
        if (r.error === 'signedout') { smsStatus = null; smsApplyStatus(comp, true); }
      }
      smsRenderLive(chat, leadId, chat.__jsSmsList);
    } finally {
      delete comp.dataset.busy;
      btn.disabled = false;
    }
  }

  function smsOpenEditor(comp, i) {
    const t = smsTemplates();
    const ed = comp.querySelector('.ia-sms-editor');
    ed.hidden = false;
    ed.dataset.i = String(i);
    ed.querySelector('.ia-sms-ed-name').value = t[i].name;
    ed.querySelector('.ia-sms-ed-text').value = t[i].text;
    smsGrow(ed.querySelector('.ia-sms-ed-text'));
    ed.querySelector('.ia-sms-ed-text').focus();
  }
  // Follow-ups already sent to this lead are greyed out (with a tick), and
  // the next one to send is highlighted. "Sent" = remembered from sending
  // it here, or found among your texts in the chat (RingCentral or BO).
  const SMS_SENT_KEY = 'js-sms-sent';
  const smsKey = (t) => String(t || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  function smsSentMemory() { try { const o = JSON.parse(GM_getValue(SMS_SENT_KEY, '{}')); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
  // When each follow-up went out: { t: { leadId: { index: time } } }.
  // Older sends (before this was added) have no time and just say "Sent".
  const IA_SENT_TIMES_KEY = 'ia-sent-times';
  function iaSentTimes() { try { const o = JSON.parse(GM_getValue(IA_SENT_TIMES_KEY, '{}')); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
  function iaSentAt(kind, leadId, i) { const o = iaSentTimes(); return ((o[kind] || {})[leadId] || {})[i] || null; }
  function iaMarkSentTime(kind, leadId, i) {
    const o = iaSentTimes();
    o[kind] = o[kind] || {};
    o[kind][leadId] = o[kind][leadId] || {};
    o[kind][leadId][i] = Date.now();
    try { GM_setValue(IA_SENT_TIMES_KEY, JSON.stringify(o)); } catch (e) { /* best-effort */ }
  }
  // "Sent 2 hrs ago"
  function iaAgo(ts) {
    if (!ts) return 'Sent';
    const m = Math.max(0, Math.round((Date.now() - ts) / 60000));
    if (m < 1) return 'Sent just now';
    if (m < 60) return 'Sent ' + m + ' min ago';
    if (m < 1440) { const h = Math.floor(m / 60); return 'Sent ' + h + (h === 1 ? ' hr ago' : ' hrs ago'); }
    const d = Math.floor(m / 1440);
    return 'Sent ' + d + (d === 1 ? ' day ago' : ' days ago');
  }
  function smsRememberSent(leadId, i) {
    iaMarkSentTime('t', leadId, i);
    const o = smsSentMemory();
    const list = Array.isArray(o[leadId]) ? o[leadId] : [];
    if (!list.includes(i)) list.push(i);
    delete o[leadId];
    o[leadId] = list;
    // Never trimmed: every lead's progress is kept for good.
    try { GM_setValue(SMS_SENT_KEY, JSON.stringify(o)); } catch (e) { /* best-effort */ }
  }
  // --- Saved-work protection ---------------------------------------------
  // The follow-up history only ever grows, so if it suddenly comes back
  // empty or far smaller than yesterday's backup (Chrome clean-up, a bad
  // sync), the backup is merged back in. Merging never removes anything.
  // A backup is kept for each of the last 7 days. Never rename these keys.
  const IA_PROTECTED = [SMS_SENT_KEY, IA_SENT_TIMES_KEY];
  (function iaGuardSavedWork() {
    if (window.top !== window) return;
    const read = (k) => { try { const o = JSON.parse(GM_getValue(k, '{}')); return o && typeof o === 'object' && !Array.isArray(o) ? o : {}; } catch (e) { return {}; } };
    const count = (k, o) => (k === IA_SENT_TIMES_KEY ? Object.keys(o.t || {}).length : Object.keys(o).length);
    const merge = (k, cur, add) => {
      if (!add || typeof add !== 'object') return cur;
      if (k === IA_SENT_TIMES_KEY) {
        const a = add.t || {}; cur.t = cur.t || {};
        Object.keys(a).forEach((id) => { cur.t[id] = Object.assign({}, a[id], cur.t[id] || {}); });
      } else {
        Object.keys(add).forEach((id) => {
          if (!Array.isArray(add[id])) return;
          const l = Array.isArray(cur[id]) ? cur[id] : [];
          add[id].forEach((i) => { if (!l.includes(Number(i))) l.push(Number(i)); });
          cur[id] = l;
        });
      }
      return cur;
    };
    let days = {};
    try { days = JSON.parse(GM_getValue('ia-backup-days', '{}')) || {}; } catch (e) { days = {}; }
    const latest = Object.keys(days).sort().pop();
    const snap = latest && days[latest];
    if (snap) IA_PROTECTED.forEach((k) => {
      const had = count(k, snap[k] || {});
      const cur = read(k);
      if (had >= 5 && count(k, cur) < had * 0.5) { try { GM_setValue(k, JSON.stringify(merge(k, cur, snap[k]))); } catch (e) { /* ignore */ } }
    });
    const day = new Date().toISOString().slice(0, 10);
    if (!days[day]) {
      days[day] = {};
      IA_PROTECTED.forEach((k) => { days[day][k] = read(k); });
      Object.keys(days).sort().slice(0, -7).forEach((d) => delete days[d]);
      try { GM_setValue('ia-backup-days', JSON.stringify(days)); } catch (e) { /* ignore */ }
    }
  })();

  function smsSentSet(chat, leadId) {
    const sent = new Set((smsSentMemory()[leadId] || []).map(Number));
    const outs = [];
    (chat.__jsSmsList || []).forEach((m) => { if (m.dir === 'Outbound') outs.push(smsKey(m.text)); });
    (smsLocal.get(leadId) || []).forEach((m) => { if (m.state === 'sent') outs.push(smsKey(m.text)); });
    chat.querySelectorAll('.chat__message--my-side:not(.ia-sms-msg) .chat__message__part').forEach((p) => outs.push(smsKey(p.textContent)));
    smsTemplates().forEach((t, i) => {
      const k = smsKey(smsFill(t.text, leadId, chat)).slice(0, 60);
      if (k.length >= 20 && outs.some((o) => o.indexOf(k) === 0)) sent.add(i);
    });
    return sent;
  }
  function smsUpdateChips(chat, leadId) {
    const comp = chat.querySelector('.ia-sms');
    if (!comp) return;
    const sent = smsSentSet(chat, leadId);
    const chips = Array.from(comp.querySelectorAll('.ia-sms-chip'));
    const next = chips.find((c) => !sent.has(+c.dataset.i));
    chips.forEach((c) => {
      const isSent = sent.has(+c.dataset.i);
      c.classList.toggle('ia-sms-chip--sent', isSent);
      c.classList.toggle('ia-sms-chip--next', c === next);
      const tick = c.querySelector('.ia-sms-chip__tick');
      if (tick) tick.hidden = !isSent;
      let ago = c.querySelector('.ia-sms-chip__ago');
      if (isSent && !ago) { ago = document.createElement('span'); ago.className = 'ia-sms-chip__ago'; const nm = c.querySelector('.ia-sms-chip__name'); if (nm) nm.after(ago); }
      if (ago) { const txt = isSent ? iaAgo(iaSentAt('t', leadId, +c.dataset.i)) : ''; if (ago.textContent !== txt) ago.textContent = txt; ago.hidden = !isSent; }
    });
  }
  function smsRefreshChips() {
    document.querySelectorAll('.ia-sms').forEach((comp) => {
      const t = smsTemplates();
      comp.querySelectorAll('.ia-sms-chip').forEach((c) => {
        const x = t[+c.dataset.i];
        if (!x) return;
        c.querySelector('.ia-sms-chip__name').textContent = x.name;
        c.title = x.text;
      });
      const chat = comp.closest('.chat[id^="sms-chat-"]');
      if (chat) smsUpdateChips(chat, chat.id.replace('sms-chat-', ''));
    });
  }
  try { GM_addValueChangeListener(SMS_TPL_KEY, () => smsRefreshChips()); } catch (e) { /* other tabs refresh on reload */ }

  // Message boxes grow with the text instead of scrolling inside.
  function smsGrow(ta) {
    ta.style.height = 'auto';
    ta.style.height = (ta.scrollHeight + 2) + 'px';
  }

  function smsWire(comp, chat, leadId) {
    comp.addEventListener('click', (e) => {
      const ed = comp.querySelector('.ia-sms-editor');
      const edit = e.target.closest('.ia-sms-chip__edit');
      if (edit) { smsOpenEditor(comp, +edit.closest('.ia-sms-chip').dataset.i); return; }
      const chip = e.target.closest('.ia-sms-chip');
      if (chip) {
        const ta = comp.querySelector('.ia-sms-text');
        ta.value = smsFill(smsTemplates()[+chip.dataset.i].text, leadId, chat);
        smsGrow(ta);
        comp.dataset.tpl = chip.dataset.i;
        comp.dataset.tplKey = smsKey(ta.value).slice(0, 40);
        ta.focus();
        ta.setSelectionRange(ta.value.length, ta.value.length);
        return;
      }
      if (e.target.closest('.js-sms-view')) {
        try { GM_setValue(SMS_VIEW_KEY, smsView() === 'rc' ? 'bo' : 'rc'); } catch (er) { /* ignore */ }
        smsRenderLive(chat, leadId, chat.__jsSmsList);
        return;
      }
      if (e.target.closest('.ia-sms-ed-cancel')) { ed.hidden = true; return; }
      if (e.target.closest('.ia-sms-ed-reset')) {
        const d = SMS_DEFAULT_TPL[+ed.dataset.i];
        ed.querySelector('.ia-sms-ed-name').value = d.name;
        ed.querySelector('.ia-sms-ed-text').value = d.text;
        return;
      }
      if (e.target.closest('.ia-sms-ed-save')) {
        const t = smsTemplates();
        const i = +ed.dataset.i;
        t[i] = { name: ed.querySelector('.ia-sms-ed-name').value.trim() || SMS_DEFAULT_TPL[i].name, text: ed.querySelector('.ia-sms-ed-text').value };
        saveSmsTemplates(t);
        ed.hidden = true;
        smsRefreshChips();
        return;
      }
      if (e.target.closest('.ia-sms-send')) {
        if (!comp.dataset.signed) {
          if (typeof setRcPanelOpen === 'function') setRcPanelOpen(true);
          smsStatus = null;
          setTimeout(() => smsLoad(chat, leadId, false, true), 1500);
          return;
        }
        smsSend(chat, leadId, comp.querySelector('.ia-sms-text').value);
      }
    });
    comp.querySelectorAll('textarea').forEach((t) => t.addEventListener('input', () => smsGrow(t)));
    comp.querySelector('.ia-sms-text').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); comp.querySelector('.ia-sms-send').click(); }
    });
  }

  function smsChats() {
    return Array.from(document.querySelectorAll('.chat[id^="sms-chat-"]')).filter((c) => c.getClientRects().length);
  }

  function smsScan() {
    document.querySelectorAll('.chat[id^="sms-chat-"]').forEach((chat) => {
      const leadId = chat.id.replace('sms-chat-', '');
      if (!/^\d+$/.test(leadId)) return;
      const bar = Array.from(chat.querySelectorAll('.chat__input')).find((b) => !b.classList.contains('ia-sms') && /only view this chat/i.test(b.textContent));
      let comp = chat.querySelector('.ia-sms');
      if (bar) {
        bar.classList.add('ia-sms-hidden');
        if (!comp || comp.previousElementSibling !== bar) {
          if (comp) comp.remove();
          comp = document.createElement('div');
          comp.className = 'ia-sms';
          comp.innerHTML = smsComposerHtml();
          bar.insertAdjacentElement('afterend', comp);
          smsWire(comp, chat, leadId);
          chat.__jsSmsLoadedAt = 0;
          smsRenderLive(chat, leadId, chat.__jsSmsList);
        }
      }
      if (!comp) return;
      if (!chat.querySelector('.ia-sms-live') && (smsView() === 'rc' || (chat.__jsSmsList && smsUnsynced(chat, chat.__jsSmsList).length))) smsRenderLive(chat, leadId, chat.__jsSmsList);
      if (chat.getClientRects().length && !chat.__jsSmsLoadedAt) { chat.__jsSmsLoadedAt = Date.now(); smsLoad(chat, leadId, false, true); }
    });
  }

  let smsRefreshTimer = null;
  function smsRefreshAll(statusToo) {
    if (smsRefreshTimer) clearTimeout(smsRefreshTimer);
    smsRefreshTimer = setTimeout(() => {
      smsRefreshTimer = null;
      smsChats().forEach((chat) => {
        const comp = chat.querySelector('.ia-sms');
        if (!comp) return;
        if (statusToo) { smsStatus = null; smsApplyStatus(comp, true); }
        smsLoad(chat, chat.id.replace('sms-chat-', ''), true, false);
      });
    }, 600);
  }

  __jsRegisterScan(smsScan);
  // Live: refresh every 15s while the RC tab is on screen.
  setInterval(() => { if (!document.hidden && smsChats().some((c) => c.querySelector('.ia-sms'))) smsRefreshAll(false); }, 15000);

  GM_addStyle(`
    .chat__input.ia-sms-hidden, .chat__screen .ia-sms-hidden { display: none !important; }
    .ia-sms-rcview .chat__messages > :not(.ia-sms-live) { display: none !important; }
    .ia-sms-rcview .ia-sms-tag { display: none; }
    .ia-sms-note { padding: 24px 12px; text-align: center; opacity: .7; font-style: italic; }
    .js-sms-view { margin-left: 10px; padding: 1px 8px; border-radius: 4px; border: 1px solid rgba(127,127,127,.4); background: transparent; color: inherit; cursor: pointer; font-size: 11px; font-weight: 600; }
    .js-sms-view:hover { border-color: #3b82f6; color: #3b82f6; }
    .ia-sms { padding: 8px 12px 10px; border-top: 1px solid rgba(127,127,127,.25); font-size: 13px; }
    .ia-sms-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 6px; }
    .ia-sms-chip { display: inline-flex; align-items: center; gap: 6px; padding: 5px 4px 5px 13px; border-radius: 999px;
      border: 1px solid rgba(148,163,184,.55); color: inherit; background: rgba(148,163,184,.12); cursor: pointer;
      font-weight: 600; font-size: 12.5px; line-height: 1; user-select: none; transition: background .15s, border-color .15s, opacity .15s; }
    .ia-sms-chip:hover { border-color: #3b82f6; background: rgba(59,130,246,.18); }
    .ia-sms-chip__edit { display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; border-radius: 999px;
      font-weight: 400; font-size: 12px; opacity: .65; border-left: 0; }
    .ia-sms-chip__edit:hover { opacity: 1; background: rgba(255,255,255,.18); }
    .ia-sms-chip__tick { font-weight: 800; }
    .ia-sms-chip__tick[hidden] { display: none; }
    .ia-sms-chip--next { background: #5b5bd6; border-color: #5b5bd6; color: #fff; box-shadow: 0 1px 6px rgba(37,99,235,.45); }
    .ia-sms-chip--next:hover { background: #1d4ed8; border-color: #1d4ed8; }
    .ia-sms-chip--sent { opacity: 1; background: rgba(34,197,94,.12); border-color: rgba(34,197,94,.55); }
    .ia-sms-chip__ago { margin-left: 2px; font-size: 11px; font-weight: 700; color: #16a34a; white-space: nowrap; }
    .ia-sms-chip__ago[hidden] { display: none; }
    .ia-sms-chip--sent .ia-sms-chip__tick { color: #22c55e; }
    .ia-sms-row { display: flex; gap: 8px; align-items: flex-end; }
    .ia-sms textarea { flex: 1; width: 100%; resize: none; overflow: hidden; box-sizing: border-box; min-height: 38px; padding: 6px 8px; border-radius: 6px;
      border: 1px solid rgba(127,127,127,.4); background: transparent; color: inherit; font: inherit; line-height: 1.35; }
    .ia-sms textarea:focus { outline: none; border-color: #3b82f6; }
    .ia-sms-btn { padding: 6px 12px; border-radius: 6px; border: 1px solid rgba(127,127,127,.4); background: transparent; color: inherit; cursor: pointer; font-weight: 600; font-size: 12px; white-space: nowrap; }
    .ia-sms-btn--go { background: #5b5bd6; border-color: #5b5bd6; color: #fff; }
    .ia-sms-btn--go:hover { background: #4b4bc4; }
    .ia-sms-btn--go:disabled { opacity: .55; cursor: default; }
    .ia-sms-btn--signin { background: #f97316; border-color: #f97316; }
    .ia-sms-btn--signin:hover { background: #ea580c; }
    .ia-sms-foot { display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-top: 4px; min-height: 16px; font-size: 11px; opacity: .85; }
    .ia-sms-status--err { color: #dc2626; }
    .ia-sms-via { margin-left: auto; opacity: .6; }
    .ia-sms-editor { margin-bottom: 8px; padding: 8px; border-radius: 6px; border: 1px dashed rgba(59,130,246,.5); display: flex; flex-direction: column; gap: 6px; }
    .ia-sms-editor[hidden] { display: none; }
    .ia-sms-ed-name { width: 160px; padding: 3px 6px; border-radius: 4px; border: 1px solid rgba(127,127,127,.4); background: transparent; color: inherit; font: inherit; font-weight: 600; }
    .ia-sms-ed-row { display: flex; gap: 6px; align-items: center; }
    .ia-sms-hint { margin-right: auto; font-size: 11px; opacity: .7; font-family: ui-monospace, monospace; }
    .ia-sms-tag { margin-left: 6px; padding: 0 4px; border-radius: 3px; font-size: 9px; font-weight: 700; letter-spacing: .03em; background: rgba(249,115,22,.15); color: #ea580c; vertical-align: middle; }
    .ia-sms-state { font-style: italic; opacity: .8; }
    .ia-sms-state--err { color: #dc2626; font-style: normal; font-weight: 600; }
    .ia-sms-msg--sending { opacity: .6; }
    .ia-sms-msg--failed { cursor: pointer; }
  `);

  function setPanelStatus(text) {
    const el = ensureBmo();
    const statusEl = el.querySelector('.ia-screen-info__status');
    if (!statusEl) return;
    statusEl.textContent = text || '';
    // Collapses to zero height when empty (the common case) instead of
    // reserving its line's worth of space regardless — extra headroom
    // for a long, 2-line name's route to stay visible underneath it.
    statusEl.style.display = text ? '' : 'none';
  }

  // The row currently on display in Pip's screen — the single source of
  // truth for who Call will actually dial. Call never recomputes "who's
  // next" independently of what's shown; it always acts on exactly this
  // reference, so there's no way for what's displayed and what gets dialed
  // to diverge.
  let currentPanelRow = null;
  // Whether that row has ACTUALLY been dialed yet, as opposed to just
  // being queued up. This is what the "Up next" vs "Currently calling"
  // label reflects — a lead shown before any tel: link has fired for them
  // is never labeled as being actively called, even momentarily.
  let currentRowDialed = false;

  function renderPanelForRow(row, dialed) {
    currentPanelRow = row;
    currentRowDialed = !!dialed;
    const el = ensureBmo();
    const face = el.querySelector('.ia-face');
    const info = el.querySelector('.ia-screen-info');
    if (!row) {
      face.style.display = '';
      info.style.display = 'none';
      return;
    }
    face.style.display = 'none';
    info.style.display = '';
    const leadInfo = getLeadInfo(row);
    el.querySelector('.ia-screen-info__label').textContent = dialed ? 'Currently calling' : 'Up next';
    const clientEl = el.querySelector('.ia-screen-info__client');
    clientEl.textContent = leadInfo.clientName || ('Lead ' + leadInfo.leadId);
    clientEl.href = leadInfo.href;
    el.querySelector('.ia-screen-info__route').textContent = [leadInfo.origin, leadInfo.dest].filter(Boolean).join(' \u2192 ');
    setPanelStatus('');
    updateProgress(row);
  }

  // "Lead 4 of 23" — position among this page's leads that have a timer
  // running (the ones the dialer works through); page shown after page 1.
  function updateProgress(row) {
    const out = iaWidget && iaWidget.querySelector('.ia-progress');
    if (!out) return;
    const rows = getLeadRows().filter((r) => hasTimerRunning(r));
    const idx = rows.indexOf(row);
    const pageInput = document.querySelector('.pagination-v2 input[type="number"]');
    const page = pageInput ? parseInt(pageInput.value, 10) : 1;
    out.textContent = idx >= 0 ? 'Lead ' + (idx + 1) + ' of ' + rows.length + (page > 1 ? ' \u00B7 p' + page : '') : '';
  }

  // --- Core call action ---------------------------------------------------
  // The one genuine user gesture Chrome requires per call. Everything
  // inside this handler — the reveal click, reading the number, building
  // and clicking the tel: link — runs from that same gesture, which is
  // what keeps the tel: launch inside Chrome's anti-flood window.
  //
  // Double dial is its own explicit button, not a pre-checked toggle —
  // Call always marks the lead called and advances normally; pressing
  // Double Dial afterward (a separate, equally genuine user gesture, so
  // it's just as valid for Chrome's anti-flood check) redials the number
  // that was JUST called, straight from memory, with no need to re-find
  // or re-reveal anything since it's already known.
  let lastCalledInfo = null; // { number, leadId, href, clientName, origin, dest }
  let lastCalledRow = null;  // that lead's row in the list

  function updateDoubleDialButton() {
    const btn = iaWidget && iaWidget.querySelector('.ia-btn-doubledial');
    if (btn) btn.classList.toggle('ia-btn--disabled', !lastCalledInfo);
  }

  // Guards against a second Call press starting while the first is still
  // mid-flight (revealing, waiting, or in the post-dial pause) — without
  // this, two rapid presses could run two overlapping calls at once, each
  // reading/advancing shared state while the other is still using it.
  let callInFlight = false;

  async function handleCallClick(isAuto) {
    if (callInFlight) return;
    // Pressing Call yourself overrides any "you're on a call" pause.
    if (!isAuto) {
      for (const [k, c] of activeCalls) if (!c.mine) activeCalls.delete(k);
      pendingAutoNext = false;
    }
    clearAutoNext(); // pressing Call during the countdown dials right away
    startAutoRun();
    callInFlight = true;
    try {
      let row = currentPanelRow;
      if (row && !document.body.contains(row)) row = null; // stale reference (e.g. page navigated) -- treat as gone

      // Whoever's shown having ALREADY been dialed is what tells apart
      // "this is a fresh lead, dial it in place" from "this one's done,
      // advance to the next before dialing" — every press after the
      // first one for a given lead lands in the second case, since that
      // first press already flipped currentRowDialed to true.
      let info, number;
      // Loops only to step past leads with a blocked number (e.g.
      // +10000000000) — those are skipped automatically, never dialed.
      for (let guard = 0; guard < 50; guard++) {
        if (!row || currentRowDialed) {
          row = await getNextPendingRow();
          if (!row) {
            // Everything left is in quiet hours: not "all done" — they're
            // still waiting for daytime.
            if (quietSeenInScan) { stopAutoRun(); setPanelStatus('The rest are in quiet hours (22:00\u201308:00)'); return; }
            await onAllLeadsDone();
            return;
          }
          // Shown immediately, labeled "Up next" — not "Currently
          // calling" — since nothing has actually been dialed for them
          // yet at this point.
          renderPanelForRow(row, false);
        }

        info = getLeadInfo(row);
        const phoneCell = findPhoneCell(row);
        if (!phoneCell) { setPanelStatus('Could not find phone cell for this lead'); return; }

        number = phoneCell.textContent.trim();
        if (!PHONE_REVEALED_RE.test(number)) {
          setPanelStatus('Revealing number\u2026');
          phoneCell.click();
          number = await waitForRevealedNumber(phoneCell, 2000);
          if (!number) { setPanelStatus('Number did not reveal in time \u2014 try again'); return; }
        }

        if (BLOCKED_NUMBERS.includes(String(number).replace(/\D/g, ''))) {
          markSkipped(info.leadId);
          currentRowDialed = true; // move past it on the next loop
          continue;
        }
        break;
      }

      if (!isAuto && isQuietTime(rowLocalTime(row)) && !(await confirmQuietCall(rowLocalTime(row)))) {
        setPanelStatus('Call cancelled \u2014 quiet hours');
        return;
      }
      leadRedialed = false;
      dialNumber(number, !isAuto);

      lastCalledInfo = Object.assign({ number }, info);
      lastCalledRow = row;
      updateDoubleDialButton();
      markCalled(info.leadId);
      markStartedToday();
      // NOW, and only now — after the tel: link has actually fired — does
      // the label flip to "Currently calling". Pip's screen then
      // deliberately keeps showing this same lead for however long the
      // real call actually takes, which the script has no way to
      // observe. It only moves on once Call is pressed again — the
      // explicit "I'm done with this one" signal — rather than on a
      // fixed timer that can't know whether the call was even answered,
      // let alone ended.
      //
      // No "Dialed +X" confirmation shown here on purpose now — that
      // used to sit on screen persistently (until the next action),
      // eating into the space the name and route need in the common,
      // successful case. The name/route already update to confirm which
      // lead this was for; the number itself was only ever a bonus, not
      // something this needs to keep displaying.
      renderPanelForRow(row, true);
      if (awaitingCallEnd) setPanelStatus('Dialing\u2026');
    } finally {
      callInFlight = false;
    }
  }

  // Every lead on every page is done for the current round.
  // Level-up only when EVERY lead on EVERY page is green/yellow:
  //  1st Call with nothing left → re-checks all pages from page 1.
  //  2nd Call, still nothing left → Super Pip + round 2 (marks go red).
  async function onAllLeadsDone() {
    stopAutoRun();
    if (pendingScanState === 'pageFail') {
      levelUpArmed = false;
      setPanelStatus('Next page didn\u2019t load \u2014 press Call again');
      return;
    }
    if (getRound() === 1) {
      if (!levelUpArmed) {
        setPanelStatus('Checking all pages\u2026');
        await goToFirstPage();
        const left = await getNextPendingRow();
        if (left) { renderPanelForRow(left, false); setPanelStatus('More leads left \u2014 press Call'); return; }
        if (pendingScanState === 'pageFail') { setPanelStatus('Next page didn\u2019t load \u2014 press Call again'); return; }
        levelUpArmed = true;
        renderPanelForRow(null, false);
        setPanelStatus('All leads called \u2713 Press Call to level up');
        return;
      }
      levelUpArmed = false;
      unlockSuper();
      setRound(2);
      await goToFirstPage();
      renderPanelForRow(await getNextPendingRow(), false);
      setPanelStatus('Round 1 complete \u2014 Round 2: press Call');
    } else {
      renderPanelForRow(null, false);
      setPanelStatus('Round 2 done \u2713');
    }
  }

  // --- Super Pip: rainbow body for finishing the day's follow-up -------
  function superUnlockedToday() {
    try { return !!GM_getValue(SUPER_STORAGE_PREFIX + todayKey(), false); } catch (e) { return false; }
  }
  function applySuperState() {
    // Earned today (first follow-up done) AND actively calling → rainbow.
    // Stopped → back to whatever color the user picked.
    const running = !!(iaWidget && iaWidget.classList.contains('ia-widget--running'));
    if (iaWidget) iaWidget.classList.toggle('ia-widget--super', (superUnlockedToday() && running) || rainbowTheme);
  }
  function unlockSuper() {
    const first = !superUnlockedToday();
    try { GM_setValue(SUPER_STORAGE_PREFIX + todayKey(), true); } catch (e) { /* best-effort */ }
    applySuperState();
    if (first) playLevelUp(true);
  }
  // Rainbow ends by itself when the follow-up day rolls over (2pm GMT).
  setInterval(applySuperState, 60 * 1000);

  // Takes over Pip's screen to unambiguously show who's actually being
  // redialed, then hands it back to whatever Call is next ready for once
  // done — rather than leaving whoever Call last advanced to on screen
  // while this rings a completely different, earlier lead underneath it.
  async function handleDoubleDialClick() {
    if (!lastCalledInfo || callInFlight) return;
    callInFlight = true;
    try {
      clearAutoNext();
      dialNumber(lastCalledInfo.number, true);
      leadRedialed = true; // the auto double-dial won't add a third call

      // The redial is for the lead Pip called last, so that lead stays on
      // screen (even if the next lead was already showing in the
      // countdown); the next lead comes back once this call ends.
      if (lastCalledRow && document.body.contains(lastCalledRow)) {
        showLastCalledLead();
        setPanelLabel('Redialing');
        setPanelStatus(awaitingCallEnd ? 'Dialing\u2026' : '');
        return;
      }

      const el = ensureBmo();
      el.querySelector('.ia-face').style.display = 'none';
      el.querySelector('.ia-screen-info').style.display = '';
      el.querySelector('.ia-screen-info__label').textContent = 'Redialing';
      const clientEl = el.querySelector('.ia-screen-info__client');
      clientEl.textContent = lastCalledInfo.clientName || ('Lead ' + lastCalledInfo.leadId);
      clientEl.href = lastCalledInfo.href;
      el.querySelector('.ia-screen-info__route').textContent = [lastCalledInfo.origin, lastCalledInfo.dest].filter(Boolean).join(' \u2192 ');

      await wait(1800);
      renderPanelForRow(currentPanelRow, currentRowDialed); // restores exactly whatever was shown before, label included
    } finally {
      callInFlight = false;
    }
  }

  async function handleSkipClick() {
    if (callInFlight) return;
    // Skipped leads are tracked separately from called ones (yellow vs
    // green row indicator). Only meaningful for a lead that hasn't
    // actually been dialed yet — skipping one already called would
    // contradictorily mark it both called AND skipped at once, so an
    // already-dialed row just gets moved past instead, unmarked.
    let row = currentPanelRow;
    if (row && !document.body.contains(row)) row = null;
    if (row && !currentRowDialed) markSkipped(getLeadId(row));
    const wasCounting = countingToNext;
    if (wasCounting) clearAutoNext();
    const next = await getNextPendingRow();
    renderPanelForRow(next, false);
    if (wasCounting && next && autoRunning && !awaitingCallEnd) startNextCountdown(); // fresh timer for the new lead
  }

  // --- Hourly "daily follow up" reminder, synced across tabs --------------
  // Anthropic's Tampermonkey research earlier in this project confirmed
  // GM_addValueChangeListener as a genuine, real API for this exact
  // cross-tab case — same script, same domain, multiple tabs — which is
  // what makes dismissing on one page reliably hide it on every other open
  // page too, rather than each tab running its own independent clock.
  const REMINDER_DISMISSED_KEY = 'bmo-reminder-dismissed-until';
  const STARTED_TODAY_PREFIX = 'bmo-started-';

  function markStartedToday() {
    try { GM_setValue(STARTED_TODAY_PREFIX + todayKey(), true); } catch (e) { /* best-effort */ }
  }

  function startedToday() {
    try { return !!GM_getValue(STARTED_TODAY_PREFIX + todayKey(), false); } catch (e) { return false; }
  }

  function reminderDismissedUntil() {
    try { return Number(GM_getValue(REMINDER_DISMISSED_KEY, 0)) || 0; } catch (e) { return 0; }
  }

  function showReminder() {
    const el = ensureBmo();
    const bubble = el.querySelector('.ia-reminder');
    const wasAlreadyShowing = bubble.style.display !== 'none';
    bubble.querySelector('.ia-reminder__text').textContent = startedToday()
      ? 'Continue your daily follow up'
      : 'Start your daily follow up';
    bubble.style.display = '';
    // Only the transition from hidden to shown gets the wave — this
    // runs every minute while a reminder sits undismissed (see
    // checkReminder's interval), and re-waving every single minute
    // would be more annoying than helpful.
    if (!wasAlreadyShowing) peekAndWave();
  }

  function hideReminderBubble() {
    if (!iaWidget) return;
    const bubble = iaWidget.querySelector('.ia-reminder');
    if (bubble) bubble.style.display = 'none';
  }

  function dismissReminder() {
    const until = Date.now() + 60 * 60 * 1000;
    try { GM_setValue(REMINDER_DISMISSED_KEY, until); } catch (e) { /* best-effort */ }
    hideReminderBubble();
  }

  function checkReminder() {
    if (Date.now() >= reminderDismissedUntil()) showReminder();
  }

  try {
    GM_addValueChangeListener(REMINDER_DISMISSED_KEY, function (name, oldValue, newValue, remote) {
      if (!remote) return; // only react to OTHER tabs' changes -- this tab already updated itself directly
      if (Date.now() < Number(newValue)) hideReminderBubble();
      else checkReminder();
    });
  } catch (e) { /* listener unavailable -- reminder still works locally, just not synced across tabs */ }

  setInterval(checkReminder, 60 * 1000); // checked every minute so the hourly boundary is caught promptly, not just once an hour on the dot
  checkReminder(); // also check once on load, in case it was already due when this page opened

  // ==========================================================================
  // Callback reminders
  // ==========================================================================
  // Set a callback on a lead (the ⏰ Callback chip next to the lead number,
  // or ⏰ on the panel's lead card). When it's due, Pip peeks out with the
  // lead: Open lead / +15 min / Done. Only a reminder for the agent;
  // nothing is sent to anyone. All times are Egypt time (Africa/Cairo),
  // whatever the computer's own clock is set to. Shared by every BO tab.
  const CB_KEY = 'ia-callbacks';
  const CB_TZ = 'Africa/Cairo';
  const CB_CLOCK = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M5 4 2.5 6.5M19 4l2.5 2.5"/></svg>';

  // --- Egypt time ---------------------------------------------------------
  let cbFmtParts = null;
  function cbParts(ms) {
    if (!cbFmtParts) cbFmtParts = new Intl.DateTimeFormat('en-GB', { timeZone: CB_TZ, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', weekday: 'short', hourCycle: 'h23' });
    const o = {};
    cbFmtParts.formatToParts(new Date(ms)).forEach((p) => { o[p.type] = p.value; });
    return { y: +o.year, m: +o.month, d: +o.day, h: +o.hour % 24, mi: +o.minute, wd: o.weekday };
  }
  // Egypt wall-clock time -> real moment (handles Egypt's summer time).
  function cbFromCairo(y, m, d, h, mi) {
    const want = Date.UTC(y, m - 1, d, h, mi);
    let ms = want;
    for (let i = 0; i < 3; i++) {
      const p = cbParts(ms);
      const diff = want - Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi);
      if (!diff) break;
      ms += diff;
    }
    return ms;
  }
  const cbPad = (n) => String(n).padStart(2, '0');
  const cbDayNum = (p) => Date.UTC(p.y, p.m - 1, p.d) / 86400000;
  const CB_MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function cbFmt(ms) {
    const p = cbParts(ms);
    const t = cbPad(p.h) + ':' + cbPad(p.mi);
    const days = cbDayNum(p) - cbDayNum(cbParts(Date.now()));
    if (days === 0) return 'Today ' + t;
    if (days === 1) return 'Tomorrow ' + t;
    if (days === -1) return 'Yesterday ' + t;
    if (days > 1 && days < 7) return p.wd + ' ' + t;
    return p.d + ' ' + CB_MON[p.m - 1] + ' ' + t;
  }
  const cbShort = (ms) => cbFmt(ms).replace(/^Today /, '');

  // --- Saved list -----------------------------------------------------------
  function cbLoad() {
    try {
      const a = JSON.parse(GM_getValue(CB_KEY, '[]'));
      return Array.isArray(a) ? a.filter((c) => c && c.leadId && Number.isFinite(c.at)) : [];
    } catch (e) { return []; }
  }
  function cbSave(list) {
    list.sort((a, b) => a.at - b.at);
    try { GM_setValue(CB_KEY, JSON.stringify(list)); } catch (e) { /* best-effort */ }
    cbRefresh();
  }
  const cbFor = (leadId) => cbLoad().find((c) => c.leadId === String(leadId)) || null;
  function cbSet(info, at, note) {
    const list = cbLoad().filter((c) => c.leadId !== String(info.leadId));
    list.push({ leadId: String(info.leadId), name: info.name || '', route: info.route || '', at, note: note || '', setAt: Date.now() });
    cbSave(list);
  }
  function cbRemove(leadId) { cbSave(cbLoad().filter((c) => c.leadId !== String(leadId))); }
  function cbOpenLead(leadId) {
    const path = '/leads/' + leadId;
    if (location.pathname === path) return;
    const url = location.origin + path;
    try { if (typeof GM_openInTab === 'function') { GM_openInTab(url, { active: true, insert: true, setParent: true }); return; } } catch (e) { /* fall back */ }
    window.open(url, '_blank', 'noopener');
  }

  // --- Which lead -----------------------------------------------------------
  function cbPageLeadId() {
    const m = location.pathname.match(/^\/leads\/(\d+)\/?$/);
    return m ? m[1] : null;
  }
  // Client name and route from the lead page's own card (best effort).
  function cbLeadPageInfo(leadId) {
    const info = { leadId: String(leadId), name: '', route: '' };
    try {
      const tag = Array.from(document.querySelectorAll('span')).find((sp) => sp.textContent.trim() === '#' + leadId);
      let root = tag;
      for (let i = 0; i < 12 && root; i++) {
        root = root.parentElement;
        if (root && root.querySelectorAll('.text-base.leading-6.font-semibold').length >= 2) break;
      }
      if (root) {
        const codes = Array.from(root.querySelectorAll('.text-base.leading-6.font-semibold')).map((e) => e.textContent.trim()).filter(Boolean);
        const nameEl = root.querySelector('span.truncate');
        if (nameEl) info.name = nameEl.textContent.trim();
        if (codes.length >= 2) info.route = codes[0] + ' → ' + codes[codes.length - 1];
      }
    } catch (e) { /* ignore */ }
    return info;
  }
  function cbPanelLeadInfo() {
    if (!currentPanelRow) return null;
    const li = getLeadInfo(currentPanelRow);
    if (!li || !li.leadId) return null;
    return { leadId: String(li.leadId), name: li.clientName || '', route: [li.origin, li.dest].filter(Boolean).join(' → ') };
  }
  const cbName = (c) => c.name || ('Lead ' + c.leadId);

  // --- Pop-ups (time picker and list) -------------------------------------
  let cbPop = null;
  function cbClosePop() { if (cbPop) { cbPop.el.remove(); cbPop = null; } }
  function cbPopShell(anchor, kind) {
    const again = cbPop && cbPop.anchor === anchor && cbPop.kind === kind;
    cbClosePop();
    if (again) return null;
    const el = document.createElement('div');
    el.className = 'ia-cbpop';
    // Same colours as the panel (mode + accent).
    const src = ensureBmo();
    const cs = getComputedStyle(src);
    ['--ia-bg', '--ia-field', '--ia-line', '--ia-line2', '--ia-text', '--ia-title', '--ia-muted', '--ia-sec', '--ia-onacc', '--ia-bad', '--ia-shadow', '--acc', '--ia-glass', '--ia-edge', '--ia-inner', '--ia-chip', '--ia-chipshadow', '--ia-sky', '--ia-pri', '--ia-onpri']
      .forEach((v) => { const val = cs.getPropertyValue(v); if (val) el.style.setProperty(v, val.trim()); });
    if (iaIsNova(iaMode())) el.classList.add('ia-nova');
    el.addEventListener('mousedown', (e) => e.stopPropagation());
    el.addEventListener('click', (e) => e.stopPropagation());
    el.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') cbClosePop(); });
    cbPop = { el, anchor, kind };
    return el;
  }
  function cbPlace(el, anchor) {
    document.body.appendChild(el);
    const r = anchor.getBoundingClientRect();
    const w = el.offsetWidth, h = el.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = Math.max(8, r.top - h - 6);
    const left = Math.max(8, Math.min(r.right - w, window.innerWidth - w - 8, r.left));
    el.style.left = Math.max(8, left) + 'px';
    el.style.top = top + 'px';
  }
  function cbHead(text) {
    const h = document.createElement('div');
    h.className = 'ia-cbpop-h';
    const t = document.createElement('span');
    t.textContent = text;
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'ia-cbpop-x';
    x.setAttribute('aria-label', 'Close');
    x.textContent = '×';
    x.addEventListener('click', cbClosePop);
    h.append(t, x);
    return h;
  }
  function cbBtn(label, cls, fn) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = cls;
    b.textContent = label;
    b.addEventListener('click', (e) => { e.preventDefault(); fn(e, b); });
    return b;
  }

  function cbOpenPicker(anchor, info) {
    if (!info || !info.leadId) return;
    const el = cbPopShell(anchor, 'pick');
    if (!el) return;
    const existing = cbFor(info.leadId);
    el.appendChild(cbHead('Call back ' + (info.name || 'lead ' + info.leadId)));
    let at = existing ? existing.at : null;
    const quick = document.createElement('div');
    quick.className = 'ia-cbpop-quick';
    const when = document.createElement('div');
    when.className = 'ia-cbpop-when';
    const whenT = document.createElement('b');
    const whenZ = document.createElement('span');
    whenZ.textContent = 'Egypt time';
    when.append(whenT, whenZ);
    const pick = document.createElement('div');
    pick.className = 'ia-cbpop-pick';
    pick.hidden = true;
    const dIn = document.createElement('input');
    dIn.type = 'date';
    dIn.setAttribute('aria-label', 'Date (Egypt time)');
    const tIn = document.createElement('input');
    tIn.type = 'time';
    tIn.setAttribute('aria-label', 'Time (Egypt time)');
    pick.append(dIn, tIn);
    const paintWhen = () => { whenT.textContent = at ? cbFmt(at) : 'Pick a time'; };
    const fillPick = (ms) => { const p = cbParts(ms); dIn.value = p.y + '-' + cbPad(p.m) + '-' + cbPad(p.d); tIn.value = cbPad(p.h) + ':' + cbPad(p.mi); };
    const readPick = () => {
      const dm = dIn.value.match(/^(\d{4})-(\d{2})-(\d{2})$/), tm = tIn.value.match(/^(\d{2}):(\d{2})/);
      at = dm && tm ? cbFromCairo(+dm[1], +dm[2], +dm[3], +tm[1], +tm[2]) : null;
      paintWhen();
    };
    dIn.addEventListener('input', readPick);
    tIn.addEventListener('input', readPick);
    const inMin = (n) => Math.ceil((Date.now() + n * 60000) / 60000) * 60000;
    const tomorrow10 = () => { const p = cbParts(Date.now()); return cbFromCairo(p.y, p.m, p.d + 1, 10, 0); };
    const opts = [['30 min', () => inMin(30)], ['1 hour', () => inMin(60)], ['2 hours', () => inMin(120)], ['4 hours', () => inMin(240)], ['Tomorrow 10:00', tomorrow10], ['Pick time', null]];
    const qBtns = [];
    opts.forEach(([label, fn], i) => {
      const b = cbBtn(label, 'ia-cbpop-q', () => {
        qBtns.forEach((x) => x.classList.toggle('on', x === b));
        if (fn) { at = fn(); pick.hidden = true; } else { pick.hidden = false; fillPick(at || inMin(60)); readPick(); }
        err.textContent = '';
        paintWhen();
      });
      if (i === 4) b.classList.add('wide');
      qBtns.push(b);
      quick.appendChild(b);
    });
    const note = document.createElement('input');
    note.type = 'text';
    note.className = 'ia-cbpop-note';
    note.placeholder = 'Note (optional)';
    note.maxLength = 140;
    note.value = existing ? existing.note : '';
    const err = document.createElement('div');
    err.className = 'ia-cbpop-err';
    const acts = document.createElement('div');
    acts.className = 'ia-cbpop-acts';
    const save = () => {
      if (!at) { err.textContent = 'Pick a time first'; return; }
      if (at < Date.now() - 60000) { err.textContent = 'That time has already passed'; return; }
      cbSet(info, at, note.value.trim());
      cbClosePop();
    };
    note.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
    acts.appendChild(cbBtn(existing ? 'Update callback' : 'Set callback', 'ia-cbpop-go', save));
    if (existing) acts.appendChild(cbBtn('Remove', 'ia-cbpop-rm', () => { cbRemove(info.leadId); cbClosePop(); }));
    el.append(quick, pick, when, note, err, acts);
    if (existing) { qBtns[5].classList.add('on'); pick.hidden = false; fillPick(existing.at); }
    else { qBtns[1].classList.add('on'); at = inMin(60); }
    paintWhen();
    cbPlace(el, anchor);
  }

  function cbOpenList(anchor) {
    const el = cbPopShell(anchor, 'list');
    if (!el) return;
    const paint = () => {
      el.textContent = '';
      const list = cbLoad();
      el.appendChild(cbHead('Callbacks · ' + list.length + ' · Egypt time'));
      if (!list.length) {
        const e = document.createElement('div');
        e.className = 'ia-cbpop-empty';
        e.textContent = 'No callbacks yet. Tap the clock on a lead to set one.';
        el.appendChild(e);
        return;
      }
      const now = Date.now();
      list.forEach((c) => {
        const row = document.createElement('div');
        row.className = 'ia-cbpop-row';
        row.title = (c.note ? c.note + ' · ' : '') + 'Open lead ' + c.leadId;
        const tm = document.createElement('span');
        tm.className = 'ia-cbpop-tm' + (c.at <= now ? ' due' : '');
        tm.textContent = c.at <= now ? 'Now' : cbShort(c.at);
        const n = document.createElement('span');
        n.className = 'ia-cbpop-n';
        const b = document.createElement('b');
        b.textContent = cbName(c);
        const s = document.createElement('span');
        s.textContent = [c.leadId, c.route].filter(Boolean).join(' · ');
        n.append(b, s);
        const x = cbBtn('×', 'ia-cbpop-x', (e) => { e.stopPropagation(); cbRemove(c.leadId); paint(); });
        x.setAttribute('aria-label', 'Remove callback for ' + cbName(c));
        row.append(tm, n, x);
        row.addEventListener('click', () => { cbOpenLead(c.leadId); cbClosePop(); });
        el.appendChild(row);
      });
    };
    paint();
    el._iaPaint = paint;
    cbPlace(el, anchor);
  }

  document.addEventListener('mousedown', (e) => {
    if (cbPop && !cbPop.el.contains(e.target) && !(cbPop.anchor && cbPop.anchor.contains(e.target))) cbClosePop();
  }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') cbClosePop(); });

  // --- Lead page chip -------------------------------------------------------
  function cbChipLabel(c) { return c ? cbShort(c.at) : 'Callback'; }
  // Opens the Disclaimers & Scripts page (IA_DISC_HTML, at the end of the
  // file) in a new tab.
  // Opens one of the built-in pages in a new tab. `lead` (client name,
  // destination) is handed to the page as window.IA_LEAD for pre-filling.
  function iaOpenPage(html, lead) {
    const data = '<script>window.IA_LEAD=' + JSON.stringify(lead || {}).replace(/</g, '\\u003c') + ';<\/script>';
    const page = html.replace('</head>', data + '</head>');
    try {
      const url = URL.createObjectURL(new Blob([page], { type: 'text/html' }));
      const w = window.open(url, '_blank');
      if (w) { setTimeout(() => URL.revokeObjectURL(url), 60000); return; }
    } catch (e) { /* try the other way */ }
    const w2 = window.open('', '_blank');
    if (w2) { w2.document.open(); w2.document.write(page); w2.document.close(); }
  }
  function iaLeadPrefill() {
    const id = cbPageLeadId();
    const info = id ? cbLeadPageInfo(id) : {};
    const codes = String(info.route || '').split('\u2192').map((s) => s.trim()).filter(Boolean);
    return { client: info.name || '', dest: codes.length > 1 ? codes[codes.length - 1] : '', leadId: id || '' };
  }
  function iaOpenDisclaimers() { iaOpenPage(IA_DISC_HTML, iaLeadPrefill()); }
  const IA_TOOL_ICON = (d) => '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>';
  const IA_TOOL_CHIPS = [
    { key: 'vip', label: 'VIP Itinerary', note: 'Client itinerary picture + email',  title: 'Make a VIP itinerary for the client (new tab)', html: () => IA_VIP_HTML,
      icon: IA_TOOL_ICON('<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.6 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z"/>') },
    { key: 'gk', label: 'GK Converter', note: 'Segments to GK sell entries',  title: 'Turn Sabre segments into GK sell entries (new tab)', html: () => IA_GK_HTML,
      icon: IA_TOOL_ICON('<path d="M4 7h13l-3-3M20 17H7l3 3"/>') },
    { key: 'pnr', label: 'How to make a PNR', note: 'Step-by-step guide',  title: 'Step-by-step PNR guide (new tab)', html: () => IA_PNR_HTML,
      icon: IA_TOOL_ICON('<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17h.01"/>') },
  ];
  let iaToolsMenu = null;
  function iaCloseToolsMenu() { if (iaToolsMenu) { iaToolsMenu.remove(); iaToolsMenu = null; } document.querySelectorAll('.ia-tools-chip.is-open').forEach((c) => c.classList.remove('is-open')); }
  function iaToggleToolsMenu(chip) {
    if (iaToolsMenu) { iaCloseToolsMenu(); return; }
    const m = document.createElement('div');
    m.className = 'ia-tools-menu';
    IA_TOOL_CHIPS.forEach((tc) => {
      const it = document.createElement('button');
      it.type = 'button';
      it.className = 'ia-tools-item';
      it.innerHTML = '<span class="ia-tools-ic">' + tc.icon + '</span><span class="ia-tools-tx"><b>' + tc.label + '</b><small>' + tc.note + '</small></span>';
      it.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); iaCloseToolsMenu(); iaOpenPage(tc.html(), iaLeadPrefill()); });
      m.appendChild(it);
    });
    document.body.appendChild(m);
    const r = chip.getBoundingClientRect();
    m.style.left = Math.max(8, Math.min(r.left, window.innerWidth - m.offsetWidth - 8)) + 'px';
    m.style.top = (r.bottom + 6) + 'px';
    chip.classList.add('is-open');
    iaToolsMenu = m;
  }
  document.addEventListener('mousedown', (e) => { if (iaToolsMenu && !iaToolsMenu.contains(e.target) && !e.target.closest('.ia-tools-chip')) iaCloseToolsMenu(); }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') iaCloseToolsMenu(); }, true);
  window.addEventListener('scroll', () => iaCloseToolsMenu(), true);
  function cbWireChip() {
    const id = cbPageLeadId();
    if (!id) return;
    let chip = document.querySelector('.ia-cb-chip');
    if (chip && chip.dataset.lead !== id) { chip.remove(); chip = null; }
    if (!chip) {
      const tag = Array.from(document.querySelectorAll('div.text-secondary-400.text-xs.font-medium')).find((d) => (d.textContent.match(/#\s*(\d{5,})/) || [])[1] === id);
      if (!tag || !tag.parentElement) return;
      chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'ia-cb-chip';
      chip.dataset.lead = id;
      chip.innerHTML = CB_CLOCK + '<span></span>';
      chip.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); cbOpenPicker(chip, cbLeadPageInfo(id)); });
      tag.insertAdjacentElement('afterend', chip);
    }
    // Disclaimers & Scripts page, next to the callback chip.
    let disc = document.querySelector('.ia-disc-chip');
    if (disc && disc.previousElementSibling !== chip) { disc.remove(); disc = null; }
    if (!disc) {
      disc = document.createElement('button');
      disc.type = 'button';
      disc.className = 'ia-cb-chip ia-disc-chip';
      disc.title = 'Open the disclaimers and scripts (1-click copy) in a new tab';
      disc.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg><span>Disclaimers</span>';
      disc.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); iaOpenDisclaimers(); });
      chip.insertAdjacentElement('afterend', disc);
    }
    // Tools ▾ (VIP Itinerary / GK Converter / How to make a PNR), after
    // Disclaimers: one chip with a small menu, so the lead header stays tidy.
    let tools = document.querySelector('.ia-tools-chip');
    if (tools && tools.previousElementSibling !== disc) { tools.remove(); tools = null; }
    if (!tools) {
      tools = document.createElement('button');
      tools.type = 'button';
      tools.className = 'ia-cb-chip ia-disc-chip ia-tools-chip';
      tools.title = 'VIP Itinerary, GK Converter, How to make a PNR';
      tools.innerHTML = IA_TOOL_ICON('<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/>') + '<span>Tools</span><span class="ia-tools-caret">\u25be</span>';
      tools.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); iaToggleToolsMenu(tools); });
      disc.insertAdjacentElement('afterend', tools);
    }
    const c = cbFor(id);
    const t = chip.querySelector('span');
    const label = cbChipLabel(c);
    if (t.textContent !== label) t.textContent = label;
    chip.classList.toggle('is-set', !!c);
    chip.classList.toggle('is-due', !!c && c.at <= Date.now());
    chip.title = c ? 'Callback ' + cbFmt(c.at) + ' (Egypt time)' + (c.note ? ': ' + c.note : '') + '. Click to change.' : 'Set a callback reminder for this lead';
    if (c) {
      const p = cbLeadPageInfo(id);
      if ((p.name && p.name !== c.name) || (p.route && p.route !== c.route)) {
        cbSave(cbLoad().map((x) => (x.leadId === id ? Object.assign(x, { name: p.name || x.name, route: p.route || x.route }) : x)));
      }
    }
  }

  // --- Due reminder ---------------------------------------------------------
  const cbWaved = new Set();
  function cbDueEl() {
    const w = ensureBmo();
    let el = w.querySelector('.ia-cbdue');
    if (el) return el;
    el = document.createElement('div');
    el.className = 'ia-cbdue';
    el.hidden = true;
    el.innerHTML = '<div class="ia-cbdue__top"><span class="ia-cbdue__k"></span><button type="button" class="ia-cbdue__x" aria-label="Clear this callback">&times;</button></div>' +
      '<div class="ia-cbdue__who"></div><div class="ia-cbdue__meta"></div><div class="ia-cbdue__note"></div>' +
      '<div class="ia-cbdue__acts"><button type="button" class="ia-cbdue__a is-main" data-a="open">Open lead</button><button type="button" class="ia-cbdue__a" data-a="snooze">+15 min</button><button type="button" class="ia-cbdue__a" data-a="done">Done</button></div>' +
      '<div class="ia-cbdue__more"></div>';
    el.addEventListener('mousedown', (e) => e.stopPropagation());
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      const b = e.target.closest && e.target.closest('button');
      const id = el.dataset.lead;
      if (!b || !id) return;
      const a = b.classList.contains('ia-cbdue__x') ? 'done' : b.dataset.a;
      if (a === 'open') { cbRemove(id); cbOpenLead(id); }
      else if (a === 'snooze') { cbSave(cbLoad().map((c) => (c.leadId === id ? Object.assign(c, { at: Date.now() + 15 * 60000 }) : c))); cbWaved.delete(id); }
      else if (a === 'done') cbRemove(id);
    });
    w.appendChild(el);
    return el;
  }
  function cbPaintDue(list) {
    const now = Date.now();
    const due = list.filter((c) => c.at <= now);
    const w = iaWidget;
    if (!due.length) {
      const el = w && w.querySelector('.ia-cbdue');
      if (el) el.hidden = true;
      if (w) w.classList.remove('ia-widget--cbdue');
      return;
    }
    const c = due[0];
    const el = cbDueEl();
    el.dataset.lead = c.leadId;
    const late = now - c.at > 5 * 60000;
    el.querySelector('.ia-cbdue__k').textContent = late ? 'Callback · due ' + cbShort(c.at) : 'Callback now';
    el.querySelector('.ia-cbdue__who').textContent = cbName(c);
    el.querySelector('.ia-cbdue__meta').textContent = ['Lead ' + c.leadId, c.route, 'set ' + cbShort(c.setAt || c.at)].filter(Boolean).join(' · ');
    const nt = el.querySelector('.ia-cbdue__note');
    nt.textContent = c.note || '';
    nt.hidden = !c.note;
    const more = el.querySelector('.ia-cbdue__more');
    more.textContent = due.length > 1 ? '+' + (due.length - 1) + ' more due' : '';
    more.hidden = due.length < 2;
    el.hidden = false;
    iaWidget.classList.add('ia-widget--cbdue');
    if (!cbWaved.has(c.leadId)) { cbWaved.add(c.leadId); peekAndWave(); }
  }

  // --- Panel buttons --------------------------------------------------------
  function cbPaintPanel(list) {
    const w = iaWidget;
    if (!w) return;
    const badge = w.querySelector('.ia-cb-badge');
    if (badge) {
      badge.textContent = list.length > 9 ? '9+' : String(list.length);
      badge.hidden = !list.length;
      badge.classList.toggle('is-due', list.some((c) => c.at <= Date.now()));
    }
    const card = w.querySelector('.ia-cb-card');
    if (card) {
      const info = cbPanelLeadInfo();
      const c = info && list.find((x) => x.leadId === info.leadId);
      card.classList.toggle('is-set', !!c);
      card.title = c ? 'Callback ' + cbFmt(c.at) + ' (Egypt time). Click to change.' : 'Set a callback for this lead';
    }
  }

  function cbRefresh() {
    const list = cbLoad();
    try { cbPaintPanel(list); } catch (e) { /* ignore */ }
    try { cbPaintDue(list); } catch (e) { /* ignore */ }
    try { cbWireChip(); } catch (e) { /* ignore */ }
    if (cbPop && cbPop.kind === 'list' && cbPop.el._iaPaint) cbPop.el._iaPaint();
  }

  try { GM_addValueChangeListener(CB_KEY, () => cbRefresh()); } catch (e) { /* other tabs catch up on the timer */ }
  setInterval(cbRefresh, 15000);
  __jsRegisterScan(() => { try { cbWireChip(); } catch (e) { /* ignore */ } });
  setTimeout(cbRefresh, 0);


  // Clear the downloaded-font copy older versions saved (no longer used).
  try { if (GM_getValue('bmo-font-fredoka-v1', null)) GM_setValue('bmo-font-fredoka-v1', null); } catch (e) { /* ignore */ }

  GM_addStyle(`
    .dialer-called-dot {
      position: absolute;
      top: 3px;
      left: -4px;
      width: 13px;
      height: 13px;
      border-radius: 50%;
      background: transparent;
      border: 2px solid rgba(255,255,255,.35);
      box-sizing: border-box;
    }
    .dialer-called-dot { cursor: context-menu; }
    .dialer-called-dot.is-nocall::after { content: ''; position: absolute; left: -2px; right: -2px; top: 50%; height: 2px; margin-top: -1px; background: #94a3b8; transform: rotate(-45deg); border-radius: 2px; }
    .dialer-called-dot.is-nocall:not(.is-called):not(.is-skipped):not(.is-called2) { border-color: #94a3b8; }
    .dialer-called-dot.is-called { background: #2ecc71; border-color: #2ecc71; box-shadow: 0 0 5px rgba(46,204,113,.8); }
    .dialer-called-dot.is-skipped { background: #f1c40f; border-color: #f1c40f; box-shadow: 0 0 5px rgba(241,196,15,.8); }
    .dialer-called-dot.is-called2 { background: #e53935; border-color: #e53935; box-shadow: 0 0 5px rgba(229,57,53,.85); }

    .ia-widget {
      position: fixed;
      right: 20px;
      bottom: 20px;
      z-index: 99999;
      width: 280px;
      height: 331px;
      pointer-events: none;
      /* Matches roughly where the bubble sits within this box (bottom
         right), so the drag-tilt rotation pivots near the bubble
         itself rather than around the whole box's center — without
         this, tilting would swing the bubble through a wide arc around
         a point far from where it visually sits, instead of reading as
         the bubble itself leaning in place. */
      transform-origin: 83% 88%;
      --ia-pip-body: #13b3a0;
      --ia-pip-side: #0c8a7b;
      --ia-pip-dark: #0d6e63;
      --ia-pip-screen: #dcf3ef;
      --ia-pip-text: #0b3b34;
    }
    .ia-widget--pink {
      --ia-pip-body: #ec4899;
      --ia-pip-side: #c42f78;
      --ia-pip-dark: #9d174d;
      --ia-pip-screen: #fce7f3;
      --ia-pip-text: #831843;
    }
    .ia-widget--black {
      --ia-pip-body: #26282b;
      --ia-pip-side: #141517;
      --ia-pip-dark: #0a0a0a;
      --ia-pip-screen: #e5e5e5;
      --ia-pip-text: #1a1a1a;
    }
    .ia-widget--midnight {
      --ia-pip-body: #1e293b;
      --ia-pip-side: #0b1120;
      --ia-pip-dark: #0f172a;
      --ia-pip-screen: #cffafe;
      --ia-pip-text: #083344;
    }
    .ia-headset { opacity: 0; transition: opacity .6s ease; pointer-events: none; }
    .ia-widget--pink .ia-headset { opacity: 1; }
    .ia-widget--gold {
      --ia-pip-body: #d4a52a;
      --ia-pip-side: #a9801a;
      --ia-pip-dark: #8a6508;
      --ia-pip-screen: #fff6d6;
      --ia-pip-text: #5c4200;
    }
    .ia-crown { opacity: 0; transition: opacity .6s ease; pointer-events: none; }
    .ia-widget--gold .ia-crown { opacity: 1; }
    .ia-widget--gold .ia-bubble,
    .ia-widget--gold .ia-full { animation: ia-gold-shine 2.4s ease-in-out infinite; }
    @keyframes ia-gold-shine {
      0%, 100% { filter: drop-shadow(0 0 2px rgba(255, 215, 0, .35)); }
      50% { filter: drop-shadow(0 0 10px rgba(255, 215, 0, .9)); }
    }
    .ia-widget--gold-unlock .ia-full { animation: ia-gold-burst 1.5s ease-out 1; }
    @keyframes ia-gold-burst {
      0% { filter: drop-shadow(0 0 0 rgba(255, 215, 0, 0)) brightness(1); }
      25% { filter: drop-shadow(0 0 28px rgba(255, 215, 0, 1)) brightness(1.5); }
      100% { filter: drop-shadow(0 0 4px rgba(255, 215, 0, .4)) brightness(1); }
    }
    .ia-lid { opacity: 0; fill: var(--ia-pip-screen); transition: fill .6s ease, opacity 1.3s ease; }
    .ia-eye { transform-box: fill-box; transform-origin: center; transition: transform 1.3s ease; }

    /* --- 3D look: light from above, everything casts its shadow down --- */
    .ia-bodygrp { filter: drop-shadow(0 6px 5px rgba(0,0,0,.22)); }
    .ia-rim { fill: none; stroke: #fff; stroke-opacity: .25; stroke-width: 1.5; stroke-linecap: round; pointer-events: none; }
    .ia-lip { fill: none; stroke: #fff; stroke-opacity: .28; stroke-width: 1.5; pointer-events: none; }
    .ia-glare { fill: #fff; opacity: .35; pointer-events: none; }
    .ia-hl { fill: none; stroke: #fff; stroke-opacity: .5; stroke-width: 1.6; stroke-linecap: round; pointer-events: none; }
    .ia-pill { transition: fill .6s ease; }

    /* Button bases: darker shade of each button, with a soft shadow
       directly underneath. */
    .ia-base { filter: drop-shadow(0 2px 2px rgba(0,0,0,.35)); transition: fill .6s ease; }
    .ia-cross-base rect { fill: #c99a12; }
    .ia-btn-skip .ia-base { fill: #2f86ad; stroke: #2f86ad; }
    .ia-btn-skip polygon { stroke-width: 3; stroke-linejoin: round; }
    .ia-btn-doubledial .ia-base { fill: #6aa83a; }
    .ia-stop-base { fill: #b8301f; }
    .ia-stop-face { transition: fill .6s ease; }

    /* Pressing: the button sinks onto its base. */
    .ia-top, .ia-btn-label { transition: transform .1s ease, fill .6s ease; }
    .ia-btn:active .ia-top, .ia-btn:active .ia-btn-label { transform: translateY(2px); }

    /* Labels are engraved into each button: the letters are a darker
       shade of the button's own color, with a thin light edge along their
       bottom (light from above catching the lower lip of the cut). */
    .ia-btn-label {
      font-weight: 700 !important;
      filter: drop-shadow(0 .8px 0 rgba(255,255,255,.55)) drop-shadow(0 -.6px 0 rgba(0,0,0,.25));
    }
    .ia-label-call { fill: #9a7400; }
    .ia-label-skip { fill: #1d6b8f; color: #1d6b8f; }
    .ia-label-2x { fill: #3f7419; }
    /* Rainbow: a deep violet bottom edge reads better under the rainbow. */
    .ia-widget.ia-widget--super { --ia-pip-side: #5b3a8c; }
    .ia-label-stop { fill: #9b2010; filter: drop-shadow(0 .8px 0 rgba(255,255,255,.4)) drop-shadow(0 -.6px 0 rgba(0,0,0,.3)); }

    /* Double-dial switch: the small dot by 2X is a red lamp. Off = dark,
       unlit red. On = lit, glowing red. */
    .ia-dd-toggle { cursor: pointer; }
    .ia-led { font-family: system-ui, sans-serif; font-size: 7.4px; font-weight: 700; letter-spacing: .05px; fill: var(--ia-pip-text); transition: fill .6s ease; pointer-events: none; }
    /* Name strip: rests centered, scrolls off to the left, comes back in
       from the right and settles centered again. */
    /* 10s resting centered, ~3s out to the left, ~3s back in. */
    /* Moved as one flat layer (no re-snapping of the letters each step),
       so the text glides sideways without bobbing up and down. */
    .ia-led-move { animation: ia-led-lap 16s linear infinite; will-change: transform; }
    @keyframes ia-led-lap {
      0% { transform: translateX(0); }
      62.5% { transform: translateX(0); }
      81.25% { transform: translateX(-58px); }
      81.26% { transform: translateX(58px); }
      100% { transform: translateX(0); }
    }
    .ia-dd-dot { fill: #6b1414; stroke: #3a0606; stroke-width: 1; transition: fill .6s ease, filter .6s ease !important; }
    .ia-dd-shine { fill: #fff; opacity: .15; pointer-events: none; transition: opacity .6s ease; }
    .ia-widget--dd-on .ia-dd-dot { fill: #ff2a2a; filter: drop-shadow(0 0 3px rgba(255,40,40,.95)) drop-shadow(0 0 6px rgba(255,40,40,.6)); }
    .ia-widget--dd-on .ia-dd-shine { opacity: .75; }

    /* Super Pip: flowing rainbow body once the day's follow-up is done. */
    .ia-rainbow { opacity: 0; transition: opacity .6s ease; pointer-events: none; }
    .ia-widget--super .ia-rainbow { opacity: 1; }
    /* Bubble rainbow sits on a layer under the screen that fades in/out at
       the same .6s as everything else (a gradient background would snap). */
    .ia-bubble::after {
      content: ''; position: absolute; inset: 0 0 4px 0; border-radius: inherit; z-index: 0;
      background: linear-gradient(135deg, #ff3b3b, #ff9f1c, #ffe14d, #3ddc84, #3fa9f5, #9b5de5, #ff3b3b, #ff9f1c, #ffe14d);
      background-size: 400% 400%;
      animation: ia-rainbow-flow 4s linear infinite;
      opacity: 0; transition: opacity .6s ease; pointer-events: none;
    }
    .ia-bubble > svg { position: relative; z-index: 1; }
    .ia-widget.ia-widget--super .ia-bubble::after { opacity: 1; }
    @keyframes ia-rainbow-flow { 0% { background-position: 0% 0%; } 100% { background-position: 100% 100%; } }
    /* Keep button labels readable on the rainbow. The outlines always
       exist but are fully transparent until the rainbow is on, so they fade
       in and out at the same .6s speed as the body instead of snapping. */
    .ia-btn-label { stroke: rgba(0,0,0,0); stroke-width: 2.4px; paint-order: stroke; stroke-linejoin: round; }
    .ia-cross rect { stroke: rgba(0,0,0,0); stroke-width: 1.2px; }
    .ia-btn-label, .ia-cross rect { transition: stroke .6s ease, fill .6s ease, transform .1s ease !important; }
    .ia-widget.ia-widget--super .ia-btn-label { stroke: rgba(0,0,0,0); }
    .ia-widget--super .ia-btn-doubledial .ia-btn-label { stroke: rgba(0,0,0,0); }
    .ia-widget.ia-widget--super .ia-cross rect { stroke: rgba(0,0,0,0); }

    /* Locked color button wiggle (Super Pip day). */
    .ia-locked-wiggle { transform-box: fill-box; transform-origin: center; animation: ia-wiggle .45s ease 1; }
    @keyframes ia-wiggle { 0%,100% { transform: rotate(0); } 25% { transform: rotate(-9deg); } 50% { transform: rotate(8deg); } 75% { transform: rotate(-5deg); } }

    /* Level-up celebration: Pip hops, a light ring bursts, sparks fly
       out and "LEVEL UP!" pops above his head. */
    .ia-levelup {
      position: absolute; right: 0; bottom: 0; width: 280px; height: 331px;
      pointer-events: none; display: none; z-index: 5;
    }
    .ia-widget--levelup .ia-levelup { display: block; }
    .ia-levelup__text, .ia-levelup__sub {
      position: absolute; left: 50%; top: 2px; transform: translateX(-50%);
      font: 900 26px/1 'Bahnschrift', 'Segoe UI', system-ui, sans-serif; letter-spacing: .04em;
      white-space: nowrap;
      background: linear-gradient(90deg, #ff3b3b, #ff9f1c, #ffe14d, #3ddc84, #3fa9f5, #9b5de5);
      -webkit-background-clip: text; background-clip: text; color: transparent;
      filter: drop-shadow(0 2px 0 rgba(0,0,0,.35)) drop-shadow(0 0 6px rgba(255,255,255,.9));
      opacity: 0; animation: ia-lvl-text 2.4s cubic-bezier(.2,1.4,.4,1) forwards;
    }
    .ia-levelup__sub {
      top: 34px; font-size: 12px; letter-spacing: .25em; display: none;
      animation-delay: .25s;
    }
    .ia-widget--levelup-sub .ia-levelup__sub { display: block; }
    @keyframes ia-lvl-text {
      0% { opacity: 0; transform: translateX(-50%) translateY(30px) scale(.3); }
      20% { opacity: 1; transform: translateX(-50%) translateY(-6px) scale(1.18); }
      32% { transform: translateX(-50%) translateY(0) scale(1); }
      80% { opacity: 1; transform: translateX(-50%) translateY(-4px) scale(1); }
      100% { opacity: 0; transform: translateX(-50%) translateY(-22px) scale(1); }
    }
    .ia-levelup__ring {
      position: absolute; left: 50%; top: 52%; width: 40px; height: 40px; margin: -20px 0 0 -20px;
      border-radius: 50%; border: 4px solid rgba(255,255,255,.95);
      box-shadow: 0 0 18px 6px rgba(255,225,77,.8), inset 0 0 12px rgba(255,255,255,.8);
      opacity: 0; animation: ia-lvl-ring 1s ease-out forwards;
    }
    @keyframes ia-lvl-ring {
      0% { opacity: 1; transform: scale(.2); }
      100% { opacity: 0; transform: scale(7); }
    }
    .ia-levelup__spark {
      position: absolute; left: 50%; top: 50%; width: 10px; height: 10px; margin: -5px 0 0 -5px;
      background: #fff6b0;
      clip-path: polygon(50% 0, 62% 38%, 100% 50%, 62% 62%, 50% 100%, 38% 62%, 0 50%, 38% 38%);
      filter: drop-shadow(0 0 4px #ffd84d);
      opacity: 0; animation: ia-lvl-spark 1.3s ease-out forwards;
    }
    .ia-levelup__spark:nth-child(odd) { background: #b9f3ff; filter: drop-shadow(0 0 4px #5ec8f0); }
    @keyframes ia-lvl-spark {
      0% { opacity: 1; transform: rotate(var(--a)) translateY(0) scale(.4); }
      70% { opacity: 1; }
      100% { opacity: 0; transform: rotate(var(--a)) translateY(calc(-1 * var(--d))) scale(1.2) rotate(180deg); }
    }
    .ia-widget--levelup .ia-full { animation: ia-lvl-hop .7s cubic-bezier(.3,1.6,.5,1) 1 !important; }
    @keyframes ia-lvl-hop {
      0% { translate: 0 0; } 30% { translate: 0 -16px; } 55% { translate: 0 0; } 75% { translate: 0 -5px; } 100% { translate: 0 0; }
    }

    /* Easter egg: cracked screen. */
    .ia-crack { opacity: 0; pointer-events: none; transition: opacity .5s ease; }
    .ia-crack path { fill: none; stroke: #2b2b2b; stroke-width: 1.4; stroke-linecap: round; stroke-linejoin: round; }
    .ia-widget--cracked .ia-crack { opacity: .9; transition: none; }
    /* Cracked = sad: frown, droopy brows and a tear instead of the smile. */
    .ia-sad, .ia-sad-tear { display: none; }
    .ia-sad { fill: none; stroke: #1a1a1a; stroke-width: 3.5; stroke-linecap: round; }
    .ia-sad-tear { fill: #5ec8f0; }
    .ia-widget--cracked .ia-smile, .ia-widget--cracked .ia-lid { display: none; }
    .ia-widget--cracked .ia-sad, .ia-widget--cracked .ia-sad-tear { display: inline; }
    .ia-widget--cracked .ia-full, .ia-widget--cracked .ia-bubble { animation: ia-impact .35s ease-out 1; }
    @keyframes ia-impact {
      0% { translate: 0 0; } 20% { translate: -4px 2px; } 40% { translate: 4px -2px; }
      60% { translate: -2px 1px; } 80% { translate: 2px 0; } 100% { translate: 0 0; }
    }

    /* Stop pressed while running: a clear "stopped" flash. */
    .ia-widget--stop-flash .ia-stop-face { animation: ia-old-stop-flash .9s ease-out 1; }
    @keyframes ia-old-stop-flash { 0% { fill: #ffffff; } 100% { } }
    /* Everything themeable transitions fill/stroke together, so toggling
       the palette reads as one smooth cross-fade across the whole
       character rather than separate pieces changing at different
       times. */
    .ia-themed { transition: fill .6s ease, stroke .6s ease; }
    .ia-bubble {
      position: absolute;
      right: 0;
      bottom: 0;
      width: 96px;
      height: 76px;
      border-radius: 16px;
      background: var(--ia-pip-body);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: inset 0 -4px 0 var(--ia-pip-side), inset 0 1.5px 0 rgba(255,255,255,.25), 0 6px 12px rgba(0,0,0,.3);
      cursor: grab;
      pointer-events: auto;
      transition: transform .3s cubic-bezier(.34,1.56,.64,1), opacity .2s, background .6s ease;
    }
    .ia-bubble:active { cursor: grabbing; }
    .ia-full {
      position: absolute;
      right: 0;
      bottom: 0;
      transform-origin: bottom right;
      transform: scale(0.2);
      opacity: 0;
      pointer-events: none;
      transition: transform .35s cubic-bezier(.34,1.56,.64,1), opacity .2s;
      overflow: visible;
    }
    /* Invisible 16px grab zone around the minimized bubble */
    .ia-bubble::before {
      content: '';
      position: absolute;
      inset: -16px;
      border-radius: 28px;
    }
    .ia-widget--maximized .ia-full { transform: scale(1); opacity: 1; pointer-events: none; }
    /* Only Pip's actual body (and what's on it) can be grabbed/clicked —
       not the empty space around him, his hidden arms or accessories. */
    .ia-widget--maximized .ia-full > :not(.ia-arm-left):not(.ia-arm-right):not(.ia-headset):not(.ia-crown):not(defs) { pointer-events: auto; cursor: grab; }
    .ia-widget--maximized .ia-full .ia-btn, .ia-widget--maximized .ia-full .ia-btn *, .ia-widget--maximized .ia-full .ia-dd-toggle,
    .ia-widget--maximized .ia-screen-info__client, .ia-widget--maximized .ia-reminder { cursor: pointer !important; }
    .ia-widget--maximized .ia-bubble { transform: scale(0.15); opacity: 0; pointer-events: none; }
    .ia-widget--dragging,
    .ia-widget--dragging * { cursor: grabbing !important; }
    /* A "peek" shows the full character the same way maximizing does,
       but stays non-interactive (pointer-events stays off) and doesn't
       touch iaMaximized — used only for the hourly reminder's
       attention-grabbing wave when Pip is currently minimized, so the
       wave has an actual character to play on without it counting as
       Pip being genuinely opened. */
    .ia-widget--peeking .ia-full { transform: scale(1); opacity: 1; }
    .ia-widget--peeking .ia-bubble { transform: scale(0.15); opacity: 0; }
    .ia-btn { cursor: pointer; }
    .ia-btn--disabled { opacity: .4; pointer-events: none; }
    /* While auto-dialing, the red Stop button pulses so it's obvious Pip
       is running on his own and how to halt him. */
    .ia-widget--running .ia-stop-face { animation: ia-stop-pulse 1.2s ease-in-out infinite; }
    @keyframes ia-stop-pulse { 0%, 100% { opacity: 1; } 50% { opacity: .55; } }
    /* Fonts already built into Windows — no downloads, no permission
       prompts. Bahnschrift is Windows' modern geometric font. */
    .ia-btn-label { font-family: 'Bahnschrift', 'Segoe UI Variable Display', 'Segoe UI', system-ui, sans-serif; font-weight: 600; font-kerning: normal; pointer-events: none; }
    .ia-eye { fill: #1a1a1a; }
    .ia-smile { fill: none; stroke: #1a1a1a; stroke-width: 4; stroke-linecap: round; }

    /* Dead face — shown for 2s after a vicious shake, on top of whichever
       face (bubble or full) is currently visible, and hides the normal
       one underneath it. */
    .ia-dead-face, .ia-bubble-dead-face { display: none; }
    .ia-widget--dead .ia-face, .ia-widget--dead .ia-bubble-face { display: none; }
    .ia-widget--dead .ia-dead-face, .ia-widget--dead .ia-bubble-dead-face { display: inline; }
    .ia-dead-eye { fill: none; stroke: #1a1a1a; stroke-width: 3; stroke-linecap: round; }
    .ia-dead-mouth { fill: none; stroke: #1a1a1a; stroke-width: 4; stroke-linecap: round; }
    .ia-dead-tongue { fill: #ff6b8a; stroke: #c2455f; stroke-width: 1.5; }
    /* Arms are invisible by default now -- they only ever exist on
       screen for the duration of a wave: fading in, waving, then fading
       back out, rather than sitting there permanently. Both arms share
       the same fade; only the right one also rotates. */
    .ia-arm-left, .ia-arm-right { opacity: 0; }
    .ia-arm-left.ia-waving { animation: ia-arm-fade 2.2s ease-in-out 1; }
    .ia-arm-right.ia-waving {
      transform-origin: 168px 103px;
      animation: ia-arm-fade 2.2s ease-in-out 1, ia-wave-rotate 2.2s ease-in-out 1;
    }
    @keyframes ia-arm-fade {
      0% { opacity: 0; }
      10% { opacity: 1; }
      85% { opacity: 1; }
      100% { opacity: 0; }
    }
    @keyframes ia-wave-rotate {
      0%, 10%, 85%, 100% { transform: rotate(0deg); }
      25% { transform: rotate(-22deg); }
      40% { transform: rotate(10deg); }
      55% { transform: rotate(-16deg); }
      70% { transform: rotate(4deg); }
    }
    /* pointer-events is only re-enabled while Pip is actually maximized.
       .ia-full itself is pointer-events:none while minimized/peeking,
       but that's just an ancestor default — an explicit pointer-events
       on a descendant (this foreignObject content) overrides it, so
       without scoping this to --maximized, the client link underneath
       the invisible, scaled-down full body would still catch clicks
       landing on the minimized bubble (right around where the eyes
       are) and open the lead instead of letting the bubble's own click
       handler maximize Pip. */
    .ia-screen-info { font-family: system-ui, sans-serif; color: var(--ia-pip-text); pointer-events: none; transition: color .6s ease; }
    .ia-widget--maximized .ia-screen-info { pointer-events: auto; }
    /* The screen's text box (an HTML island inside the SVG) doesn't scale
       smoothly with the body in Chrome and visibly jumps while Pip grows
       or shrinks — so it fades out at once on minimize and only fades in
       once he's fully open. */
    .ia-widget:not(.ia-widget--maximized):not(.ia-widget--peeking) .ia-screen-info { opacity: 0; transition: opacity .08s ease, color .6s ease; }
    .ia-widget--maximized .ia-screen-info, .ia-widget--peeking .ia-screen-info { opacity: 1; transition: opacity .2s ease .3s, color .6s ease; }
    .ia-screen-info__label { font-size: 8px; line-height: 1.1; text-transform: uppercase; opacity: .65; letter-spacing: .03em; white-space: nowrap; }
    /* Was using -webkit-line-clamp (display:-webkit-box) to cap this at
       2 lines — that hack's height computation isn't reliable inside an
       SVG foreignObject specifically, unlike in a normal HTML document,
       and a miscalculated height here would push the route line below
       it to start from the wrong position, visually landing on top of
       the name instead of under it. A plain block with a fixed
       max-height in px is a more literal, predictable way to cap this
       at 2 lines' worth of space — no fancy ellipsis, but it reliably
       reserves exactly the height it claims, which the route line's own
       position depends on being correct.

       The name pushing the destination out of view turned out to have a
       second cause on top of that: the foreignObject box is a fixed
       height, and the (usually empty) status line below the route was
       still reserving its own line-height + margin even with no text in
       it — room that a 2-line name needed. :empty collapses it to
       nothing when there's nothing to show, and the destination/route
       line is given first claim on whatever space is left after the
       label and the (capped) name, so it is never the one that gets
       clipped. */
    .ia-screen-info__client {
      display: block;
      max-height: 30px;
      overflow: hidden;
      font-weight: 700;
      font-size: 13px;
      margin-top: 1px;
      color: var(--ia-pip-text);
      text-decoration: none;
      line-height: 1.15;
      transition: color .6s ease;
    }
    .ia-screen-info__client:hover { text-decoration: underline; }
    .ia-screen-info__route { font-size: 10px; line-height: 1.15; opacity: .8; margin-top: 1px; }
    .ia-screen-info__status { font-size: 8px; line-height: 1.1; opacity: .7; margin-top: 2px; }
    .ia-screen-info__status:empty { display: none; margin-top: 0; }

    .ia-reminder {
      position: absolute;
      right: 4px;
      /* Follows whichever face is actually showing: parked just above
         the small minimized bubble by default, and only jumps up above
         the full 331px-tall body while it's actually on screen (maximized,
         or mid-"peek") -- see the .ia-widget--maximized/--peeking
         overrides below. Both the box and the bubble stay a fixed size
         either way, so these are plain fixed offsets, not something that
         needs recalculating in JS. */
      bottom: 86px;
      width: 190px;
      background: var(--ia-pip-body);
      color: #fff;
      border-radius: 10px;
      padding: 10px 12px;
      font-family: system-ui, sans-serif;
      font-size: 12px;
      box-shadow: 0 4px 14px rgba(0,0,0,.4);
      pointer-events: auto;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: background .6s ease, bottom .25s ease;
    }
    .ia-widget--maximized .ia-reminder,
    .ia-widget--peeking .ia-reminder {
      bottom: 341px;
    }
    .ia-reminder__text { flex: 1; }
    .ia-reminder__dismiss {
      background: none;
      border: none;
      color: #fff;
      opacity: .6;
      font-size: 16px;
      line-height: 1;
      cursor: pointer;
      padding: 0 2px;
    }
    .ia-reminder__dismiss:hover { opacity: 1; }
    .ia-quiet { position: fixed; inset: 0; z-index: 2147483600; background: rgba(6,10,24,.38); display: flex; align-items: center; justify-content: center; }
    .ia-quiet__card { width: 300px; box-sizing: border-box; border-radius: 20px; padding: 14px; background: var(--q-sky), var(--q-glass); border: 1px solid var(--q-edge);
      box-shadow: var(--q-shadow), inset 0 1px 0 var(--q-inner); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5); font-family: Inter, 'Segoe UI', system-ui, sans-serif; color: var(--q-title); }
    .ia-quiet__scr { display: grid; grid-template-columns: auto 1fr; grid-template-areas: 'pip time' 'pip msg'; column-gap: 12px; align-items: center; }
    .ia-quiet__pip { grid-area: pip; width: 44px; height: 44px; border-radius: 14px; display: grid; place-items: center; background: var(--q-chip); box-shadow: var(--q-chipsh); }
    .ia-quiet__time { grid-area: time; display: flex; align-items: center; gap: 6px; font: 800 22px/1.15 Inter, 'Segoe UI', system-ui, sans-serif; letter-spacing: -.01em; }
    .ia-quiet__moon { font-size: 17px; }
    .ia-quiet__msg { grid-area: msg; margin-top: 2px; font: 700 12.5px/1.35 Inter, 'Segoe UI', system-ui, sans-serif; color: var(--q-sec); }
    .ia-quiet__btns { display: flex; justify-content: flex-end; gap: 8px; margin-top: 14px; }
    .ia-quiet__btns button { border: 1px solid transparent; border-radius: 999px; padding: 7px 15px; font: 800 12px Inter, 'Segoe UI', system-ui, sans-serif; cursor: pointer; }
    .ia-quiet__no { background: var(--q-chip); color: var(--q-title); box-shadow: var(--q-chipsh); }
    .ia-quiet__no:hover { border-color: var(--q-acc); }
    .ia-quiet__yes { background: linear-gradient(180deg, color-mix(in srgb, var(--q-acc) 78%, white), var(--q-acc)); color: var(--q-onacc); }
    .ia-quiet__yes:focus-visible, .ia-quiet__no:focus-visible { outline: 2px solid var(--q-acc); outline-offset: 2px; }
  `);


  // ------------------------------------------------------------------
  // TBC Assistant — Pip + clean panel in three modes (dark / light /
  // navy). Added last so it wins over the original character styles.
  // Colours mirror IA_MODES / IA_ACCENTS at the top of the file.
  // ------------------------------------------------------------------
  GM_addStyle(`
    .ia-widget { font-family: Inter, 'Segoe UI', system-ui, -apple-system, sans-serif; }
    .ia-widget.ia-mode-dark { --ia-bg:#0e0f13; --ia-card:transparent; --ia-cardbd:#23252d; --ia-field:#15171d; --ia-line:#23252d; --ia-line2:#2c2f38; --ia-text:#e8e8ed; --ia-title:#f4f4f7; --ia-muted:#8a8d98; --ia-sec:#c9cad3; --ia-head:#e8e8ed; --ia-eye:#0e0f13; --ia-onacc:#0e0f13; --ia-ok:#4ade80; --ia-bad:#f8717f; --ia-stop:#e5484d; --ia-foot:#5d6070; --ia-shadow:0 18px 44px rgba(0,0,0,.55); --acc:#2dd4bf; }
    .ia-widget.ia-mode-light { --ia-bg:#ffffff; --ia-card:#f6f6f8; --ia-cardbd:#f6f6f8; --ia-field:#f6f6f8; --ia-line:#e4e4e9; --ia-line2:#e4e4e9; --ia-text:#18181b; --ia-title:#18181b; --ia-muted:#6b6b76; --ia-sec:#3f3f46; --ia-head:#3f3f46; --ia-eye:#ffffff; --ia-onacc:#ffffff; --ia-ok:#16a34a; --ia-bad:#dc3e42; --ia-stop:#dc3e42; --ia-foot:#a1a1aa; --ia-shadow:0 14px 36px rgba(15,23,42,.18); --acc:#0f766e; }
    .ia-widget.ia-mode-navy { --ia-bg:#0b1628; --ia-card:#10203a; --ia-cardbd:#1c2e4d; --ia-field:#10203a; --ia-line:#1c2e4d; --ia-line2:#23395e; --ia-text:#e6edf7; --ia-title:#f1f5fb; --ia-muted:#8aa0bf; --ia-sec:#c4d2e6; --ia-head:#e6edf7; --ia-eye:#0b1628; --ia-onacc:#0b1628; --ia-ok:#4ade80; --ia-bad:#ff8a8a; --ia-stop:#e5484d; --ia-foot:#5b7092; --ia-shadow:0 18px 44px rgba(2,8,23,.6); --acc:#5eead4; }
    .ia-widget.ia-mode-dark.ia-widget--midnight { --acc:#7c7cf8; }
    .ia-widget.ia-mode-light.ia-widget--midnight { --acc:#5b5bd6; }
    .ia-widget.ia-mode-navy.ia-widget--midnight { --acc:#7c9cff; }
    .ia-widget.ia-mode-dark.ia-widget--pink { --acc:#f472b6; }
    .ia-widget.ia-mode-light.ia-widget--pink { --acc:#db2777; }
    .ia-widget.ia-mode-navy.ia-widget--pink { --acc:#f9a8d4; }
    .ia-widget.ia-mode-dark.ia-widget--black { --acc:#e4e4e7; }
    .ia-widget.ia-mode-light.ia-widget--black { --acc:#27272a; }
    .ia-widget.ia-mode-navy.ia-widget--black { --acc:#e6edf7; }
    .ia-widget.ia-mode-dark.ia-widget--gold { --acc:#f5b544; }
    .ia-widget.ia-mode-light.ia-widget--gold { --acc:#b45309; }
    .ia-widget.ia-mode-navy.ia-widget--gold { --acc:#fcd34d; }
    .ia-widget.ia-mode-dark.ia-widget--super { --acc:#a78bfa; }
    .ia-widget.ia-mode-light.ia-widget--super { --acc:#7c3aed; }
    .ia-widget.ia-mode-navy.ia-widget--super { --acc:#c4b5fd; }

    /* Pip */
    .pip { display: block; flex: none; }
    .pip .pip-body { fill: var(--acc); transition: fill .3s; }
    .pip .pip-hs-arc { fill: none; stroke: var(--ia-head); stroke-width: 3.4; stroke-linecap: round; }
    .pip .pip-hs { fill: var(--ia-head); }
    .pip .pip-mic { fill: none; stroke: var(--ia-head); stroke-width: 2.6; stroke-linecap: round; }
    .pip .pip-eye { fill: var(--ia-eye); }
    .pip .pip-line { fill: none; stroke: var(--ia-eye); stroke-width: 2.8; stroke-linecap: round; }
    .pip .pip-wave { fill: none; stroke: var(--ia-ok); stroke-width: 2.4; stroke-linecap: round; animation: pip-wave 1.2s ease-in-out infinite; }
    @keyframes pip-wave { 0%, 100% { opacity: .35; } 50% { opacity: 1; } }
    .pip .pip-f-call { display: none; }
    .ia-widget--oncall .pip .pip-f-idle { display: none; }
    .ia-widget--oncall .pip .pip-f-call { display: inline; }
    .ia-widget--levelup .pip { animation: pip-bounce .7s cubic-bezier(.3,1.6,.5,1) 2; }
    @keyframes pip-bounce { 0%, 100% { transform: translateY(0); } 40% { transform: translateY(-5px); } }

    /* Minimized tile (96 x 76) */
    .ia-widget .ia-bubble { background: var(--ia-bg); border: 1px solid var(--ia-line); border-radius: 14px; box-sizing: border-box;
      box-shadow: var(--ia-shadow); transition: transform .3s cubic-bezier(.34,1.56,.64,1), opacity .2s, background .3s, border-color .3s; }
    .ia-widget .ia-bubble::after { display: none; }
    .ia-widget .ia-bubble:hover { border-color: var(--acc); }
    .ia-mini { position: relative; z-index: 1; display: flex; align-items: center; justify-content: center; }
    .ia-mini__dot { position: absolute; top: -9px; right: -16px; }
    .ia-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--ia-line2); flex: none; transition: background .3s; }
    .ia-widget--running .ia-dot { background: var(--ia-ok); animation: ia-pulse 1.6s ease-in-out infinite; }
    @keyframes ia-pulse { 0%, 100% { opacity: 1; } 50% { opacity: .45; } }

    /* Open panel (280 x 331) */
    .ia-widget .ia-panel { width: 280px; height: 331px; box-sizing: border-box; padding: 13px; display: flex; flex-direction: column; gap: 9px;
      background: var(--ia-bg); color: var(--ia-text); border: 1px solid var(--ia-line); border-radius: 14px;
      box-shadow: var(--ia-shadow); overflow: hidden; transition: transform .3s cubic-bezier(.34,1.3,.64,1), opacity .2s, background .3s, border-color .3s, color .3s; }
    .ia-widget--maximized .ia-panel { cursor: grab; pointer-events: auto; }
    .ia-head { display: flex; align-items: center; gap: 7px; height: 32px; flex: none; }
    .ia-head__txt { flex: 1; min-width: 0; }
    .ia-head__title { font-size: 13.5px; font-weight: 600; color: var(--ia-title); line-height: 1.15; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ia-head__greet { font-size: 11px; color: var(--ia-muted); line-height: 1.25; height: 14px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .ia-head__greet .ia-led { font: inherit; letter-spacing: 0; fill: currentColor; }
    .ia-iconbtn { width: 24px; height: 24px; border-radius: 6px; box-sizing: border-box; display: inline-flex; align-items: center; justify-content: center; flex: none;
      color: var(--ia-muted); border: 1px solid transparent; font-size: 15px; line-height: 1; cursor: pointer; transition: background .15s, border-color .15s, color .15s; }
    .ia-iconbtn:hover { border-color: var(--ia-line2); color: var(--ia-title); }
    .ia-mode-btn { border-color: var(--ia-line2); color: var(--ia-sec); }
    .ia-ico { display: none; }
    .ia-mode-dark .ia-ico-dark, .ia-mode-light .ia-ico-light, .ia-mode-navy .ia-ico-navy { display: block; }
    .ia-min { width: 18px; }
    .ia-swatch { width: 10px; height: 10px; border-radius: 50%; background: var(--acc); box-shadow: 0 0 0 2px var(--ia-bg), 0 0 0 3px var(--ia-line2); transition: background .3s; }

    .ia-card { flex: 1; min-height: 0; background: var(--ia-card); border: 1px solid var(--ia-cardbd); border-radius: 10px; padding: 11px 12px; display: flex; flex-direction: column; transition: background .3s, border-color .3s; }
    .ia-idle { margin: auto; text-align: center; }
    .ia-idle__icon { display: inline-flex; color: var(--acc); margin-bottom: 4px; }
    .ia-idle__t { font-size: 14px; font-weight: 600; color: var(--ia-title); }
    .ia-idle__s { font-size: 11.5px; color: var(--ia-muted); margin-top: 2px; }
    .ia-panel .ia-screen-info { color: var(--ia-text); display: flex; flex-direction: column; height: 100%; }
    .ia-panel .ia-screen-info[style*="none"] { display: none !important; }
    .ia-panel .ia-screen-info__label { font-size: 11px; color: var(--acc); opacity: 1; font-weight: 600; line-height: 1.2; text-transform: none; letter-spacing: 0; }
    .ia-panel .ia-screen-info__client { font-size: 17px; font-weight: 600; color: var(--ia-title); max-height: 42px; line-height: 1.22; margin-top: 5px; }
    .ia-panel .ia-screen-info__route { font-size: 12.5px; color: var(--ia-muted); opacity: 1; margin-top: 3px; font-variant-numeric: tabular-nums; }
    .ia-card-foot { margin-top: auto; padding-top: 7px; border-top: 1px solid var(--ia-line); display: flex; align-items: baseline; gap: 8px; font-size: 11.5px; }
    .ia-panel .ia-screen-info__status { color: var(--ia-sec); opacity: 1; margin: 0; padding: 0; border: 0; line-height: 1.3; flex: 1; min-width: 0; }
    .ia-progress { margin-left: auto; color: var(--ia-muted); white-space: nowrap; font-variant-numeric: tabular-nums; }
    .ia-card-foot:has(.ia-screen-info__status[style*="none"]):has(.ia-progress:empty) { display: none; }

    .ia-panel button.ia-btn { font: inherit; display: inline-flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer; border-radius: 8px; transition: filter .15s, background .15s, border-color .15s, color .15s, opacity .2s; }
    .ia-call { height: 42px; flex: none; border: 0; border-radius: 9px !important; background: var(--acc); color: var(--ia-onacc); font-size: 14px !important; font-weight: 600 !important; }
    .ia-call:hover { filter: brightness(1.08); }
    .ia-call:active, .ia-sec:active, .ia-stop:active { transform: translateY(1px); }
    .ia-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 7px; flex: none; }
    .ia-sec, .ia-stop { height: 34px; font-size: 12px !important; font-weight: 500 !important; }
    .ia-sec { background: transparent; color: var(--ia-sec); border: 1px solid var(--ia-line2); }
    .ia-sec:hover { border-color: var(--acc); color: var(--ia-title); }
    .ia-stop { background: transparent; color: var(--ia-bad); border: 1px solid var(--ia-line2); }
    .ia-stop:hover { border-color: var(--ia-stop); }
    .ia-widget--running .ia-stop { background: var(--ia-stop); color: #fff; border-color: var(--ia-stop); }
    .ia-widget--stop-flash .ia-stop { animation: ia-stop-flash .9s ease-out 1; }
    @keyframes ia-stop-flash { 0% { background: var(--ia-stop); color: #fff; } 100% { } }
    .ia-panel .ia-btn--disabled { opacity: .4; }

    .ia-stats { display: flex; justify-content: space-between; align-items: center; gap: 6px; height: 20px; flex: none; font-size: 11px; font-weight: 600; color: var(--ia-muted); white-space: nowrap; }
    .ia-stats > span { flex: none; }
    .ia-stats b { font-size: 12.5px; font-weight: 800; color: var(--ia-title); font-variant-numeric: tabular-nums; margin-right: 1px; }
    .ia-stats b.ia-stat-ok { color: var(--ia-ok); }
    .ia-stats b.ia-stat-skip { color: #f5c542; }
    .ia-mode-light .ia-stats b.ia-stat-skip { color: #b7791f; }
    .ia-stats .ia-stat-round { text-align: right; }
    /* Bolder text across the panel */
    .ia-head__greet { font-weight: 600; }
    .ia-idle__t { font-weight: 800; }
    .ia-idle__s { font-weight: 600; }
    .ia-card-foot { font-weight: 600; }
    .ia-panel .ia-screen-info__client { font-weight: 800; }
    .ia-panel .ia-screen-info__label { font-weight: 800; }
    .ia-panel .ia-screen-info__route { font-weight: 600; }
    .ia-toggle { font-weight: 700; }
    .ia-sec, .ia-stop { font-weight: 700 !important; }
    .ia-call { font-weight: 800 !important; }
    .ia-foot { font-weight: 600; }
    /* Room for the numbers row inside the fixed 280 x 331 panel */
    .ia-widget .ia-panel { gap: 8px; }
    .ia-call { height: 38px; }
    .ia-sec, .ia-stop { height: 30px; }
    .ia-card { padding: 9px 12px; overflow: hidden; }
    .ia-panel .ia-screen-info__client { display: block; max-height: none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 4px; }
    .ia-card-foot { padding-top: 6px; }
    .ia-toggles { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; flex: none; }
    .ia-toggle { display: flex; align-items: center; justify-content: space-between; height: 22px; font-size: 12px; color: var(--ia-sec); cursor: pointer; }
    .ia-switch { position: relative; width: 28px; height: 16px; border-radius: 8px; background: var(--ia-line2); transition: background .2s; }
    .ia-switch span { position: absolute; top: 2px; left: 2px; width: 12px; height: 12px; border-radius: 50%; background: var(--ia-bg); transition: transform .2s, background .2s; }
    .ia-mode-light .ia-switch span { background: #ffffff; }
    .ia-widget--dd-on .ia-toggle--dd .ia-switch { background: var(--acc); }
    .ia-widget--dd-on .ia-toggle--dd .ia-switch span { transform: translateX(12px); background: var(--ia-onacc); }
    .ia-foot { height: 12px; flex: none; text-align: right; font-size: 10px; color: var(--ia-foot); line-height: 12px; margin-top: -4px; }


    /* Callback reminders */
    .ia-head { gap: 5px; }
    .ia-cb-btn { position: relative; width: 22px; border-color: var(--ia-line2); color: var(--ia-sec); }
    .ia-cb-badge { position: absolute; top: -6px; right: -7px; min-width: 15px; height: 15px; padding: 0 4px; box-sizing: border-box; border-radius: 999px;
      background: var(--acc); color: var(--ia-onacc); font: 800 9.5px/15px Inter, 'Segoe UI', system-ui, sans-serif; text-align: center; box-shadow: 0 0 0 2px var(--ia-bg); }
    .ia-cb-badge.is-due { background: var(--ia-bad); color: #fff; }
    .ia-cb-badge[hidden] { display: none !important; }
    .ia-card { position: relative; }
    .ia-panel .ia-screen-info .ia-cb-card { position: absolute; top: 6px; right: 7px; width: 22px; height: 22px; border-color: var(--ia-line2); color: var(--ia-sec); }
    .ia-panel .ia-screen-info .ia-cb-card.is-set { background: var(--acc); border-color: var(--acc); color: var(--ia-onacc); }
    .ia-panel .ia-screen-info__label { padding-right: 28px; }
    .ia-cbdue { position: absolute; right: 4px; bottom: 86px; width: 260px; box-sizing: border-box; pointer-events: auto; z-index: 3;
      background: var(--ia-bg); color: var(--ia-text); border: 1px solid var(--acc); border-radius: 12px; padding: 10px 12px;
      box-shadow: var(--ia-shadow); font: 600 12px/1.35 Inter, 'Segoe UI', system-ui, sans-serif; display: grid; gap: 6px; cursor: default; }
    .ia-cbdue[hidden], .ia-cbdue [hidden] { display: none !important; }
    .ia-widget--maximized .ia-cbdue, .ia-widget--peeking .ia-cbdue { bottom: 341px; }
    .ia-widget--cbdue .ia-reminder { display: none !important; }
    .ia-cbdue__top { display: flex; align-items: center; gap: 8px; }
    .ia-cbdue__k { flex: 1; color: var(--acc); font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: .06em; }
    .ia-cbdue__x { background: none; border: 0; color: var(--ia-muted); font: 800 17px/1 system-ui, sans-serif; cursor: pointer; padding: 0 2px; }
    .ia-cbdue__x:hover { color: var(--ia-title); }
    .ia-cbdue__who { font-size: 15px; font-weight: 800; color: var(--ia-title); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ia-cbdue__meta { color: var(--ia-muted); font-weight: 700; }
    .ia-cbdue__note { background: var(--ia-field); border: 1px solid var(--ia-line); border-radius: 7px; padding: 6px 8px; color: var(--ia-text); word-break: break-word; }
    .ia-cbdue__acts { display: grid; grid-template-columns: 1.4fr 1fr 1fr; gap: 6px; margin-top: 2px; }
    .ia-cbdue__a { border: 1px solid var(--ia-line2); background: transparent; color: var(--ia-title); border-radius: 7px; padding: 7px 4px; font: 800 12px/1 Inter, 'Segoe UI', system-ui, sans-serif; cursor: pointer; }
    .ia-cbdue__a:hover { border-color: var(--acc); }
    .ia-cbdue__a.is-main { background: var(--acc); border-color: var(--acc); color: var(--ia-onacc); }
    .ia-cbdue__more { color: var(--ia-muted); font-size: 11px; font-weight: 700; text-align: right; }

    .ia-cbpop { position: fixed; z-index: 2147483000; width: 260px; box-sizing: border-box; display: grid; gap: 8px; padding: 10px;
      background: var(--ia-bg, #0e0f13); color: var(--ia-text, #e8e8ed); border: 1px solid var(--ia-line, #23252d); border-radius: 10px;
      box-shadow: var(--ia-shadow, 0 18px 44px rgba(0,0,0,.55)); font: 600 12px/1.35 Inter, 'Segoe UI', system-ui, sans-serif; text-align: left; }
    .ia-cbpop [hidden] { display: none !important; }
    .ia-cbpop button { font-family: inherit; }
    .ia-cbpop-h { display: flex; align-items: center; justify-content: space-between; gap: 8px; color: var(--ia-muted, #8a8d98); font-weight: 700; }
    .ia-cbpop-h span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ia-cbpop-x { background: none; border: 0; color: var(--ia-muted, #8a8d98); font: 800 16px/1 system-ui, sans-serif; cursor: pointer; padding: 0 2px; }
    .ia-cbpop-x:hover { color: var(--ia-title, #fff); }
    .ia-cbpop-quick { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
    .ia-cbpop-q { border: 1px solid var(--ia-line2, #2c2f38); background: transparent; color: var(--ia-text, #e8e8ed); border-radius: 7px; padding: 6px 2px; font-size: 12px; font-weight: 700; cursor: pointer; }
    .ia-cbpop-q.wide { grid-column: span 2; }
    .ia-cbpop-q:hover { border-color: var(--acc, #7c7cf8); }
    .ia-cbpop-q.on { background: var(--acc, #7c7cf8); border-color: var(--acc, #7c7cf8); color: var(--ia-onacc, #0e0f13); }
    .ia-cbpop-pick { display: flex; gap: 6px; }
    .ia-cbpop-pick input, .ia-cbpop-note { flex: 1; min-width: 0; box-sizing: border-box; background: var(--ia-field, #15171d); color: var(--ia-title, #fff); border: 1px solid var(--ia-line2, #2c2f38);
      border-radius: 7px; padding: 6px 8px; font: 700 12px Inter, 'Segoe UI', system-ui, sans-serif; outline: none; color-scheme: dark light; }
    .ia-cbpop-pick input:focus, .ia-cbpop-note:focus { border-color: var(--acc, #7c7cf8); }
    .ia-cbpop-when { display: flex; justify-content: space-between; align-items: baseline; border: 1px solid var(--ia-line, #23252d); border-radius: 7px; padding: 6px 8px; }
    .ia-cbpop-when b { font-weight: 800; color: var(--ia-title, #fff); }
    .ia-cbpop-when span { color: var(--ia-muted, #8a8d98); font-size: 11px; }
    .ia-cbpop-err { color: var(--ia-bad, #f8717f); font-weight: 700; }
    .ia-cbpop-err:empty { display: none; }
    .ia-cbpop-acts { display: flex; gap: 6px; }
    .ia-cbpop-go { flex: 1; border: 0; border-radius: 7px; padding: 8px; background: var(--acc, #7c7cf8); color: var(--ia-onacc, #0e0f13); font-weight: 800; font-size: 13px; cursor: pointer; }
    .ia-cbpop-rm { border: 1px solid var(--ia-line2, #2c2f38); background: transparent; color: var(--ia-bad, #f8717f); border-radius: 7px; padding: 8px 10px; font-weight: 800; font-size: 12px; cursor: pointer; }
    .ia-cbpop-empty { color: var(--ia-muted, #8a8d98); padding: 4px 2px 2px; }
    .ia-cbpop-row { display: grid; grid-template-columns: 74px 1fr auto; gap: 8px; align-items: center; padding: 7px 4px; border-top: 1px solid var(--ia-line, #23252d); cursor: pointer; border-radius: 6px; }
    .ia-cbpop-h + .ia-cbpop-row { border-top: 0; }
    .ia-cbpop-row:hover { background: var(--ia-field, #15171d); }
    .ia-cbpop-tm { font-weight: 800; font-variant-numeric: tabular-nums; color: var(--ia-title, #fff); }
    .ia-cbpop-tm.due { color: var(--ia-bad, #f8717f); }
    .ia-cbpop-n { min-width: 0; }
    .ia-cbpop-n b { display: block; font-weight: 800; color: var(--ia-title, #fff); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ia-cbpop-n span { display: block; color: var(--ia-muted, #8a8d98); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

    .ia-cb-chip { display: inline-flex; align-items: center; gap: 5px; margin: 4px 0 0; padding: 2px 9px; border-radius: 999px; cursor: pointer;
      border: 1px solid #c7c7f5; background: #eef0ff; color: #3f3fb5; font: 800 12px/18px Inter, 'Segoe UI', system-ui, sans-serif; vertical-align: middle; }
    .ia-cb-chip:hover { border-color: #5b5bd6; }
    .ia-disc-chip { margin-left: 6px; }
    .ia-cb-chip { white-space: nowrap; flex: none; height: 22px; box-sizing: border-box; line-height: 18px; }
    .ia-cb-chip svg { flex: none; }
    .ia-tools-caret { font-size: 10px; margin-left: -1px; opacity: .8; }
    .ia-tools-chip.is-open { border-color: #5b5bd6; }
    .ia-tools-menu { position: fixed; z-index: 2147483000; min-width: 230px; padding: 6px; border-radius: 14px; display: grid; gap: 2px;
      background: var(--ias-sky, none), var(--ias-glass, #1b2132); border: 1px solid var(--ias-edge, rgba(255,255,255,.12)); box-shadow: var(--ias-shadow, 0 18px 40px rgba(0,0,0,.5)), inset 0 1px 0 var(--ias-inner, rgba(255,255,255,.06));
      -webkit-backdrop-filter: blur(18px) saturate(1.4); backdrop-filter: blur(18px) saturate(1.4); font-family: Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-tools-item { display: flex; align-items: center; gap: 10px; width: 100%; padding: 7px 9px; border: 0; border-radius: 10px; background: transparent; color: var(--ias-title, #fff); text-align: left; cursor: pointer; }
    .ia-tools-item:hover { background: var(--ias-chip, rgba(255,255,255,.08)); }
    .ia-tools-ic { width: 26px; height: 26px; border-radius: 8px; display: grid; place-items: center; flex: none; background: var(--ias-chip, rgba(255,255,255,.08)); color: var(--ias-acc, #7c7cf8); }
    .ia-tools-tx { display: grid; line-height: 1.25; }
    .ia-tools-tx b { font: 800 12.5px Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-tools-tx small { font: 600 11px Inter, 'Segoe UI', system-ui, sans-serif; color: var(--ias-muted, #9aa0b8); }
    .ia-cb-chip.is-set { background: #5b5bd6; border-color: #5b5bd6; color: #fff; }
    .ia-cb-chip.is-due { background: #e5484d; border-color: #e5484d; color: #fff; }
    /* Reminder card */
    .ia-widget .ia-reminder { background: var(--ia-bg); color: var(--ia-text); border: 1px solid var(--ia-line); border-radius: 10px;
      box-shadow: var(--ia-shadow); font-family: inherit; }
    .ia-widget .ia-reminder__dismiss { color: var(--ia-muted); }

    /* Round-complete banner instead of the game "level up" */
    .ia-widget .ia-levelup__text { top: -46px; font: 600 12px/1 Inter, 'Segoe UI', system-ui, sans-serif; letter-spacing: 0;
      background: var(--ia-bg); -webkit-background-clip: border-box; background-clip: border-box; color: var(--ia-title);
      border: 1px solid var(--acc); padding: 9px 12px; border-radius: 8px; filter: none;
      box-shadow: var(--ia-shadow); animation: ia-banner 2.4s ease forwards; }
    @keyframes ia-banner { 0% { opacity: 0; transform: translateX(-50%) translateY(8px); } 12%, 85% { opacity: 1; transform: translateX(-50%) translateY(0); } 100% { opacity: 0; transform: translateX(-50%) translateY(-6px); } }
    .ia-widget--levelup .ia-full { animation: none !important; }

    /* Switch off the old character-only effects */
    .ia-widget--gold .ia-bubble, .ia-widget--gold .ia-full,
    .ia-widget--gold-unlock .ia-full,
    .ia-widget--cracked .ia-full, .ia-widget--cracked .ia-bubble { animation: none !important; filter: none !important; }
  `);

  // ------------------------------------------------------------------
  // Sky Glass (2.0): frosted glass panel, rounded chips, bold text.
  // Mode colours come straight from IA_MODES, so they always match the
  // flight-site pop-up, search panel and banners.
  // ------------------------------------------------------------------
  GM_addStyle(Object.keys(IA_MODES).map((m) => '.ia-widget.ia-mode-' + m + ' { ' + Object.keys(IA_MODES[m]).map((k) => '--ia-' + k + ':' + IA_MODES[m][k] + ';').join(' ') + ' }').join('\n') + `
    .ia-widget.ia-mode-light.ia-widget--midnight { --acc:#1f5cff; }
    .ia-widget { font-family: 'Plus Jakarta Sans', Inter, 'Segoe UI', system-ui, -apple-system, sans-serif; }
    .ia-widget .ia-panel { background: var(--ia-sky), var(--ia-glass); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5);
      border: 1px solid var(--ia-edge); border-radius: 22px; box-shadow: var(--ia-shadow), inset 0 1px 0 var(--ia-edge); padding: 12px; }
    .ia-widget .ia-bubble { background: var(--ia-sky), var(--ia-glass); -webkit-backdrop-filter: blur(18px) saturate(1.4); backdrop-filter: blur(18px) saturate(1.4);
      border: 1px solid var(--ia-edge); border-radius: 22px; box-shadow: var(--ia-shadow), inset 0 1px 0 var(--ia-edge); }
    .ia-head { gap: 4px; }
    .ia-head .pip { width: 26px; height: 28px; }
    .ia-head__title { font-size: 13.5px; font-weight: 800; letter-spacing: -.01em; }
    .ia-iconbtn, .ia-mode-btn, .ia-cb-btn { border: 1px solid transparent !important; border-radius: 10px; background: var(--ia-chip); box-shadow: var(--ia-chipshadow); color: var(--ia-title); }
    .ia-iconbtn:hover { border-color: var(--acc) !important; }
    .ia-min { width: 22px; font-weight: 800; }
    .ia-head .ia-iconbtn { width: 22px; height: 22px; border-radius: 8px; }
    .ia-head .ia-dot { margin: 0 1px; }
    .ia-card { background: var(--ia-inner); border: 0; border-radius: 16px; box-shadow: var(--ia-chipshadow); padding: 8px 12px; }
    .ia-panel .ia-screen-info__label::before { content: ''; display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: var(--ia-ok); margin-right: 6px; vertical-align: 1px;
      box-shadow: 0 0 0 3px color-mix(in srgb, var(--ia-ok) 22%, transparent); }
    .ia-panel .ia-screen-info__client { font-size: 17.5px; margin-top: 3px; }
    .ia-panel .ia-screen-info__route { margin-top: 1px; font-weight: 700; }
    .ia-card-foot { border-top: 0; padding-top: 3px; font-weight: 700; }
    .ia-panel .ia-screen-info__status { font-size: 11.5px; font-weight: 700; }
    .ia-idle__icon { color: var(--acc); }
    .ia-panel .ia-screen-info .ia-cb-card { border-radius: 8px; border: 1px solid transparent; background: var(--ia-chip); color: var(--ia-title); top: 6px; right: 6px; }
    .ia-stats { height: 32px; gap: 5px; justify-content: stretch; }
    .ia-stats > span { flex: 1 1 0; min-width: 0; height: 32px; display: flex; flex-direction: column; align-items: center; justify-content: center; border-radius: 10px;
      background: var(--ia-chip); box-shadow: var(--ia-chipshadow); font-size: 9.5px; font-weight: 700; line-height: 1.1; text-transform: lowercase; text-align: center; }
    .ia-stats b { order: -1; font-size: 14px; margin: 0; line-height: 1.05; }
    .ia-stats .ia-stat-round { text-align: center; }
    .ia-call { height: 36px; border-radius: 14px !important; background: linear-gradient(135deg, color-mix(in srgb, var(--acc) 78%, #fff), var(--acc)); color: var(--ia-onacc);
      box-shadow: 0 8px 18px color-mix(in srgb, var(--acc) 35%, transparent); }
    .ia-sec, .ia-stop { border: 1px solid transparent !important; border-radius: 12px !important; background: var(--ia-chip); box-shadow: var(--ia-chipshadow); font-weight: 800 !important; }
    .ia-sec { color: var(--ia-title); }
    .ia-sec:hover { border-color: var(--acc) !important; }
    .ia-stop { color: var(--ia-bad); }
    .ia-stop:hover { border-color: var(--ia-stop) !important; }
    .ia-widget--running .ia-stop { background: var(--ia-stop); color: #fff; }
    .ia-toggle { color: var(--ia-sec); font-weight: 700; }
    .ia-switch { background: var(--ia-chip); box-shadow: inset 0 0 0 1px var(--ia-line2); }
    .ia-switch span { background: #ffffff; }
    .ia-mode-light .ia-switch { background: #c9d4ea; box-shadow: none; }
    .ia-widget--dd-on .ia-toggle--dd .ia-switch { box-shadow: none; }
    .ia-widget--dd-on .ia-toggle--dd .ia-switch span { background: #ffffff; }
    .ia-foot { font-weight: 700; }
    .ia-widget .ia-reminder { background: var(--ia-sky), var(--ia-glass); -webkit-backdrop-filter: blur(18px) saturate(1.4); backdrop-filter: blur(18px) saturate(1.4);
      border: 1px solid var(--ia-edge); border-radius: 16px; font-weight: 700; }
    .ia-widget .ia-levelup__text { background: var(--ia-glass); -webkit-backdrop-filter: blur(18px); backdrop-filter: blur(18px); border: 1px solid var(--ia-edge); border-radius: 14px; font-weight: 800; }
    .ia-cbdue { background: var(--ia-sky), var(--ia-glass); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5);
      border: 1px solid var(--ia-edge); border-radius: 18px; box-shadow: var(--ia-shadow), inset 0 1px 0 var(--ia-edge), 0 0 0 2px color-mix(in srgb, var(--acc) 35%, transparent); }
    .ia-cbdue__k { text-transform: none; letter-spacing: 0; font-size: 11.5px; }
    .ia-cbdue__note { background: var(--ia-inner); border: 0; border-radius: 12px; font-weight: 700; }
    .ia-cbdue__a { border: 1px solid transparent; background: var(--ia-chip); box-shadow: var(--ia-chipshadow); border-radius: 12px; height: 30px; }
    .ia-cbdue__a.is-main { background: linear-gradient(135deg, color-mix(in srgb, var(--acc) 78%, #fff), var(--acc)); border-color: transparent; color: var(--ia-onacc); }
    .ia-cbpop { background: var(--ia-sky, transparent), var(--ia-glass, #0e0f13); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5);
      border: 1px solid var(--ia-edge, #23252d); border-radius: 18px; box-shadow: var(--ia-shadow), inset 0 1px 0 var(--ia-edge, transparent); padding: 11px; }
    .ia-cbpop-q, .ia-cbpop-rm { border: 1px solid transparent; background: var(--ia-chip); box-shadow: var(--ia-chipshadow); border-radius: 12px; font-weight: 800; }
    .ia-cbpop-q:hover { border-color: var(--acc); }
    .ia-cbpop-pick input, .ia-cbpop-note { border: 1px solid transparent; background: var(--ia-chip); border-radius: 12px; }
    .ia-cbpop-when { border: 0; background: var(--ia-inner); border-radius: 12px; }
    .ia-cbpop-go { border-radius: 12px; background: linear-gradient(135deg, color-mix(in srgb, var(--acc) 78%, #fff), var(--acc)); box-shadow: 0 8px 18px color-mix(in srgb, var(--acc) 30%, transparent); }
    .ia-cbpop-row { border-top: 0; border-radius: 12px; }
    .ia-cbpop-row:hover { background: var(--ia-chip); }
    .ia-cb-chip { border-radius: 999px; }
  `);

  // ------------------------------------------------------------------
  // Nova (2.15.0): the website's look for the panel and its pop-ups.
  // Only applies in Nova and Nova Night (the widget gets .ia-nova).
  // Animations use transform and opacity only.
  // ------------------------------------------------------------------
  GM_addStyle(`
    .ia-widget.ia-mode-nova { --acc: #FF5B2E; } .ia-widget.ia-mode-novanight { --acc: #FF7048; }
    .ia-mode-nova .ia-ico-dark, .ia-mode-novanight .ia-ico-dark { display: block; }
    .ia-widget.ia-nova { font-family: ${IA_NOVA_FONT}; --ia-spring: cubic-bezier(.34,1.4,.64,1); }
    .ia-widget.ia-nova .ia-panel { background: var(--ia-sky), var(--ia-glass); border: 1px solid var(--ia-line); border-radius: 26px; box-shadow: var(--ia-shadow); padding: 12px; }
    .ia-widget.ia-nova .ia-bubble { background: var(--ia-sky), var(--ia-glass); border: 1px solid var(--ia-line); border-radius: 26px; box-shadow: var(--ia-shadow); }
    .ia-widget.ia-nova .ia-head__title { font-family: ${IA_NOVA_DISPLAY}; font-weight: 700; font-size: 12.5px; letter-spacing: -.02em; }
    .ia-widget.ia-nova .ia-head__greet { font-weight: 600; }
    .ia-widget.ia-nova .ia-iconbtn, .ia-widget.ia-nova .ia-mode-btn, .ia-widget.ia-nova .ia-cb-btn { border-radius: 50% !important; background: var(--ia-chip); box-shadow: var(--ia-chipshadow);
      transition: transform .25s var(--ia-spring), border-color .15s; }
    .ia-widget.ia-nova .ia-iconbtn:active { transform: scale(.88); }
    .ia-widget.ia-nova .ia-btn-theme { display: none !important; }
    .ia-widget.ia-nova .ia-cb-badge { background: var(--acc); color: #121628; font-family: ${IA_NOVA_MONO}; font-weight: 500; }
    .ia-widget.ia-nova .ia-card { background: var(--ia-inner); border-radius: 18px; box-shadow: none; }
    .ia-widget.ia-nova .ia-panel .ia-screen-info__label { font-family: ${IA_NOVA_MONO}; font-weight: 500; font-size: 9.5px; letter-spacing: .1em; text-transform: uppercase; color: var(--ia-ok); }
    .ia-widget.ia-nova .ia-panel .ia-screen-info__client { font-family: ${IA_NOVA_DISPLAY}; font-weight: 600; font-size: 15px; letter-spacing: -.03em; }
    .ia-widget.ia-nova .ia-idle__t { font-family: ${IA_NOVA_DISPLAY}; font-weight: 600; letter-spacing: -.02em; }
    .ia-widget.ia-nova .ia-panel .ia-screen-info .ia-cb-card { border-radius: 50%; background: var(--ia-chip); box-shadow: var(--ia-chipshadow); }
    .ia-widget.ia-nova .ia-panel .ia-screen-info .ia-cb-card.is-set { background: var(--ia-pri); color: var(--ia-onpri); }
    .ia-widget.ia-nova .ia-stats > span { border-radius: 12px; background: var(--ia-inner); box-shadow: none; font-family: ${IA_NOVA_MONO}; font-weight: 500; font-size: 8.5px; letter-spacing: .04em; text-transform: uppercase; }
    .ia-widget.ia-nova .ia-stats b { font-family: ${IA_NOVA_DISPLAY}; font-weight: 600; font-size: 13.5px; letter-spacing: -.03em; }
    .ia-widget.ia-nova .ia-call { border-radius: 999px !important; background: var(--ia-pri); color: var(--ia-onpri); filter: none;
      box-shadow: 0 10px 22px -12px color-mix(in srgb, var(--ia-text) 70%, transparent); transition: transform .3s var(--ia-spring), opacity .2s; }
    .ia-widget.ia-nova .ia-call:hover { filter: none; transform: translateY(-1px); }
    .ia-widget.ia-nova .ia-call:active, .ia-widget.ia-nova .ia-sec:active, .ia-widget.ia-nova .ia-stop:active { transform: scale(.95); }
    .ia-widget.ia-nova .ia-sec, .ia-widget.ia-nova .ia-stop { border-radius: 999px !important; background: var(--ia-chip); box-shadow: inset 0 0 0 1.5px var(--ia-line); transition: transform .3s var(--ia-spring), border-color .15s; }
    .ia-widget.ia-nova .ia-sec:hover { border-color: var(--ia-line2) !important; }
    .ia-widget.ia-nova.ia-widget--running .ia-stop { background: var(--ia-stop); color: #fff; box-shadow: none; }
    .ia-widget.ia-nova .ia-switch { background: var(--ia-line2); box-shadow: none; }
    .ia-widget.ia-nova.ia-widget--dd-on .ia-toggle--dd .ia-switch { background: var(--ia-pri); }
    .ia-widget.ia-nova.ia-widget--dd-on .ia-toggle--dd .ia-switch span { background: var(--acc); }
    .ia-widget.ia-nova .ia-news-btn { font-family: ${IA_NOVA_FONT}; background: var(--ia-chip); box-shadow: var(--ia-chipshadow); }
    .ia-widget.ia-nova .ia-foot { font-family: ${IA_NOVA_MONO}; font-weight: 500; letter-spacing: .04em; }
    .ia-widget.ia-nova .ia-reminder, .ia-widget.ia-nova .ia-levelup__text { border: 1px solid var(--ia-line); border-radius: 18px; font-family: ${IA_NOVA_FONT}; }
    .ia-widget.ia-nova .ia-cbdue { font-family: ${IA_NOVA_FONT}; border: 1px solid var(--ia-line); border-radius: 22px; box-shadow: var(--ia-shadow); }
    .ia-widget.ia-nova .ia-cbdue__k { font-family: ${IA_NOVA_MONO}; font-weight: 500; letter-spacing: .1em; text-transform: uppercase; font-size: 10px; color: var(--acc); }
    .ia-widget.ia-nova .ia-cbdue__who { font-family: ${IA_NOVA_DISPLAY}; font-weight: 600; letter-spacing: -.03em; }
    .ia-widget.ia-nova .ia-cbdue__a { border-radius: 999px; font-family: ${IA_NOVA_FONT}; box-shadow: inset 0 0 0 1.5px var(--ia-line); transition: transform .3s var(--ia-spring); }
    .ia-widget.ia-nova .ia-cbdue__a:active { transform: scale(.95); }
    .ia-widget.ia-nova .ia-cbdue__a.is-main { background: var(--ia-pri); color: var(--ia-onpri); box-shadow: none; }
    .ia-cbpop.ia-nova { font-family: ${IA_NOVA_FONT}; border: 1px solid var(--ia-line); border-radius: 22px; }
    .ia-cbpop.ia-nova .ia-cbpop-q, .ia-cbpop.ia-nova .ia-cbpop-rm { border-radius: 999px; box-shadow: inset 0 0 0 1.5px var(--ia-line); }
    .ia-cbpop.ia-nova .ia-cbpop-q.on { background: var(--ia-pri); color: var(--ia-onpri); box-shadow: none; }
    .ia-cbpop.ia-nova .ia-cbpop-pick input, .ia-cbpop.ia-nova .ia-cbpop-note { border-radius: 14px; box-shadow: inset 0 0 0 1.5px var(--ia-line); }
    .ia-cbpop.ia-nova .ia-cbpop-go { border-radius: 999px; background: var(--ia-pri); color: var(--ia-onpri); box-shadow: none; }
    .ia-cbpop.ia-nova .ia-cbpop-tm { font-family: ${IA_NOVA_MONO}; font-weight: 500; }

    /* Look menu (every look) */
    .ia-looks { position: absolute; top: 46px; right: 10px; z-index: 6; width: 196px; box-sizing: border-box; padding: 8px; display: grid; gap: 2px;
      background: var(--ia-sky), var(--ia-glass); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5);
      border: 1px solid var(--ia-line); border-radius: 18px; box-shadow: var(--ia-shadow); animation: ia-looks-in .28s cubic-bezier(.34,1.4,.64,1) both; transform-origin: top right; }
    @keyframes ia-looks-in { from { opacity: 0; transform: translateY(-6px) scale(.96); } }
    .ia-looks__hd { padding: 2px 8px 4px; font: 500 9.5px/1.4 ${IA_NOVA_MONO}; letter-spacing: .12em; text-transform: uppercase; color: var(--ia-muted); }
    .ia-look { display: flex; align-items: center; gap: 9px; width: 100%; padding: 7px 9px; border: 0; border-radius: 12px; background: transparent; color: var(--ia-title);
      font-family: inherit; font-weight: 700; font-size: 12.5px; line-height: 1.2; text-align: left; cursor: pointer; transition: transform .25s cubic-bezier(.34,1.4,.64,1); }
    .ia-look:hover { background: var(--ia-chip); }
    .ia-look:active { transform: scale(.97); }
    .ia-look[aria-checked="true"] { background: var(--ia-pri, var(--acc)); color: var(--ia-onpri, var(--ia-onacc)); }
    .ia-look small { margin-left: auto; font: 500 9px ${IA_NOVA_MONO}; letter-spacing: .08em; text-transform: uppercase; opacity: .7; }
    .ia-look__dots { display: inline-flex; flex: none; }
    .ia-look__dots i { width: 13px; height: 13px; border-radius: 50%; margin-left: -4px; box-shadow: 0 0 0 1.5px var(--ia-chip), 0 0 0 2px rgba(127,127,127,.25); }
    .ia-look__dots i:first-child { margin-left: 0; }
    @media (prefers-reduced-motion: reduce) { .ia-looks { animation: none; } }
  `);

  // Shares PART 2/3/4's single observer instead of keeping its own —
  // see the comment where __jsEnsureSharedObserver is defined.
  // ==========================================================================
  // Send quotes (leads list). For each lead on the page the tool reads its
  // quotes from the BO, keeps only the green-badge (profitable) ones, writes
  // the BO's own "Send options" email, and then SHOWS EACH EMAIL AND WAITS:
  // nothing goes out until the agent presses Send (Skip and Stop are always
  // there). Emails only: texting was taken out in 2.14.0.
  // A yellow tick in the PQs column marks leads whose quotes went out today
  // (click it to tick / untick); ticked leads are skipped.
  // ==========================================================================
  const SQ_SENT_KEY = 'ia-quotes-sent';      // { e|t: { leadId: [quote ids] } }
  const SQ_DAY_KEY = 'ia-quotes-done-day';   // today's ticks (day rolls at 2pm GMT)
  const sqSleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const SQ_AIRLINES = {
    AA: 'American Airlines', DL: 'Delta', UA: 'United', AC: 'Air Canada', BA: 'British Airways', LH: 'Lufthansa', AF: 'Air France', KL: 'KLM',
    EK: 'Emirates', QR: 'Qatar Airways', EY: 'Etihad', TK: 'Turkish Airlines', SQ: 'Singapore Airlines', CX: 'Cathay Pacific', NH: 'ANA', JL: 'Japan Airlines',
    QF: 'Qantas', VS: 'Virgin Atlantic', IB: 'Iberia', LX: 'Swiss', OS: 'Austrian', SN: 'Brussels Airlines', TP: 'TAP Air Portugal', AY: 'Finnair',
    SK: 'SAS', AZ: 'ITA Airways', EI: 'Aer Lingus', KE: 'Korean Air', OZ: 'Asiana', BR: 'EVA Air', CI: 'China Airlines', CA: 'Air China', MU: 'China Eastern',
    CZ: 'China Southern', AI: 'Air India', TG: 'Thai Airways', MS: 'EgyptAir', ET: 'Ethiopian', SA: 'South African', KQ: 'Kenya Airways', RJ: 'Royal Jordanian',
    SV: 'Saudia', GF: 'Gulf Air', WY: 'Oman Air', KU: 'Kuwait Airways', LA: 'LATAM', AV: 'Avianca', CM: 'Copa Airlines', AM: 'Aeromexico', AR: 'Aerolineas Argentinas',
    G3: 'Gol', JJ: 'LATAM Brasil', B6: 'JetBlue', AS: 'Alaska Airlines', HA: 'Hawaiian Airlines', WS: 'WestJet', NZ: 'Air New Zealand', PR: 'Philippine Airlines',
    MH: 'Malaysia Airlines', GA: 'Garuda Indonesia', VN: 'Vietnam Airlines', PK: 'PIA', UL: 'SriLankan', LO: 'LOT Polish', OU: 'Croatia Airlines', JU: 'Air Serbia',
    RO: 'TAROM', FI: 'Icelandair', WN: 'Southwest', F9: 'Frontier', NK: 'Spirit', AT: 'Royal Air Maroc', TU: 'Tunisair', AH: 'Air Algerie', BG: 'Biman', S7: 'S7 Airlines',
  };

  // ---- the leads list -------------------------------------------------------
  const sqRowFor = (id) => getLeadRows().find((r) => getLeadId(r) === id) || null;
  function sqHeaderIndex(row, re) {
    const table = row.closest('table');
    if (!table) return -1;
    let col = 0;
    for (const th of table.querySelectorAll('thead tr:first-child th')) {
      const label = th.querySelector('.list-table-v2__sort') || th;
      if (re.test(label.textContent.trim())) return col;
      col += th.colSpan || 1;
    }
    return -1;
  }
  function sqCellAt(row, idx) {
    if (idx < 0) return null;
    let col = 0;
    for (const td of row.children) {
      const span = td.colSpan || 1;
      if (idx >= col && idx < col + span) return td;
      col += span;
    }
    return null;
  }
  const sqIsEmail = (t) => /^[^\s@]+@[^\s@]+$/.test(String(t || '').trim());
  // The lead's email as the row shows it, only if it's already shown in full.
  function sqShownEmail(row) {
    const td = sqCellAt(row, sqHeaderIndex(row, /^email$/i));
    for (const cell of (td ? [td] : Array.from(row.children))) {
      for (const el of cell.querySelectorAll('div.truncate')) {
        const t = el.textContent.trim();
        if (sqIsEmail(t)) return t.includes('*') ? '' : t;
      }
    }
    return '';
  }
  // The row's agent: <td><div class="truncate max-w-[120px]"><span>Name</span></div></td>
  function sqAgentOf(row) {
    for (const sp of row.querySelectorAll('td > div.truncate > span')) {
      const box = sp.parentElement;
      if (!/max-w-\[120px\]/.test(box.className) || box.classList.contains('cursor-pointer')) continue;
      const t = sp.textContent.replace(/\s+/g, ' ').trim();
      if (/^[\p{L}][\p{L} .'-]+$/u.test(t)) return t;
    }
    return '';
  }
  function sqInfo(row) {
    const i = getLeadInfo(row);
    return { leadId: i.leadId, clientName: i.clientName, origin: i.origin, dest: i.dest, agent: sqAgentOf(row) };
  }
  // ---- what went out (memory + the yellow tick) ----------------------------
  function sqSentMap() { try { const o = JSON.parse(GM_getValue(SQ_SENT_KEY, '{}')); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
  const sqSent = (kind, leadId) => new Set((((sqSentMap()[kind] || {})[leadId]) || []).map(String));
  function sqRemember(kind, leadId, pks) {
    const o = sqSentMap();
    o[kind] = o[kind] || {};
    const s = new Set((o[kind][leadId] || []).map(String));
    pks.forEach((p) => s.add(String(p)));
    o[kind][leadId] = Array.from(s);
    try { GM_setValue(SQ_SENT_KEY, JSON.stringify(o)); } catch (e) { /* best-effort */ }
  }
  // e / t = quotes sent today by email / text, m = ticked by hand, u = unticked by hand today,
  // f = follow-up email sent today.
  function sqDayLog() {
    try {
      const o = JSON.parse(GM_getValue(SQ_DAY_KEY, '{}'));
      if (o && o.day === todayKey() && o.e && o.t) { o.m = o.m || {}; o.u = o.u || {}; o.f = o.f || {}; return o; }
    } catch (e) { /* fall through */ }
    return { day: todayKey(), e: {}, t: {}, m: {}, u: {}, f: {} };
  }
  const sqSaveDay = (o) => { try { GM_setValue(SQ_DAY_KEY, JSON.stringify(o)); } catch (e) { /* best-effort */ } };
  function sqTicked(leadId) {
    const o = sqDayLog(), id = String(leadId);
    if (o.u[id]) return false;
    return !!(o.e[id] || o.t[id] || o.m[id]);
  }
  function sqMark(kind, leadId) { const o = sqDayLog(); o[kind][String(leadId)] = Date.now(); delete o.u[String(leadId)]; sqSaveDay(o); sqPaintTicks(); }
  function sqToggle(leadId) {
    const o = sqDayLog(), id = String(leadId);
    if (sqTicked(id)) { delete o.e[id]; delete o.t[id]; delete o.m[id]; o.u[id] = Date.now(); } else { delete o.u[id]; o.m[id] = Date.now(); }
    sqSaveDay(o);
    sqPaintTicks();
  }
  // Yellow tick in the cell right after "PQs" (the sent-PQs count).
  function sqPaintTicks() {
    const o = sqDayLog();
    getLeadRows().forEach((row) => {
      const id = String(getLeadId(row) || '');
      const pi = sqHeaderIndex(row, /^PQs/i);
      const td = pi < 0 ? null : sqCellAt(row, pi + 1);
      const host = td && (td.querySelector('.flex.items-center') || td);
      if (!host) return;
      let ck = host.querySelector('.ia-sq-tick');
      if (!ck) {
        ck = document.createElement('span');
        ck.className = 'ia-sq-tick';
        ck.setAttribute('role', 'button');
        ck.textContent = '✓';
        ck.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); const r = ck.closest('tr'); if (r) sqToggle(getLeadId(r)); });
        ['mousedown', 'mouseup', 'dblclick'].forEach((n) => ck.addEventListener(n, (ev) => ev.stopPropagation()));
        host.appendChild(ck);
      }
      const on = sqTicked(id);
      ck.classList.toggle('is-on', on);
      const tip = on
        ? (o.m[id] ? 'Ticked by hand' : 'Quotes emailed today') + ' \u2014 Send quotes skips this lead. Click to untick.'
        : 'Quotes not sent today. Click to tick it and skip this lead.';
      if (ck.title !== tip) ck.title = tip;
    });
  }

  // ---- the BO's API -----------------------------------------------------------
  function sqHeaders() {
    const h = Object.assign({}, __jsApi.headers);
    if (!Object.keys(h).some((k) => /authorization/i.test(k))) { const sa = __jsStoredAuth(); if (sa) h.Authorization = sa; }
    return Object.keys(h).some((k) => /authorization/i.test(k)) ? h : null;
  }
  async function sqApi(path, body) {
    const h = sqHeaders();
    if (!h) throw new Error('BO session not ready yet — wait a few seconds and try again');
    const headers = Object.assign({ Accept: 'application/json' }, h);
    const opts = { credentials: 'include', headers };
    if (body !== undefined) { headers['content-type'] = 'application/json'; opts.method = 'POST'; opts.body = JSON.stringify(body); }
    const res = await pageWin.fetch(path, opts);
    let j = null;
    try { j = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok || (j && j.success === false)) throw new Error((j && j.message) || ('BO said HTTP ' + res.status));
    return j;
  }
  const sqFirst = (j) => { const r = j && (j.result || j.data); return Array.isArray(r) ? r : []; };
  const sqDollars = (n) => '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 });
  const SQ_MON = { JAN: 'Jan', FEB: 'Feb', MAR: 'Mar', APR: 'Apr', MAY: 'May', JUN: 'Jun', JUL: 'Jul', AUG: 'Aug', SEP: 'Sep', OCT: 'Oct', NOV: 'Nov', DEC: 'Dec' };
  const sqDay = (d) => (SQ_MON[d.slice(2)] || d.slice(2)) + ' ' + parseInt(d.slice(0, 2), 10);
  // Profit the way the lead page's green / red badge shows it:
  // sell - net - (sell x card-fee %), summed over passengers.
  function sqMoney(d) {
    const cnt = { adult: d.adult_count, child: d.child_count, infant: d.infant_count };
    let sell = 0, net = 0, known = true, perAdult = null;
    (d.preTickets || []).forEach((pt) => {
      if (/award/i.test(pt.sell_type || '')) known = false;
      (pt.prices || []).forEach((p) => {
        const type = String(p.passenger_type || '').toLowerCase();
        const n = cnt[type] != null ? Number(cnt[type]) || 0 : 1;
        if (p.net_price == null || p.sell_amount == null) known = false;
        sell += (Number(p.sell_amount) || 0) * n;
        net += (Number(p.net_price) || 0) * n;
        if (type === 'adult' && perAdult == null) perAdult = Number(p.sell_amount) || 0;
      });
    });
    const fee = sell * (Number(d.check_payment_ps) || 0) / 100;
    return { sell, net, perAdult, known, profit: Math.round((sell - net - fee) * 100) / 100 };
  }
  // "Copa Airlines: JFK → GRU Feb 18, return GRU → JFK Feb 22 — $3,191 per adult"
  function sqLine(d, m) {
    const segs = (d.segments || []).slice().sort((a, b) => (a.number || 0) - (b.number || 0)).map((sg) => {
      const x = String(sg.line_raw || '').toUpperCase().match(/\b([A-Z0-9]{2})\s*\*?\s*(\d{1,4})\s+[A-Z]\s+(\d{2}[A-Z]{3})\s+([A-Z]{3})\s*([A-Z]{3})\b/);
      return x ? { carrier: x[1], date: x[3], from: x[4], to: x[5], ret: !!Number(sg.is_return) } : null;
    }).filter(Boolean);
    if (!segs.length) return 'Flight option — ' + sqDollars(m.perAdult != null ? m.perAdult : m.sell);
    const out = segs.filter((s) => !s.ret), back = segs.filter((s) => s.ret);
    const leg = (a) => a[0].from + ' → ' + a[a.length - 1].to + ' ' + sqDay(a[0].date);
    const trip = (out.length ? leg(out) : leg(segs)) + (back.length ? ', return ' + leg(back) : '');
    const air = SQ_AIRLINES[segs[0].carrier] || segs[0].carrier;
    const travelers = (Number(d.adult_count) || 0) + (Number(d.child_count) || 0) + (Number(d.infant_count) || 0);
    const price = (m.perAdult != null && Number(d.adult_count) === travelers)
      ? sqDollars(m.perAdult) + ' per adult' + (travelers > 1 ? ' (' + sqDollars(m.sell) + ' total)' : '')
      : sqDollars(m.sell) + ' total';
    return air + ': ' + trip + ' — ' + price;
  }
  // The lead's quotes, fresh from the BO: [{ pk, line, profit, ok, why, sent, link }].
  async function sqLoad(leadId) {
    const lead = sqFirst(await sqApi('/api/database/v2/Lead/find?pks=' + leadId))[0];
    if (!lead) throw new Error('lead ' + leadId + ' not found in the BO');
    const lst = sqFirst(await sqApi('/api/database/v2/LeadPriceQuoteList/find?pks=' + leadId))[0];
    const ids = ((lst && lst.list) || []).map(String);
    if (!ids.length) return { lead, quotes: [] };
    const meta = {};
    sqFirst(await sqApi('/api/database/v2/PriceQuote/find?pks=' + ids.join(','))).forEach((x) => { meta[String(x.id)] = x; });
    // Each quote's "View deal" link comes from the offer it was last sent in.
    const links = {};
    const offers = Array.from(new Set(Object.keys(meta).map((k) => meta[k].offer_pk).filter(Boolean).map(String))).sort((a, b) => Number(a) - Number(b));
    if (offers.length) {
      try {
        sqFirst(await sqApi('/api/database/v2/LeadOffer/find?pks=' + offers.join(','))).sort((a, b) => Number(a.id) - Number(b.id)).forEach((o) => {
          (o.links || []).forEach((u) => { const mm = String(u).match(/\/A(\d+)$/); if (mm) links[mm[1]] = u; });
        });
      } catch (e) { /* links are optional */ }
    }
    const quotes = [];
    for (const id of ids) {
      const mt = meta[id];
      if (!mt || mt.is_hidden) continue;
      const j = await sqApi('/api/database/v1/priceQuotes/PriceQuoteFormModel/' + id);
      const d = j && (j.result || j.data || j);
      if (!d || !Array.isArray(d.preTickets)) continue;
      const m = sqMoney(d);
      let why = '';
      if (!m.known) why = 'profit unknown (award / no net price)';
      else if (m.profit <= 0) why = (m.profit < 0 ? 'negative' : 'zero') + ' profit';
      quotes.push({ pk: id, line: sqLine(d, m), profit: m.profit, ok: !why, why, sent: !!mt.is_sent, link: links[id] || '' });
    }
    return { lead, quotes };
  }
  // Only ever called after the agent pressed Send.
  async function sqSendEmail(lead, pks) {
    if (!lead.client_email_pk) return { ok: false, error: 'the lead has no email in the BO' };
    try {
      await sqApi('/api/database/v2/LeadOffer/action/sendOffer?waitsForResponse=true', {
        personal: false, lead_pk: String(lead.id), email_pk: String(lead.client_email_pk), project_pk: String(lead.project_pk || '1'),
        price_quote_pks: pks.map(String), passengers_info: null, recommended_pq_pk: null, hotel_included_pq_pks: [],
        order_by_pq: 'price_based', discount: [], badgeTypes: pks.map((p) => ({ pq_pk: String(p), badgeTypes: [] })),
      });
      return { ok: true };
    } catch (e) { return { ok: false, error: 'the BO refused the email (' + (e && e.message ? e.message : e) + ')' }; }
  }
  // ---- the window -------------------------------------------------------------
  const sqRun = { on: false, stop: false };
  function sqWin() {
    document.querySelectorAll('.ia-sq').forEach((n) => n.remove());
    const pal = iaPalette();
    const ov = document.createElement('div');
    ov.className = 'ia-sq' + (iaIsNova(pal.mode) ? ' ia-sq--nova' : '');
    ov.style.cssText = '--q-glass:' + pal.glass + ';--q-sky:' + pal.sky + ';--q-edge:' + pal.edge + ';--q-inner:' + pal.inner + ';--q-chip:' + pal.chip + ';--q-chipsh:' + pal.chipshadow + ';--q-title:' + pal.title + ';--q-sec:' + pal.sec + ';--q-acc:' + pal.pri + ';--q-onacc:' + pal.onpri + ';--q-shadow:' + pal.shadow + ';--q-ok:' + (pal.ok || '#22c55e') + ';--q-bad:' + (pal.bad || '#ef4444');
    const card = document.createElement('div');
    card.className = 'ia-sq__card';
    ov.appendChild(card);
    document.body.appendChild(ov);
    return { ov, card, close: () => ov.remove() };
  }
  const sqEsc = (s) => smsEsc(s);
  function sqHead(icon, small, title, tag) {
    return '<div class="ia-sq__head"><div class="ia-sq__ic">' + icon + '</div><div><small>' + sqEsc(small) + '</small><b>' + sqEsc(title) + '</b></div>' + (tag ? '<span class="ia-sq__tag">' + sqEsc(tag) + '</span>' : '') + '</div>';
  }
  // Shows one email and waits for the agent: resolves 'send' | 'skip' | 'stop'.
  function sqAsk(w, o) {
    return new Promise((resolve) => {
      const qs = o.quotes.map((x) => '<div class="ia-sq__q' + (x.ok ? '' : ' is-red') + '"><span class="ia-sq__box' + (x.ok ? '' : ' is-off') + '">' + (x.ok ? '✓' : '') + '</span><span>' + sqEsc(x.line) + '</span><span class="ia-sq__p">' + (x.ok ? '+' + sqDollars(x.profit) : (x.profit < 0 ? '−' + sqDollars(-x.profit) : sqDollars(x.profit || 0)) + ' · not sent') + '</span></div>').join('');
      w.card.innerHTML = sqHead('\u2709', 'Lead ' + o.n + ' of ' + o.tot + ' \u00b7 #' + o.id, o.name, 'Email \u00b7 BO Send options')
        + '<div class="ia-sq__to"><span>To</span>' + sqEsc(o.to) + '</div>'
        + qs
        + '<div class="ia-sq__btns"><span class="ia-sq__prog">' + sqEsc(o.prog) + '</span><button type="button" class="ia-sq__b is-stop">Stop</button><button type="button" class="ia-sq__b">Skip</button><button type="button" class="ia-sq__b is-go">Send email</button></div>';
      const [stop, skip, go] = w.card.querySelectorAll('.ia-sq__b');
      const done = (v) => { document.removeEventListener('keydown', onKey, true); resolve({ act: v }); };
      const onKey = (e) => { if (e.key === 'Escape') { e.preventDefault(); done('stop'); } };
      stop.addEventListener('click', () => done('stop'));
      skip.addEventListener('click', () => done('skip'));
      go.addEventListener('click', () => { go.disabled = true; done('send'); });
      document.addEventListener('keydown', onKey, true);
      setTimeout(() => go.focus(), 0);
    });
  }
  function sqBusy(w, o, line) {
    w.card.innerHTML = sqHead('✈', 'Lead ' + o.n + ' of ' + o.tot + ' · #' + o.id, o.name) + '<div class="ia-sq__wait">' + sqEsc(line) + '</div>'
      + '<div class="ia-sq__btns"><span class="ia-sq__prog">' + sqEsc(o.prog) + '</span><button type="button" class="ia-sq__b is-stop">Stop</button></div>';
    w.card.querySelector('.is-stop').addEventListener('click', () => { sqRun.stop = true; });
  }
  // ==========================================================================
  // Follow-up emails (2.17.0). "Send emails" on the leads list offers Quotes
  // (PQs, as before) or a Follow-up email from four templates each agent can
  // edit (saved on their own computer). The client's first name, the agent
  // and the trip (cities and dates) are read from the BO for each lead and
  // filled in. Every email is shown and waits for Send / Skip / Stop; the
  // agent can change the subject or text for that one email first.
  // ==========================================================================
  const FU_TPL_KEY = 'ia-fu-email-templates';
  const FU_KIND_KEY = 'ia-send-kind';
  const FU_PICK_KEY = 'ia-fu-pick';
  const FU_SIGN = '\n\nBest regards,\n{agent}\nTravel Business Class';
  const FU_DEFAULT = [
    { name: 'Follow-up 1', subject: 'Your business class trip to {destination}',
      text: 'Hi {client},\n\n{agent} here from Travel Business Class regarding your trip from {origin} to {destination} ({dates}). I’ve got you some really good discounted business class deals with major airlines and wanted to confirm a few details with you to see which one will work best.\n\nWhen is the best time to talk?' + FU_SIGN },
    { name: 'Follow-up 2', subject: 'Following up – your flight to {destination}',
      text: 'Hi {client},\n\nJust following up on my previous message about your flight to {destination} ({dates}). I found a couple of business class options that look pretty good for your trip.\n\nWould you have a few minutes today for me to run them by you?' + FU_SIGN },
    { name: 'Follow-up 3', subject: 'Still looking at flights to {destination}?',
      text: 'Hi {client},\n\nI wanted to check in and see if you’re still looking at options for your trip from {origin} to {destination} ({dates}). I’d be happy to go over the best fares I’m seeing and find something that makes sense for you.\n\nWhen would be a good time to connect?' + FU_SIGN },
    { name: 'Follow-up 4', subject: 'Before I close out your flight request',
      text: 'Hi {client},\n\nI wanted to catch you before I close out your flight request for {trip}. I still have some good business class fares available with major airlines.\n\nWhat time would be easiest for me to reach you?' + FU_SIGN },
  ];
  function fuTemplates() {
    let t = null;
    try { t = JSON.parse(GM_getValue(FU_TPL_KEY, 'null')); } catch (e) { t = null; }
    return FU_DEFAULT.map((d, i) => {
      const x = Array.isArray(t) ? t[i] : null;
      return x && typeof x.text === 'string' && x.text.trim() ? { name: d.name, subject: String(x.subject || d.subject), text: x.text } : Object.assign({}, d);
    });
  }
  function fuSaveTemplates(list) {
    try { GM_setValue(FU_TPL_KEY, JSON.stringify(list.map((x) => ({ subject: x.subject, text: x.text })))); } catch (e) { /* best-effort */ }
  }
  const fuGet = (k, d) => { try { return GM_getValue(k, d); } catch (e) { return d; } };
  const fuSet = (k, v) => { try { GM_setValue(k, v); } catch (e) { /* best-effort */ } };
  const fuCity = (c) => (c ? (SMS_CITY[c] || c) : '');
  function fuDay(unix, tz) {
    if (!unix) return '';
    const d = new Date(Number(unix) * 1000);
    const o = { month: 'short', day: 'numeric' };
    try { return d.toLocaleDateString('en-US', Object.assign({ timeZone: tz || 'UTC' }, o)); } catch (e) { return d.toLocaleDateString('en-US', Object.assign({ timeZone: 'UTC' }, o)); }
  }
  // The agent's name from the BO: the lead's agent as the leads list shows
  // it, otherwise the signed-in agent from the BO login, otherwise the first
  // name the panel already knows.
  function fuAgentName(row) {
    const fromRow = row ? sqAgentOf(row) : '';
    if (fromRow) return fromRow;
    const toks = [];
    try { const a = __jsStoredAuth(); if (a) toks.push(a); } catch (e) { /* ignore */ }
    try { Object.keys(__jsApi.headers || {}).forEach((k) => { if (/authorization/i.test(k)) toks.push(__jsApi.headers[k]); }); } catch (e) { /* ignore */ }
    for (const t of toks) {
      try {
        const part = String(t).replace(/^Bearer\s+/i, '').split('.')[1];
        if (!part) continue;
        const j = JSON.parse(decodeURIComponent(escape(atob(part.replace(/-/g, '+').replace(/_/g, '/')))));
        for (const o of [j, j.user, j.data]) {
          if (!o || typeof o !== 'object') continue;
          const f = o.first_name || o.firstName || o.given_name || '', l = o.last_name || o.lastName || o.family_name || '';
          const n = (f + ' ' + l).trim() || (o.name && /\s/.test(o.name) ? String(o.name) : '');
          if (n) return n;
        }
      } catch (e) { /* try the next */ }
    }
    return smsAgentName() || fuGet('bmo-first-name', '');
  }
  // The client's first name and the trip, read from the BO for this lead.
  async function fuLoad(leadId, row) {
    const lead = sqFirst(await sqApi('/api/database/v2/Lead/find?pks=' + leadId))[0];
    if (!lead) throw new Error('lead ' + leadId + ' not found in the BO');
    let first = '';
    if (lead.client_pk) {
      try {
        const c = sqFirst(await sqApi('/api/database/v2/ClientPreview/find?pks=' + lead.client_pk))[0];
        first = c && c.first_name ? String(c.first_name).trim().split(/\s+/)[0] : '';
      } catch (e) { /* the name is a nice-to-have */ }
    }
    if (first) first = first.charAt(0).toUpperCase() + first.slice(1).toLowerCase();
    const info = row ? sqInfo(row) : {};
    const from = fuCity(lead.from_iata_code || info.origin), to = fuCity(lead.to_iata_code || info.dest);
    const dep = fuDay(lead.departure_date, lead.from_iata_timezone);
    const ret = lead.return_date ? fuDay(lead.return_date, lead.to_iata_timezone) : '';
    const dates = dep && ret && ret !== dep ? dep + ' – ' + ret : dep;
    const vals = {
      client: first || 'there',
      agent: String(fuAgentName(row) || '').trim() || 'your Travel Business Class agent',
      origin: from || 'your city',
      destination: to || 'your destination',
      dates,
      trip: [from && to ? from + ' to ' + to : (to || 'your trip'), dates].filter(Boolean).join(', '),
    };
    return { lead, vals };
  }
  function fuFill(text, v) {
    return String(text)
      .replace(/\{(client|agent|origin|destination|dates|trip)\}/gi, (m, k) => v[k.toLowerCase()] || '')
      .replace(/[ \t]*\(\s*\)/g, '')
      .replace(/[ \t]{2,}/g, ' ')
      .replace(/ +([,.!?])/g, '$1');
  }
  const fuHtml = (t) => String(t).split(/\n{2,}/).map((p) => '<p>' + smsEsc(p).replace(/\n/g, '<br>') + '</p>').join('');
  // Only ever called after the agent pressed Send. Goes out through the BO,
  // so it shows in the lead's history.
  async function fuSend(lead, email, subject, text) {
    const data = { to_email_uuids: [], to_emails: [], subject, body: fuHtml(text), attachments: [] };
    if (email) data.to_emails.push(email);
    else if (lead.client_email_pk) data.to_email_uuids.push(String(lead.client_email_pk));
    else return { ok: false, error: 'the lead has no email in the BO' };
    try {
      await sqApi('/api/database/v2/EmailContactAttempt/action/send?waitsForResponse=false', {
        model: { model_name: 'Lead', model_pk: String(lead.id) }, conversation_pk: null, data,
      });
      return { ok: true };
    } catch (e) { return { ok: false, error: 'the BO refused the email (' + (e && e.message ? e.message : e) + ')' }; }
  }
  // Which follow-up a lead gets: the next one it hasn't had, or the one picked.
  function fuIndexFor(leadId, pick) {
    const had = sqSent('f', leadId);
    if (pick === 'next') { for (let i = 0; i < 4; i++) if (!had.has(String(i))) return i; return null; }
    const i = Number(pick) - 1;
    return had.has(String(i)) ? null : i;
  }
  const fuToday = (leadId) => !!((sqDayLog().f || {})[String(leadId)]);
  function fuMarkToday(leadId) { const o = sqDayLog(); o.f = o.f || {}; o.f[String(leadId)] = Date.now(); sqSaveDay(o); }

  function sqStart() {
    if (sqRun.on) return;
    const rows = getLeadRows();
    const w = sqWin();
    if (!rows.length) {
      w.card.innerHTML = sqHead('✉', 'Send emails', 'Open your leads list first') + '<div class="ia-sq__btns"><button type="button" class="ia-sq__b is-go">OK</button></div>';
      w.card.querySelector('.is-go').addEventListener('click', w.close);
      return;
    }
    const items = rows.map((row) => ({ id: String(getLeadId(row)), info: sqInfo(row) }));
    let kind = fuGet(FU_KIND_KEY, 'q') === 'f' ? 'f' : 'q';
    let pick = String(fuGet(FU_PICK_KEY, 'next'));
    if (!/^(next|[1-4])$/.test(pick)) pick = 'next';
    const paint = () => {
      let sum, note, todo;
      if (kind === 'q') {
        const ticked = items.filter((x) => sqTicked(x.id)).length;
        todo = items.filter((x) => !sqTicked(x.id));
        sum = '<div><b>' + todo.length + '</b> leads to go through</div>' + (ticked ? '<div>Quotes already sent today (yellow tick): <b>' + ticked + '</b> — skipped</div>' : '');
        note = 'For each lead the tool reads its quotes from the BO and prepares the BO’s own “Send options” email with the green-badge quotes only; red ($0 or less), hidden and award quotes are never included. <b>You’ll see and confirm every email before it goes.</b>';
      } else {
        let today = 0, had = 0;
        todo = [];
        items.forEach((x) => {
          if (fuToday(x.id)) { today++; return; }
          const idx = fuIndexFor(x.id, pick);
          if (idx == null) { had++; return; }
          todo.push(Object.assign({}, x, { idx }));
        });
        sum = '<div><b>' + todo.length + '</b> leads to go through</div>'
          + (today ? '<div>Already had a follow-up today: <b>' + today + '</b> — skipped</div>' : '')
          + (had ? '<div>' + (pick === 'next' ? 'Had all 4 follow-ups' : 'Already had follow-up ' + pick) + ': <b>' + had + '</b> — skipped</div>' : '');
        note = 'The client’s name, your name and the trip are filled in from the BO for each lead. <b>You’ll see every email first; nothing goes out until you press Send.</b> <a class="ia-sq__link" href="#">Edit templates</a>';
      }
      const segBtn = (k, label) => '<button type="button" class="ia-sq__segb' + (kind === k ? ' is-on' : '') + '" data-kind="' + k + '">' + label + '</button>';
      const chip = (v, label) => '<button type="button" class="ia-sq__chip' + (pick === v ? ' is-on' : '') + '" data-pick="' + v + '">' + label + '</button>';
      w.card.innerHTML = sqHead('✉', 'Send emails', 'Leads on this page')
        + '<div class="ia-sq__seg">' + segBtn('q', 'Quotes (PQs)') + segBtn('f', 'Follow-up email') + '</div>'
        + (kind === 'f' ? '<div class="ia-sq__lbl">Which follow-up</div><div class="ia-sq__chips">' + chip('next', 'Next for each lead') + chip('1', '1') + chip('2', '2') + chip('3', '3') + chip('4', '4') + '</div>' : '')
        + '<div class="ia-sq__sum ia-sq__box2">' + sum + '</div>'
        + '<div class="ia-sq__note">' + note + '</div>'
        + '<div class="ia-sq__btns"><button type="button" class="ia-sq__b ia-sq-cancel">Cancel</button><button type="button" class="ia-sq__b is-go ia-sq-start"' + (todo.length ? '' : ' disabled') + '>Start</button></div>';
      w.card.querySelectorAll('[data-kind]').forEach((b) => b.addEventListener('click', () => { kind = b.dataset.kind; fuSet(FU_KIND_KEY, kind); paint(); }));
      w.card.querySelectorAll('[data-pick]').forEach((b) => b.addEventListener('click', () => { pick = b.dataset.pick; fuSet(FU_PICK_KEY, pick); paint(); }));
      const ed = w.card.querySelector('.ia-sq__link');
      if (ed) ed.addEventListener('click', (e) => { e.preventDefault(); fuEditor(w, paint); });
      w.card.querySelector('.ia-sq-cancel').addEventListener('click', w.close);
      w.card.querySelector('.ia-sq-start').addEventListener('click', () => (kind === 'q' ? sqGo(w, todo) : fuGo(w, todo)));
    };
    paint();
  }

  // Edit the four follow-up templates (saved for this agent only).
  function fuEditor(w, back) {
    const list = fuTemplates();
    let cur = 0;
    const draw = () => {
      const t = list[cur];
      w.card.innerHTML = sqHead('✎', 'Follow-up emails', 'Edit templates')
        + '<div class="ia-sq__chips ia-sq__tabs">' + list.map((x, i) => '<button type="button" class="ia-sq__chip' + (i === cur ? ' is-on' : '') + '" data-tab="' + i + '">' + (i + 1) + '</button>').join('') + '</div>'
        + '<div class="ia-sq__lbl">Subject</div><input class="ia-sq__in ia-fu-subj" type="text" value="' + sqEsc(t.subject) + '">'
        + '<div class="ia-sq__lbl">Text</div><textarea class="ia-sq__in ia-sq__ta ia-fu-text">' + sqEsc(t.text) + '</textarea>'
        + '<div class="ia-sq__hint">{client} · {agent} · {origin} · {destination} · {dates} · {trip} are filled in for each lead</div>'
        + '<div class="ia-sq__btns"><button type="button" class="ia-sq__b ia-fu-reset" style="margin-right:auto">Reset</button><button type="button" class="ia-sq__b ia-fu-cancel">Cancel</button><button type="button" class="ia-sq__b is-go ia-fu-save">Save</button></div>';
      const keep = () => { list[cur].subject = w.card.querySelector('.ia-fu-subj').value; list[cur].text = w.card.querySelector('.ia-fu-text').value; };
      w.card.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => { keep(); cur = +b.dataset.tab; draw(); }));
      w.card.querySelector('.ia-fu-reset').addEventListener('click', () => { list[cur] = Object.assign({}, FU_DEFAULT[cur]); draw(); });
      w.card.querySelector('.ia-fu-cancel').addEventListener('click', () => back());
      w.card.querySelector('.ia-fu-save').addEventListener('click', () => {
        keep();
        list.forEach((x, i) => { if (!x.text.trim()) list[i] = Object.assign({}, FU_DEFAULT[i]); });
        fuSaveTemplates(list);
        back();
      });
    };
    draw();
  }
  // Shows one follow-up email and waits: { act: 'send' | 'skip' | 'stop', subject, text }.
  function fuAsk(w, o) {
    return new Promise((resolve) => {
      w.card.innerHTML = sqHead('✉', 'Lead ' + o.n + ' of ' + o.tot + ' · #' + o.id, o.name, o.tag)
        + '<div class="ia-sq__to"><span>To</span>' + sqEsc(o.to) + '</div>'
        + '<div class="ia-sq__lbl">Subject</div><input class="ia-sq__in ia-fu-subj" type="text" value="' + sqEsc(o.subject) + '">'
        + '<div class="ia-sq__lbl">Email</div><textarea class="ia-sq__in ia-sq__ta ia-fu-text">' + sqEsc(o.text) + '</textarea>'
        + '<div class="ia-sq__hint">Changes here are for this email only</div>'
        + '<div class="ia-sq__btns"><span class="ia-sq__prog">' + sqEsc(o.prog) + '</span><button type="button" class="ia-sq__b is-stop">Stop</button><button type="button" class="ia-sq__b">Skip</button><button type="button" class="ia-sq__b is-go">Send email</button></div>';
      const [stop, skip, go] = w.card.querySelectorAll('.ia-sq__b');
      const subj = w.card.querySelector('.ia-fu-subj'), txt = w.card.querySelector('.ia-fu-text');
      const done = (v) => { document.removeEventListener('keydown', onKey, true); resolve({ act: v, subject: subj.value.trim(), text: txt.value }); };
      const onKey = (e) => { if (e.key === 'Escape') { e.preventDefault(); done('stop'); } };
      stop.addEventListener('click', () => done('stop'));
      skip.addEventListener('click', () => done('skip'));
      go.addEventListener('click', () => {
        if (!subj.value.trim() || !txt.value.trim()) { (subj.value.trim() ? txt : subj).focus(); return; }
        go.disabled = true; done('send');
      });
      document.addEventListener('keydown', onKey, true);
      setTimeout(() => go.focus(), 0);
    });
  }
  async function fuGo(w, todo) {
    sqRun.on = true; sqRun.stop = false;
    const st = { sent: 0, skip: 0, fail: [] };
    const tpl = fuTemplates();
    const tot = todo.length;
    let n = 0;
    const prog = () => 'Sent so far: ' + st.sent + (st.skip ? ' · ' + st.skip + ' skipped' : '');
    try {
      for (const item of todo) {
        if (sqRun.stop) break;
        n++;
        const name = item.info.clientName || ('Lead ' + item.id);
        const o = { n, tot, id: item.id, name, prog: prog() };
        if (fuToday(item.id)) continue;
        sqBusy(w, o, 'Reading this lead from the BO…');
        let data;
        try { data = await fuLoad(item.id, sqRowFor(item.id)); } catch (err) { st.fail.push(name + ' (' + (err && err.message ? err.message : err) + ')'); continue; }
        if (sqRun.stop) break;
        const t = tpl[item.idx];
        const shown = sqShownEmail(sqRowFor(item.id) || document.body);
        const a = await fuAsk(w, Object.assign({}, o, {
          prog: prog(), tag: t.name, to: shown || 'the client’s email on this lead',
          subject: fuFill(t.subject, data.vals), text: fuFill(t.text, data.vals),
        }));
        if (a.act === 'stop') { sqRun.stop = true; break; }
        if (a.act === 'skip') { st.skip++; continue; }
        sqBusy(w, o, 'Sending the email…');
        const r = await fuSend(data.lead, shown, a.subject, a.text);
        if (r.ok) { sqRemember('f', item.id, [item.idx]); fuMarkToday(item.id); st.sent++; } else st.fail.push(name + ' (' + r.error + ')');
        await sqSleep(1500);
      }
    } finally {
      sqRun.on = false;
    }
    const fails = st.fail.length ? '<div>Failed: <b>' + st.fail.length + '</b> — ' + st.fail.slice(0, 4).map(sqEsc).join('; ') + (st.fail.length > 4 ? '; …' : '') + '</div>' : '';
    w.card.innerHTML = sqHead('✓', 'Follow-up emails', sqRun.stop ? 'Stopped' : 'Done')
      + '<div class="ia-sq__sum"><div>Emails sent: <b>' + st.sent + '</b></div><div>Skipped by you: <b>' + st.skip + '</b></div>' + fails + '</div>'
      + '<div class="ia-sq__note">Everything sent is remembered: the next run gives each client the next follow-up.</div>'
      + '<div class="ia-sq__btns"><button type="button" class="ia-sq__b is-go">Close</button></div>';
    w.card.querySelector('.is-go').addEventListener('click', w.close);
  }

  async function sqGo(w, todo) {
    sqRun.on = true; sqRun.stop = false;
    const st = { e: 0, skip: 0, none: 0, fail: [] };
    const tot = todo.length;
    let n = 0;
    const prog = () => 'Sent so far: ' + st.e + ' email' + (st.e === 1 ? '' : 's') + (st.skip ? ' \u00b7 ' + st.skip + ' skipped' : '');
    try {
      for (const item of todo) {
        if (sqRun.stop) break;
        n++;
        const name = item.info.clientName || ('Lead ' + item.id);
        const o = { n, tot, id: item.id, name, prog: prog() };
        if (sqTicked(item.id)) continue;
        sqBusy(w, o, 'Reading this lead\u2019s quotes from the BO\u2026');
        let data;
        try { data = await sqLoad(item.id); } catch (err) { st.fail.push(name + ' (' + (err && err.message ? err.message : err) + ')'); continue; }
        if (sqRun.stop) break;
        if (!data.quotes.some((x) => x.ok)) { st.none++; continue; }
        const done = sqSent('e', item.id);
        const list = data.quotes.filter((x) => x.ok && !done.has(x.pk) && !x.sent);
        if (!list.length) { sqMark('e', item.id); continue; }
        const shown = sqShownEmail(sqRowFor(item.id) || document.body);
        const show = data.quotes.filter((x) => !x.ok || list.includes(x));
        const a = await sqAsk(w, Object.assign({}, o, { prog: prog(), to: shown || 'the client\u2019s email on this lead', quotes: show }));
        if (a.act === 'stop') { sqRun.stop = true; break; }
        if (a.act === 'skip') { st.skip++; continue; }
        sqBusy(w, o, 'Sending the email\u2026');
        const r = await sqSendEmail(data.lead, list.map((x) => x.pk));
        if (r.ok) { sqRemember('e', item.id, list.map((x) => x.pk)); sqMark('e', item.id); st.e++; } else st.fail.push(name + ' (' + r.error + ')');
        await sqSleep(1500);
      }
    } finally {
      sqRun.on = false;
    }
    const fails = st.fail.length ? '<div>Failed: <b>' + st.fail.length + '</b> \u2014 ' + st.fail.slice(0, 4).map(sqEsc).join('; ') + (st.fail.length > 4 ? '; \u2026' : '') + '</div>' : '';
    w.card.innerHTML = sqHead('\u2713', 'Send quotes', sqRun.stop ? 'Stopped' : 'Done')
      + '<div class="ia-sq__sum"><div>Emails sent: <b>' + st.e + '</b></div>'
      + '<div>Skipped by you: <b>' + st.skip + '</b> \u00b7 No green quotes: <b>' + st.none + '</b></div>' + fails + '</div>'
      + '<div class="ia-sq__note">Everything sent is remembered, so the next run carries on where this one stopped.</div>'
      + '<div class="ia-sq__btns"><button type="button" class="ia-sq__b is-go">Close</button></div>';
    w.card.querySelector('.is-go').addEventListener('click', w.close);
    sqPaintTicks();
  }

  // The "✈ Send quotes" chip, before "Showing … of … entries" on a leads list.
  function sqChip() {
    if (window.top !== window) return;
    const onList = !/^\/leads\/\d+/.test(location.pathname) && getLeadRows().length > 0;
    let chip = document.querySelector('.ia-sq-chip');
    const label = onList && Array.from(document.querySelectorAll('span, div, p')).find((el) => el.children.length === 0 && /^Showing\s+\d+\s*(?:-|to)\s*\d+\s+of\s+\d+/i.test(el.textContent.trim()));
    if (!label) { if (chip) chip.remove(); return; }
    if (!chip) {
      chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'ia-sq-chip';
      chip.textContent = '\u2709 Send emails';
      chip.title = 'Email each lead its green quotes or a follow-up \u2014 you confirm every email';
      chip.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); sqStart(); });
    }
    const pal = iaPalette();
    chip.style.setProperty('--q-acc', pal.pri);
    chip.style.setProperty('--q-onacc', pal.onpri);
    if (chip.nextElementSibling !== label) label.insertAdjacentElement('beforebegin', chip);
  }
  function sqScan() { try { sqChip(); if (getLeadRows().length) sqPaintTicks(); } catch (e) { /* ignore */ } }

  GM_addStyle(`
    .ia-sq-chip { display: inline-flex; align-items: center; gap: 4px; margin-right: 10px; border: 0; border-radius: 999px; padding: 5px 12px; cursor: pointer; white-space: nowrap;
      font: 800 12px Inter, 'Segoe UI', system-ui, sans-serif; color: var(--q-onacc, #fff); background: linear-gradient(135deg, color-mix(in srgb, var(--q-acc, #7c7cf8) 78%, #fff), var(--q-acc, #7c7cf8)); box-shadow: 0 4px 12px rgba(0,0,0,.18); }
    .ia-sq-chip:hover { filter: brightness(1.06); }
    .ia-sq-tick { flex: none; cursor: pointer; margin-left: 4px; font: 800 12px/1 system-ui, sans-serif; color: #facc15; opacity: 0; transition: opacity .15s; user-select: none; }
    .ia-sq-tick.is-on { opacity: 1; text-shadow: 0 0 1px rgba(120,80,0,.6); }
    tr:hover .ia-sq-tick:not(.is-on) { opacity: .35; }
    .ia-sq { position: fixed; inset: 0; z-index: 2147483600; background: rgba(6,10,24,.38); display: flex; align-items: center; justify-content: center; }
    .ia-sq__card { width: 440px; max-width: calc(100vw - 32px); max-height: calc(100vh - 40px); overflow: auto; box-sizing: border-box; border-radius: 20px; padding: 14px; background: var(--q-sky), var(--q-glass); border: 1px solid var(--q-edge);
      -webkit-backdrop-filter: blur(22px) saturate(1.5); backdrop-filter: blur(22px) saturate(1.5); box-shadow: var(--q-shadow), inset 0 1px 0 var(--q-edge); color: var(--q-title); font: 600 13px Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-sq__head { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; }
    .ia-sq__ic { width: 32px; height: 32px; border-radius: 10px; display: grid; place-items: center; background: var(--q-acc); color: var(--q-onacc); font-size: 15px; flex: none; }
    .ia-sq__head small { display: block; color: var(--q-sec); font-weight: 700; font-size: 11px; }
    .ia-sq__head b { font-size: 14px; font-weight: 800; }
    .ia-sq__tag { margin-left: auto; font: 800 10.5px Inter, 'Segoe UI', system-ui, sans-serif; padding: 3px 9px; border-radius: 999px; background: color-mix(in srgb, var(--q-acc) 18%, transparent); white-space: nowrap; }
    .ia-sq__to { background: var(--q-inner); border-radius: 12px; padding: 7px 10px; margin-bottom: 8px; font-size: 12px; }
    .ia-sq__to span { color: var(--q-sec); font-weight: 700; margin-right: 6px; }
    .ia-sq__q { display: grid; grid-template-columns: auto 1fr auto; gap: 8px; align-items: center; padding: 6px 8px; border-radius: 10px; background: var(--q-inner); margin-bottom: 5px; font-size: 12px; }
    .ia-sq__q.is-red { opacity: .6; }
    .ia-sq__p { font-weight: 800; color: var(--q-ok); white-space: nowrap; }
    .ia-sq__q.is-red .ia-sq__p { color: var(--q-bad); }
    .ia-sq__box { width: 15px; height: 15px; border-radius: 5px; background: var(--q-acc); color: var(--q-onacc); display: grid; place-items: center; font-size: 10px; }
    .ia-sq__box.is-off { background: transparent; border: 1.5px solid var(--q-sec); box-sizing: border-box; }
    .ia-sq__hint { font-size: 11px; color: var(--q-sec); margin-top: 5px; font-weight: 600; }
    .ia-sq__wait { padding: 10px 2px; color: var(--q-sec); }
    .ia-sq__sum div { margin: 3px 0; }
    .ia-sq__chk { display: flex; gap: 8px; align-items: center; margin: 7px 0; font-size: 12.5px; cursor: pointer; }
    .ia-sq__chk input { accent-color: var(--q-acc); width: 15px; height: 15px; margin: 0; }
    .ia-sq__note { font: 500 11.5px/1.45 Inter, 'Segoe UI', system-ui, sans-serif; color: var(--q-sec); background: var(--q-inner); border-radius: 10px; padding: 8px 10px; margin-top: 8px; }
    .ia-sq__note b { color: var(--q-title); }
    .ia-sq__btns { display: flex; gap: 6px; justify-content: flex-end; align-items: center; margin-top: 12px; }
    .ia-sq__prog { margin-right: auto; font-size: 11.5px; color: var(--q-sec); }
    .ia-sq__b { white-space: nowrap; border: 1px solid transparent; border-radius: 999px; padding: 7px 14px; cursor: pointer; font: 800 12px Inter, 'Segoe UI', system-ui, sans-serif; background: var(--q-chip); color: var(--q-title); box-shadow: var(--q-chipsh); }
    .ia-sq__b:hover { border-color: var(--q-acc); }
    .ia-sq__b.is-go { background: linear-gradient(180deg, color-mix(in srgb, var(--q-acc) 78%, white), var(--q-acc)); color: var(--q-onacc); }
    .ia-sq__b.is-stop { color: var(--q-bad); }
    .ia-sq__b:disabled { opacity: .6; cursor: default; }
    .ia-sq__seg { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; padding: 4px; border-radius: 999px; background: var(--q-inner); margin-bottom: 4px; }
    .ia-sq__segb { border: 0; border-radius: 999px; min-height: 36px; cursor: pointer; background: transparent; color: var(--q-sec); font: 800 12.5px Inter, 'Segoe UI', system-ui, sans-serif; transition: transform .25s cubic-bezier(.34,1.4,.64,1); }
    .ia-sq__segb.is-on { background: var(--q-acc); color: var(--q-onacc); box-shadow: 0 8px 18px -10px rgba(0,0,0,.5); }
    .ia-sq__segb:active, .ia-sq__chip:active { transform: scale(.95); }
    .ia-sq__lbl { font: 800 10px Inter, 'Segoe UI', system-ui, sans-serif; letter-spacing: .08em; text-transform: uppercase; color: var(--q-sec); margin: 10px 2px 6px; }
    .ia-sq__chips { display: flex; flex-wrap: wrap; gap: 5px; }
    .ia-sq__tabs .ia-sq__chip { flex: 1; }
    .ia-sq__chip { border: 0; border-radius: 999px; padding: 7px 12px; cursor: pointer; background: var(--q-chip); color: var(--q-title); box-shadow: inset 0 0 0 1.5px color-mix(in srgb, var(--q-sec) 30%, transparent); font: 800 12px Inter, 'Segoe UI', system-ui, sans-serif; transition: transform .25s cubic-bezier(.34,1.4,.64,1); }
    .ia-sq__chip.is-on { background: var(--q-acc); color: var(--q-onacc); box-shadow: none; }
    .ia-sq__box2 { background: var(--q-inner); border-radius: 12px; padding: 8px 10px; margin-top: 10px; }
    .ia-sq__link { color: var(--q-title); font-weight: 800; text-decoration: underline; cursor: pointer; }
    .ia-sq__in { display: block; width: 100%; box-sizing: border-box; border: 0; border-radius: 12px; background: var(--q-inner); color: var(--q-title); padding: 8px 10px; outline: none;
      box-shadow: inset 0 0 0 1.5px color-mix(in srgb, var(--q-sec) 25%, transparent); font: 600 12.5px/1.5 Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-sq__in:focus { box-shadow: inset 0 0 0 1.5px var(--q-acc); }
    .ia-sq__ta { min-height: 190px; resize: vertical; font-weight: 500; }
    .ia-sq--nova .ia-sq__card { font-family: ${IA_NOVA_FONT}; border-radius: 24px; }
    .ia-sq--nova .ia-sq__card .ia-sq__b, .ia-sq--nova .ia-sq__segb, .ia-sq--nova .ia-sq__chip, .ia-sq--nova .ia-sq__in { font-family: ${IA_NOVA_FONT}; }
    .ia-sq--nova .ia-sq__head b { font-family: ${IA_NOVA_DISPLAY}; font-weight: 600; letter-spacing: -.02em; }
    .ia-sq--nova .ia-sq__ic { border-radius: 50%; }
    .ia-sq--nova .ia-sq__b { min-height: 34px; }
    .ia-sq--nova .ia-sq__b.is-go { background: var(--q-acc); }
  `);

  // ==========================================================================
  // What's new: a button on the panel (next to Double-dial) that shows only
  // the newest update's changes. A small dot shows until the agent opens it
  // once after an update.
  // ==========================================================================
  const IA_NEWS = {
    version: '3.1.0',
    items: [
      'TBC Assistant is now its own Chrome extension. Tampermonkey isn\u2019t needed any more.',
      'Everything works the same as before. Install it once from the website\u2019s step-by-step guide.',
      'When a new version is out, a small banner shows you how to update in a minute.',
    ],
  };
  const IA_NEWS_SEEN_KEY = 'ia-news-seen';
  function iaNewsUnseen() { try { return GM_getValue(IA_NEWS_SEEN_KEY, '') !== IA_NEWS.version; } catch (e) { return false; } }
  function iaPaintNewsBtn() {
    const b = iaWidget && iaWidget.querySelector('.ia-news-btn');
    if (b) b.classList.toggle('is-new', iaNewsUnseen());
  }
  function iaShowNews() {
    try { GM_setValue(IA_NEWS_SEEN_KEY, IA_NEWS.version); } catch (e) { /* ignore */ }
    iaPaintNewsBtn();
    const w = sqWin();
    w.card.classList.add('ia-news');
    w.card.innerHTML = sqHead('✦', 'What’s new', 'In version ' + IA_NEWS.version)
      + '<ul class="ia-news__list">' + IA_NEWS.items.map((t) => '<li>' + sqEsc(t) + '</li>').join('') + '</ul>'
      + '<div class="ia-sq__btns"><button type="button" class="ia-sq__b is-go">Got it</button></div>';
    w.card.querySelector('.is-go').addEventListener('click', w.close);
    w.ov.addEventListener('click', (e) => { if (e.target === w.ov) w.close(); });
    const onKey = (e) => { if (e.key === 'Escape') { document.removeEventListener('keydown', onKey, true); w.close(); } };
    document.addEventListener('keydown', onKey, true);
  }
  function iaWireNewsBtn() {
    if (!iaWidget) return;
    const tog = iaWidget.querySelector('.ia-toggles');
    if (!tog || tog.querySelector('.ia-news-btn')) return;
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'ia-news-btn';
    b.title = 'What the latest update changed';
    b.innerHTML = '<span class="ia-news-btn__dot"></span>What’s new';
    b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); iaShowNews(); });
    b.addEventListener('mousedown', (e) => e.stopPropagation());
    tog.appendChild(b);
    iaPaintNewsBtn();
  }
  GM_addStyle(`
    .ia-news-btn { justify-self: end; align-self: center; display: inline-flex; align-items: center; gap: 5px; border: 1px solid transparent; border-radius: 999px; padding: 3px 9px; cursor: pointer;
      font: 800 11px Inter, 'Segoe UI', system-ui, sans-serif; color: var(--ia-sec); background: var(--ia-chip, rgba(127,127,127,.12)); white-space: nowrap; }
    .ia-news-btn:hover { border-color: var(--acc); color: var(--ia-title); }
    .ia-news-btn__dot { width: 6px; height: 6px; border-radius: 50%; background: var(--acc); display: none; }
    .ia-news-btn.is-new .ia-news-btn__dot { display: inline-block; }
    .ia-news-btn.is-new { color: var(--ia-title); }
    .ia-news__list { margin: 4px 0 0; padding-left: 18px; font: 600 12.5px/1.5 Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-news__list li { margin: 5px 0; }
  `);

  __jsRegisterScan(() => { ensureBmo(); updateAllRowIndicators(); checkOwner(); addCallIcons(); iaWireNewsBtn(); sqScan(); });
  __jsEnsureSharedObserver();
  ensureBmo();
})();

// ====================================================================
// SECTION 6 · Keep the RingCentral widget signed in
// ====================================================================
// Runs only INSIDE the RingCentral phone frame. Chrome sometimes wipes the
// widget's saved sign-in (third-party storage clearing, "clear on close",
// cleaner apps). This keeps a backup copy of the widget's own saved data
// in Tampermonkey's storage, which Chrome doesn't clear, and puts it back
// when it's been wiped. No password is ever stored — only the sign-in that
// RingCentral itself saves, and RingCentral still ends it after 7 days of
// the BO not being opened at all.
//
// It only restores when the widget's storage is COMPLETELY empty (wiped).
// Signing out on purpose leaves the widget's other settings behind, so a
// deliberate sign-out is respected and never undone.
(function () {
  'use strict';
  if (location.hostname !== 'apps.ringcentral.com') return;

  const BACKUP_KEY = 'rc-widget-storage-backup';
  const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

  function readBackup() {
    try {
      const b = JSON.parse(GM_getValue(BACKUP_KEY, 'null'));
      if (b && b.savedAt && Date.now() - b.savedAt < MAX_AGE_MS && b.data) return b;
    } catch (e) { /* ignore */ }
    return null;
  }

  function snapshot() {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      data[k] = localStorage.getItem(k);
    }
    return data;
  }

  let storageOk = true;
  try { localStorage.length; } catch (e) { storageOk = false; }
  if (!storageOk) return; // Chrome is blocking the widget's storage entirely

  // Restore after a wipe, then reload the frame once so the widget starts
  // up already signed in.
  if (localStorage.length === 0 && !sessionStorage.getItem('js-rc-restored')) {
    const b = readBackup();
    if (b) {
      try {
        Object.keys(b.data).forEach((k) => localStorage.setItem(k, b.data[k]));
        sessionStorage.setItem('js-rc-restored', '1');
        location.reload();
        return;
      } catch (e) { /* storage full or blocked — fall through to normal sign-in */ }
    }
  }

  // Back up the widget's data every 30 seconds while there's something
  // worth keeping (it refreshes its sign-in while open, so the copy stays
  // current).
  function backup() {
    if (localStorage.length === 0) return;
    try { GM_setValue(BACKUP_KEY, JSON.stringify({ savedAt: Date.now(), data: snapshot() })); } catch (e) { /* best-effort */ }
  }
  setTimeout(backup, 5000);
  setInterval(backup, 30000);
})();

// ====================================================================
// SECTION 8 · RC tab texts: the RingCentral side
// ====================================================================
// Runs only INSIDE the RingCentral phone frame, and only answers the BO's
// own pages. Works purely through the phone's own screen: it reads the
// conversation RingCentral is showing (opened for the lead by the BO page
// with RingCentral's "open conversation" command), and to send it types into
// RingCentral's message box and presses RingCentral's own Send button.
(function () {
  'use strict';
  if (location.hostname !== 'apps.ringcentral.com') return;

  const W = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
  const BO_ORIGIN_RE = /^https:\/\/([a-z0-9-]+\.)*(travelbusinessclass\.com|tmgbo\.com)$/;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const digits = (n) => String(n || '').replace(/\D/g, '').slice(-10);
  const err = (code, message) => Object.assign(new Error(message || code), { code });

  async function until(fn, ms, step) {
    const end = Date.now() + ms;
    for (;;) {
      const v = fn();
      if (v) return v;
      if (Date.now() > end) return null;
      await sleep(step || 100);
    }
  }

  function signedOut() {
    if (document.querySelector('[data-sign="loginButton"]')) return true;
    return Array.from(document.querySelectorAll('button')).some((b) => /^sign in$/i.test(b.textContent.trim()));
  }
  function status() {
    if (signedOut()) return { signedIn: false };
    if (!document.querySelector('[data-sign]')) return { signedIn: false, loading: true };
    return { signedIn: true };
  }

  const panel = () => document.querySelector('[data-sign="conversationPanel"]');
  function panelMatches(p, phone) {
    const n = p.querySelector('[data-sign="currentName"]');
    const t = n ? (n.getAttribute('title') || '') + ' ' + n.textContent : '';
    return digits(t).length >= 7 && digits(t) === digits(phone);
  }

  // "8/19/2026, 1:13 AM" -> ISO time. Only the first text of a group shows
  // its time; the rest of the group shares it.
  function parseTime(s) {
    const m = String(s || '').match(/(\d{1,2})\/(\d{1,2})\/(\d{4}),?\s+(\d{1,2}):(\d{2})\s*([AP]M)?/i);
    if (m) {
      let h = +m[4];
      if (m[6]) { const pm = /p/i.test(m[6]); if (pm && h < 12) h += 12; if (!pm && h === 12) h = 0; }
      return new Date(+m[3], +m[1] - 1, +m[2], h, +m[5]).toISOString();
    }
    const t = String(s || '').match(/^(\d{1,2}):(\d{2})\s*([AP]M)?$/i);
    if (t) {
      let h = +t[1];
      if (t[3]) { const pm = /p/i.test(t[3]); if (pm && h < 12) h += 12; if (!pm && h === 12) h = 0; }
      const d = new Date(); d.setHours(h, +t[2], 0, 0); return d.toISOString();
    }
    const d = new Date(s);
    return isNaN(d) ? null : d.toISOString();
  }

  function readList(p) {
    const out = [];
    let time = null;
    p.querySelectorAll('[data-sign="message"]').forEach((m) => {
      const ts = m.querySelector('[data-sign="conversationSendTime"]');
      if (ts) time = parseTime(ts.textContent.trim()) || time;
      const inb = m.querySelector('[data-sign="InboundText"]');
      const outb = m.querySelector('[data-sign="OutboundText"]');
      const el = inb || outb;
      if (!el) return;
      const text = el.textContent.trim();
      if (!text) return;
      out.push({ dir: inb ? 'Inbound' : 'Outbound', text, time });
    });
    // Texts above the first time shown take the next known time.
    let next = new Date().toISOString();
    for (let i = out.length - 1; i >= 0; i--) { if (out[i].time) next = out[i].time; else out[i].time = next; }
    return out;
  }

  // Waits until the message list stops changing (RingCentral fills it in).
  async function settled(p) {
    let last = -1;
    let same = 0;
    const end = Date.now() + 3000;
    while (Date.now() < end) {
      const n = p.querySelectorAll('[data-sign="message"]').length;
      if (n === last && n > 0) { if (++same >= 3) return; } else same = 0;
      last = n;
      await sleep(150);
    }
  }

  // Scrolls RingCentral's (hidden) message list up so it loads older texts
  // too, until nothing more comes in, then back down.
  async function loadOlder(p) {
    const first = p.querySelector('[data-sign="message"]');
    const el = p.querySelector('.ConversationMessageList') || (first && first.parentElement);
    if (!el) return;
    let last = -1;
    let still = 0;
    for (let i = 0; i < 12 && still < 2; i++) {
      const n = p.querySelectorAll('[data-sign="message"]').length;
      if (n === last) still++; else still = 0;
      last = n;
      el.scrollTop = 0;
      el.dispatchEvent(new Event('scroll', { bubbles: true }));
      await sleep(700);
    }
    el.scrollTop = el.scrollHeight;
  }

  // RingCentral's message box (same on a conversation and on Compose Text).
  function msgBox(root) {
    return root.querySelector('textarea[data-sign="messageInput"]') || root.querySelector('textarea[placeholder^="Type message"]');
  }

  // Numbers on the Compose Text screen ("To:" box: typed value or chip).
  function composeShowsNumber(phone) {
    const want = digits(phone);
    const vals = Array.from(document.querySelectorAll('input')).map((i) => i.value);
    document.querySelectorAll('div, span').forEach((el) => { if (el.children.length === 0) vals.push(el.textContent); });
    return vals.some((v) => { const d = digits(v); return d.length >= 7 && d === want; });
  }

  // The screen opened after "mark": a new one, never the old one. With an
  // existing thread RingCentral opens the conversation; with none yet it
  // opens "Compose Text" with the lead's number in the To box.
  async function freshScreen(phone) {
    return until(() => {
      const p = panel();
      if (p && !p.hasAttribute('data-ia-old')) {
        const n = p.querySelector('[data-sign="currentName"]');
        const shown = n ? digits((n.getAttribute('title') || '') + ' ' + n.textContent) : '';
        // A plain number on screen must be the lead's; a saved contact name
        // is trusted because this screen was just opened for this number.
        if (shown.length >= 7 && shown !== digits(phone)) return null;
        return { kind: 'conv', root: p };
      }
      if (p) return null;
      const ta = msgBox(document);
      if (!ta || ta.hasAttribute('data-ia-old')) return null;
      if (!composeShowsNumber(phone)) return null;
      return { kind: 'compose', root: document.body };
    }, 10000);
  }

  function setText(ta, text) {
    const setter = Object.getOwnPropertyDescriptor(W.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, text);
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
  }

  async function handle(d) {
    if (d.op === 'status') return status();
    if (status().signedIn !== true) throw err('signedout', 'RingCentral is signed out');
    if (d.op === 'mark') {
      document.querySelectorAll('[data-sign="conversationPanel"], textarea').forEach((p) => p.setAttribute('data-ia-old', '1'));
      return {};
    }
    if (d.op === 'read') {
      let p;
      if (d.fresh) {
        const sc = await freshScreen(d.phone);
        if (!sc) throw err('nopanel', 'Couldn\u2019t open the conversation in RingCentral');
        if (sc.kind === 'compose') return { match: true, list: [] }; // no texts with this number yet
        p = sc.root;
        await settled(p);
        await loadOlder(p);
      } else {
        p = panel();
        if (!p) throw err('nopanel');
        if (!panelMatches(p, d.phone)) return { match: false };
      }
      await settled(p);
      return { match: true, list: readList(p) };
    }
    if (d.op === 'send') {
      const text = String(d.text || '').trim();
      if (!text) throw err('http', 'Nothing to send');
      const sc = await freshScreen(d.phone);
      if (!sc) throw err('nopanel', 'Couldn\u2019t open the conversation in RingCentral \u2014 not sent');
      const root = sc.root;
      if (sc.kind === 'conv') await settled(root);
      const ta = await until(() => { const t = msgBox(root); return t && !t.hasAttribute('data-ia-old') ? t : null; }, 4000);
      if (!ta) throw err('http', 'RingCentral message box not found \u2014 not sent');
      const outsNow = () => Array.from(document.querySelectorAll('[data-sign="OutboundText"]'));
      const before = outsNow().filter((o) => o.textContent.trim() === text).length;
      setText(ta, text);
      await sleep(250);
      const btn = await until(() => {
        const b = root.querySelector('[data-sign="messageButton"]') || (root.querySelector('button .send_filled') || {}).closest && root.querySelector('button .send_filled').closest('button');
        return b && !b.disabled && b.getAttribute('aria-disabled') !== 'true' ? b : null;
      }, 3000);
      if (!btn) throw err('http', 'RingCentral Send button not ready \u2014 not sent');
      btn.click();
      // Sent = the text shows up as yours in RingCentral (from Compose Text,
      // RingCentral moves on to the new conversation by itself).
      const ok = await until(() => outsNow().filter((o) => o.textContent.trim() === text).length > before, 15000, 200);
      if (!ok) throw err('unconfirmed', 'RingCentral didn\u2019t confirm \u2014 check the RC panel before resending');
      await sleep(300);
      const p = panel();
      return { list: p ? readList(p) : null };
    }
    throw err('http', 'Unknown request');
  }

  W.addEventListener('message', (e) => {
    if (!BO_ORIGIN_RE.test(e.origin) || !e.source) return;
    const d = e.data;
    if (!d || typeof d !== 'object' || !d.__jsSms || !d.id) return;
    handle(d).then(
      (data) => e.source.postMessage({ __jsSmsRes: 1, id: d.id, ok: true, data }, e.origin),
      (x) => e.source.postMessage({ __jsSmsRes: 1, id: d.id, ok: false, error: x.code || 'http', message: x.message }, e.origin),
    );
  });
})();

// ====================================================================
// SECTION 7 · Airport-change (self-transfer) detector on lead options
// ====================================================================
// Reads each flight option's segment lines on a lead (e.g.
// "1   KL 602   J 25JUL   LAX AMS   150P 905A¥1") and looks at every
// connection: where one flight lands vs where the next one departs.
// It's flagged as an airport change only when ALL of these are true:
//   - the two airports are different (lands EWR, leaves LGA),
//   - they serve the same city (known multi-airport city, or under ~100
//     miles apart), and
//   - the next flight leaves less than 24 hours after landing.
// A long gap means the traveler is staying there (multi-city / open-jaw),
// and far-apart airports are different cities — neither is flagged. So
// "lands LIS, leaves BCN two weeks later" is correctly left alone.
// A flagged option gets a red "EWR & LGA" highlight above its segments,
// and the two segment lines involved get a red edge.
(function () {
  'use strict';
  if (window.top !== window) return;
  if (!location.hostname.includes('travelbusinessclass.com')) return;

  const MAX_TRANSFER_HOURS = 24;
  const SAME_AREA_MILES = 100;

  const METRO_GROUPS = [
    ['JFK', 'EWR', 'LGA'], ['IAD', 'DCA', 'BWI'], ['ORD', 'MDW'], ['LAX', 'BUR', 'LGB', 'SNA', 'ONT'],
    ['SFO', 'OAK', 'SJC'], ['MIA', 'FLL', 'PBI'], ['DFW', 'DAL'], ['IAH', 'HOU'], ['DTW', 'DET'],
    ['YYZ', 'YTZ'], ['YUL', 'YMX'], ['GRU', 'CGH', 'VCP'], ['GIG', 'SDU'], ['EZE', 'AEP'],
    ['LHR', 'LGW', 'STN', 'LTN', 'LCY', 'SEN'], ['CDG', 'ORY', 'BVA'], ['FCO', 'CIA'], ['MXP', 'LIN', 'BGY'],
    ['ARN', 'BMA', 'NYO'], ['OSL', 'TRF', 'RYG'], ['IST', 'SAW'], ['SVO', 'DME', 'VKO'], ['BRU', 'CRL'],
    ['FRA', 'HHN'], ['BER', 'SXF'], ['DXB', 'DWC', 'SHJ'], ['HND', 'NRT'], ['KIX', 'ITM', 'UKB'],
    ['ICN', 'GMP'], ['PVG', 'SHA'], ['PEK', 'PKX'], ['BKK', 'DMK'], ['CGK', 'HLP'], ['KUL', 'SZB'],
    ['MNL', 'CRK'], ['TPE', 'TSA'], ['DEL', 'HDO'], ['BOM', 'NMI'], ['MEL', 'AVV'],
  ];
  const METRO_OF = {};
  METRO_GROUPS.forEach((g, i) => g.forEach((code) => { METRO_OF[code] = i; }));

  function sameArea(a, b) {
    if (METRO_OF[a] != null && METRO_OF[a] === METRO_OF[b]) return true;
    const ca = AIRPORT_COORDS[a];
    const cb = AIRPORT_COORDS[b];
    return !!(ca && cb && haversineMiles(ca[0], ca[1], cb[0], cb[1]) < SAME_AREA_MILES);
  }

  const MONTHS_IDX = { JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5, JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11 };
  const ROW_RE = /^\s*\d+\s+[A-Z0-9]{2}\s*\*?\s*\d+\s+[A-Z]\s+(\d{2})([A-Z]{3})\s+([A-Z]{3})\s+([A-Z]{3})\s+(\d{3,4}[AP])\s+(\d{3,4}[AP])(¥\d+|-\d+)?/;

  function clock(t) {
    const ap = t.slice(-1);
    const d = t.slice(0, -1);
    let h = parseInt(d.slice(0, d.length - 2), 10);
    const m = parseInt(d.slice(-2), 10);
    if (ap === 'P' && h < 12) h += 12;
    if (ap === 'A' && h === 12) h = 0;
    return { h, m };
  }

  // Years aren't printed, so they're inferred: dates count forward from
  // the first leg, rolling into next year when the month goes backwards
  // (a December trip returning in January).
  function parseLegs(texts) {
    const legs = [];
    let year = new Date().getFullYear();
    let lastMonth = null;
    for (const text of texts) {
      const m = text.match(ROW_RE);
      if (!m) { legs.push(null); continue; }
      const day = parseInt(m[1], 10);
      const month = MONTHS_IDX[m[2]];
      if (month === undefined) { legs.push(null); continue; }
      if (lastMonth !== null && month < lastMonth) year += 1;
      lastMonth = month;
      const dep = clock(m[5]);
      const arr = clock(m[6]);
      let offset = 0;
      if (m[7]) offset = m[7][0] === '¥' ? parseInt(m[7].slice(1), 10) : -parseInt(m[7].slice(1), 10);
      legs.push({
        origin: m[3],
        dest: m[4],
        depart: new Date(year, month, day, dep.h, dep.m),
        arrive: new Date(year, month, day + offset, arr.h, arr.m),
      });
    }
    return legs;
  }

  // Both airports in a flagged pair are in the same city, so the same time
  // zone — comparing their local times directly is accurate.
  function findAirportChanges(legs) {
    const changes = [];
    for (let i = 0; i < legs.length - 1; i++) {
      const a = legs[i];
      const b = legs[i + 1];
      if (!a || !b || a.dest === b.origin) continue;
      if (!sameArea(a.dest, b.origin)) continue;
      const gapHours = (b.depart - a.arrive) / 3600000;
      if (gapHours < 0 || gapHours >= MAX_TRANSFER_HOURS) continue;
      changes.push({ from: a.dest, to: b.origin, rowA: i, rowB: i + 1 });
    }
    return changes;
  }

  function scanOptions() {
    document.querySelectorAll('.lead-option-segment-segments').forEach((box) => {
      const pres = Array.from(box.querySelectorAll(':scope > pre'));
      const texts = pres.map((p) => (p.querySelector('.overflow-hidden') || p).textContent.trim());
      const signature = texts.join('|');
      const holder = box.closest('.lead-option-segment') || box.parentElement;
      if (box.dataset.jsApcSig === signature && (!box.dataset.jsApcHit || holder.querySelector(':scope > .ia-apc-flag'))) return;
      box.dataset.jsApcSig = signature;

      const old = holder.querySelector(':scope > .ia-apc-flag');
      if (old) old.remove();
      pres.forEach((p) => p.classList.remove('ia-apc-row'));

      const changes = findAirportChanges(parseLegs(texts));
      box.dataset.jsApcHit = changes.length ? '1' : '';
      if (!changes.length) return;

      const flag = document.createElement('div');
      flag.className = 'ia-apc-flag';
      changes.forEach((c) => {
        const tag = document.createElement('span');
        tag.className = 'ia-apc-tag';
        tag.appendChild(worriedPip(17));
        tag.appendChild(document.createTextNode(c.from + ' & ' + c.to));
        tag.title = 'Airport change: arrives ' + c.from + ', next flight departs ' + c.to;
        flag.appendChild(tag);
        if (pres[c.rowA]) pres[c.rowA].classList.add('ia-apc-row');
        if (pres[c.rowB]) pres[c.rowB].classList.add('ia-apc-row');
      });
      holder.insertBefore(flag, holder.firstChild);
    });
  }

  GM_addStyle(`
    .ia-apc-flag { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 4px 0; }
    .ia-apc-tag {
      display: inline-flex; align-items: center; gap: 4px; line-height: 16px;
      background: #dc2626; color: #fff; font-weight: 700; font-size: 12px;
      padding: 1px 7px 1px 2px; border-radius: 4px; font-family: system-ui, sans-serif;
      letter-spacing: .02em;
    }
    pre.ia-apc-row { box-shadow: inset 3px 0 0 #dc2626; }
  `);

  __jsRegisterScan(scanOptions);
  __jsEnsureSharedObserver();
  scanOptions();
})();


// ====================================================================
// SECTION 7b · Quote Card
// ====================================================================
// A small "Card" button above each option's flights on a lead: turns the
// option into a clean picture for the client (copy and paste it into a
// text or chat, or download it). Nothing is sent from here.
(function () {
  'use strict';
  if (window.top !== window) return;
  if (!location.hostname.includes('travelbusinessclass.com')) return;

  const ROW = /^\s*\d+\s+([A-Z0-9]{2})\s*\*?\s*(\d+)\s+([A-Z])\s+(\d{2})([A-Z]{3})\s+([A-Z]{3})\s+([A-Z]{3})\s+(\d{3,4}[AP])\s+(\d{3,4}[AP])(¥\d+|-\d+)?/;
  const MON = { JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5, JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11 };
  const MON_N = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const clock = (t) => { const ap = t.slice(-1), d = t.slice(0, -1); let h = parseInt(d.slice(0, d.length - 2), 10); const m = parseInt(d.slice(-2), 10); if (ap === 'P' && h < 12) h += 12; if (ap === 'A' && h === 12) h = 0; return { h, m }; };
  function parse(texts) {
    const legs = [];
    let year = new Date().getFullYear(), last = null;
    const nowM = new Date().getMonth();
    texts.forEach((text) => {
      const m = text.match(ROW);
      if (!m) return;
      const day = parseInt(m[4], 10), mon = MON[m[5]];
      if (mon === undefined) return;
      if (last === null && mon < nowM - 1) year += 1; // first leg early next year
      if (last !== null && mon < last) year += 1;
      last = mon;
      const dep = clock(m[8]), arr = clock(m[9]);
      let off = 0;
      if (m[10]) off = m[10][0] === '¥' ? parseInt(m[10].slice(1), 10) : -parseInt(m[10].slice(1), 10);
      legs.push({ al: m[1], fn: m[2], cls: m[3], from: m[6], to: m[7], depT: m[8], arrT: m[9], off,
        dep: new Date(year, mon, day, dep.h, dep.m), arr: new Date(year, mon, day + off, arr.h, arr.m) });
    });
    return legs;
  }
  const METRO = [['JFK', 'EWR', 'LGA'], ['LHR', 'LGW', 'LCY', 'STN', 'LTN'], ['CDG', 'ORY'], ['HND', 'NRT'], ['IAD', 'DCA', 'BWI'], ['ORD', 'MDW'], ['IST', 'SAW'], ['DXB', 'DWC'], ['ICN', 'GMP'], ['PVG', 'SHA'], ['PEK', 'PKX'], ['FCO', 'CIA'], ['MXP', 'LIN']];
  const sameCity = (a, b) => a === b || METRO.some((g) => g.includes(a) && g.includes(b));
  // Journeys: a new one starts when the next flight leaves from somewhere
  // else or 24h+ later (the traveler is staying there).
  function journeys(legs) {
    const out = [];
    legs.forEach((lg, i) => {
      const prev = legs[i - 1];
      const gap = prev ? (lg.dep - prev.arr) / 60000 : null;
      if (!prev || !sameCity(prev.to, lg.from) || gap < 0 || gap >= 24 * 60) out.push([lg]);
      else out[out.length - 1].push(lg);
    });
    return out;
  }
  const HUB_NAMES = { DOH: 'Doha', DXB: 'Dubai', AUH: 'Abu Dhabi', IST: 'Istanbul', SIN: 'Singapore', HKG: 'Hong Kong', LIS: 'Lisbon', KEF: 'Reykjavik',
    HEL: 'Helsinki', AMS: 'Amsterdam', ICN: 'Seoul', TPE: 'Taipei', BKK: 'Bangkok', KUL: 'Kuala Lumpur', HND: 'Tokyo', NRT: 'Tokyo', CPH: 'Copenhagen', DUB: 'Dublin', ZRH: 'Zurich', MUC: 'Munich', VIE: 'Vienna', ATH: 'Athens', MAD: 'Madrid' };
  const fmtDur = (min) => { const h = Math.floor(min / 60), m = Math.round(min % 60); return h ? h + 'h' + (m ? ' ' + m + 'm' : '') : m + 'm'; };

  // --- Pop-ups -------------------------------------------------------------
  let pop = null;
  const closePop = () => { if (pop) { pop.el.remove(); pop = null; } };
  document.addEventListener('mousedown', (e) => { if (pop && !pop.el.contains(e.target) && !(pop.anchor && pop.anchor.contains(e.target))) closePop(); }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePop(); });
  function paintVars(el) {
    const p = iaPalette();
    const v = { bg: p.bg, field: p.field, line: p.line, line2: p.line2, text: p.text, title: p.title, muted: p.muted, sec: p.sec, acc: p.pri, onacc: p.onpri,
      bad: p.bad, ok: p.ok, shadow: p.shadow, glass: p.glass || p.bg, edge: p.edge || p.line, inner: p.inner || p.field, chip: p.chip || p.field, chipshadow: p.chipshadow || 'none', sky: p.sky || 'none' };
    Object.keys(v).forEach((k) => el.style.setProperty('--iot-' + k, v[k]));
    el.style.colorScheme = iaIsLight(p.mode) ? 'light' : 'dark';
  }
  function openPop(anchor, kind, build) {
    const again = pop && pop.anchor === anchor && pop.kind === kind;
    closePop();
    if (again) return null;
    const el = document.createElement('div');
    el.className = 'ia-iot-pop ia-iot-pop--' + kind;
    paintVars(el);
    el.addEventListener('mousedown', (e) => e.stopPropagation());
    el.addEventListener('keydown', (e) => e.stopPropagation());
    pop = { el, anchor, kind };
    build(el);
    document.body.appendChild(el);
    const r = anchor.getBoundingClientRect();
    const w = el.offsetWidth, h = el.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = Math.max(8, r.top - h - 6);
    el.style.left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8)) + 'px';
    el.style.top = top + 'px';
    return el;
  }
  const mkEl = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  function head(el, text) {
    const h = mkEl('div', 'ia-iot-h');
    h.appendChild(mkEl('span', null, text));
    const x = mkEl('button', 'ia-iot-x', '×');
    x.type = 'button';
    x.setAttribute('aria-label', 'Close');
    x.addEventListener('click', closePop);
    h.appendChild(x);
    el.appendChild(h);
  }

  // --- Quote Card -------------------------------------------------------
  const CABIN = (c) => ('FA'.includes(c) ? 'First' : 'JCDIZR'.includes(c) ? 'Business' : 'WEO'.includes(c) ? 'Premium Economy' : 'Economy');
  const t12 = (d) => { let h = d.getHours(); const m = d.getMinutes(); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return h + ':' + String(m).padStart(2, '0') + ' ' + ap; };
  const dLabel = (d) => WD[d.getDay()] + ' ' + d.getDate() + ' ' + MON_N[d.getMonth()];
  function sellOf(box) {
    let n = box;
    for (let i = 0; i < 10 && n; i++) {
      n = n.parentElement;
      const table = n && n.querySelector('table.lead-option-price-table');
      if (table) {
        const heads = Array.from(table.querySelectorAll('thead th')).map((th) => th.textContent.trim().toUpperCase());
        const si = heads.indexOf('SELL');
        const tr = Array.from(table.querySelectorAll('tbody tr')).find((r) => (r.querySelector('td') || {}).textContent && r.querySelector('td').textContent.trim().toUpperCase() === 'ADT');
        const cell = tr && si >= 0 ? tr.querySelectorAll('td')[si] : null;
        const num = cell ? parseFloat(cell.textContent.replace(/[^0-9.]/g, '')) : NaN;
        return num > 0 ? num : null;
      }
    }
    return null;
  }
  function clientName() {
    const m = location.pathname.match(/\/leads\/(\d+)/);
    if (!m) return '';
    const tag = Array.from(document.querySelectorAll('span')).find((sp) => sp.textContent.trim() === '#' + m[1]);
    let root = tag;
    for (let i = 0; i < 12 && root; i++) { root = root.parentElement; if (root && root.querySelector('span.truncate')) break; }
    const el = root && root.querySelector('span.truncate');
    return el ? el.textContent.trim() : '';
  }
  function agentFirst() { try { return GM_getValue('bmo-first-name', '') || ''; } catch (e) { return ''; } }

  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function drawCard(canvas, legs, info) {
    const p = iaPalette();
    const acc = p.acc;
    const js = journeys(legs);
    const W = 900, pad = 44;
    const rowH = 92, conH = 34, jHead = 44;
    let H = 150 + 70;
    js.forEach((j) => { H += jHead + j.length * rowH + (j.length - 1) * conH + 22; });
    if (info.note) H += 52;
    H += 120;
    canvas.width = W * 2; canvas.height = H * 2;
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(2, 2);
    const F = (w, s) => w + ' ' + s + "px Inter, 'Segoe UI', system-ui, sans-serif";
    // Background: soft sky
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#eaf2ff'); g.addColorStop(1, '#ffffff');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(31,92,255,.08)'; ctx.beginPath(); ctx.arc(W - 60, 30, 180, 0, Math.PI * 2); ctx.fill();
    // Header
    ctx.fillStyle = '#5a6888'; ctx.font = F(700, 15);
    ctx.fillText((info.client ? 'Prepared for ' + info.client : 'Your flight option'), pad, pad + 6);
    ctx.fillStyle = '#0d1b3e'; ctx.font = F(800, 34);
    const first = legs[0], lastJ = js[js.length - 1], last = lastJ[lastJ.length - 1];
    const title = js.length > 1 && last.to === first.from ? first.from + '  ⇄  ' + js[0][js[0].length - 1].to : first.from + '  →  ' + last.to;
    ctx.fillText(title, pad, pad + 50);
    ctx.font = F(800, 15);
    const cab = CABIN(first.cls) + ' class';
    const cw = ctx.measureText(cab).width + 28;
    rr(ctx, W - pad - cw, pad + 24, cw, 32, 16); ctx.fillStyle = acc; ctx.fill();
    ctx.fillStyle = '#fff'; ctx.fillText(cab, W - pad - cw + 14, pad + 45);
    let y = 150;
    js.forEach((j, ji) => {
      ctx.fillStyle = acc; ctx.font = F(800, 13);
      const lbl = (js.length === 2 && last.to === first.from ? (ji === 0 ? 'OUTBOUND' : 'RETURN') : 'FLIGHT ' + (ji + 1)) + '  ·  ' + dLabel(j[0].dep).toUpperCase();
      ctx.fillText(lbl, pad, y + 18);
      y += jHead;
      j.forEach((lg, li) => {
        rr(ctx, pad, y, W - pad * 2, rowH - 12, 18);
        ctx.fillStyle = 'rgba(255,255,255,.92)'; ctx.fill();
        ctx.strokeStyle = 'rgba(13,27,62,.07)'; ctx.lineWidth = 1; ctx.stroke();
        // airline badge
        rr(ctx, pad + 16, y + 16, 48, 48, 14); ctx.fillStyle = '#0d1b3e'; ctx.fill();
        ctx.fillStyle = '#fff'; ctx.font = F(800, 17); ctx.textAlign = 'center'; ctx.fillText(lg.al, pad + 40, y + 46); ctx.textAlign = 'left';
        ctx.fillStyle = '#5a6888'; ctx.font = F(700, 13); ctx.fillText(lg.al + ' ' + lg.fn, pad + 80, y + 30);
        ctx.fillStyle = '#0d1b3e'; ctx.font = F(800, 24);
        ctx.fillText(lg.from, pad + 80, y + 60);
        ctx.font = F(700, 15); ctx.fillStyle = '#0d1b3e';
        ctx.fillText(t12(lg.dep), pad + 140, y + 59);
        ctx.fillStyle = '#9aa6c2'; ctx.font = F(700, 18); ctx.fillText('→', pad + 290, y + 59);
        ctx.fillStyle = '#0d1b3e'; ctx.font = F(800, 24); ctx.fillText(lg.to, pad + 330, y + 60);
        ctx.font = F(700, 15); ctx.fillText(t12(lg.arr) + (lg.off > 0 ? '  +' + lg.off : lg.off < 0 ? '  ' + lg.off : ''), pad + 390, y + 59);
        if (lg.off) { ctx.fillStyle = '#5a6888'; ctx.font = F(700, 12); ctx.fillText('arrives ' + dLabel(lg.arr), pad + 390, y + 30); }
        y += rowH;
        if (li < j.length - 1) {
          const nx = j[li + 1];
          const gap = (nx.dep - lg.arr) / 60000;
          ctx.fillStyle = '#5a6888'; ctx.font = F(700, 13);
          ctx.fillText('•  Connect in ' + (HUB_NAMES[lg.to] ? HUB_NAMES[lg.to] + ' (' + lg.to + ')' : lg.to) + '  ·  ' + fmtDur(gap), pad + 22, y + 8);
          y += conH;
        }
      });
      y += 22;
    });
    if (info.note) {
      rr(ctx, pad, y, W - pad * 2, 40, 14); ctx.fillStyle = 'rgba(31,92,255,.08)'; ctx.fill();
      ctx.fillStyle = '#0d1b3e'; ctx.font = F(700, 14); ctx.fillText(info.note.slice(0, 95), pad + 16, y + 25);
      y += 52;
    }
    // Price
    rr(ctx, pad, y + 6, W - pad * 2, 86, 22);
    const pg = ctx.createLinearGradient(pad, 0, W - pad, 0); pg.addColorStop(0, '#3a74ff'); pg.addColorStop(1, '#1f4fe0');
    ctx.fillStyle = pg; ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.8)'; ctx.font = F(700, 14); ctx.fillText(info.priceLabel || 'Price per person', pad + 24, y + 40);
    ctx.fillStyle = '#fff'; ctx.font = F(800, 34); ctx.fillText(info.price || '', pad + 24, y + 78);
    if (info.agent) { ctx.font = F(700, 14); ctx.textAlign = 'right'; ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillText('Your agent: ' + info.agent, W - pad - 24, y + 56); ctx.textAlign = 'left'; }
  }

  function showCard(anchor, legs, box) {
    openPop(anchor, 'card', (el) => {
      head(el, 'Quote card · copy and send to your client');
      const cv = document.createElement('canvas');
      cv.className = 'ia-iot-cv';
      const wrap = mkEl('div', 'ia-iot-cvwrap');
      wrap.appendChild(cv);
      const sell = sellOf(box);
      const f = (label, val, ph) => { const l = mkEl('label', 'ia-iot-f'); l.appendChild(mkEl('span', null, label)); const i = document.createElement('input'); i.type = 'text'; i.value = val || ''; i.placeholder = ph || ''; l.appendChild(i); return { l, i }; };
      const fc = f('Client', clientName(), 'Client name');
      const fp = f('Price', sell ? '$' + Math.round(sell).toLocaleString('en-US') : '', '$4,890');
      const fn = f('Note', '', 'e.g. Includes seats and 2 bags each');
      const fa = f('Agent', agentFirst(), 'Your name');
      const grid = mkEl('div', 'ia-iot-fields');
      [fc, fp, fn, fa].forEach((x) => grid.appendChild(x.l));
      const draw = () => drawCard(cv, legs, { client: fc.i.value.trim(), price: fp.i.value.trim(), note: fn.i.value.trim(), agent: fa.i.value.trim() });
      [fc, fp, fn, fa].forEach((x) => x.i.addEventListener('input', draw));
      const acts = mkEl('div', 'ia-iot-acts');
      const msg = mkEl('span', 'ia-iot-msg');
      const copy = mkEl('button', 'ia-iot-go', 'Copy picture');
      copy.type = 'button';
      copy.addEventListener('click', () => {
        cv.toBlob(async (blob) => {
          try {
            await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
            msg.textContent = '✓ Copied. Paste it into your text or chat.';
          } catch (e) { msg.textContent = 'Copy was blocked. Use Download instead.'; }
        }, 'image/png');
      });
      const dl = mkEl('button', 'ia-iot-sec', 'Download');
      dl.type = 'button';
      dl.addEventListener('click', () => {
        const a = document.createElement('a');
        a.href = cv.toDataURL('image/png');
        a.download = 'Flight option ' + legs[0].from + '-' + legs[legs.length - 1].to + '.png';
        document.body.appendChild(a); a.click(); a.remove();
        msg.textContent = '✓ Saved to your Downloads.';
      });
      acts.append(copy, dl, msg);
      el.append(wrap, grid, acts);
      draw();
    });
  }

  // --- Buttons on each option -------------------------------------------------
  function scan() {
    document.querySelectorAll('.lead-option-segment-segments').forEach((box) => {
      const pres = Array.from(box.querySelectorAll(':scope > pre'));
      const texts = pres.map((p) => (p.querySelector('.overflow-hidden') || p).textContent.trim());
      const sig = texts.join('|');
      const holder = box.closest('.lead-option-segment') || box.parentElement;
      const existing = holder.querySelector(':scope > .ia-iot-row');
      if (existing && existing.dataset.sig === sig) return;
      if (existing) existing.remove();
      const legs = parse(texts);
      if (!legs.length) return;
      const row = mkEl('div', 'ia-iot-row');
      row.dataset.sig = sig;
      const cb = mkEl('button', 'ia-iot-btn', '🖼 Card');
      cb.type = 'button';
      cb.title = 'Make a picture of this option for your client';
      cb.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); showCard(cb, legs, box); });
      row.append(cb);
      const apc = holder.querySelector(':scope > .ia-apc-flag');
      if (apc) apc.insertAdjacentElement('afterend', row); else holder.insertBefore(row, holder.firstChild);
    });
  }

  GM_addStyle(`
    .ia-iot-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin: 0 0 6px 0; font-family: Inter, 'Segoe UI', system-ui, sans-serif; }
    .ia-iot-btn { height: 22px; padding: 0 10px; border-radius: 999px; border: 1px solid #c7d2fe; background: #eef2ff; color: #3730a3; font: 800 11.5px/20px Inter, 'Segoe UI', system-ui, sans-serif; cursor: pointer; }
    .ia-iot-btn:hover { border-color: #6366f1; }
    .ia-iot-pop { position: fixed; z-index: 2147483000; box-sizing: border-box; width: 420px; max-width: calc(100vw - 16px); max-height: calc(100vh - 16px); overflow-y: auto;
      display: grid; gap: 10px; padding: 12px; color: var(--iot-text); font: 600 12.5px/1.45 Inter, 'Segoe UI', system-ui, sans-serif;
      background: var(--iot-sky), var(--iot-glass); -webkit-backdrop-filter: blur(20px) saturate(1.5); backdrop-filter: blur(20px) saturate(1.5);
      border: 1px solid var(--iot-edge); border-radius: 18px; box-shadow: var(--iot-shadow), inset 0 1px 0 var(--iot-edge); text-align: left; }
    .ia-iot-pop--card { width: 560px; }
    .ia-iot-h { display: flex; justify-content: space-between; align-items: center; gap: 8px; font-weight: 800; color: var(--iot-muted); }
    .ia-iot-x { border: 0; background: none; color: var(--iot-muted); font: 800 17px/1 system-ui, sans-serif; cursor: pointer; padding: 0 2px; }
    .ia-iot-x:hover { color: var(--iot-title); }
    .ia-iot-air-h { display: flex; align-items: center; gap: 8px; }
    .ia-iot-air-h b { font-size: 14px; font-weight: 800; color: var(--iot-title); }
    .ia-iot-cvwrap { border-radius: 14px; overflow: hidden; background: #fff; line-height: 0; }
    .ia-iot-cv { width: 100% !important; height: auto !important; display: block; }
    .ia-iot-fields { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
    .ia-iot-f { display: grid; gap: 3px; font-size: 11px; font-weight: 800; color: var(--iot-muted); }
    .ia-iot-f input { box-sizing: border-box; width: 100%; border: 1px solid transparent; border-radius: 10px; background: var(--iot-chip); color: var(--iot-title); padding: 7px 9px;
      font: 700 12.5px Inter, 'Segoe UI', system-ui, sans-serif; outline: none; }
    .ia-iot-f input:focus { border-color: var(--iot-acc); }
    .ia-iot-acts { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .ia-iot-go { border: 0; border-radius: 12px; padding: 9px 16px; background: linear-gradient(135deg, color-mix(in srgb, var(--iot-acc) 78%, #fff), var(--iot-acc)); color: var(--iot-onacc);
      font: 800 13px Inter, 'Segoe UI', system-ui, sans-serif; cursor: pointer; }
    .ia-iot-sec { border: 1px solid transparent; border-radius: 12px; padding: 8px 14px; background: var(--iot-chip); color: var(--iot-title); font: 800 13px Inter, 'Segoe UI', system-ui, sans-serif; cursor: pointer; }
    .ia-iot-sec:hover { border-color: var(--iot-acc); }
    .ia-iot-msg { font-weight: 700; color: var(--iot-muted); }
  `);

  if (typeof __jsRegisterScan === 'function') __jsRegisterScan(scan);
  setInterval(scan, 3000);
  scan();
})();

// Shared hook: the itinerary builder below fills in .run(cmd) so the lead's
// search panel (Fast Search) can drive the same terminal.
const __iaTerm = { run: null, busy: false };
// ====================================================================
// SECTION 11 · Terminal helper (Sabre terminal) for Fast Search
// ====================================================================
// Drives the terminal's command bar for the search panel's Fast Search
// button: opens the Terminal tab if needed, sends I, then the JR search.
(function () {
  'use strict';
  if (!location.hostname.includes('travelbusinessclass.com')) return;
  if (window.top !== window && /^jsworker-/.test(window.name || '')) return;

  const CFG = {
    INPUT: 'input[placeholder="TYPE COMMAND HERE" i]',
    OUTPUT: '.terminal__output',
    ECHO: '.terminal-delta__command-input',
    SEP: '§',             // Sabre end item (tested: chains entries)
    CHAIN_MAX: 3,         // the terminal runs at most 3 sells per entry (tested)
    DISPLAY: '*IA',
    CLEAR: 'I',           // ignore, sent on its own first (reply IGD)
    SELL: (s, cls, pax) => `0${s.airline}${s.flight}${cls}${s.date}${s.from}${s.to}NN${pax}`,
    QUIET_MS: 400,        // a reply is complete once its block stops changing this long
    EMPTY_MS: 1500,       // chained sells often reply with nothing: accept an empty block after this
    TIMEOUT_MS: 15000,
    GAP_MS: 120,
    AUTO_CLOSE_MS: 4000,
  };

  const state = { running: false, abort: false };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* ---------- terminal driving ---------- */
  // The BO can keep more than one terminal in the page (closed tabs stay
  // in the DOM, hidden): always use the visible command bar, and the output
  // area that belongs to that same terminal.
  const shown = (el) => !!(el && el.getClientRects().length);
  const getInput = () => {
    const all = Array.from(document.querySelectorAll(CFG.INPUT));
    return all.find(shown) || all[0] || null;
  };
  const getOutput = () => {
    const i = getInput();
    if (shown(i)) {
      for (let el = i.parentElement; el && el !== document.body; el = el.parentElement) {
        const o = el.querySelector(CFG.OUTPUT);
        if (o) return o;
      }
    }
    const all = Array.from(document.querySelectorAll(CFG.OUTPUT));
    return all.find(shown) || all[0] || null;
  };
  const blocksOf = (out) => Array.from(out.querySelectorAll('pre')).filter((p) => p.querySelector(':scope > ' + CFG.ECHO));
  const norm = (s) => String(s).toUpperCase().replace(/[^A-Z0-9*]/g, '');
  const echoOf = (b) => { const e = b.querySelector(':scope > ' + CFG.ECHO); return e ? norm(e.textContent.replace(/^\s*❯\s*/, '')) : ''; };
  // The reply as it reads on screen: rendered text keeps the line breaks
  // between rows (divs / table rows), which plain textContent would glue
  // together into one line.
  const outputText = (b) => {
    const e = b.querySelector(':scope > ' + CFG.ECHO);
    const glued = () => Array.from(b.childNodes).filter((n) => n !== e).map((n) => n.textContent).join('');
    if (typeof b.innerText !== 'string') return glued();
    let t = b.innerText;
    const et = e ? e.innerText : '';
    if (et && t.indexOf(et) === 0) t = t.slice(et.length);
    else if (e) return glued();
    return t;
  };
  function setInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }
  function submit(input) {
    let el = input;
    for (let i = 0; i < 6 && el; i++) {
      el = el.parentElement;
      const btn = el && Array.from(el.querySelectorAll('button')).find((b) => /^\s*send\s*$/i.test(b.textContent) && !b.disabled);
      if (btn) { btn.click(); return; }
    }
    ['keydown', 'keypress', 'keyup'].forEach((type) =>
      input.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })));
  }
  // The terminal first shows "Loading ..." in the reply, then swaps in the
  // real text. That placeholder never counts as the answer.
  const isLoading = (t) => /^\s*LOADING\b/i.test(t);
  // strict: only return once done(block) is true (the timeout returns null).
  // Steps the agent doesn't need to see (I, the sells, retries) are hidden
  // the moment they appear while hideSink is set; only *IA stays on screen.
  let hideSink = null;
  function hideBlock(b) {
    if (!b || !hideSink) return;
    b.style.setProperty('display', 'none', 'important');
    if (!hideSink.includes(b)) hideSink.push(b);
  }
  const unhideAll = (list) => (list || []).forEach((b) => { try { b.style.removeProperty('display'); } catch (e) { /* ignore */ } });
  async function waitForBlock(cmd, before, done, strict, timeoutMs) {
    const want = norm(cmd);
    const start = Date.now();
    let sig = '', lastChange = Date.now();
    while (Date.now() - start < (timeoutMs || CFG.TIMEOUT_MS)) {
      await sleep(60);
      const out = getOutput();
      if (!out) continue;
      const blocks = blocksOf(out);
      const last = blocks[blocks.length - 1];
      if (!last || echoOf(last) !== want) continue;
      if (last === before.node && last.textContent === before.text) continue;
      hideBlock(last);
      const s = last.textContent.length + ':' + last.querySelectorAll('tr').length;
      if (s !== sig) { sig = s; lastChange = Date.now(); }
      const quiet = Date.now() - lastChange;
      const input = getInput();
      const busy = !!(input && input.disabled);
      const text = outputText(last);
      if (isLoading(text) && !(done && done.acceptLoading)) continue; // still loading
      if (strict) { if (done && done(last)) return last; continue; }
      const hasReply = text.trim().length > 0 || last.querySelector('table');
      if (hasReply && ((done && done(last)) || (!busy && quiet >= CFG.QUIET_MS))) return last;
      if (!hasReply && !busy && quiet >= CFG.EMPTY_MS) return last; // chained sells: empty reply
    }
    return null;
  }
  async function runCommand(cmd, done, strict, timeoutMs) {
    const input = getInput();
    const out = getOutput();
    if (!input) throw new Error('The terminal command bar is not on this page.');
    if (!out) throw new Error('The terminal output area is not on this page.');
    for (let i = 0; i < 100 && input.disabled; i++) await sleep(100);
    const blocks = blocksOf(out);
    const lastBefore = blocks[blocks.length - 1];
    const before = { node: lastBefore || null, text: lastBefore ? lastBefore.textContent : '' };
    setInputValue(input, cmd);
    await sleep(40);
    submit(input);
    // If the bar didn't take it (still holding the command, or the terminal
    // swapped in a new bar meanwhile), enter it once more. A command the bar
    // already took is never sent twice.
    const want = norm(cmd);
    const echoed = () => {
      const o = getOutput();
      const bl = o ? blocksOf(o) : [];
      const last = bl[bl.length - 1];
      return !!(last && echoOf(last) === want && !(last === before.node && last.textContent === before.text));
    };
    for (let k = 0; k < 25 && !echoed(); k++) await sleep(60);
    if (!echoed()) {
      const now = getInput();
      if (now && (now.value === cmd || (now !== input && !input.isConnected))) {
        setInputValue(now, cmd);
        await sleep(40);
        submit(now);
      }
    }
    return waitForBlock(cmd, before, done, strict, timeoutMs);
  }

  /* ---------- run commands from elsewhere (Fast Search) ---------- */
  // Opens the Terminal tab if it's closed, waits for the command bar, then
  // sends I (waits for IGD) and the given command.
  function terminalTab() {
    const t = Array.from(document.querySelectorAll('.tab__title')).find((x) => /^\s*Terminal\b/i.test(x.textContent || ''));
    if (!t) return null;
    return t.closest('.tab') || t.closest('[role="tab"]') || t.closest('.tab__content') || t;
  }
  const barReady = () => { const i = getInput(); return !!(i && i.getClientRects().length && getOutput()); };
  async function openTerminal() {
    if (barReady()) return true;
    const tab = terminalTab();
    if (!tab) return false;
    tab.click();
    const inner = tab.querySelector && tab.querySelector('.tab__content');
    for (let k = 0; k < 100 && !barReady(); k++) {
      await sleep(100);
      if (k === 15 && !barReady() && inner) inner.click();
    }
    if (!barReady()) return false;
    await sleep(350); // let a just-opened terminal finish setting up its bar
    return true;
  }
  __iaTerm.run = async function (cmd) {
    if (state.running || __iaTerm.busy || document.documentElement.dataset.iaItbRunning) return { ok: false, msg: 'busy' };
    __iaTerm.busy = true;
    document.documentElement.dataset.iaTermBusy = '1';
    try {
      if (!(await openTerminal())) return { ok: false, msg: 'no-terminal' };
      const input = getInput();
      try { input.focus(); } catch (e) { /* ignore */ }
      // I, then the search as soon as I's reply is in (IGD or anything else;
      // a search doesn't depend on it). If the bar didn't take the I, once more.
      const replied = (blk) => outputText(blk).trim().length > 0;
      const quiet = [];
      hideSink = quiet; // the I isn't shown, only the search
      let cleared = await runCommand(CFG.CLEAR, replied, true, 4000);
      if (!cleared) cleared = await runCommand(CFG.CLEAR, replied, true, 4000);
      hideSink = null;
      if (!cleared) { unhideAll(quiet); return { ok: false, msg: 'no-reply' }; }
      await sleep(CFG.GAP_MS);
      // The search counts as sent once it's on screen (results can take a while).
      const onScreen = () => true;
      onScreen.acceptLoading = true;
      const b = await runCommand(cmd, onScreen, true, 8000);
      return { ok: !!b, msg: b ? 'sent' : 'no-reply' };
    } catch (e) {
      return { ok: false, msg: 'error' };
    } finally {
      hideSink = null;
      __iaTerm.busy = false;
      delete document.documentElement.dataset.iaTermBusy;
    }
  };

})();

// ====================================================================
// SECTION 12 · Leads list: change a lead's status from its letter badge
// ====================================================================
// Click a lead's round status letter (P / F / C) on the leads list or the
// search results: a menu like the one inside the lead opens under it.
//  - Potential / Follow up: the same request the lead page sends
//    (PATCH AgentLeadModel {event:"setLeadStatus", data:{status_id}}).
//  - Closed: the same "Closing reason request" the lead page shows —
//    reason, duplicate lead (for "new request in the same client card",
//    searched exactly like the BO's own box), remark and urgency — sent as
//    the BO's own closeLead request, with files dropped or pasted in.
// Uses the BO's own login headers (picked up from its own requests).
(function () {
  'use strict';
  if (!location.hostname.includes('travelbusinessclass.com')) return;
  if (window.top !== window) return;
  const W = (typeof unsafeWindow !== 'undefined' && unsafeWindow) || window;

  const STATUSES = [
    { id: 2, letter: 'P', name: 'Potential', cls: 'bg-vista-blue-300' },
    { id: 3, letter: 'F', name: 'Follow up', cls: 'bg-vodka-400' },
    { id: 0, letter: 'C', name: 'Closed', cls: 'bg-red-500', close: true },
  ];
  // The reasons the BO's Closed window offers, with the codes it sends.
  const REASONS = [
    { code: 'not_interested', title: 'Closing lead due to pax not interested/booked' },
    { code: 'no_reply', title: 'Closing lead due to no reply after proper followup' },
    { code: 'new_request', title: 'Closing older leads due to pax left a new request in the same client card', dup: true },
    { code: 'booked_economy', title: 'Booked economy class' },
    { code: 'fake_lead', title: 'Fake lead' },
    { code: 'unsubscribed', title: 'Unsubscribed by Client' },
  ];
  const URGENCY = [
    { value: '10_low', title: 'Low' },
    { value: '20_medium', title: 'Medium' },
    { value: '30_high', title: 'High' },
    { value: '40_critical', title: 'Critical' },
  ];
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* ---------- BO requests ---------- */
  function boHeaders(json) {
    const h = Object.assign({ Accept: 'application/json' }, (typeof __jsApi !== 'undefined' && __jsApi.headers) || {});
    if (!Object.keys(h).some((k) => /authorization/i.test(k))) { const sa = __jsStoredAuth(); if (sa) h.Authorization = sa; }
    if (!Object.keys(h).some((k) => /authorization/i.test(k))) {
      try {
        for (let i = 0; i < W.localStorage.length; i++) {
          const k = W.localStorage.key(i);
          const v = (W.localStorage.getItem(k) || '').replace(/^"|"$/g, '');
          if (/token/i.test(k) && /^[\w-]+\.[\w-]+\.[\w-]+$/.test(v)) { h.Authorization = 'Bearer ' + v; break; }
        }
      } catch (e) { /* ignore */ }
    }
    if (!Object.keys(h).some((k) => /authorization/i.test(k))) return null;
    Object.keys(h).forEach((k) => { if (/^x-activeat$/i.test(k)) delete h[k]; });
    h['x-activeat'] = String(Math.floor(Date.now() / 1000));
    if (!Object.keys(h).some((k) => /^x-workspace$/i.test(k))) h['x-workspace'] = '1';
    if (!Object.keys(h).some((k) => /^x-workspace-project$/i.test(k))) h['x-workspace-project'] = '1';
    if (json) h['content-type'] = 'application/json';
    return h;
  }
  async function bo(method, url, body) {
    const h = boHeaders(!!body);
    if (!h) throw new Error('BO session not ready yet — wait a few seconds and try again.');
    const res = await W.fetch(url, { method, credentials: 'include', headers: h, body: body ? JSON.stringify(body) : undefined });
    let j = null;
    try { j = await res.json(); } catch (e) { /* not JSON */ }
    if (!res.ok || !j || j.success === false) {
      const msg = (j && (j.message || (j.errors && Object.values(j.errors).flat().join(' ')))) || ('HTTP ' + res.status);
      throw new Error(String(msg));
    }
    return j;
  }
  const setStatus = (leadId, statusId) => bo('PATCH', '/api/database/v1/leads/AgentLeadModel/' + leadId, { event: 'setLeadStatus', data: { status_id: statusId } });
  const closeLead = (leadId, reason, dupId, remark, urgency, filePks) => bo('POST', '/api/database/v2/Lead/action/closeLead?waitsForResponse=false', {
    lead_pk: String(leadId),
    closing_reason: reason,
    closing_reason_remark: null,
    duplicate_lead_pk: dupId ? String(dupId) : null,
    issue_data: { remark: remark || '', urgency: urgency || '20_medium', expires_at: null, file_pks: (filePks || []).map(String) },
  });
  // The BO's duplicate-lead search: mergeable leads (not this one) matching
  // the typed text, newest first; then their route and client name.
  async function searchDuplicates(leadId, text) {
    const q = 'where[0][ne][0]=id&where[0][ne][1]=' + encodeURIComponent(leadId)
      + '&where[1][eq][0]=can_merge&where[1][eq][1]=true'
      + '&where[2][lo][0]=keywords&where[2][lo][1]=' + encodeURIComponent(text)
      + '&orderBy[0][0]=id&orderBy[0][1]=desc';
    const s = await bo('GET', '/api/database/v2/Lead/search?' + q.replace(/\[/g, '%5B').replace(/\]/g, '%5D'));
    const pks = (s.result || []).map(String).slice(0, 20);
    if (!pks.length) return [];
    const f = await bo('GET', '/api/database/v2/Lead/find?pks=' + pks.join(','));
    const leads = f.result || [];
    const cpks = Array.from(new Set(leads.map((l) => l.client_pk).filter(Boolean)));
    const names = {};
    if (cpks.length) {
      try {
        const c = await bo('GET', '/api/database/v2/ClientPreview/find?pks=' + cpks.join(','));
        (c.result || []).forEach((x) => { names[String(x.id)] = { first: (x.first_name || '').trim(), last: (x.last_name || '').trim() }; });
      } catch (e) { /* names are a nice-to-have */ }
    }
    const byId = {};
    leads.forEach((l) => { byId[String(l.id)] = l; });
    return pks.map((pk) => byId[pk]).filter(Boolean).map((l) => {
      const n = names[String(l.client_pk)] || { first: '', last: '' };
      const full = [n.first, n.last].filter(Boolean).join(' ');
      return {
        id: String(l.id),
        title: '#' + l.id + (full ? ' | ' + full : ''),
        sub: (l.from_iata_code || '') + ' -> ' + (l.to_iata_code || ''),
        // The card under the picked lead, as the BO shows it.
        client: [n.last, n.first].filter(Boolean).join(' '),
        from: l.from_iata_code || '', to: l.to_iata_code || '',
        fromDate: dayMon(l.departure_date, l.from_iata_timezone),
        toDate: dayMon(l.return_date || l.departure_date, l.to_iata_timezone),
      };
    });
  }

  /* ---------- finding the badge ---------- */
  const leadIdOf = (row) => {
    const a = row && row.querySelector('a[href*="/leads/"]');
    const m = a && (a.getAttribute('href') || '').match(/\/leads\/(\d+)/);
    return m ? m[1] : null;
  };
  // The status letter in a leads-list row: a small round one-letter badge.
  function badgeFrom(target) {
    const el = target && target.closest && target.closest('div.rounded-full');
    if (!el || !el.classList.contains('w-4') || !el.classList.contains('h-4')) return null;
    if (!/^[NPFC]$/.test((el.textContent || '').trim())) return null; // New, Potential, Follow up, Closed
    if (!el.closest('.v-popper--has-tooltip')) return null;
    const row = el.closest('tr');
    if (!row || !leadIdOf(row)) return null;
    return { el, row, leadId: leadIdOf(row) };
  }
  function paintBadge(el, st) {
    Array.from(el.classList).forEach((c) => { if (/^bg-/.test(c)) el.classList.remove(c); });
    el.classList.add(st.cls);
    el.textContent = st.letter;
  }

  // A small green note that confirms a change, then fades.
  function lsmToast(text) {
    document.querySelectorAll('.ia-lsm-toast').forEach((n) => n.remove());
    const t = document.createElement('div');
    t.className = 'ia-lsm-toast';
    t.textContent = text;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; }, 2200);
    setTimeout(() => t.remove(), 2600);
  }

  /* ---------- the status menu (the BO's own, at its own size) ---------- */
  let menu = null;
  let ctx = null; // { el, row, leadId }
  function closeMenu() {
    if (menu) menu.remove();
    menu = null;
    if (!modal) ctx = null;
  }
  function place() {
    if (!menu || !ctx || !ctx.el.isConnected) return;
    const r = ctx.el.getBoundingClientRect();
    const w = menu.offsetWidth, h = menu.offsetHeight;
    const vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;
    const left = Math.min(Math.max(8, r.left - 8), vw - w - 8);
    let top = r.bottom + 6;
    if (top + h > vh - 8) top = Math.max(8, r.top - h - 6);
    menu.style.left = Math.round(left) + 'px';
    menu.style.top = Math.round(top) + 'px';
  }
  function open(b) {
    closeMenu();
    ctx = b;
    menu = document.createElement('div');
    menu.className = 'ia-lsm dropdown-menu__content box dark:bg-dark-1 p-2 w-32 mt-0';
    document.body.appendChild(menu);
    showStatuses();
  }
  function showStatuses(err) {
    menu.innerHTML = STATUSES.map((s, i) => '<a class="dropdown-menu__item ia-lsm-item" data-i="' + i + '">'
      + '<span class="' + s.cls + ' flex-none flex items-center justify-center w-4 h-4 rounded-full mr-2 text-2xs text-white font-semibold">' + s.letter + '</span> ' + esc(s.name) + '</a>').join('')
      + (err ? '<div class="ia-lsm-err">' + esc(err) + '</div>' : '');
    menu.querySelectorAll('.ia-lsm-item').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); pick(STATUSES[+a.dataset.i]); }));
    place();
  }
  async function pick(st) {
    const c = ctx;
    if (st.close) { closeMenu(); ctx = c; openClose(c); return; }
    menu.querySelectorAll('.ia-lsm-item').forEach((a) => a.classList.add('is-off'));
    try {
      await setStatus(c.leadId, st.id);
      paintBadge(c.el, st);
      c.row.classList.remove('ia-lsm-closed');
      closeMenu();
      lsmToast('✓ Lead ' + c.leadId + ' → ' + st.name);
    } catch (e) {
      if (menu && ctx === c) showStatuses('Not changed: ' + e.message);
    }
  }

  /* ---------- files: the BO's own uploader, step for step ---------- */
  // startUpload {chunkCount, fileType, fileName} -> uploadID; every 500 KB
  // piece at once as uploadChunk {uploadID, number, data: <data URL>} (each
  // retried up to 3 more times); completeUpload {uploadID} -> the file's id.
  const FILE_API = '/api/database/v1/files/FileListModel/0';
  const CHUNK = 1024 * 500;
  const MAX_FILE = 32 * 1024 * 1024;
  const readChunk = (blob) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error || new Error('Could not read the file'));
    r.readAsDataURL(blob);
  });
  async function uploadFile(file, onPct, isDropped) {
    const chunkCount = Math.ceil(file.size / CHUNK);
    let done = 0;
    const tick = () => { done++; onPct(Math.round(done / (chunkCount + 2) * 100)); };
    const s = await bo('PATCH', FILE_API, { event: 'startUpload', data: { chunkCount, fileType: file.type, fileName: file.name } });
    const uploadID = s.result && s.result.uploadID;
    if (!uploadID) throw new Error('The BO did not start the upload.');
    tick();
    const one = async (n, tries) => {
      if (isDropped()) throw new Error('removed');
      const data = await readChunk(file.slice(n * CHUNK, n * CHUNK + CHUNK));
      try { await bo('PATCH', FILE_API, { event: 'uploadChunk', data: { uploadID, number: n, data } }); }
      catch (e) { if (tries > 3 || isDropped()) throw e; return one(n, tries + 1); }
      tick();
    };
    await Promise.all(Array.from({ length: chunkCount }, (_, n) => one(n, 1)));
    const c = await bo('PATCH', FILE_API, { event: 'completeUpload', data: { uploadID } });
    if (!c.result || c.result.id == null) throw new Error('The BO did not finish the upload.');
    tick();
    return c.result;
  }
  // The BO's file icon (its "IMG" one, copied), recoloured per file type.
  function fileIcon(ext) {
    const e = String(ext || '').toLowerCase();
    const [label, color] = /^(png|jpe?g|gif|webp|bmp|heic|svg)$/.test(e) ? ['IMG', '#FBC500']
      : e === 'pdf' ? ['PDF', '#ef4444'] : /^(mp3|wav|m4a|ogg|aac|amr)$/.test(e) ? ['AUD', '#8b5cf6']
        : /^(mp4|mov|avi|webm)$/.test(e) ? ['VID', '#ec4899'] : /^(docx?|txt|rtf)$/.test(e) ? ['DOC', '#3b82f6']
          : /^(xlsx?|csv)$/.test(e) ? ['XLS', '#16a34a'] : /^(eml|msg)$/.test(e) ? ['EML', '#0ea5e9'] : ['FILE', '#64748b'];
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 28 28"><path fill="#738195" fill-opacity=".2" d="M8 28h18a2 2 0 0 0 2-2V8l-8-8H8a2 2 0 0 0-2 2v24a2 2 0 0 0 2 2Z"/><path fill="#738195" fill-opacity=".2" d="M28 8v6l-6-6h6Z"/><path fill="#738195" fill-opacity=".5" d="M22 8h6l-8-8v6a2 2 0 0 0 2 2Z"/>'
      + '<rect width="20" height="11" x="4" y="13" fill="' + color + '" rx="2"/><text x="14" y="21.3" font-size="' + (label.length > 3 ? 5.6 : 7) + '" font-weight="800" fill="#fff" text-anchor="middle" font-family="Arial,sans-serif">' + label + '</text></svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }
  // Dates on the duplicate lead's card, as the BO shows them: "26 Nov", or
  // "04 Jan 27" when it's not this year; in the airport's own time zone.
  function dayMon(unix, tz) {
    if (!unix) return '';
    const fmt = (zone) => {
      const parts = new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: '2-digit', timeZone: zone }).formatToParts(new Date(unix * 1000));
      const g = (t) => (parts.find((p) => p.type === t) || {}).value || '';
      const thisYear = String(new Date().getFullYear()).slice(-2);
      return g('day') + ' ' + g('month') + (g('year') !== thisYear ? ' ' + g('year') : '');
    };
    try { return fmt(tz || 'UTC'); } catch (e) { return fmt('UTC'); }
  }

  /* ---------- the "Closing reason request?" window (the BO's own HTML) ---------- */
  const ICO = {
    chev: '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>',
    urg: {
      '10_low': '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down text-primary icon --large"><polyline points="6 9 12 15 18 9"></polyline></svg>',
      '20_medium': '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minus text-primary icon --large"><line x1="5" y1="12" x2="19" y2="12"></line></svg>',
      '30_high': '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-up text-warning icon --large"><polyline points="18 15 12 9 6 15"></polyline></svg>',
      '40_critical': '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-up text-danger icon --large"><polyline points="17 11 12 6 7 11"></polyline><polyline points="17 18 12 13 7 18"></polyline></svg>',
    },
    info: '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-info text-info-500 icon --xl flex-none"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
    warn: '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-triangle text-warning icon --large flex-none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
    close: '<svg height="10" viewBox="0 0 10 10" width="10" class="app-modal__close__corner app-modal__close__corner--first"><path d="M10 10V0s0 3-3 7c-4 3-7 3-7 3h10Z" fill="currentColor"></path></svg><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 16 16"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m12 4-8 8M4 4l8 8"></path></svg><svg height="10" viewBox="0 0 10 10" width="10" class="app-modal__close__corner app-modal__close__corner--second"><path d="M10 10V0s0 3-3 7c-4 3-7 3-7 3h10Z" fill="currentColor"></path></svg>',
    upload: '<svg class="upload-area__icon" width="64" height="75" viewBox="0 0 64 75" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M47 1H26a5 5 0 0 0-5 5v42a5 5 0 0 0 5 5h31a5 5 0 0 0 5-5V17L47 1Z" stroke="#2F5AD8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M47 1v16h15M42 43V27M34 35h15" stroke="#2F5AD8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path opacity=".6" d="M16 12a5 5 0 0 0-5 5v42a5 5 0 0 0 5 5h31a5 5 0 0 0 5-5" stroke="#2F5AD8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path opacity=".3" d="M6 22a5 5 0 0 0-5 5v42a5 5 0 0 0 5 5h31a5 5 0 0 0 5-5" stroke="#2F5AD8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    trash: '<svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash w-3.5 h-3.5 !stroke-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>',
  };
  const optHtml = (items) => '<div class="input-select__options --undefined" role="listbox"><div class="input-select__options__container">'
    + items.map((o, i) => '<div role="option" data-i="' + i + '"><div class="input-select__option' + (o.selected ? ' input-select__option--selected' : '') + (o.empty ? ' input-select__option--empty' : '') + '">'
      + (o.image ? '<div class="input-select__option__image flex items-center justify-center">' + o.image + '</div>' : '')
      + '<div class="input-select__option__text"><div class="input-select__option__text__title">' + esc(o.title) + '</div>'
      + (o.sub ? '<div class="input-select__option__text__subtitle">' + esc(o.sub) + '</div>' : '') + '</div></div></div>').join('')
    + '</div></div>';

  let modal = null;   // the window (outer wrapper)
  let form = null;    // its state
  let files = [];     // { key, name, ext, status: 'up'|'ok'|'err', pct, pk, err, dropped }
  let fileSeq = 0;
  // Backup styles are switched on per part only when the BO hasn't styled
  // that part (its stylesheet for it not loaded yet). A part counts as
  // styled when it looks different from a plain element of the same kind.
  let fbChecked = {};
  const FB_PARTS = { modal: '.app-modal__container', select: '.input-select', field: '.input-field__input', upload: '.upload-area__label', list: '.upload-list__file', card: '.ia-lsm-card', notice: '.ia-lsm-info', util: 'form.grid', label: '.form-label' };
  function boStyled(el) {
    const probe = document.createElement(el.tagName);
    el.parentNode.insertBefore(probe, el);
    const a = getComputedStyle(el), b = getComputedStyle(probe);
    const diff = ['display', 'position', 'borderTopStyle', 'borderTopWidth', 'backgroundColor', 'paddingTop', 'paddingLeft', 'borderTopLeftRadius', 'minHeight', 'fontSize', 'fontWeight', 'gridTemplateColumns', 'marginBottom'].some((k) => a[k] !== b[k]);
    probe.remove();
    return diff;
  }
  function checkStyles() {
    if (!modal) return;
    Object.keys(FB_PARTS).forEach((part) => {
      if (fbChecked[part]) return;
      const el = modal.querySelector(FB_PARTS[part]);
      if (!el) return; // not on screen yet: checked once it is
      fbChecked[part] = true;
      if (!boStyled(el)) modal.classList.add('ia-lsm-fb-' + part);
    });
  }
  function closeModal() {
    files.forEach((f) => { f.dropped = true; }); // stop any upload still running
    files = [];
    if (modal) modal.remove();
    modal = null; form = null; ctx = null;
  }
  function openClose(c) {
    closeModal();
    ctx = c;
    form = { leadId: c.leadId, reason: '', dup: null, remark: '', urgency: '20_medium', open: null, dupText: '', dupList: [], dupMsg: '', err: '', busy: false };
    modal = document.createElement('div');
    modal.className = 'ia-lsm-wrap';
    modal.innerHTML = '<div id="app-modal--CloseLeadReasonRequestModal" class="app-modal app-modal--top ia-lsm-modal">'
      + '<div class="app-modal__container app-modal__container--default !max-w-[500px]" workspaceproject="1">'
      + '<div class="app-modal__header app-modal__header--with-close-button"><div class="app-modal__header__content"><div class="app-modal__header__title"><span>Closing reason request?</span></div></div>'
      + '<div class="app-modal__close ia-lsm-close">' + ICO.close + '</div></div>'
      + '<div class="app-modal__body"><div class="p-4 border-t border-gray-200 dark:border-dark-5 ia-lsm-body"></div></div>'
      + '<div class="app-modal__footer"><div class="flex justify-between"><button class="button ia-lsm-cancel" type="button"> Cancel </button><button class="button --primary ia-lsm-go" type="button"> Close the lead </button></div></div>'
      + '</div></div>';
    document.body.appendChild(modal);
    // If the BO's own window styles aren't loaded yet, the wrapper does the
    // backdrop and centring; when they are, it stays out of the way.
    const am = modal.querySelector('.app-modal');
    if (getComputedStyle(am).position !== 'fixed') modal.classList.add('ia-lsm-wrap--own');
    fbChecked = {};
    modal.querySelector('.ia-lsm-close').addEventListener('click', closeModal);
    modal.querySelector('.ia-lsm-cancel').addEventListener('click', closeModal);
    modal.querySelector('.ia-lsm-go').addEventListener('click', submitClose);
    // Only a press on the backdrop itself closes it (not one inside the
    // window that redraws the part it landed on).
    modal.addEventListener('mousedown', (e) => { if (e.target === modal || e.target.classList.contains('app-modal')) closeModal(); });
    wireDrops();
    drawBody();
  }
  const uploading = () => files.some((f) => !f.dropped && f.status === 'up');
  const canClose = () => { const r = REASONS.find((x) => x.code === form.reason); return !!r && (!r.dup || !!form.dup) && !uploading() && !form.busy; };
  function drawButtons() {
    if (!modal) return;
    const go = modal.querySelector('.ia-lsm-go');
    go.disabled = !canClose();
    go.textContent = form.busy ? ' Closing… ' : uploading() ? ' Uploading… ' : ' Close the lead ';
  }
  function drawBody() {
    if (!modal) return;
    const body = modal.querySelector('.ia-lsm-body');
    const keepFocus = document.activeElement && body.contains(document.activeElement) ? document.activeElement.dataset.k : null;
    const R = REASONS.find((r) => r.code === form.reason);
    const d = form.dup;
    const reasonOpen = form.open === 'reason', urgOpen = form.open === 'urg', dupOpen = form.open === 'dup';
    let top = '<div class=""><label class="form-label items-center gap-1">Closing reason</label>'
      + '<div class="dropdown input-select input-select--search' + (reasonOpen ? ' dropdown--opened' : '') + '" data-sel="reason">'
      + '<input type="text" class="input-select__input" data-k="reason" autocomplete="off"' + (R ? '' : ' placeholder="Please select a closing reason"') + ' value="">'
      + (R ? '<div class="input-select__placeholder">' + esc(R.title) + '</div>' : '')
      + '<div class="input-select__arrow">' + ICO.chev + '</div>'
      + '<div class="dropdown__content w-full" tabindex="-1"' + (reasonOpen ? ' style="position:absolute;inset:0 auto auto 0;margin:0;transform:translate(0,31px)"' : '') + '>'
      + (reasonOpen ? optHtml([{ title: 'Please select a closing reason', empty: true, selected: !R }].concat(REASONS.map((r) => ({ title: r.title, selected: r === R })))) : '')
      + '</div></div></div>';
    if (R && R.dup) {
      top += '<div class=""><label class="form-label items-center gap-1">Select duplicate lead</label>'
        + '<div class="dropdown input-select input-select--search' + (dupOpen ? ' dropdown--opened' : '') + '" data-sel="dup">'
        + '<input type="text" class="input-select__input" data-k="dup" autocomplete="off" value="' + esc(form.dupText) + '">'
        + (d && !form.dupText ? '<div class="input-select__placeholder">' + esc(d.title) + '</div>' : '')
        + '<div class="input-select__arrow">' + ICO.chev + '</div>'
        + '<div class="dropdown__content w-full" tabindex="-1"' + (dupOpen ? ' style="position:absolute;inset:0 auto auto 0;margin:0;transform:translate(0,31px)"' : '') + '>'
        + (dupOpen ? (form.dupList.length
          ? optHtml([{ title: '--------', empty: true, selected: !d }].concat(form.dupList.map((o) => ({ title: o.title, sub: o.sub, selected: !!(d && d.id === o.id) }))))
          : '<div class="input-select__options --undefined" role="listbox"><div class="input-select__options__container"></div><div class="input-select__options__no-results"> ' + esc(form.dupMsg || 'Start typing ...') + ' </div></div>') : '')
        + '</div></div></div>';
      if (d) {
        top += '<div data-v-47b8d642="" class="mb-2 box border border-theme-4 py-3 px-0.5 rounded-md shadow-none leading-snug ia-lsm-card"><div data-v-47b8d642="" class="grid gap-y-2.5 grid-cols-2">'
          + '<div data-v-47b8d642="" class="_item"><div data-v-47b8d642="" class="_title"> Lead ID </div><div data-v-47b8d642="" class="_value"><a data-v-47b8d642="" href="/leads/' + esc(d.id) + '" class="text-primary" target="_blank"> #' + esc(d.id) + '</a></div></div>'
          + '<div data-v-47b8d642="" class="_item"><div data-v-47b8d642="" class="_title"> Client </div><div data-v-47b8d642="" class="_value">' + esc(d.client) + '</div></div>'
          + '<div data-v-47b8d642="" class="_item"><div data-v-47b8d642="" class="_title"> From </div><div data-v-47b8d642="" class="_value">' + esc(d.from) + ' <span data-v-47b8d642="" class="text-theme-2 font-medium whitespace-nowrap">' + esc(d.fromDate) + '</span></div></div>'
          + '<div data-v-47b8d642="" class="_item"><div data-v-47b8d642="" class="_title"> To </div><div data-v-47b8d642="" class="_value">' + esc(d.to) + ' <span data-v-47b8d642="" class="text-theme-2 font-medium whitespace-nowrap">' + esc(d.toDate) + '</span></div></div>'
          + '</div></div>';
      }
    }
    const U = URGENCY.find((u) => u.value === form.urgency) || URGENCY[1];
    body.innerHTML = '<div class="flex flex-col gap-4">' + top + '</div><hr class="my-4">'
      + '<form class="grid grid-cols-2 gap-4" onsubmit="return false">'
      + '<div class="col-span-2 border rounded flex items-center gap-3 px-3 py-2 bg-info-50 border-info-200 text-info-800 text-xs ia-lsm-info">' + ICO.info + '<div> Please, provide all the necessary information that would help approve your request in the shortest time. </div></div>'
      + '<div class="col-span-2"><label class="form-label items-center gap-1">Remark</label><div class="input-field input-textarea --normal"><textarea class="input-field__input" data-k="remark" placeholder="Information that would help approve your request" rows="3" autocomplete="Off">' + esc(form.remark) + '</textarea></div></div>'
      + '<div class=""><label class="form-label items-center gap-1">Urgency</label>'
      + '<div class="dropdown input-select' + (urgOpen ? ' dropdown--opened' : '') + '" data-sel="urg"><div class="input-select__value" tabindex="0" data-k="urg">'
      + '<div class="input-select__image flex items-center justify-center">' + ICO.urg[U.value] + '</div><div class="input-select__value__text"><div class="input-select__value__text__title">' + U.title + '</div></div>'
      + '<div class="input-select__arrow">' + ICO.chev + '</div></div>'
      + '<div class="dropdown__content w-full" tabindex="-1"' + (urgOpen ? ' style="position:absolute;inset:0 auto auto 0;margin:0;transform:translate(0,31px)"' : '') + '>'
      + (urgOpen ? optHtml(URGENCY.map((u) => ({ title: u.title, image: ICO.urg[u.value], selected: u === U }))) : '')
      + '</div></div></div>'
      + '<div class="col-span-2"><div class="upload-area upload-area--compact ia-lsm-drop"><label class="upload-area__label"><div class="upload-area__value"></div><div class="upload-area__info"><div><div class="upload-area__title">Drag or paste files here</div><div class="upload-area__max-size"> (max. 32 Mb) </div></div>' + ICO.upload + '</div><input type="file" class="upload-area__input" multiple=""></label></div>'
      + '<div class="text-2xs text-secondary-400 text-center mt-1.5"> Please attach any call recordings, email screens, SMS, and any other relevant files </div></div>'
      + '<div class="upload-list col-span-2 ia-lsm-files"></div>'
      + '<div class="col-span-2 border rounded flex items-center gap-3 px-3 py-2 bg-warning-50 text-warning-900 border-warning text-xs ia-lsm-warn">' + ICO.warn + '<div> Requests with limited and noncompliant information will be declined. </div></div>'
      + (form.err ? '<div class="col-span-2 border rounded flex items-center gap-3 px-3 py-2 text-xs ia-lsm-errbox">' + esc(form.err) + '</div>' : '')
      + '</form>';
    wireBody(body);
    drawFiles();
    drawButtons();
    checkStyles();
    if (keepFocus) { const el = body.querySelector('[data-k="' + keepFocus + '"]'); if (el) { el.focus(); if (el.setSelectionRange && el.value) el.setSelectionRange(el.value.length, el.value.length); } }
  }
  function wireBody(body) {
    const sel = (name) => body.querySelector('[data-sel="' + name + '"]');
    const toggle = (name) => { form.open = form.open === name ? null : name; drawBody(); };
    body.querySelectorAll('[data-sel]').forEach((box) => {
      box.addEventListener('mousedown', (e) => {
        if (e.target.closest('.dropdown__content')) return;
        if (box.dataset.sel === 'dup' && form.open === 'dup' && e.target.closest('input')) return;
        e.preventDefault();
        toggle(box.dataset.sel);
        const inp = body.querySelector('[data-k="' + box.dataset.sel + '"]');
        if (inp && form.open === box.dataset.sel) inp.focus();
      });
    });
    // Closing reason: also filters as you type, like the BO's search box.
    const rIn = body.querySelector('[data-k="reason"]');
    rIn.addEventListener('input', () => {
      const t = rIn.value.toLowerCase();
      const box = sel('reason').querySelector('.dropdown__content');
      form.open = 'reason';
      sel('reason').classList.add('dropdown--opened');
      box.setAttribute('style', 'position:absolute;inset:0 auto auto 0;margin:0;transform:translate(0,31px)');
      const list = REASONS.filter((r) => r.title.toLowerCase().includes(t));
      box.innerHTML = optHtml(list.map((r) => ({ title: r.title, selected: r.code === form.reason })));
      box.querySelectorAll('[role=option]').forEach((o) => o.addEventListener('mousedown', (e) => { e.preventDefault(); chooseReason(list[+o.dataset.i].code); }));
    });
    if (form.open === 'reason') {
      sel('reason').querySelectorAll('[role=option]').forEach((o) => o.addEventListener('mousedown', (e) => {
        e.preventDefault();
        const i = +o.dataset.i;
        chooseReason(i === 0 ? '' : REASONS[i - 1].code);
      }));
    }
    if (form.open === 'urg') {
      sel('urg').querySelectorAll('[role=option]').forEach((o) => o.addEventListener('mousedown', (e) => { e.preventDefault(); form.urgency = URGENCY[+o.dataset.i].value; form.open = null; drawBody(); }));
    }
    const dIn = body.querySelector('[data-k="dup"]');
    if (dIn) {
      let timer = null;
      dIn.addEventListener('input', () => {
        form.dupText = dIn.value;
        form.open = 'dup';
        clearTimeout(timer);
        const text = dIn.value.trim();
        if (!text) { form.dupList = []; form.dupMsg = ''; drawBody(); return; }
        const my = (form.dupSeq = (form.dupSeq || 0) + 1);
        timer = setTimeout(async () => {
          form.dupMsg = 'Searching ...';
          if (!form.dupList.length) drawBody();
          let list = [];
          try { list = await searchDuplicates(form.leadId, text); } catch (e) { if (form && form.dupSeq === my) { form.dupList = []; form.dupMsg = e.message; drawBody(); } return; }
          if (!form || form.dupSeq !== my) return;
          form.dupList = list;
          form.dupMsg = list.length ? '' : 'No results';
          drawBody();
        }, 250);
      });
      if (form.open === 'dup') {
        sel('dup').querySelectorAll('[role=option]').forEach((o) => o.addEventListener('mousedown', (e) => {
          e.preventDefault();
          const i = +o.dataset.i;
          form.dup = i === 0 ? null : form.dupList[i - 1];
          form.dupText = '';
          form.open = null;
          drawBody();
        }));
      }
    }
    const ta = body.querySelector('[data-k="remark"]');
    ta.addEventListener('input', () => { form.remark = ta.value; });
    body.querySelectorAll('input, textarea, [tabindex]').forEach((x) => x.addEventListener('keydown', (e) => { if (e.key !== 'Escape') e.stopPropagation(); }));
    const picker = body.querySelector('.upload-area__input');
    picker.addEventListener('change', () => { addFiles(picker.files); picker.value = ''; });
  }
  function chooseReason(code) {
    form.reason = code;
    if (!(REASONS.find((r) => r.code === code) || {}).dup) { form.dup = null; form.dupText = ''; form.dupList = []; }
    form.open = null;
    drawBody();
  }
  // File rows, as the BO draws them (name and extension apart, status, bin).
  function drawFiles() {
    const box = modal && modal.querySelector('.ia-lsm-files');
    if (!box) return;
    const list = files.filter((f) => !f.dropped);
    box.style.display = list.length ? '' : 'none';
    box.innerHTML = list.map((f) => {
      const base = f.name.replace(/\.[^.]+$/, '');
      const ext = /\.[^.]+$/.test(f.name) ? f.name.match(/\.[^.]+$/)[0] : '';
      const data = f.status === 'ok' ? '<span class="text-green-500">Uploaded</span>'
        : f.status === 'err' ? '<span class="text-danger ia-lsm-ferr">Failed — ' + esc(f.err) + '</span>'
          : '<span class="text-primary">Uploading… ' + f.pct + '%</span><div class="ia-lsm-fbar"><i style="width:' + f.pct + '%"></i></div>';
      return '<div class="upload-list__file" data-k="' + f.key + '"><div class="upload-list__file__icon"><img src="' + fileIcon(f.ext) + '" class="upload-list__file__icon__image" alt=""></div>'
        + '<div class="upload-list__file__info"><div class="upload-list__file__title pr-9"><div class="upload-list__file__name" title="' + esc(f.name) + '">' + esc(base) + '</div><div class="upload-list__file__type"> ' + esc(ext) + '</div></div>'
        + '<div class="upload-list__file__data">' + data + '</div></div>'
        + '<div class="upload-list__file__action"><button class="p-1 hover:scale-125 transition-transform ia-lsm-bin" type="button">' + ICO.trash + '</button></div></div>';
    }).join('');
    box.querySelectorAll('.ia-lsm-bin').forEach((b) => b.addEventListener('click', (e) => {
      e.preventDefault();
      const f = files.find((x) => String(x.key) === b.closest('.upload-list__file').dataset.k);
      if (f) f.dropped = true; // removing sends nothing, as in the BO
      drawFiles(); drawButtons();
    }));
    checkStyles();
  }
  function addFiles(list) {
    if (!modal) return;
    Array.from(list || []).forEach((file) => {
      const f = { key: ++fileSeq, name: file.name || 'pasted-file', ext: ((file.name || '').match(/\.([^.]+)$/) || [])[1] || (file.type || '').split('/')[1] || '', status: 'up', pct: 0, pk: null, err: '', dropped: false };
      files.push(f);
      if (file.size > MAX_FILE) { f.status = 'err'; f.err = 'over 32 Mb'; return; }
      uploadFile(file, (p) => { f.pct = p; if (!f.dropped) drawFiles(); }, () => f.dropped)
        .then((r) => { f.status = 'ok'; f.pk = String(r.id); })
        .catch((e) => { f.status = 'err'; f.err = String((e && e.message) || e).slice(0, 80); })
        .finally(() => { drawFiles(); drawButtons(); });
    });
    drawFiles(); drawButtons();
  }
  // Dropping anywhere on the window works (wired once per window).
  function wireDrops() {
    const box = modal.querySelector('.app-modal__container');
    const over = (on) => { const d = modal && modal.querySelector('.ia-lsm-drop'); if (d) d.classList.toggle('ia-lsm-over', on); };
    ['dragenter', 'dragover'].forEach((t) => box.addEventListener(t, (e) => { e.preventDefault(); over(true); }));
    box.addEventListener('dragleave', (e) => { if (!box.contains(e.relatedTarget)) over(false); });
    box.addEventListener('drop', (e) => { e.preventDefault(); over(false); if (e.dataTransfer && e.dataTransfer.files.length) addFiles(e.dataTransfer.files); });
  }
  // Pasting files while the window is open adds them (text pastes normally).
  document.addEventListener('paste', (e) => {
    if (!modal) return;
    const list = e.clipboardData && e.clipboardData.files;
    if (!list || !list.length) return;
    e.preventDefault();
    e.stopPropagation();
    addFiles(list);
  }, true);
  async function submitClose() {
    if (!form || !canClose()) return;
    const c = ctx;
    const pks = files.filter((f) => !f.dropped && f.status === 'ok' && f.pk).map((f) => f.pk);
    form.busy = true; form.err = ''; drawButtons();
    try {
      await closeLead(form.leadId, form.reason, form.dup && form.dup.id, form.remark, form.urgency, pks);
      paintBadge(c.el, STATUSES[2]);
      c.row.classList.add('ia-lsm-closed');
      closeModal();
      lsmToast('✓ Closing request sent for lead ' + c.leadId);
    } catch (er) {
      if (form) { form.busy = false; form.err = 'Not closed: ' + er.message; drawBody(); }
    }
  }

  // One listener for the whole page (rows are redrawn often by the BO).
  document.addEventListener('click', (e) => {
    if (modal && (modal.contains(e.target) || !e.target.isConnected)) {
      // a click inside the window closes its open list unless it was on that list
      if (form && form.open && !e.target.closest('[data-sel="' + form.open + '"]')) { form.open = null; drawBody(); }
      return;
    }
    if (menu && menu.contains(e.target)) return;
    const b = badgeFrom(e.target);
    if (b) {
      e.preventDefault();
      e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      if (menu && ctx && ctx.el === b.el) { closeMenu(); return; }
      open(b);
      return;
    }
    if (menu) closeMenu();
  }, true);
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (modal) { e.stopPropagation(); if (form && form.open) { form.open = null; drawBody(); } else closeModal(); return; }
    if (menu) { e.stopPropagation(); closeMenu(); }
  }, true);
  window.addEventListener('scroll', () => place(), true);
  window.addEventListener('resize', () => place());

  // The menu at the BO's own size; everything else in the window uses the
  // BO's own classes. The :where() rules below have zero weight: they only
  // show when the BO's own styles for that part haven't loaded yet.
  GM_addStyle(`
    .ia-lsm { position: fixed !important; z-index: 2147483000; box-sizing: border-box !important; width: 8rem !important; min-width: 0 !important; max-width: 8rem !important; right: auto !important; bottom: auto !important; height: auto !important; transform: none !important; margin: 0 !important; box-shadow: 0 10px 25px rgba(0,0,0,.3); }
    .ia-lsm .dropdown-menu__item { display: flex; align-items: center; cursor: pointer; white-space: nowrap; }
    .ia-lsm .dropdown-menu__item.is-off { opacity: .5; pointer-events: none; }
    .ia-lsm-err { margin-top: 6px; padding: 5px 6px; border-radius: 6px; background: rgba(239,68,68,.15); color: #f87171; font-size: 11px; white-space: normal; }
    .ia-lsm-wrap { position: relative; z-index: 2147482000; }
    .ia-lsm-wrap--own { position: fixed; inset: 0; background: rgba(15,23,42,.55); overflow-y: auto; }
    .ia-lsm-wrap .dropdown__content:empty { display: none; }
    .ia-lsm-wrap .ia-lsm-over { border-color: #2F5AD8 !important; background: rgba(47,90,216,.08); }
    .ia-lsm-fbar { height: 3px; border-radius: 9px; background: rgba(148,163,184,.25); margin-top: 3px; overflow: hidden; width: 160px; }
    .ia-lsm-fbar i { display: block; height: 100%; background: #2F5AD8; transition: width .2s; }
    .ia-lsm-errbox { background: rgba(239,68,68,.12); border-color: rgba(239,68,68,.5); color: #f87171; }
    tr.ia-lsm-closed > td { opacity: .55; }
    tr .v-popper--has-tooltip div.rounded-full.w-4.h-4 { cursor: pointer; position: relative; }
    tr .v-popper--has-tooltip div.rounded-full.w-4.h-4:hover { outline: 2px dashed #93c5fd; outline-offset: 2px; }
    .ia-lsm-toast { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); z-index: 2147483600; background: #16a34a; color: #fff; border-radius: 8px; padding: 8px 14px;
      font: 600 12.5px Inter, 'Segoe UI', system-ui, sans-serif; box-shadow: 0 6px 16px rgba(0,0,0,.25); transition: opacity .35s ease; pointer-events: none; }
    /* ---- fallbacks (zero weight) ---- */
    :where(.ia-lsm) { background: #fff; color: #111827; border-radius: 8px; padding: 6px; border: 1px solid #e5e7eb; font: 600 12.5px Inter, 'Segoe UI', system-ui, sans-serif; }
    :where(.ia-lsm) .dropdown-menu__item { gap: 0; padding: 6px 8px; border-radius: 6px; }
    :where(.ia-lsm) .dropdown-menu__item:hover { background: rgba(15,23,42,.06); }
    :where(.ia-lsm) .rounded-full { border-radius: 50%; }
    :where(.ia-lsm) .w-4 { width: 16px; } :where(.ia-lsm) .h-4 { height: 16px; }
    :where(.ia-lsm) .flex { display: flex; } :where(.ia-lsm) .items-center { align-items: center; } :where(.ia-lsm) .justify-center { justify-content: center; }
    :where(.ia-lsm) .mr-2 { margin-right: 8px; } :where(.ia-lsm) .text-white { color: #fff; } :where(.ia-lsm) .text-2xs { font-size: 10px; } :where(.ia-lsm) .font-semibold { font-weight: 700; }
    :where(.ia-lsm) .bg-vista-blue-300 { background: #60a5fa; } :where(.ia-lsm) .bg-vodka-400 { background: #a78bfa; } :where(.ia-lsm) .bg-red-500 { background: #ef4444; }
    :where(.ia-lsm-wrap--own) .app-modal { display: flex; justify-content: center; align-items: flex-start; min-height: 100%; padding: 60px 16px; box-sizing: border-box; }
    :where(.ia-lsm-fb-modal) .app-modal__container { position: relative; width: 100%; max-width: 500px; background: #28304b; color: #e2e8f0; border-radius: 8px; box-shadow: 0 20px 50px rgba(0,0,0,.45); font-size: 14px; }
    :where(.ia-lsm-fb-modal) .app-modal__header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; }
    :where(.ia-lsm-fb-modal) .app-modal__header__title { font-size: 17px; font-weight: 600; }
    :where(.ia-lsm-fb-modal) .app-modal__close { cursor: pointer; display: flex; align-items: center; }
    :where(.ia-lsm-fb-modal) .app-modal__close__corner { display: none; }
    :where(.ia-lsm-fb-modal) .app-modal__footer { padding: 14px 20px 18px; }
    :where(.ia-lsm-fb-label) .form-label { display: block; margin-bottom: 8px; font-weight: 500; }
    :where(.ia-lsm-fb-select) .input-select { position: relative; display: flex; align-items: center; min-height: 34px; border: 1px solid rgba(148,163,184,.25); border-radius: 6px; background: #1f2638; cursor: pointer; }
    :where(.ia-lsm-fb-select) .input-select__input { flex: 1; min-width: 0; height: 32px; padding: 0 30px 0 12px; border: 0; background: transparent; color: inherit; font: inherit; font-size: 13px; outline: none; cursor: pointer; }
    :where(.ia-lsm-fb-select) .input-select__placeholder { position: absolute; left: 12px; right: 30px; top: 50%; transform: translateY(-50%); font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; pointer-events: none; }
    :where(.ia-lsm-fb-select) .input-select__arrow { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); display: flex; opacity: .7; pointer-events: none; }
    :where(.ia-lsm-fb-select) .input-select__value { display: flex; align-items: center; gap: 10px; width: 100%; height: 32px; padding: 0 30px 0 12px; font-size: 13px; outline: none; }
    :where(.ia-lsm-fb-select) .dropdown__content { z-index: 20; width: 100%; }
    :where(.ia-lsm-fb-select) .input-select__options { background: #2f3854; border-radius: 6px; padding: 4px; box-shadow: 0 10px 25px rgba(0,0,0,.35); max-height: 260px; overflow-y: auto; }
    :where(.ia-lsm-fb-select) .input-select__option { display: flex; align-items: center; gap: 10px; padding: 7px 10px; border-radius: 5px; font-size: 13px; cursor: pointer; }
    :where(.ia-lsm-fb-select) .input-select__option:hover { background: rgba(255,255,255,.06); }
    :where(.ia-lsm-fb-select) .input-select__option--selected { color: #3b82f6; background: rgba(255,255,255,.08); }
    :where(.ia-lsm-fb-select) .input-select__option__text__subtitle { font-size: 11.5px; opacity: .6; }
    :where(.ia-lsm-fb-select) .input-select__options__no-results { padding: 8px 10px; font-size: 12.5px; opacity: .7; }
    :where(.ia-lsm-fb-field) .input-field__input { width: 100%; box-sizing: border-box; padding: 8px 12px; border: 1px solid rgba(148,163,184,.25); border-radius: 6px; background: #1f2638; color: inherit; font: inherit; font-size: 13px; resize: vertical; outline: none; }
    :where(.ia-lsm-fb-upload) .upload-area__label { display: block; border: 1.5px dashed rgba(148,163,184,.4); border-radius: 8px; padding: 14px; cursor: pointer; }
    :where(.ia-lsm-fb-upload) .upload-area__info { display: flex; align-items: center; justify-content: center; flex-direction: row-reverse; gap: 14px; }
    :where(.ia-lsm-fb-upload) .upload-area__title { font-size: 17px; font-weight: 600; opacity: .8; }
    :where(.ia-lsm-fb-upload) .upload-area__max-size { font-size: 11px; opacity: .6; }
    :where(.ia-lsm-fb-upload) .upload-area__icon { width: 40px; height: 47px; }
    :where(.ia-lsm-fb-upload) .upload-area__input { display: none; }
    :where(.ia-lsm-fb-list) .upload-list__file { display: flex; align-items: center; gap: 12px; padding: 4px 0; }
    :where(.ia-lsm-fb-list) .upload-list__file__icon__image { width: 28px; height: 28px; display: block; }
    :where(.ia-lsm-fb-list) .upload-list__file__info { flex: 1; min-width: 0; }
    :where(.ia-lsm-fb-list) .upload-list__file__title { display: flex; font-weight: 600; font-size: 13px; }
    :where(.ia-lsm-fb-list) .upload-list__file__name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    :where(.ia-lsm-fb-list) .upload-list__file__data { font-size: 11.5px; }
    :where(.ia-lsm-fb-list) .upload-list__file__action button { border: 0; background: transparent; color: inherit; cursor: pointer; }
    :where(.ia-lsm-fb-modal) .button { border: 1px solid rgba(148,163,184,.3); border-radius: 6px; padding: 7px 16px; background: #fff; color: #111827; font: 500 13px system-ui, sans-serif; cursor: pointer; }
    :where(.ia-lsm-fb-modal) .button.--primary { background: #2563eb; border-color: #2563eb; color: #fff; }
    :where(.ia-lsm-fb-modal) .button:disabled { opacity: .55; cursor: not-allowed; }
    :where(.ia-lsm-fb-notice) .ia-lsm-info { background: #ecfeff; border-color: #a5f3fc; color: #155e75; }
    :where(.ia-lsm-fb-notice) .ia-lsm-warn { background: #fefce8; border-color: #f59e0b; color: #78350f; }
    :where(.ia-lsm-fb-card) .ia-lsm-card { border: 1px solid rgba(148,163,184,.3); border-radius: 6px; padding: 12px 2px; }
    :where(.ia-lsm-fb-card) .ia-lsm-card ._item { padding: 0 12px; }
    :where(.ia-lsm-fb-card) .ia-lsm-card ._title { font-size: 10px; text-transform: uppercase; letter-spacing: .04em; opacity: .6; }
    :where(.ia-lsm-fb-card) .ia-lsm-card ._value { font-size: 12.5px; font-weight: 600; }
    :where(.ia-lsm-fb-modal) hr { border: 0; border-top: 1px solid rgba(148,163,184,.2); margin: 16px 0; }
    :where(.ia-lsm-fb-util) .grid { display: grid; }
    :where(.ia-lsm-fb-util) .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    :where(.ia-lsm-fb-util) .col-span-2 { grid-column: span 2 / span 2; }
    :where(.ia-lsm-fb-util) .gap-4 { gap: 1rem; }
    :where(.ia-lsm-fb-util) .flex { display: flex; }
    :where(.ia-lsm-fb-util) .flex-col { flex-direction: column; }
    :where(.ia-lsm-fb-util) .p-4 { padding: 1rem; }
  `);
})();

// ====================================================================
// Disclaimers & Scripts page (opened by the Disclaimers chip in a lead)
// ====================================================================
const IA_DISC_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Disclaimers & Scripts - TBC</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<style>
  :root{--bg:#0b111e;--card:#151e2d;--line:#2a364a;--ink:#f8fafc;--mid:#94a3b8;
        --grad:linear-gradient(135deg,#0ea5e9 0%,#0369a1 100%);--code:#38bdf8;}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Inter',-apple-system,sans-serif;background:var(--bg);color:var(--ink);
       padding:30px 20px;line-height:1.5;-webkit-font-smoothing:antialiased}
  .wrap{max-width:820px;margin:0 auto;display:flex;flex-direction:column;gap:16px}
  .header{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px 22px;
          display:flex;justify-content:space-between;align-items:center;gap:12px}
  .brand{display:flex;align-items:center;gap:12px}
  .logo{background:var(--grad);color:#fff;font-weight:800;font-size:22px;padding:4px 12px;
        border-radius:8px;letter-spacing:-1px}
  h1{font-size:17px;font-weight:800}
  .sub{font-size:11px;font-weight:600;color:var(--mid);text-transform:uppercase;letter-spacing:1px}
  .panel{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px}
  .tabs { display: flex; gap: 8px; margin-bottom: 16px; border-bottom: 1px solid var(--line); padding-bottom: 12px; overflow-x: auto; }
  .tabs::-webkit-scrollbar { display: none; }
  .tab-btn { background: transparent; border: none; color: var(--mid); font-size: 13px; font-weight: 700; cursor: pointer; padding: 8px 16px; border-radius: 8px; transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1); white-space: nowrap; }
  .tab-btn:hover { background: rgba(255,255,255,0.05); color: var(--ink); }
  .tab-btn.active { background: var(--grad); color: #fff; box-shadow: 0 4px 15px rgba(14,165,233,0.3); }
  .tab-content { display: none; flex-direction: column; gap: 16px; animation: fadein 0.3s ease; }
  .tab-content.active { display: flex; }
  @keyframes fadein { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
  .block-title { font-size: 11.5px; font-weight: 800; color: #7dd3fc; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; display: block; }
  .copy-block {
    background: #090e17; border: 1px solid var(--line); border-radius: 12px; padding: 16px 18px;
    font-size: 13px; color: var(--code); white-space: pre-wrap; line-height: 1.6;
    cursor: pointer; transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1); position: relative;
  }
  .copy-block:hover { border-color: var(--code); background: #0c1424; transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.4); }
  .copy-block::after {
    content: 'Click to copy'; position: absolute; top: 12px; right: 14px; font-size: 10px; font-weight: 700;
    color: rgba(56, 189, 248, 0.5); text-transform: uppercase; letter-spacing: 0.5px; transition: 0.2s;
  }
  .copy-block:hover::after { color: rgba(56, 189, 248, 1); }
  .toast{position:fixed;bottom:20px;right:20px;background:var(--grad);color:#fff;padding:10px 20px;
         border-radius:99px;font-size:12.5px;font-weight:700;opacity:0;pointer-events:none;
         transition:opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
         transform:translateY(20px); box-shadow: 0 10px 30px rgba(14,165,233,0.4);}
  .toast.show{opacity:1;transform:translateY(0);}

/* Fill in for this lead (TBC Assistant) */
.ia-fill{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px 12px;margin:0 0 18px;padding:14px 16px;border-radius:16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08)}
.ia-fill h3{grid-column:1/-1;margin:0;font:800 12px/1.2 Inter,system-ui,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#7dd3fc}
.ia-fill label{display:grid;gap:4px;font:700 11px Inter,system-ui,sans-serif;color:#94a3b8;min-width:0}
.ia-fill input{width:100%;box-sizing:border-box;padding:8px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(15,23,42,.65);color:#e2e8f0;font:600 13px Inter,system-ui,sans-serif;outline:none}
.ia-fill input:focus{border-color:#38bdf8}
.ia-fill .hint{grid-column:1/-1;font:600 11px Inter,system-ui,sans-serif;color:#64748b}
.copy-block mark{background:rgba(56,189,248,.18);color:inherit;border-radius:4px;padding:0 2px}
@media (max-width:640px){.ia-fill{grid-template-columns:1fr 1fr}}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div class="brand">
      <div class="logo">tbc</div>
      <div><h1>Disclaimers & Scripts</h1><div class="sub">1-Click Copy Templates</div></div>
    </div>
  </div>
  <div class="ia-fill">
    <h3>Fill in for this lead</h3>
    <label>Client name<input id="f-client" placeholder="Customer"></label>
    <label>Your direct number<input id="f-phone" placeholder="xxxxxxxxxxxx"></label>
    <label>Taxes amount ($)<input id="f-tax" placeholder=".........."></label>
    <label>Award program / airline<input id="f-airline" placeholder="e.g. Air Canada"></label>
    <label>Fake return from<input id="f-retfrom" placeholder="XXX"></label>
    <label>Fake return date<input id="f-retdate" placeholder="e.g. 12 of December"></label>
    <div class="hint">The texts below update as you type. Empty boxes keep the original wording. Your number is remembered.</div>
  </div>
  <div class="panel">
    <div class="tabs">
      <button class="tab-btn active" onclick="openTab(event, 'discounts')">Discounts</button>
      <button class="tab-btn" onclick="openTab(event, 'abt')">ABT Award</button>
      <button class="tab-btn" onclick="openTab(event, 'revenue')">Revenue ELR / FRT</button>
    </div>
    <!-- DISCOUNTS TAB -->
    <div id="discounts" class="tab-content active">
      <div>
        <span class="block-title">For UA, DL and AA bookings:</span>
        <div class="copy-block" onclick="copyText(this)">This ticket is issued under special fare conditions and does not include a 24-hour void or refund option.
The ticket is non-refundable under all circumstances, including flight disruptions or cancellations.
If unused, the ticket may be canceled for future credit only, subject to airline rules, penalties, and any fare difference at the time of rebooking.
By confirming your booking, you agree to these conditions.</div>
      </div>
      <div>
        <span class="block-title">For other airlines:</span>
        <div class="copy-block" onclick="copyText(this)">This ticket is issued under special fare conditions and does not include a 24-hour void, exchange, nor refund option.
The ticket is non-refundable under all circumstances, including flight disruptions or cancellations.
By confirming your booking, you agree to these conditions.</div>
      </div>
    </div>
    <!-- ABT AWARD TAB -->
    <div id="abt" class="tab-content">
      <div>
        <span class="block-title">Award Ticket [Only over the phone]</span>
        <div class="copy-block" onclick="copyText(this)">Dear Customer,
Thank you for booking with airbusinesstravel.com
I would like to mention the following very important points.
For any changes or cancelations or any other requests please call me directly at xxxxxxxxxxxx.
These are non-fare tickets issued with corporate points, coupons and vouchers.
This means that you will not be able to collect miles or benefit from other bonuses, promos or discounts provided by the airlines themselves.
Please do not link any personal information to the booking such as telephone or email. The booking is linked to our email and we will update you on any changes. An attempt to link any personal frequent flyer information, email, or phone number to the tickets may result in technical discrepancies that may cause the tickets to be suspended.</div>
      </div>
      <div>
        <span class="block-title">Taxes charged from pax CC</span>
        <div class="copy-block" onclick="copyText(this)">====================== In case Award Ticketing advised that taxes are to be charged from pax CC =====================
The taxes for your ticket in the amount of $.......... will be charged separately by the airline. These separate charges, which are a part of the total price, will be reflected on your bank statement separately. Please note, that any dispute or chargebacks of the following fees will be treated as a violation of the general conditions of carriage or tariffs and may result in cancellation of the ticket.
!!! Make sure you mention the Award Program/Airline for the tax charge, eg. Air Canada, British Airways, Delta etc.</div>
      </div>
    </div>
    <!-- REVENUE ELR/FRT TAB -->
    <div id="revenue" class="tab-content">
      <div>
        <span class="block-title">Extra Leg [Only over the phone]</span>
        <div class="copy-block" onclick="copyText(this)">Dear Customer,
Once the ticket is issued and you will access your booking on the airline website I would like you to check this itinerary carefully; you have an additional segment on top of your flight. This is what we do when we try to get a better fare for you. This is how the system works: it has particular prices for specific destinations. In this case, your destination is more expensive than the destination we added. We also made the layover for more than 10-15 hours in order to give you enough time to collect your bags and take them with you from the airport, so they will not go to the final city/destination added by us.</div>
      </div>
      <div>
        <span class="block-title">Fake Return [Only over the phone]</span>
        <div class="copy-block" onclick="copyText(this)">Dear Customer,
Once the ticket is issued and you will access your booking on the airline website I would like you to check this itinerary carefully. You have an additional segment back from XXX on the XX of XXXXX. We often book a return flight to get a better fare for you. The airlines offer better bulk contracts for round-trips than one-way tickets. Therefore, you should be informed that you have that flight included in your itinerary, to avoid any confusion at the airport. It is up to you if you would like to use that flight, but please inform us if you would like to use it, since we usually cancel that segment prior to departure to avoid a no-show status on it.</div>
      </div>
    </div>
  </div>
</div>
<div class="toast" id="toast">Copied to clipboard!</div>
<script>
function openTab(evt, tabId) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tab-content");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
    tabcontent[i].classList.remove("active");
  }
  tablinks = document.getElementsByClassName("tab-btn");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabId).style.display = "flex";
  document.getElementById(tabId).classList.add("active");
  evt.currentTarget.className += " active";
}
function copyText(el) {
  var text = el.innerText;
  var marker = "Click to copy";
  if (text.endsWith(marker)) {
    text = text.slice(0, -marker.length).trim();
  }
  navigator.clipboard.writeText(text).then(function() {
    var toast = document.getElementById('toast');
    toast.classList.add('show');
    setTimeout(function() { toast.classList.remove('show'); }, 2000);
  });
}

/* Fill in for this lead (TBC Assistant) */
(function(){
  var L = window.IA_LEAD || {};
  var $ = function(id){ return document.getElementById(id); };
  var esc = function(s){ return String(s).replace(/[&<>]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c]; }); };
  var blocks = Array.prototype.slice.call(document.querySelectorAll('.copy-block'));
  blocks.forEach(function(b){ b.setAttribute('data-orig', b.innerHTML); });
  try { $('f-phone').value = localStorage.getItem('ia-disc-phone') || ''; } catch (e) {}
  if (L.client) $('f-client').value = L.client;
  if (L.dest) $('f-retfrom').value = L.dest;
  function v(id){ return $(id).value.trim(); }
  function render(){
    var client = v('f-client'), phone = v('f-phone'), tax = v('f-tax'), airline = v('f-airline'), from = v('f-retfrom'), date = v('f-retdate');
    var m = function(s){ return '<mark>' + esc(s) + '</mark>'; };
    blocks.forEach(function(b){
      var h = b.getAttribute('data-orig');
      if (client) h = h.replace('Dear Customer,', 'Dear ' + m(client) + ',');
      if (phone) h = h.replace('xxxxxxxxxxxx', m(phone));
      if (tax) h = h.replace('$..........', m('$' + tax.replace(/^\\$/, '')));
      if (airline) {
        h = h.replace('will be charged separately by the airline.', 'will be charged separately by ' + m(airline) + '.');
        h = h.replace(/\\n?!!! Make sure you mention the Award Program\\/Airline[^\\n]*/, '');
      }
      if (from || date) h = h.replace('from XXX on the XX of XXXXX', 'from ' + (from ? m(from) : 'XXX') + ' on the ' + (date ? m(date) : 'XX of XXXXX'));
      b.innerHTML = h;
    });
    try { localStorage.setItem('ia-disc-phone', phone); } catch (e) {}
  }
  ['f-client','f-phone','f-tax','f-airline','f-retfrom','f-retdate'].forEach(function(id){ $(id).addEventListener('input', render); });
  render();
})();
<\/script>
</body>
</html>`;

// ====================================================================
// Lead tool pages: VIP Itinerary Maker, GK Converter, PNR guide
// (opened by the chips next to Disclaimers inside a lead)
// ====================================================================

const IA_VIP_HTML_BASE = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TBC VIP Itinerary Maker</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"><\/script>
<style>
  :root{
    --bg:#f3f4f6; --card:#ffffff; --soft:#f9fafb;
    --ink:#111827; --mid:#6b7280; --soft-ink:#9ca3af;
    --line:#e5e7eb; --rule:#d1d5db;
    --plum:#8c1238; --plum-soft:rgba(140,18,56,.07);
    --grad:linear-gradient(135deg,#a31649 0%,#750f2e 100%);
    --ok:#059669; --chip:#1f2937; --shadow:0 1px 2px rgba(17,24,39,.06),0 6px 16px rgba(17,24,39,.07);
  }
  body.dark{
    --bg:#0b111e; --card:#151e2d; --soft:#101827;
    --ink:#f8fafc; --mid:#94a3b8; --soft-ink:#64748b;
    --line:#2a364a; --rule:#334155;
    --plum:#e8447a; --plum-soft:rgba(212,31,88,.13);
    --grad:linear-gradient(135deg,#e32965 0%,#9e143d 100%);
    --ok:#34d399; --chip:#0d1524; --shadow:0 1px 2px rgba(0,0,0,.4),0 8px 20px rgba(0,0,0,.35);
  }
  *{box-sizing:border-box}
  body{font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:var(--bg);
       color:var(--ink);margin:0;padding:20px;-webkit-font-smoothing:antialiased}
  .wrap{max-width:820px;margin:0 auto;display:flex;flex-direction:column;gap:14px}
  .top{display:flex;justify-content:space-between;align-items:center}
  .top h1{margin:0;font-size:17px;font-weight:800;letter-spacing:-.4px;color:var(--plum)}
  .ghost{background:var(--card);color:var(--ink);border:1px solid var(--line);padding:6px 14px;
       border-radius:20px;cursor:pointer;font-weight:600;font-size:12px;font-family:inherit}
  .panel{background:var(--card);padding:16px;border-radius:12px;border:1px solid var(--line)}
  .row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px}
  input[type=text],textarea{width:100%;font-family:inherit;padding:9px 11px;border:1px solid var(--line);
       border-radius:8px;background:var(--card);color:var(--ink);font-size:13px}
  textarea{height:110px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;resize:vertical}
  input:focus,textarea:focus{outline:none;border-color:var(--plum)}
  .hint{font-size:11px;color:var(--soft-ink);margin-top:7px}
  .btns{display:flex;gap:8px;flex-wrap:wrap;margin-top:11px;align-items:center}
  button.go{background:var(--grad);color:#fff;border:none;padding:9px 17px;font-size:13px;cursor:pointer;
       border-radius:7px;font-weight:600;font-family:inherit}
  button.go:hover{filter:brightness(1.12)}
  .act{display:none;gap:8px}
  .doc{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px 24px;display:none}
  .brand{display:flex;justify-content:space-between;align-items:flex-end;gap:14px;
       border-bottom:2px solid var(--plum);padding-bottom:11px;margin-bottom:16px}
  .brand-l{display:flex;align-items:center;gap:10px}
  .mark{background:var(--grad);color:#fff;font-weight:800;font-size:21px;letter-spacing:-1.2px;
       padding:3px 10px;border-radius:7px;line-height:1.15}
  .co{font-size:14px;font-weight:700;letter-spacing:-.2px}
  .co-sub{font-size:9px;font-weight:600;color:var(--soft-ink);letter-spacing:1.2px;text-transform:uppercase}
  .who{text-align:right}
  .who-name{font-size:14.5px;font-weight:700;color:var(--plum);line-height:1.2}
  .who-ref{font-size:10px;color:var(--mid);font-weight:600;margin-top:2px;letter-spacing:.5px;text-transform:uppercase}
  .jrn{margin-bottom:18px}
  .jrn:last-of-type{margin-bottom:6px}
  .jrn-head{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:9px}
  .jrn-l{display:flex;align-items:baseline;gap:10px;min-width:0}
  .jrn-tag{font-size:9px;font-weight:800;letter-spacing:1.8px;text-transform:uppercase;color:var(--plum);white-space:nowrap}
  .jrn-route{font-size:13.5px;font-weight:700;letter-spacing:-.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .jrn-meta{font-size:11px;font-weight:600;color:var(--mid);white-space:nowrap}
  .card{border:1px solid var(--line);border-radius:11px;background:var(--card);padding:10px 15px 11px;
       box-shadow:var(--shadow)}
  .card-top{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;
       padding-bottom:7px;margin-bottom:9px;border-bottom:1px solid var(--line)}
  .f-l{display:flex;align-items:center;gap:8px;min-width:0;flex-wrap:wrap}
  .f-r{display:flex;align-items:center;gap:7px;flex:none}
  .f-no{font-size:11.5px;font-weight:700;white-space:nowrap}
  .dot-sep{color:var(--rule);font-size:9px}
  .leg{display:grid;grid-template-columns:1fr minmax(150px,1.15fr) 1fr;align-items:center;gap:12px}
  .end{min-width:0}
  .end.r{text-align:right}
  .t{font-size:19px;font-weight:700;letter-spacing:-.6px;line-height:1.05}
  .t sup{font-size:10px;font-weight:800;color:var(--plum);margin-left:2px;top:-.6em}
  .code{font-size:12.5px;font-weight:800;color:var(--plum);margin-top:3px;letter-spacing:.3px}
  .city{font-size:11px;color:var(--mid);font-weight:500;line-height:1.35;white-space:nowrap;
       overflow:hidden;text-overflow:ellipsis}
  .day{font-size:10px;color:var(--soft-ink);font-weight:500;margin-top:2px;display:flex;align-items:baseline;gap:3px}
  .end.r .day{justify-content:flex-end}
  .mid-col{display:flex;flex-direction:column;align-items:center;gap:1px}
  .dur{font-size:10.5px;font-weight:700;color:var(--mid);white-space:nowrap}
  .path{display:flex;align-items:center;gap:5px;width:100%}
  .path i{height:1px;flex:1;background:var(--rule)}
  .path b{width:5px;height:5px;border-radius:50%;background:var(--plum);flex:none}
  .plane{color:var(--plum);font-size:12px;line-height:1;flex:none}
  .nonstop{font-size:9px;color:var(--soft-ink);letter-spacing:1px;text-transform:uppercase;font-weight:600}
  .conn{display:flex;align-items:center;gap:9px;padding:0;margin:0}
  .conn i{height:16px;width:1px;background:var(--rule);margin-left:26px;flex:none}
  .conn-txt{font-size:10.5px;font-weight:600;color:var(--mid);padding:6px 0}
  .conn-row{display:flex;align-items:center;gap:9px}
  .warn{font-size:10px;font-weight:600;color:#b45309;background:#fffbeb;border:1px solid #fde68a;
       border-radius:5px;padding:1px 7px}
  body.dark .warn{color:#fbbf24;background:#39290a;border-color:#7c5a12}
  .split{background:transparent;border:1px solid var(--line);color:var(--soft-ink);font-size:9px;
       padding:1px 6px;border-radius:5px;font-weight:600;cursor:pointer;font-family:inherit}
  .split:hover{border-color:var(--plum);color:var(--plum)}
  .jrn-foot{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px;
       padding-top:7px;border-top:1px solid var(--line)}
  input.e{background:transparent;border:1px dashed transparent;color:var(--mid);font-family:inherit;
       font-size:11px;font-weight:500;padding:1px 4px;border-radius:4px;width:auto;text-overflow:ellipsis}
  input.e.term{width:152px}
  input.e.term.r{text-align:right}
  input.e.eqp{width:160px}
  input.e.note{flex:1 1 190px;min-width:120px}
  input.e:hover,input.e:focus{border-color:var(--line);background:var(--soft);color:var(--ink);outline:none}
  select.s{background:transparent;border:1px solid transparent;font-family:inherit;font-size:10.5px;
       font-weight:700;color:var(--ink);cursor:pointer;padding:4px 8px;border-radius:5px;
       appearance:none;-webkit-appearance:none;display:inline-flex;align-items:center;justify-content:center;
       text-align:center;text-align-last:center;height:26px;box-sizing:border-box;}
  select.s:hover{background:var(--soft);border-color:var(--line)}
  select.s:focus{outline:none;border-color:var(--plum)}
  select.s option{background:var(--chip);color:#fff}
  select.cabin{color:#fff;background:var(--grad);border:none;border-radius:20px;
       padding:0 14px;font-size:10px;font-weight:800;letter-spacing:.6px;
       text-transform:uppercase;line-height:26px;display:inline-flex;align-items:center;justify-content:center;
       text-align:center;text-align-last:center;height:26px;}
  select.cabin:hover{background:var(--grad);filter:brightness(1.1)}
  select.bag{color:var(--mid);background:var(--soft);border:1px solid var(--line);border-radius:20px;
       padding:0 12px;font-size:10.5px;font-weight:600;line-height:26px;display:inline-flex;align-items:center;justify-content:center;
       text-align:center;text-align-last:center;height:26px;}
  select.bag:hover{background:var(--soft);border-color:var(--plum);color:var(--ink)}
  select.status{color:var(--ok)}
  .fine{margin-top:14px;padding-top:9px;border-top:1px solid var(--line);display:flex;
       justify-content:space-between;gap:10px;font-size:9.5px;color:var(--soft-ink);font-weight:500}
  .is-exporting .split{display:none!important}
  .is-exporting select.s{pointer-events:none}
  .is-exporting select.s:not(.cabin):not(.bag){border-color:transparent!important;background:transparent!important}
  .mode-row{display:flex;gap:10px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
  .mode-row select{width:auto;min-width:210px}
  .tk{border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-bottom:10px;background:var(--soft)}
  .tk-head{display:flex;align-items:center;gap:8px;margin-bottom:7px}
  .tk-name{font-size:11px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;color:var(--plum)}
  .tk-head input{flex:0 0 200px;padding:6px 9px;font-size:12px}
  .tk-del{margin-left:auto;background:transparent;border:1px solid var(--line);color:var(--soft-ink);
          font-size:11px;padding:3px 9px;border-radius:6px;cursor:pointer;font-family:inherit}
  .tk-del:hover{border-color:#ef4444;color:#ef4444}
  .add-tk{background:transparent;border:1px dashed var(--rule);color:var(--mid);padding:7px 14px;
          border-radius:8px;cursor:pointer;font-weight:600;font-size:12px;font-family:inherit}
  .add-tk:hover{border-color:var(--plum);color:var(--plum)}
  .tk-bar{display:flex;align-items:center;gap:8px;margin:14px 0 6px;flex-wrap:wrap}
  .tk-bar .lbl{font-size:11px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;color:var(--plum)}
  .tk-bar button{background:var(--card);border:1px solid var(--line);color:var(--ink);font-size:11px;
                 padding:4px 10px;border-radius:14px;cursor:pointer;font-family:inherit;font-weight:600}
  .tk-bar button:hover{border-color:var(--plum);color:var(--plum)}
  .mail-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap}
  .mail-head h2{font-size:14px;font-weight:800;margin:0;color:var(--plum)}
  .mail-actions{display:flex;gap:8px;flex-wrap:wrap}
  #mailBody{border:1px solid var(--line);border-radius:10px;padding:16px 18px;background:#fff;color:#111;
            max-height:520px;overflow:auto;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.5}
  #mailBody:focus{outline:none;border-color:var(--plum)}
  #mailBody img{max-width:100%;height:auto;border:1px solid #ddd;border-radius:6px}
  .mail-hint{font-size:11px;color:var(--soft-ink);margin-top:8px}
  .busy{opacity:.55;pointer-events:none}
  .top-l{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
  .brandtabs{display:inline-flex;gap:4px;background:var(--soft);border:1px solid var(--line);
       border-radius:999px;padding:3px}
  .brandtabs button{border:none;background:transparent;color:var(--mid);font-family:inherit;
       font-size:12px;font-weight:800;letter-spacing:.6px;padding:6px 18px;border-radius:999px;
       cursor:pointer;transition:.15s}
  .brandtabs button:hover{color:var(--ink)}
  .brandtabs button.on{background:var(--grad);color:#fff}
</style>
</head>
<body>
<div class="wrap">
  <div class="top">
    <div class="top-l">
      <h1 id="brandTitle">TBC VIP Itinerary Maker</h1>
      <div class="brandtabs">
        <button id="bt-tbc" class="on" onclick="setBrand('tbc')">TBC</button>
        <button id="bt-abt" onclick="setBrand('abt')">ABT</button>
      </div>
    </div>
    <button class="ghost" onclick="toggleDark()">Dark mode</button>
  </div>
  <div class="panel">
    <div class="row2">
      <input type="text" id="pax" placeholder="Passenger name (e.g. Mr. John Doe)">
      <input type="text" id="pnr" placeholder="PNR / record locator (e.g. ABC123)">
    </div>
    <div class="mode-row">
      <label class="hint" style="margin:0">Disclaimer type</label>
      <select id="mode" onchange="onModeChange()">
        <option value="mixed">Mixed cabin - one ticket</option>
        <option value="separate">Separate tickets</option>
      </select>
      <button class="add-tk" id="addTk" style="display:none" onclick="addTicket()">+ Add ticket</button>
    </div>
    <div id="tickets"></div>
    <div class="hint">Reads VI*, *I and *IA. Codeshare stars, terminals, aircraft, cabins and "operated by" are detected automatically.</div>
    <div class="btns">
      <button class="go" onclick="regenerate()">Generate itinerary</button>
      <div id="act" class="act">
        <button class="ghost" onclick="buildEmail()">Build disclaimer email</button>
      </div>
    </div>
  </div>
  <div id="docs"></div>
  <div class="panel" id="mailPanel" style="display:none">
    <div class="mail-head">
      <h2>Disclaimer email</h2>
      <div class="mail-actions">
        <button class="go" onclick="copyEmail()">Copy email + screenshots</button>
        <button class="ghost" onclick="buildEmail()">Rebuild</button>
      </div>
    </div>
    <div id="mailBody" contenteditable="true"></div>
    <div class="mail-hint">Edit anything above, then Copy and paste straight into a Gmail compose window - the screenshots travel with the text. Baggage lines and the cabin sentence come from the dropdowns on each flight card, so set those first and hit Rebuild.</div>
  </div>
</div>
<script>
var MONTHS = { JAN:0, FEB:1, MAR:2, APR:3, MAY:4, JUN:5,
               JUL:6, AUG:7, SEP:8, OCT:9, NOV:10, DEC:11 };
var AIRLINES = {
  AA:'American Airlines', AC:'Air Canada', AF:'Air France', AI:'Air India', AM:'Aeromexico',
  AR:'Aerolineas Argentinas', AS:'Alaska Airlines', AT:'Royal Air Maroc', AV:'Avianca', AY:'Finnair',
  AZ:'ITA Airways', A3:'Aegean Airlines', BA:'British Airways', BR:'EVA Air', B6:'JetBlue',
  CI:'China Airlines', CM:'Copa Airlines', CX:'Cathay Pacific', CZ:'China Southern', DL:'Delta Air Lines',
  EI:'Aer Lingus', EK:'Emirates', ET:'Ethiopian Airlines', EY:'Etihad Airways', FI:'Icelandair',
  F9:'Frontier Airlines', GA:'Garuda Indonesia', GF:'Gulf Air', HA:'Hawaiian Airlines', IB:'Iberia',
  JL:'Japan Airlines', KE:'Korean Air', KL:'KLM', KQ:'Kenya Airways', LA:'LATAM Airlines',
  LH:'Lufthansa', LO:'LOT Polish Airlines', LX:'Swiss', MS:'EgyptAir', MU:'China Eastern',
  NH:'ANA', NK:'Spirit Airlines', NZ:'Air New Zealand', OS:'Austrian Airlines', OZ:'Asiana Airlines',
  PR:'Philippine Airlines', PS:'Ukraine International', QF:'Qantas', QR:'Qatar Airways',
  RJ:'Royal Jordanian', SA:'South African Airways', SK:'SAS', SN:'Brussels Airlines',
  SQ:'Singapore Airlines', SU:'Aeroflot', SV:'Saudia', TG:'Thai Airways', TK:'Turkish Airlines',
  TP:'TAP Air Portugal', UA:'United Airlines', UX:'Air Europa', VA:'Virgin Australia',
  VN:'Vietnam Airlines', VS:'Virgin Atlantic', WN:'Southwest Airlines', WS:'WestJet', WY:'Oman Air'
};
var AIRPORTS = {
  AMS:'Amsterdam', ARN:'Stockholm', ATH:'Athens', ATL:'Atlanta', AUH:'Abu Dhabi', AUS:'Austin',
  BCN:'Barcelona', BER:'Berlin', BKK:'Bangkok', BNE:'Brisbane', BOG:'Bogota', BOM:'Mumbai',
  BOS:'Boston', BRU:'Brussels', BUD:'Budapest', BWI:'Baltimore', CAI:'Cairo', CDG:'Paris Charles de Gaulle',
  CLT:'Charlotte', CMN:'Casablanca', CPH:'Copenhagen', CPT:'Cape Town', CRW:'Charleston', CUN:'Cancun',
  DEL:'Delhi', DEN:'Denver', DFW:'Dallas Fort Worth', DOH:'Doha', DUB:'Dublin', DUS:'Dusseldorf',
  DXB:'Dubai', EWR:'Newark', EZE:'Buenos Aires', FCO:'Rome Fiumicino', FLL:'Fort Lauderdale',
  FRA:'Frankfurt', GIG:'Rio de Janeiro', GRU:'Sao Paulo', GVA:'Geneva', HAM:'Hamburg', HEL:'Helsinki',
  HKG:'Hong Kong', HND:'Tokyo Haneda', HNL:'Honolulu', IAD:'Washington Dulles', IAH:'Houston',
  ICN:'Seoul Incheon', IST:'Istanbul', JED:'Jeddah', JFK:'New York JFK', JNB:'Johannesburg',
  KEF:'Reykjavik', KUL:'Kuala Lumpur', LAS:'Las Vegas', LAX:'Los Angeles', LGA:'New York LaGuardia',
  LGW:'London Gatwick', LHR:'London Heathrow', LIM:'Lima', LIS:'Lisbon', MAD:'Madrid', MAN:'Manchester',
  MCO:'Orlando', MEL:'Melbourne', MEX:'Mexico City', MIA:'Miami', MLE:'Male', MNL:'Manila',
  MSP:'Minneapolis', MUC:'Munich', MXP:'Milan Malpensa', NBO:'Nairobi', NCE:'Nice', NRT:'Tokyo Narita',
  ORD:"Chicago O'Hare", ORY:'Paris Orly', OSL:'Oslo', PDX:'Portland', PEK:'Beijing', PHL:'Philadelphia',
  PHX:'Phoenix', PMI:'Palma de Mallorca', PRG:'Prague', PTY:'Panama City', PVG:'Shanghai Pudong',
  RUH:'Riyadh', SAN:'San Diego', SCL:'Santiago', SEA:'Seattle', SFO:'San Francisco',
  SGN:'Ho Chi Minh City', SIN:'Singapore', SJU:'San Juan', SLC:'Salt Lake City', STR:'Stuttgart',
  SVO:'Moscow', SYD:'Sydney', TLV:'Tel Aviv', TPE:'Taipei', VCE:'Venice', VIE:'Vienna', WAW:'Warsaw',
  YOW:'Ottawa', YUL:'Montreal', YVR:'Vancouver', YYC:'Calgary', YYZ:'Toronto', ZRH:'Zurich'
};
var EQP = {
  '221':'Airbus A220-100','223':'Airbus A220-300','CS1':'Airbus A220-100','CS3':'Airbus A220-300',
  '318':'Airbus A318','319':'Airbus A319','31N':'Airbus A319neo',
  '320':'Airbus A320','32A':'Airbus A320','32N':'Airbus A320neo',
  '321':'Airbus A321','32B':'Airbus A321','32Q':'Airbus A321neo','32X':'Airbus A321XLR',
  '330':'Airbus A330','332':'Airbus A330-200','333':'Airbus A330-300','338':'Airbus A330-800neo','339':'Airbus A330-900neo',
  '340':'Airbus A340','342':'Airbus A340-200','343':'Airbus A340-300','345':'Airbus A340-500','346':'Airbus A340-600',
  '350':'Airbus A350','359':'Airbus A350-900','351':'Airbus A350-1000','35K':'Airbus A350-1000',
  '380':'Airbus A380','388':'Airbus A380-800',
  '717':'Boeing 717','727':'Boeing 727',
  '733':'Boeing 737-300','734':'Boeing 737-400','735':'Boeing 737-500',
  '736':'Boeing 737-600','73G':'Boeing 737-700','737':'Boeing 737-700','73W':'Boeing 737-700',
  '738':'Boeing 737-800','73H':'Boeing 737-800','739':'Boeing 737-900','73J':'Boeing 737-900ER','73ER':'Boeing 737-900ER',
  '7M7':'Boeing 737 MAX 7','7M8':'Boeing 737 MAX 8','7M9':'Boeing 737 MAX 9','7M1':'Boeing 737 MAX 10','7MJ':'Boeing 737 MAX 10',
  '744':'Boeing 747-400','747':'Boeing 747-400','74H':'Boeing 747-8','748':'Boeing 747-8',
  '757':'Boeing 757','752':'Boeing 757-200','753':'Boeing 757-300',
  '767':'Boeing 767','762':'Boeing 767-200','763':'Boeing 767-300','76W':'Boeing 767-300ER','764':'Boeing 767-400ER',
  '777':'Boeing 777','772':'Boeing 777-200','77L':'Boeing 777-200LR','773':'Boeing 777-300','77W':'Boeing 777-300ER','779':'Boeing 777-9',
  '787':'Boeing 787 Dreamliner','788':'Boeing 787-8','789':'Boeing 787-9','78J':'Boeing 787-10','781':'Boeing 787-10',
  'E70':'Embraer 170','E75':'Embraer 175','E7W':'Embraer 175','E90':'Embraer 190','E95':'Embraer 195',
  '290':'Embraer E190-E2','295':'Embraer E195-E2','E29':'Embraer E195-E2',
  'ER3':'Embraer ERJ-135','ER4':'Embraer ERJ-140','ERD':'Embraer ERJ-145','ERJ':'Embraer ERJ-145',
  'CR1':'Bombardier CRJ-100','CR2':'Bombardier CRJ-200','CR5':'Bombardier CRJ-550',
  'CR7':'Bombardier CRJ-700','CR9':'Bombardier CRJ-900','CRK':'Bombardier CRJ-1000',
  'AT4':'ATR 42','AT5':'ATR 42-500','AT7':'ATR 72','726':'ATR 72-600',
  'DH1':'De Havilland Dash 8-100','DH2':'De Havilland Dash 8-200','DH3':'De Havilland Dash 8-300','DH4':'De Havilland Dash 8 Q400','Q400':'De Havilland Dash 8 Q400'
};
var OPERATOR_FIX = {
  'SKYWEST':'SkyWest','GOJET':'GoJet','COMMUTEAIR':'CommuteAir','PSA':'PSA','MESA':'Mesa',
  'ENVOY':'Envoy','PIEDMONT':'Piedmont','ENDEAVOR':'Endeavor','REPUBLIC':'Republic','JAZZ':'Jazz',
  'BINTER':'Binter','SILVER':'Silver','LTD':'','CO':'','COMPANY':'','INC':'','AIRLINES':'Airlines'
};
function normalize(t){
  return String(t)
    .replace(/(\\d{1,4}[AP])[^\\dA-Za-z\\s-](\\d)/gi,'$1#$2')
    .replace(/([A-Z0-9]{2})\\s*\\*\\s*(\\d{1,4})(?=\\D|$)/gi,'$1 $2');
}
function titleCase(s){ return !s ? '' : s.toLowerCase().replace(/\\b\\w/g,function(c){ return c.toUpperCase(); }); }
function city(code){ return AIRPORTS[code] || code; }
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;'); }
function cabinFromClass(c){
  c = (c||'').toUpperCase();
  if (!c) return 'Economy';
  if ('FA'.indexOf(c) > -1) return 'First';
  if ('JCDIZ'.indexOf(c) > -1) return 'Business';
  if ('WEPS'.indexOf(c) > -1) return 'Premium Economy';
  return 'Economy';
}
function cabinName(s){
  var u = String(s||'').toUpperCase();
  if (/FIRST/.test(u)) return 'First';
  if (/BUSINESS/.test(u)) return 'Business';
  if (/PREMIUM/.test(u)) return 'Premium Economy';
  if (/ECONOMY|COACH/.test(u)) return 'Economy';
  return '';
}
function mkDate(dateStr, timeStr, year){
  var d = parseInt(dateStr.slice(0,2),10), m = MONTHS[dateStr.slice(2,5).toUpperCase()];
  var n = timeStr.slice(0,-1).replace(/\\D/g,'');
  while (n.length < 4) n = '0' + n;
  var h = parseInt(n.slice(0,2),10), mi = parseInt(n.slice(2,4),10);
  var pm = /P$/i.test(timeStr);
  if (pm && h !== 12) h += 12;
  if (!pm && h === 12) h = 0;
  return new Date(year, m, d, h, mi);
}
function fmtTime(dt){
  var h = dt.getHours(), m = dt.getMinutes(), ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12; if (h === 0) h = 12;
  return h + ':' + String(m).padStart(2,'0') + ' ' + ap;
}
function fmtDay(dt){ return ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][dt.getDay()] + ' ' + dt.getDate() + ' ' + ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][dt.getMonth()]; }
function fmtFullDay(dt){ return ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][dt.getDay()] + ' ' + dt.getDate() + ' ' + ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][dt.getMonth()] + ' ' + dt.getFullYear(); }
function fmtElapsed(s){
  if (!s) return '';
  var p = s.split('.');
  return parseInt(p[0],10) + 'h ' + String(parseInt(p[1]||0,10)).padStart(2,'0') + 'm';
}
function gap(a, b){
  var mins = Math.round((b - a) / 60000);
  if (mins < 0) return { text:'connection', hours:0, mins:0 };
  var h = Math.floor(mins/60), m = mins % 60;
  if (h >= 24) return { text: Math.floor(h/24) + 'd ' + (h%24) + 'h stopover', hours:h, mins:mins };
  return { text: h + 'h ' + String(m).padStart(2,'0') + 'm connection', hours:h, mins:mins };
}
function fixOperator(s){
  return s.split(' ').map(function(w){
    var k = w.toUpperCase().replace(/[.,]/g,'');
    if (OPERATOR_FIX.hasOwnProperty(k)) return OPERATOR_FIX[k];
    if (AIRLINES[k]) return AIRLINES[k];
    return titleCase(w);
  }).join(' ').replace(/\\s+/g,' ').trim();
}
var SEG_RE = /^\\s*\\d{1,2}\\s+([A-Z0-9]{2})\\s*(\\d{1,4})\\s*([A-Z])?\\s+(\\d{2}[A-Z]{3})\\s+(?:[A-Z]\\s+)?([A-Z]{3})\\s*([A-Z]{3})\\s*\\*?\\s*(?:[A-Z]{2}\\d{1,2})?\\s+(\\d{1,4}[AP])\\s+(\\d{1,4}[AP])(?:([^\\s\\dA-Za-z])?(\\d))?(?:\\s+(\\d{2}[A-Z]{3}))?/i;
var VI_TAIL = /\\d{1,2}\\.\\d{2}\\s+\\d{2,5}\\s+[A-Z]\\s*$/;
var VI_RE = /^\\s*\\d{1,2}\\s+([A-Z0-9]{2})\\s+(\\d{1,4})\\s+(\\d{2}[A-Z]{3})\\s+([A-Z]{3})\\s+([A-Z]{3})\\s+(\\d{1,4}[AP])\\S*\\s+(\\d{1,4}[AP])(\\S*)\\s+.*?([A-Z0-9]{3})\\s+(\\d{1,2}\\.\\d{2})\\s+\\d{2,5}\\s+[A-Z]\\s*$/i;
function dayShift(s){
  if (!s) return 0;
  var m = String(s).match(/(-)?(\\d)/);
  if (!m) return 0;
  return m[1] ? -parseInt(m[2],10) : parseInt(m[2],10);
}
function parse(raw){
  var lines = normalize(raw).split('\\n');
  var flights = [], vis = [], vi = null, last = null;
  lines.forEach(function(line){
    var t = line.trim();
    if (!t) return;
    if (VI_TAIL.test(t)){
      var m = t.match(VI_RE);
      if (m){
        vi = { cxr:m[1].toUpperCase(), flt:m[2], date:m[3].toUpperCase(),
               orig:m[4].toUpperCase(), dest:m[5].toUpperCase(),
               dep:m[6].toUpperCase(), arr:m[7].toUpperCase(), off:dayShift(m[8]),
               eqp:m[9].toUpperCase(), elapsed:m[10] };
        vis.push(vi);
      }
      last = null;
      return;
    }
    if (/(DEP|ARR)-/i.test(t)){
      var d = t.match(/DEP-\\s*([A-Z0-9 ]+?)(?=\\s{2,}|\\s*ARR-|\\s*$)/i);
      var a = t.match(/ARR-\\s*([A-Z0-9 ]+?)\\s*$/i);
      var target = vi || last;
      if (target){
        if (d) target.depTerm = titleCase(d[1].trim());
        if (a) target.arrTerm = titleCase(a[1].trim());
      }
      return;
    }
    if (/CABIN-/i.test(t)){
      var tgt = vi || last;
      if (tgt) tgt.cabin = cabinName(t.split(/CABIN-/i)[1]);
      return;
    }
    if (/OPERATED\\s+BY/i.test(t)) return;
    var g = t.match(SEG_RE);
    if (g){
      last = { cxr:g[1].toUpperCase(), no:g[2], cls:(g[3]||'').toUpperCase(), date:g[4].toUpperCase(),
               orig:g[5].toUpperCase(), dest:g[6].toUpperCase(), dep:g[7].toUpperCase(), arr:g[8].toUpperCase(),
               off: g[10] ? (g[9] === '-' ? -parseInt(g[10],10) : parseInt(g[10],10)) : 0,
               arrDate: g[11] ? g[11].toUpperCase() : null };
      flights.push(last); vi = null;
    }
  });
  if (!flights.length && vis.length){
    flights = vis.map(function(v){
      return { cxr:v.cxr, no:v.flt, cls:'', date:v.date, orig:v.orig, dest:v.dest, dep:v.dep, arr:v.arr, off:v.off, arrDate:null };
    });
  }
  var seen = {}, unique = [];
  flights.forEach(function(f){
    var k = f.cxr + '|' + f.no + '|' + f.date + '|' + f.orig + '|' + f.dest;
    if (!seen[k]){ seen[k] = f; unique.push(f); return; }
    var kept = seen[k], p;
    for (p in f){ if (f[p] && !kept[p]) kept[p] = f[p]; }
  });
  flights = unique;
  flights.forEach(function(f){
    for (var i=0;i<vis.length;i++){
      var v = vis[i];
      if (v.cxr === f.cxr && v.flt === f.no && v.date === f.date){
        f.eqp = EQP[v.eqp] || v.eqp;
        f.elapsed = fmtElapsed(v.elapsed);
        if (v.depTerm) f.depTerm = v.depTerm;
        if (v.arrTerm) f.arrTerm = v.arrTerm;
        if (v.cabin) f.cabin = v.cabin;
        if (!f.off && v.off) f.off = v.off;
        if (!f.arrDate && v.off && !f.off) f.off = v.off;
        break;
      }
    }
    if (!f.cabin) f.cabin = cabinFromClass(f.cls);
  });
  var year = null, prev = null;
  flights.forEach(function(f){
    var d;
    if (year === null){
      d = mkDate(f.date, f.dep, new Date().getFullYear());
      if (d.getTime() < Date.now() - 30*86400000) d.setFullYear(d.getFullYear()+1);
      year = d.getFullYear();
    } else {
      d = mkDate(f.date, f.dep, year);
      if (prev && d < prev){ year += 1; d = mkDate(f.date, f.dep, year); }
    }
    f.depDT = d;
    var a = mkDate(f.arrDate || f.date, f.arr, d.getFullYear());
    if (!f.arrDate && f.off) a.setDate(a.getDate() + f.off);
    f.arrDT = a;
    f.plus = Math.round((new Date(a.getFullYear(),a.getMonth(),a.getDate()) -
                         new Date(d.getFullYear(),d.getMonth(),d.getDate())) / 86400000);
    prev = a;
  });
  return flights;
}
/* ---------- branding ---------- */
var BRANDS = {
  tbc: {
    name:'TBC', mark:'tbc', company:'Travel Business Class',
    domain:'travelbusinessclass.com', title:'TBC VIP Itinerary Maker',
    light:{ plum:'#8c1238', grad:'linear-gradient(135deg,#a31649 0%,#750f2e 100%)' },
    dark :{ plum:'#e8447a', grad:'linear-gradient(135deg,#e32965 0%,#9e143d 100%)',
            bg:'#0b111e', card:'#151e2d', soft:'#101827',
            line:'#2a364a', rule:'#334155', chip:'#0d1524' }
  },
  abt: {
    name:'ABT', mark:'abt', company:'Air Business Travel',
    domain:'airbusinesstravel.com', title:'ABT VIP Itinerary Maker',
    light:{ plum:'#7d0a94', grad:'linear-gradient(135deg,#980098 0%,#470865 100%)' },
    dark :{ plum:'#d96ae8', grad:'linear-gradient(135deg,#b302b3 0%,#5a0a7a 100%)',
            bg:'#140720', card:'#1e0f2b', soft:'#180b24',
            line:'#3a2447', rule:'#4a2f5c', chip:'#150a1f' }
  }
};
var VARKEYS = ['bg','card','soft','line','rule','plum','grad','chip'];
var brand = 'tbc';
function B(){ return BRANDS[brand]; }
function setBrand(k){
  if (!BRANDS[k]) return;
  brand = k;
  try { localStorage.setItem('vipBrand', k); } catch(e){}
  paint();
}
function toggleDark(){ document.body.classList.toggle('dark'); paint(); }
function paint(){
  var b = B(), dark = document.body.classList.contains('dark');
  var v = dark ? b.dark : b.light, st = document.body.style;
  VARKEYS.forEach(function(k){ st.removeProperty('--' + k); });
  Object.keys(v).forEach(function(k){ st.setProperty('--' + k, v[k]); });
  document.title = b.title;
  var t = document.getElementById('brandTitle'); if (t) t.textContent = b.title;
  var bt = document.getElementById('bt-tbc'), ba = document.getElementById('bt-abt');
  if (bt) bt.className = (brand === 'tbc' ? 'on' : '');
  if (ba) ba.className = (brand === 'abt' ? 'on' : '');
  document.querySelectorAll('#docs .mark').forEach(function(el){ el.textContent = b.mark; });
  document.querySelectorAll('#docs .co').forEach(function(el){ el.textContent = b.company; });
  document.querySelectorAll('#docs .fine span:last-child').forEach(function(el){ el.textContent = b.domain; });
}
function initBrand(){
  var k = null;
  try { k = localStorage.getItem('vipBrand'); } catch(e){}
  if (BRANDS[k]) brand = k;
  paint();
}
/* ---------- tickets ---------- */
var tickets = [{ pnr:'', src:'' }];
var splits  = new Set();
var lastRender = [];
function mode(){ return document.getElementById('mode').value; }
function onModeChange(){
  stashTickets();
  var sep = mode() === 'separate';
  document.getElementById('addTk').style.display = sep ? '' : 'none';
  document.getElementById('pnr').style.display   = sep ? 'none' : '';
  if (!sep) tickets = [tickets[0]];
  renderTickets();
}
function addTicket(){
  stashTickets();
  if (tickets.length >= 6) return;
  tickets.push({ pnr:'', src:'' });
  renderTickets();
}
function delTicket(i){
  if (tickets.length <= 1) return;
  tickets.splice(i,1);
  renderTickets();
}
function stashTickets(){
  document.querySelectorAll('#tickets .tk').forEach(function(el){
    var i = +el.getAttribute('data-i');
    var p = el.querySelector('.tk-pnr');
    if (p) tickets[i].pnr = p.value;
    tickets[i].src = el.querySelector('textarea').value;
  });
}
function renderTickets(){
  var sep = mode() === 'separate', box = document.getElementById('tickets'), html = '';
  tickets.forEach(function(t,i){
    html += '<div class="tk" data-i="' + i + '">';
    if (sep){
      html += '<div class="tk-head"><span class="tk-name">Ticket #' + (i+1) + '</span>' +
              '<input type="text" class="tk-pnr" placeholder="PNR for this ticket" value="' + esc(t.pnr) + '">' +
              (tickets.length > 1 ? '<button class="tk-del" onclick="stashTickets();delTicket(' + i + ')">Remove</button>' : '') +
              '</div>';
    }
    html += '<textarea placeholder="Paste the Sabre segments here.">' + esc(t.src) + '</textarea></div>';
  });
  box.innerHTML = html;
  box.querySelectorAll('textarea').forEach(function(ta){
    ta.addEventListener('paste', function(){
      var el = this; setTimeout(function(){ el.value = normalize(el.value); }, 0);
    });
  });
}
/* ---------- render ---------- */
function regenerate(){ splits.clear(); render(); }
function splitAt(ti, idx){ splits.add(ti + ':' + idx); render(); }
function group(flights, ti){
  var out = [], cur = [];
  flights.forEach(function(f, i){
    f.idx = i;
    if (!cur.length){ cur.push(f); return; }
    var p = cur[cur.length-1];
    var g = gap(p.arrDT, f.depDT);
    if (splits.has(ti + ':' + p.idx) || p.dest !== f.orig || g.hours > 48){ out.push(cur); cur = [f]; }
    else { f.gap = g; cur.push(f); }
  });
  if (cur.length) out.push(cur);
  return out;
}
function label(i, n){
  if (n === 1) return 'Itinerary';
  if (n === 2) return i === 0 ? 'Outbound' : 'Return';
  return 'Flight ' + (i + 1);
}
function minConnection(a){ return (a === 'ORD' || a === 'DFW' || a === 'ATL') ? 45 : 45; }
function render(){
  stashTickets();
  var sep = mode() === 'separate';
  var paxName = document.getElementById('pax').value.trim();
  var docsEl = document.getElementById('docs');
  var out = '', any = false;
  lastRender = [];
  tickets.forEach(function(t, ti){
    var flights = [];
    try { flights = parse(t.src); } catch(e){ flights = []; }
    if (!flights.length) return;
    any = true;
    var trips = group(flights, ti);
    lastRender.push({ ti: ti, flights: flights, trips: trips });
    var pnr = sep ? t.pnr.trim() : document.getElementById('pnr').value.trim();
    if (sep){
      out += '<div class="tk-bar"><span class="lbl">Ticket #' + (ti+1) + '</span>' +
             '<button onclick="exportImage(\\'copy\\',' + ti + ')">Copy image</button>' +
             '<button onclick="exportImage(\\'download\\',' + ti + ')">Download PNG</button></div>';
    } else {
      out += '<div class="tk-bar">' +
             '<button onclick="exportImage(\\'copy\\',' + ti + ')">Copy image</button>' +
             '<button onclick="exportImage(\\'download\\',' + ti + ')">Download PNG</button></div>';
    }
    out += '<div class="doc" id="doc' + ti + '" data-ticket="' + ti + '" style="display:block">' +
      '<div class="brand"><div class="brand-l"><div class="mark">' + B().mark + '</div><div>' +
        '<div class="co">' + B().company + '</div>' +
        '<div class="co-sub">Flight itinerary' + (sep ? ' - Ticket ' + (ti+1) : '') + '</div>' +
      '</div></div><div class="who">' +
        '<div class="who-name">' + esc(paxName || 'Flight itinerary') + '</div>' +
        '<div class="who-ref">' + (pnr ? 'Booking ref: ' + esc(pnr) : '') + '</div>' +
      '</div></div>' + tripsHtml(trips, ti) +
      '<div class="fine"><span>All times are local to each airport.</span>' +
      '<span>' + B().domain + '</span></div></div>';
  });
  if (!any){ alert('No valid Sabre segments detected.'); return; }
  docsEl.innerHTML = out;
  document.getElementById('act').style.display = 'flex';
}
function tripsHtml(trips, ti){
  var html = '';
  trips.forEach(function(trip, tix){
    var a = trip[0], z = trip[trip.length-1], stops = trip.length - 1;
    html += '<section class="jrn">' +
      '<div class="jrn-head">' +
        '<div class="jrn-l"><span class="jrn-tag">' + label(tix, trips.length) + '</span>' +
        '<span class="jrn-route">' + city(a.orig) + ' (' + a.orig + ')  &rarr;  ' + city(z.dest) + ' (' + z.dest + ')</span></div>' +
        '<div class="jrn-meta">' + fmtFullDay(a.depDT) + '  &middot;  ' +
          (stops ? stops + ' stop' + (stops>1?'s':'') : 'Non-stop') + '</div>' +
      '</div>';
    trip.forEach(function(f, li){
      if (li > 0){
        var tight = f.gap.hours < 1 && f.gap.mins < minConnection(f.orig) + 15;
        var termChange = trip[li-1].arrTerm && f.depTerm && trip[li-1].arrTerm !== f.depTerm;
        html += '<div class="conn"><i></i><div class="conn-row">' +
          '<span class="conn-txt">' + f.gap.text + ' in ' + city(f.orig) + '</span>' +
          (tight ? '<span class="warn">Tight connection</span>' : '') +
          (termChange ? '<span class="warn">' + trip[li-1].arrTerm + ' &rarr; ' + f.depTerm + '</span>' : '') +
          '<button class="split" onclick="splitAt(' + ti + ',' + trip[li-1].idx + ')" title="Start a new journey here">Split</button>' +
        '</div></div>';
      }
      var airline = AIRLINES[f.cxr] || f.cxr;
      var cabins = ['Economy','Premium Economy','Business','First'].map(function(c){
        return '<option value="' + c + '"' + (c === f.cabin ? ' selected' : '') + '>' + c + '</option>';
      }).join('');
      var bags = ['2 x 32kg','1 x 32kg','2 x 23kg','1 x 23kg','3 x 23kg','Hand baggage only'].map(function(b){
        return '<option value="' + b + '"' + (b === '2 x 23kg' ? ' selected' : '') + '>' +
               (b === 'Hand baggage only' ? b : 'Baggage: ' + b) + '</option>';
      }).join('');
      html += '<div class="card" data-orig="' + f.orig + '" data-dest="' + f.dest + '">' +
        '<div class="card-top">' +
          '<div class="f-l">' +
            '<span class="f-no">' + airline + ' ' + f.cxr + ' ' + f.no + '</span>' +
            '<span class="dot-sep">&#9679;</span>' +
            '<input type="text" class="e eqp" value="' + esc(f.eqp || '') + '" placeholder="+ Aircraft">' +
          '</div>' +
          '<div class="f-r">' +
            '<select class="s bag">' + bags + '</select>' +
            '<select class="s cabin">' + cabins + '</select>' +
          '</div>' +
        '</div>' +
        '<div class="leg">' +
          '<div class="end">' +
            '<div class="t">' + fmtTime(f.depDT) + '</div>' +
            '<div class="code">' + f.orig + '</div>' +
            '<div class="city">' + city(f.orig) + '</div>' +
            '<div class="day">' + fmtDay(f.depDT) +
              '<input type="text" class="e term" value="' + esc(f.depTerm ? 'Departure ' + f.depTerm : '') + '" placeholder="+ Departure terminal"></div>' +
          '</div>' +
          '<div class="mid-col">' +
            '<span class="dur">' + (f.elapsed || '') + '</span>' +
            '<div class="path"><b></b><i></i><span class="plane">&#9992;</span><i></i><b></b></div>' +
          '</div>' +
          '<div class="end r">' +
            '<div class="t">' + fmtTime(f.arrDT) + (f.plus > 0 ? '<sup>+' + f.plus + '</sup>' : '') + '</div>' +
            '<div class="code">' + f.dest + '</div>' +
            '<div class="city">' + city(f.dest) + '</div>' +
            '<div class="day">' + fmtDay(f.arrDT) +
              '<input type="text" class="e term r" value="' + esc(f.arrTerm ? 'Arrival ' + f.arrTerm : '') + '" placeholder="+ Arrival terminal"></div>' +
          '</div>' +
        '</div>' +
      '</div>';
    });
    html += '<div class="jrn-foot">' +
        '<select class="s status"><option>Confirmed</option><option>Schedule change</option><option>On request</option></select>' +
        '<input type="text" class="e note" placeholder="+ Notes or VIP perks for this journey...">' +
      '</div></section>';
  });
  return html;
}
/* ---------- screenshot ---------- */
function snapExport(doc){
  var swaps = [];
  doc.classList.add('is-exporting');
  doc.querySelectorAll('select.s').forEach(function(sel){
    var span = document.createElement('span'), cs = getComputedStyle(sel);
    span.style.fontSize = cs.fontSize;
    span.style.fontWeight = cs.fontWeight;
    span.style.color = cs.color;
    span.style.padding = cs.padding;
    span.style.borderRadius = cs.borderRadius;
    span.style.background = cs.background;
    span.style.border = cs.border;
    span.style.letterSpacing = cs.letterSpacing;
    span.style.textTransform = cs.textTransform;
    span.style.lineHeight = '24px';
    span.style.height = '26px';
    span.style.display = 'inline-flex';
    span.style.alignItems = 'center';
    span.style.justifyContent = 'center';
    span.style.boxSizing = 'border-box';
    span.textContent = sel.options[sel.selectedIndex].text;
    sel.parentNode.insertBefore(span, sel);
    sel.style.display = 'none';
    swaps.push({ el: sel, tmp: span });
  });
  doc.querySelectorAll('input.e').forEach(function(inp){
    if (!inp.value.trim()){ inp.style.display = 'none'; swaps.push({ el: inp, tmp: null }); return; }
    var d = document.createElement('span'), cs = getComputedStyle(inp);
    ['fontSize','fontWeight','fontStyle','color','padding'].forEach(function(k){ d.style[k] = cs[k]; });
    d.style.whiteSpace = 'nowrap';
    d.textContent = (inp.classList.contains('term') ? ' · ' : '') + inp.value;
    inp.parentNode.insertBefore(d, inp); inp.style.display = 'none';
    swaps.push({ el: inp, tmp: d });
  });
  return swaps;
}
function snapRestore(doc, swaps){
  doc.classList.remove('is-exporting');
  swaps.forEach(function(s){ if (s.tmp) s.tmp.remove(); s.el.style.display = ''; });
}
async function shoot(doc){
  var bg = document.body.classList.contains('dark') ? '#0b111e' : '#f3f4f6';
  var swaps = snapExport(doc);
  try {
    await new Promise(function(r){ setTimeout(r, 60); });
    return await html2canvas(doc, { scale: 2, useCORS: true, backgroundColor: bg });
  } finally { snapRestore(doc, swaps); }
}
async function exportImage(action, ti){
  var doc = document.getElementById('doc' + ti);
  if (!doc) return;
  var canvas = await shoot(doc);
  if (action === 'download'){
    var a = document.createElement('a');
    a.download = B().name + '_Itinerary_' + (ti + 1) + '.png';
    a.href = canvas.toDataURL('image/png'); a.click();
  } else {
    canvas.toBlob(async function(blob){
      try { await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]); alert('Screenshot copied to clipboard!'); }
      catch(e){ alert('Clipboard blocked by the browser — use Download PNG instead.'); }
    });
  }
}
/* ---------- disclaimer email ---------- */
var BAG_TEXT = {
  '2 x 32kg':'2 pieces EACH PIECE UP TO 70 POUNDS/32 KILOGRAMS AND UP TO 62 LINEAR INCHES/158 LINEAR CENTIMETERS',
  '1 x 32kg':'1 piece UP TO 70 POUNDS/32 KILOGRAMS AND UP TO 62 LINEAR INCHES/158 LINEAR CENTIMETERS',
  '2 x 23kg':'2 pieces EACH PIECE UP TO 50 POUNDS/23 KILOGRAMS AND UP TO 62 LINEAR INCHES/158 LINEAR CENTIMETERS',
  '1 x 23kg':'1 piece UP TO 50 POUNDS/23 KILOGRAMS AND UP TO 62 LINEAR INCHES/158 LINEAR CENTIMETERS',
  '3 x 23kg':'3 pieces EACH PIECE UP TO 50 POUNDS/23 KILOGRAMS AND UP TO 62 LINEAR INCHES/158 LINEAR CENTIMETERS',
  'Hand baggage only':'NO CHECKED BAG INCLUDED - CARRY-ON ONLY'
};
var NUMWORD = ['zero','one','two','three','four','five','six','seven','eight','nine'];
function numWord(n){ return NUMWORD[n] || String(n); }
function cabinWord(c){
  return { 'Economy':'economy', 'Premium Economy':'premium economy',
           'Business':'business', 'First':'first' }[c] || String(c).toLowerCase();
}
function legsFromDocs(){
  var legs = [];
  document.querySelectorAll('#docs .doc').forEach(function(doc){
    var ti = +doc.getAttribute('data-ticket');
    doc.querySelectorAll('.card').forEach(function(card){
      var bag = card.querySelector('select.bag'), cab = card.querySelector('select.cabin');
      legs.push({
        ti: ti,
        orig: card.getAttribute('data-orig'),
        dest: card.getAttribute('data-dest'),
        bag: bag ? bag.value : '2 x 23kg',
        cabin: cab ? cab.value : 'Economy'
      });
    });
  });
  return legs;
}
function routeInfo(){
  var allTrips = [];
  lastRender.forEach(function(r){ allTrips = allTrips.concat(r.trips); });
  if (!allTrips.length) return null;
  var firstTrip = allTrips[0], lastTrip = allTrips[allTrips.length - 1];
  var origin = firstTrip[0].orig;
  var finalDest = lastTrip[lastTrip.length - 1].dest;
  var dest = allTrips.length > 1 ? firstTrip[firstTrip.length - 1].dest : finalDest;
  var word = allTrips.length === 1 ? 'one-way' : (finalDest === origin ? 'round-trip' : 'multi-city');
  return { origin: origin, dest: dest, word: word };
}
function cabinRank(c){ return { 'Economy':0, 'Premium Economy':1, 'Business':2, 'First':3 }[c] || 0; }
function cabinSentence(legs){
  if (legs.length < 2) return '';
  var counts = {};
  legs.forEach(function(l){ counts[l.cabin] = (counts[l.cabin] || 0) + 1; });
  var used = Object.keys(counts);
  if (used.length < 2) return '';
  var main = used.slice().sort(function(a,b){
    return (counts[b] - counts[a]) || (cabinRank(b) - cabinRank(a));
  })[0];
  var odd = legs.filter(function(l){ return l.cabin !== main; });
  var byCabin = {};
  odd.forEach(function(l){ (byCabin[l.cabin] = byCabin[l.cabin] || []).push(l); });
  var clauses = Object.keys(byCabin).sort(function(a,b){ return cabinRank(a) - cabinRank(b); }).map(function(c){
    var list = byCabin[c].map(function(l){ return 'from ' + l.orig + ' to ' + l.dest; });
    var joined = list.length === 1 ? list[0]
      : list.slice(0, -1).join(', ') + ' and ' + list[list.length - 1];
    return (list.length === 1 ? 'the flight ' : 'the flights ') + joined +
           (list.length === 1 ? ' is in ' : ' are in ') + cabinWord(c);
  });
  var body = clauses.length === 1 ? clauses[0]
    : clauses.slice(0, -1).join(', ') + ' and ' + clauses[clauses.length - 1];
  return body.charAt(0).toUpperCase() + body.slice(1) + ', the others are in ' + cabinWord(main) + '.';
}
async function buildEmail(){
  var docs = Array.prototype.slice.call(document.querySelectorAll('#docs .doc'));
  if (!docs.length){ alert('Generate the itinerary first.'); return; }
  var panel = document.getElementById('mailPanel');
  panel.classList.add('busy');
  panel.style.display = 'block';
  document.getElementById('mailBody').innerHTML = '<p>Capturing screenshots...</p>';
  try {
    var shots = [];
    for (var i = 0; i < docs.length; i++){
      var c = await shoot(docs[i]);
      shots.push(c.toDataURL('image/png'));
    }
    var sep   = mode() === 'separate';
    var name  = document.getElementById('pax').value.trim() || 'traveller';
    var legs  = legsFromDocs();
    var info  = routeInfo() || { origin:'?', dest:'?', word:'' };
    var P = function(s){ return '<p style="margin:0 0 12px">' + s + '</p>'; };
    var h = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#000;line-height:1.5">';
    h += P('Dear ' + esc(name) + ',');
    h += P('Your ' + info.word + ' journey from ' + info.origin + ' to ' + info.dest +
           (sep ? ' is composed of ' + numWord(docs.length) + ' separate bookings outlined below:'
                : ' is outlined below:'));
    shots.forEach(function(src, k){
      if (sep) h += P('<b>Ticket #' + (k+1) + ':</b>');
      h += '<p style="margin:0 0 16px"><img src="' + src + '" style="max-width:680px;width:100%"></p>';
    });
    legs.forEach(function(l){
      h += P('BAG ALLOWANCE &nbsp;&nbsp;&nbsp;&nbsp; ' + l.orig + ' to ' + l.dest + ' ' +
             (BAG_TEXT[l.bag] || l.bag));
    });
    h += P('<b>Important to note:</b>');
    var n = 1;
    if (sep){
      h += P('<b>' + (n++) + '. Connection process:</b><br>As your itinerary consists of ' +
             numWord(docs.length) + ' separate bookings, you will be required to check out and check in at the connection point.');
    }
    h += P('<b>' + (n++) + '. Schedule changes/missed flights:</b><br>All of the separate bookings will be independently treated in terms of schedule changes, should the affected itinerary disrupt the subsequent flight segments any changes to other than the affected booking will be treated as voluntary and all fare rules will apply. Failure to use all flight segments in order will result in No-Show and our company will not be held liable or responsible to cover any fees or losses associated to any aspects of this booking that result due to airline operations.');
    h += P('<b>' + (n++) + '. Baggage allowance:</b><br>For short legs in economy class, check-in bags are not included in the fare, but can be added to the booking against normal fees at the airports. Please note that in case of purchasing an additional bag, the weight limit will remain the same as for an economy ticket - 50lbs per bag');
    var cs = cabinSentence(legs);
    if (cs) h += P('<b>' + (n++) + '.</b> ' + cs);
    h += P('Kindly reply to this email with a confirmation that you have read and approved the above.');
    h += P('Your prompt response is greatly appreciated.');
    h += P('Safe travels!');
    h += '</div>';
    document.getElementById('mailBody').innerHTML = h;
  } catch(e){
    document.getElementById('mailBody').innerHTML = '<p>Could not build the email: ' + esc(e.message) + '</p>';
  } finally {
    panel.classList.remove('busy');
    panel.scrollIntoView({ behavior:'smooth', block:'start' });
  }
}
async function copyEmail(){
  var el = document.getElementById('mailBody');
  if (!el.innerHTML.trim()){ alert('Build the email first.'); return; }
  var html = el.innerHTML, text = el.innerText;
  try {
    await navigator.clipboard.write([ new ClipboardItem({
      'text/html' : new Blob([html], { type:'text/html'  }),
      'text/plain': new Blob([text], { type:'text/plain' })
    })]);
    alert('Email copied. Open a Gmail compose window and paste — the screenshots come with it.');
  } catch(e){
    var r = document.createRange(); r.selectNodeContents(el);
    var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    var ok = false;
    try { ok = document.execCommand('copy'); } catch(e2){}
    s.removeAllRanges();
    alert(ok ? 'Email copied. Paste it into Gmail.'
             : 'Clipboard blocked. Select everything in the preview box and copy manually.');
  }
}
renderTickets();
initBrand();
<\/script>
</body>
</html>`;

const IA_GK_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GK Converter - TBC</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<style>
  :root{--bg:#0b111e;--card:#151e2d;--line:#2a364a;--ink:#f8fafc;--mid:#94a3b8;
        --grad:linear-gradient(135deg,#e32965 0%,#9e143d 100%);--code:#38bdf8;}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Inter',-apple-system,sans-serif;background:var(--bg);color:var(--ink);
       padding:30px 20px;line-height:1.5;-webkit-font-smoothing:antialiased}
  .wrap{max-width:820px;margin:0 auto;display:flex;flex-direction:column;gap:16px}
  .header{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px 22px;
          display:flex;justify-content:space-between;align-items:center;gap:12px}
  .brand{display:flex;align-items:center;gap:12px}
  .logo{background:var(--grad);color:#fff;font-weight:800;font-size:22px;padding:4px 12px;
        border-radius:8px;letter-spacing:-1px}
  h1{font-size:17px;font-weight:800}
  .sub{font-size:11px;font-weight:600;color:var(--mid);text-transform:uppercase;letter-spacing:1px}
  .panel{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px}
  label.lbl{display:block;font-size:10px;font-weight:800;text-transform:uppercase;
            letter-spacing:.6px;color:var(--mid);margin-bottom:5px}
  textarea{width:100%;height:150px;background:#090e17;border:1px solid var(--line);border-radius:10px;
           padding:10px 12px;color:var(--ink);font-family:'JetBrains Mono',monospace;font-size:12px;
           outline:none;resize:vertical}
  textarea:focus{border-color:#e8447a}
  .row{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin-top:12px}
  .fld{display:flex;flex-direction:column;gap:4px}
  select,input.num{background:#090e17;border:1px solid var(--line);border-radius:8px;padding:8px 10px;
                   color:var(--ink);font-family:inherit;font-size:12px;outline:none}
  input.num{width:70px}
  button.go{background:var(--grad);color:#fff;border:none;border-radius:8px;padding:9px 18px;
            font-size:13px;font-weight:700;cursor:pointer;font-family:inherit}
  button.go:hover{filter:brightness(1.12)}
  .out{background:#090e17;border:1px solid #1e293b;border-radius:10px;padding:12px 14px;
       font-family:'JetBrains Mono',monospace;font-size:12.5px;color:var(--code);
       white-space:pre-wrap;line-height:1.6;cursor:pointer;min-height:48px}
  .out:hover{border-color:var(--code)}
  .note{font-size:11.5px;color:var(--mid);margin-top:8px}
  .toast{position:fixed;bottom:20px;right:20px;background:var(--grad);color:#fff;padding:8px 16px;
         border-radius:20px;font-size:12px;font-weight:700;opacity:0;pointer-events:none;
         transition:opacity .2s,transform .2s;transform:translateY(10px)}
  .toast.show{opacity:1;transform:translateY(0)}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div class="brand">
      <div class="logo">tbc</div>
      <div><h1>GK Converter</h1><div class="sub">Passive segment builder</div></div>
    </div>
  </div>
  <div class="panel">
    <label class="lbl">Paste Sabre segments (*I / *IA / VI*)</label>
    <textarea id="src" placeholder=" 1 TK  85J 29AUG Q TLVIST*SS1   615A  920A /DCTK /E
 2 TK  79J 29AUG Q ISTJFK*SS1  1155A  310P /DCTK /E"></textarea>
    <div class="row">
      <div class="fld">
        <label class="lbl">Status</label>
        <select id="status">
          <option value="GK">GK - passive / ghost</option>
          <option value="HK">HK - confirmed</option>
          <option value="BK">BK - booked</option>
          <option value="YK">YK - waitlist</option>
        </select>
      </div>
      <div class="fld">
        <label class="lbl">Seats</label>
        <input class="num" id="seats" type="number" min="1" max="9" value="1">
      </div>
      <div class="fld">
        <label class="lbl">Times</label>
        <select id="times">
          <option value="0">Omit times</option>
          <option value="1">Include times</option>
        </select>
      </div>
      <button class="go" onclick="convert()">Convert</button>
    </div>
  </div>
  <div class="panel">
    <label class="lbl">Sell commands - click to copy</label>
    <div class="out" id="out" onclick="copyOut()">Paste segments above, then press Convert.</div>
    <div class="note">Each line is one passive segment. Verify carrier, class, date and time format against your GDS before selling.</div>
  </div>
</div>
<div class="toast" id="toast">Copied to clipboard!</div>
<script>
var SEG = /^\\s*\\d{1,2}\\s+([A-Z0-9]{2})\\s*(\\d{1,4})\\s*([A-Z])?\\s+(\\d{2}[A-Z]{3})\\s+(?:[A-Z]\\s+)?([A-Z]{3})\\s*([A-Z]{3})\\s*\\*?\\s*(?:[A-Z]{2}\\d{1,2})?\\s+(\\d{1,4}[AP])\\s+(\\d{1,4}[AP])/i;
function pad4(t){
  var ap = t.slice(-1).toUpperCase();
  var n  = t.slice(0,-1).replace(/\\D/g,'');
  while (n.length < 4) n = '0' + n;
  return n + ap;
}
function convert(){
  var lines  = document.getElementById('src').value.split('\\n');
  var status = document.getElementById('status').value;
  var seats  = parseInt(document.getElementById('seats').value,10) || 1;
  var withT  = document.getElementById('times').value === '1';
  var cmds = [];
  lines.forEach(function(line){
    var m = line.trim().match(SEG);
    if (!m) return;
    var cxr = m[1].toUpperCase(), flt = m[2], cls = (m[3]||'Y').toUpperCase();
    var dt  = m[4].toUpperCase(), org = m[5].toUpperCase(), dst = m[6].toUpperCase();
    var cmd = '0' + cxr + flt + cls + dt + org + dst + status + seats;
    if (withT) cmd += '/' + pad4(m[7]) + ' ' + pad4(m[8]);
    cmds.push(cmd);
  });
  document.getElementById('out').textContent =
    cmds.length ? cmds.join('\\n') : 'No valid segments detected. Check the paste format.';
}
function copyOut(){
  var t = document.getElementById('out').textContent;
  if (!t || t.indexOf('No valid') === 0 || t.indexOf('Paste segments') === 0) return;
  navigator.clipboard.writeText(t).then(function(){
    var el = document.getElementById('toast');
    el.classList.add('show');
    setTimeout(function(){ el.classList.remove('show'); }, 2000);
  });
}
<\/script>
</body>
</html>`;

const IA_PNR_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GDS PNR Creation Guide - TBC</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<style>
  :root {
    --bg-body: #0b111e; --bg-card: #151e2d; --bg-sub: #101827;
    --text-main: #f8fafc; --text-muted: #94a3b8; --border: #2a364a;
    --tbc-plum: #e8447a; --tbc-gradient: linear-gradient(135deg, #e32965 0%, #9e143d 100%);
    --code-bg: #090e17; --code-border: #1e293b; --code-text: #38bdf8;
    --accent-blue: #6366f1; --tag-bg: rgba(99, 102, 241, 0.15);
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Inter', -apple-system, sans-serif;
    background-color: var(--bg-body);
    color: var(--text-main);
    padding: 30px 20px;
    -webkit-font-smoothing: antialiased;
    line-height: 1.5;
  }
  .container { max-width: 860px; margin: 0 auto; display: flex; flex-direction: column; gap: 16px; }
  .header {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 20px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
  }
  .brand-group { display: flex; align-items: center; gap: 12px; }
  .logo-badge {
    background: var(--tbc-gradient);
    color: #fff;
    font-weight: 800;
    font-size: 22px;
    padding: 4px 12px;
    border-radius: 8px;
    letter-spacing: -1px;
  }
  .title-group h1 { font-size: 17px; font-weight: 800; color: #fff; letter-spacing: -0.3px; }
  .title-group p { font-size: 11px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; }
  .status-chip {
    background: var(--tag-bg);
    border: 1px solid rgba(99, 102, 241, 0.3);
    color: #a5b4fc;
    font-size: 11px;
    font-weight: 700;
    padding: 4px 12px;
    border-radius: 20px;
  }
  .builder-card {
    background: var(--bg-card);
    border: 1px solid rgba(99, 102, 241, 0.35);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.25);
  }
  .builder-top {
    display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;
  }
  .builder-title { font-size: 13px; font-weight: 800; color: #818cf8; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 8px; }
  .btn-add-pax {
    background: var(--tbc-gradient); color: #fff; border: none; border-radius: 7px;
    padding: 5px 12px; font-size: 11.5px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 4px;
  }
  .btn-add-pax:hover { filter: brightness(1.15); }
  .pax-rows-container { display: flex; flex-direction: column; gap: 8px; margin-bottom: 14px; }
  .pax-row {
    display: flex; gap: 6px; align-items: center; background: #090e17;
    padding: 8px 10px; border-radius: 10px; border: 1px solid var(--border);
  }
  .pax-row-num {
    font-size: 11px; font-weight: 800; color: #818cf8; width: 22px; text-align: center; flex-shrink: 0;
  }
  .builder-input, .builder-select {
    background: #151e2d; border: 1px solid var(--border); border-radius: 6px;
    padding: 6px 8px; color: #fff; font-size: 11.5px; outline: none; font-family: inherit;
  }
  .builder-input:focus, .builder-select:focus { border-color: #818cf8; }
  .inp-last { flex: 1.2; min-width: 0; }
  .inp-first { flex: 1.2; min-width: 0; }
  .inp-dob { width: 95px; flex-shrink: 0; }
  .inp-type { width: 115px; flex-shrink: 0; }
  .inp-gender { width: 100px; flex-shrink: 0; }
  .inp-ref { width: 50px; text-align: center; flex-shrink: 0; }
  .btn-del-pax {
    background: transparent; border: none; color: #ef4444; font-size: 15px; cursor: pointer; padding: 2px 6px; border-radius: 4px; line-height: 1; flex-shrink: 0;
  }
  .btn-del-pax:hover { background: rgba(239, 68, 68, 0.15); }
  .builder-outputs { display: flex; flex-direction: column; gap: 8px; }
  .gen-row { display: flex; flex-direction: column; gap: 4px; }
  .gen-label { font-size: 10px; font-weight: 800; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.6px; }
  .builder-output {
    background: #090e17; border: 1px solid #1e293b; border-radius: 8px;
    padding: 8px 12px; font-family: 'JetBrains Mono', monospace; font-size: 11.5px;
    color: #38bdf8; display: flex; justify-content: space-between; align-items: flex-start; cursor: pointer;
    white-space: pre-line; line-height: 1.4;
  }
  .builder-output:hover { border-color: #38bdf8; }
  .search-bar {
    width: 100%; background: var(--bg-card); border: 1px solid var(--border);
    border-radius: 10px; padding: 10px 14px; color: #fff; font-size: 12.5px; outline: none;
    font-family: inherit; transition: border-color 0.15s;
  }
  .search-bar:focus { border-color: var(--tbc-plum); }
  .intro-card {
    background: linear-gradient(135deg, rgba(227, 41, 101, 0.08), rgba(99, 102, 241, 0.08));
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 14px 18px;
    font-size: 12.5px;
    color: #cbd5e1;
  }
  .steps-grid { display: flex; flex-direction: column; gap: 12px; }
  .step-card {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 18px 22px;
    transition: transform 0.15s, border-color 0.15s;
  }
  .step-card:hover { border-color: rgba(99, 102, 241, 0.4); }
  .step-head { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
  .step-num {
    background: var(--tbc-gradient); color: #fff; font-weight: 800; font-size: 12px;
    width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;
  }
  .step-title { font-size: 14px; font-weight: 700; color: #fff; }
  .step-content { font-size: 12.5px; color: #94a3b8; display: flex; flex-direction: column; gap: 8px; }
  .step-content strong { color: #f1f5f9; }
  .code-block {
    background: var(--code-bg); border: 1px solid var(--code-border); border-radius: 8px;
    padding: 8px 12px; font-family: 'JetBrains Mono', monospace; font-size: 12px; color: var(--code-text);
    display: flex; justify-content: space-between; align-items: center; gap: 8px; margin: 3px 0;
    cursor: pointer; transition: border-color 0.15s, background 0.15s;
  }
  .code-block:hover { border-color: rgba(56, 189, 248, 0.4); background: #0c1424; }
  .code-text-val { flex: 1; word-break: break-all; }
  .copy-btn {
    background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.1); color: #cbd5e1;
    padding: 3px 8px; border-radius: 5px; font-size: 10px; font-weight: 700; cursor: pointer;
    font-family: 'Inter', sans-serif; flex-shrink: 0; transition: 0.15s; margin-left: 8px;
  }
  .code-block:hover .copy-btn, .builder-output:hover .copy-btn { background: var(--tbc-gradient); color: #fff; border-color: transparent; }
  .note-box { background: var(--bg-sub); border-left: 3px solid var(--tbc-plum); padding: 8px 12px; border-radius: 0 6px 6px 0; font-size: 11.5px; color: #cbd5e1; margin-top: 4px; }
  .alert-box { background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); color: #fde68a; padding: 10px 14px; border-radius: 8px; font-size: 12px; margin-top: 6px; }
  .toast {
    position: fixed; bottom: 20px; right: 20px; background: var(--tbc-gradient); color: #fff;
    padding: 8px 16px; border-radius: 20px; font-size: 12px; font-weight: 700;
    box-shadow: 0 6px 20px rgba(0,0,0,0.4); opacity: 0; pointer-events: none;
    transition: opacity 0.2s, transform 0.2s; transform: translateY(10px);
  }
  .toast.show { opacity: 1; transform: translateY(0); }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="brand-group">
      <div class="logo-badge">tbc</div>
      <div class="title-group">
        <h1>How to Create a PNR in GDS</h1>
        <p>Standard Operating Procedure</p>
      </div>
    </div>
    <div class="status-chip">Multi-Pax Generator (Max 9)</div>
  </div>
  <div class="builder-card">
    <div class="builder-top">
      <div class="builder-title">&#9881; Multi-Passenger Sabre Command Generator</div>
      <button class="btn-add-pax" id="btnAddPax" onclick="addPaxRow()">+ Add Passenger</button>
    </div>
    <div class="pax-rows-container" id="paxContainer"></div>
    <div class="builder-outputs">
      <div class="gen-row">
        <span class="gen-label">1. Passenger Name Command(s)</span>
        <div class="builder-output" onclick="copySnippet(document.getElementById('outCmdName').textContent)">
          <span id="outCmdName">-LASTNAME/FIRSTNAME MR</span>
          <button class="copy-btn">Copy</button>
        </div>
      </div>
      <div class="gen-row">
        <span class="gen-label">2. TSA / APIS Command(s) (3DOCS)</span>
        <div class="builder-output" onclick="copySnippet(document.getElementById('outCmdDocs').textContent)">
          <span id="outCmdDocs">3DOCS/DB/30JAN62/M/LASTNAME/FIRSTNAME-1.1</span>
          <button class="copy-btn">Copy</button>
        </div>
      </div>
      <div class="gen-row" id="outInftRow" style="display:none;">
        <span class="gen-label" style="color:#fde68a;">3. Mandatory Infant Remark(s) (3INFT)</span>
        <div class="builder-output" style="border-color:#f59e0b;" onclick="copySnippet(document.getElementById('outCmdInft').textContent)">
          <span id="outCmdInft" style="color:#fde68a;">3INFT/LASTNAME/FIRSTNAME/30JAN62-1.1</span>
          <button class="copy-btn">Copy</button>
        </div>
      </div>
    </div>
  </div>
  <input type="text" class="search-bar" id="guideSearch" placeholder="&#128269; Search commands or steps (e.g. infant, CTCR, TK, WPRQ, TSA)...">
  <div class="intro-card">
    <strong>Dear Team,</strong><br>
    Please find below the detailed steps to correctly create a PNR in GDS. Click any code box to copy commands directly.
  </div>
  <div class="steps-grid" id="stepsList">
    <div class="step-card" data-search="itinerary seats pcc infant lap 1">
      <div class="step-head"><div class="step-num">1</div><div class="step-title">Build the Itinerary</div></div>
      <div class="step-content">
        <p>&bull; Always use the correct <strong>PCC</strong>.</p>
        <p>&bull; The number of seats taken should match the number of passengers being added.</p>
        <div class="note-box"><strong>Note:</strong> An infant on lap does not require an additional seat.</div>
      </div>
    </div>
    <div class="step-card" data-search="names passenger adult child infant seat 2">
      <div class="step-head"><div class="step-num">2</div><div class="step-title">Insert Passenger Names</div></div>
      <div class="step-content">
        <p>Use the following formats depending on passenger type:</p>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1; margin-top:2px;">Adult:</p>
        <div class="code-block" onclick="copySnippet('-LASTNAME/FIRST MIDDLE')"><span class="code-text-val">-LASTNAME/FIRST MIDDLE</span><button class="copy-btn">Copy</button></div>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1; margin-top:4px;">Child:</p>
        <div class="code-block" onclick="copySnippet('-LASTNAME/FIRST MIDDLE*P-C07')"><span class="code-text-val">-LASTNAME/FIRST MIDDLE*P-C07</span><button class="copy-btn">Copy</button></div>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1; margin-top:4px;">Infant without a seat (on lap):</p>
        <div class="code-block" onclick="copySnippet('-I/LASTNAME/FIRST MIDDLE*DOB18AUG20')"><span class="code-text-val">-I/LASTNAME/FIRST MIDDLE*DOB18AUG20</span><button class="copy-btn">Copy</button></div>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1; margin-top:4px;">Infant with a seat:</p>
        <div class="code-block" onclick="copySnippet('-LASTNAME/FIRST MIDDLE*P-INS')"><span class="code-text-val">-LASTNAME/FIRST MIDDLE*P-INS</span><button class="copy-btn">Copy</button></div>
      </div>
    </div>
    <div class="step-card" data-search="create reopen pnr *pnrpnr 3 4">
      <div class="step-head"><div class="step-num">3</div><div class="step-title">Create & Reopen PNR</div></div>
      <div class="step-content">
        <p>Type the following to create the record:</p>
        <div class="code-block" onclick="copySnippet('PNR')"><span class="code-text-val">PNR</span><button class="copy-btn">Copy</button></div>
        <p style="margin-top:4px;">Command to reopen:</p>
        <div class="code-block" onclick="copySnippet('*PNRPNR')"><span class="code-text-val">*PNRPNR</span><button class="copy-btn">Copy</button></div>
      </div>
    </div>
    <div class="step-card" data-search="tsa secure flight docs 3docs 4docs apis infant 3inft aa ba 5">
      <div class="step-head"><div class="step-num">4</div><div class="step-title">Add TSA Information</div></div>
      <div class="step-content">
        <p>Follow the formats below:</p>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1;">Adult / Child:</p>
        <div class="code-block" onclick="copySnippet('3DOCS/DB/30JAN62/M/LASTNAME/FIRSTNAME/MIDDLENAME-1.1')"><span class="code-text-val">3DOCS/DB/30JAN62/M/LASTNAME/FIRSTNAME/MIDDLENAME-1.1</span><button class="copy-btn">Copy</button></div>
        <p style="font-size:11.5px; color:#64748b;">&bull; <strong>30JAN62</strong> &rarr; Date of birth &nbsp;|&nbsp; <strong>M/F</strong> &rarr; Gender &nbsp;|&nbsp; <strong>-1.1</strong> &rarr; Passenger reference</p>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1; margin-top:4px;">Infant:</p>
        <div class="code-block" onclick="copySnippet('3DOCS/DB/29JUN24/FI/WILLIAMS/WREN BROOKE-1.1')"><span class="code-text-val">3DOCS/DB/29JUN24/FI/WILLIAMS/WREN BROOKE-1.1</span><button class="copy-btn">Copy</button></div>
        <p style="font-size:11.5px; color:#64748b;">&bull; <strong>-1.1</strong> indicates the infant is linked to the first adult in the booking.</p>
        <div class="alert-box">
          <strong>Important:</strong> Once an infant is added, you must also insert the following remark:
          <div class="code-block" style="margin-top:6px; background:#1e1b4b;" onclick="copySnippet('3INFT/WILLIAMS/WREN BROOKE/29JUN24-1.1')">
            <span class="code-text-val" style="color:#c7d2fe;">3INFT/WILLIAMS/WREN BROOKE/29JUN24-1.1</span>
            <button class="copy-btn">Copy</button>
          </div>
        </div>
        <div class="note-box" style="margin-top:6px;"><strong>Note:</strong> For AA/BA, use <strong>4DOC</strong> instead of <strong>3DOC</strong>.</div>
      </div>
    </div>
    <div class="step-card" data-search="sign save signature er 6ruby 6">
      <div class="step-head"><div class="step-num">5</div><div class="step-title">Sign & Save</div></div>
      <div class="step-content">
        <div class="code-block" onclick="copySnippet('6RUBY')"><span class="code-text-val">6RUBY</span><span style="font-size:11px; color:#64748b; margin-right:8px;">// Signature</span><button class="copy-btn">Copy</button></div>
        <div class="code-block" onclick="copySnippet('ER')"><span class="code-text-val">ER</span><span style="font-size:11px; color:#64748b; margin-right:8px;">// Save & End Transaction</span><button class="copy-btn">Copy</button></div>
      </div>
    </div>
    <div class="step-card" data-search="ctcr remarks contact email phone tk turkish 7">
      <div class="step-head"><div class="step-num">6</div><div class="step-title">Add CTCR Remarks (When Required)</div></div>
      <div class="step-content">
        <p>For some airlines (e.g., <strong>TK</strong>), adding CTCR remarks (contact details) is mandatory:</p>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1;">Email:</p>
        <div class="code-block" onclick="copySnippet('3CTCE/SCHEDULE.CHANGES//TRAVELBUSINESSCLASS.COM-1.1')"><span class="code-text-val">3CTCE/SCHEDULE.CHANGES//TRAVELBUSINESSCLASS.COM-1.1</span><button class="copy-btn">Copy</button></div>
        <p style="font-size:11.5px; font-weight:700; color:#cbd5e1; margin-top:4px;">Phone number:</p>
        <div class="code-block" onclick="copySnippet('3CTCM/8558551221-1.1')"><span class="code-text-val">3CTCM/8558551221-1.1</span><button class="copy-btn">Copy</button></div>
        <p style="font-size:11.5px; color:#64748b;">(Replace passenger reference -1.1 as per the passenger order in the booking.)</p>
      </div>
    </div>
    <div class="step-card" data-search="store save fare wprq wprq¥pv wppjcb¥rq wprq¥pl *pq pqd-all 8">
      <div class="step-head"><div class="step-num">7</div><div class="step-title">Store and Save Fare</div></div>
      <div class="step-content">
        <p>Always rebook into the correct booking classes before storing.</p>
        <div class="code-block" onclick="copySnippet('WPRQ')"><span class="code-text-val">WPRQ</span><span style="font-size:11px; color:#64748b; margin-right:8px;">// Store adult fare</span><button class="copy-btn">Copy</button></div>
        <div class="code-block" onclick="copySnippet('WPRQ¥PV')"><span class="code-text-val">WPRQ¥PV</span><span style="font-size:11px; color:#64748b; margin-right:8px;">// Price & store private</span><button class="copy-btn">Copy</button></div>
        <div class="code-block" onclick="copySnippet('WPPJCB¥RQ')"><span class="code-text-val">WPPJCB¥RQ</span><span style="font-size:11px; color:#64748b; margin-right:8px;">// Price & store JCB</span><button class="copy-btn">Copy</button></div>
        <div class="code-block" onclick="copySnippet('WPRQ¥PL')"><span class="code-text-val">WPRQ¥PL</span><span style="font-size:11px; color:#64748b; margin-right:8px;">// Price & store published</span><button class="copy-btn">Copy</button></div>
        <p style="margin-top:4px;">Sign & Save:</p>
        <div class="code-block" onclick="copySnippet('6NICKNAME§ER')"><span class="code-text-val">6NICKNAME + ER</span><button class="copy-btn">Copy</button></div>
        <div class="note-box">&bull; <strong>*PQ</strong> &rarr; Check stored fare<br>&bull; <strong>PQD-ALL</strong> &rarr; Delete storing</div>
      </div>
    </div>
    <div class="step-card" data-search="submitting pnr email thread pcc *pnrpnr *pq 9">
      <div class="step-head"><div class="step-num">8</div><div class="step-title">Submitting the PNR</div></div>
      <div class="step-content">
        <p>When sharing a PNR for a sale in an email thread, you must always provide:</p>
        <p>&bull; <strong>PCC</strong> used to create the PNR</p>
        <p>&bull; PNR display: <code style="font-family:'JetBrains Mono'; color:#38bdf8; cursor:pointer;" onclick="copySnippet('*PNRPNR')">*PNRPNR</code></p>
        <p>&bull; Stored fare display: <code style="font-family:'JetBrains Mono'; color:#38bdf8; cursor:pointer;" onclick="copySnippet('*PQ')">*PQ</code></p>
      </div>
    </div>
  </div>
</div>
<div id="toast" class="toast">Copied to clipboard!</div>
<script>
  let paxList = [];
  function copySnippet(text) {
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      const toast = document.getElementById('toast');
      toast.textContent = 'Copied to clipboard!';
      toast.classList.add('show');
      setTimeout(() => toast.classList.remove('show'), 2000);
    });
  }
  function addPaxRow(data) {
    if (paxList.length >= 9) {
      alert("Maximum 9 passengers reached.");
      return;
    }
    const idx = paxList.length;
    const defaultData = data || {
      last: idx === 0 ? 'HASSAN' : (paxList[0]?.last || 'LASTNAME'),
      first: idx === 0 ? 'HANY' : 'FIRSTNAME',
      dob: '30JAN62',
      type: 'ADT',
      gender: 'M',
      ref: (idx + 1) + '.1'
    };
    paxList.push(defaultData);
    renderPaxRows();
  }
  function deletePaxRow(idx) {
    if (paxList.length <= 1) return;
    paxList.splice(idx, 1);
    paxList.forEach((p, i) => { p.ref = (i + 1) + '.1'; });
    renderPaxRows();
  }
  function renderPaxRows() {
    const container = document.getElementById('paxContainer');
    container.innerHTML = '';
    paxList.forEach((pax, idx) => {
      const row = document.createElement('div');
      row.className = 'pax-row';
      row.innerHTML = \`
        <span class="pax-row-num">#\${idx + 1}</span>
        <input type="text" class="builder-input inp-last" placeholder="Last Name" value="\${pax.last}" data-idx="\${idx}" data-field="last">
        <input type="text" class="builder-input inp-first" placeholder="First Name" value="\${pax.first}" data-idx="\${idx}" data-field="first">
        <input type="text" class="builder-input inp-dob" placeholder="DOB" value="\${pax.dob}" data-idx="\${idx}" data-field="dob">
        <select class="builder-select inp-type" data-idx="\${idx}" data-field="type">
          <option value="ADT" \${pax.type === 'ADT' ? 'selected' : ''}>Adult</option>
          <option value="CNN" \${pax.type === 'CNN' ? 'selected' : ''}>Child (C07)</option>
          <option value="INF" \${pax.type === 'INF' ? 'selected' : ''}>Infant (Lap)</option>
          <option value="INS" \${pax.type === 'INS' ? 'selected' : ''}>Infant (Seat)</option>
        </select>
        <select class="builder-select inp-gender" data-idx="\${idx}" data-field="gender">
          <option value="M" \${pax.gender === 'M' ? 'selected' : ''}>Male (M)</option>
          <option value="F" \${pax.gender === 'F' ? 'selected' : ''}>Female (F)</option>
          <option value="MI" \${pax.gender === 'MI' ? 'selected' : ''}>Infant M (MI)</option>
          <option value="FI" \${pax.gender === 'FI' ? 'selected' : ''}>Infant F (FI)</option>
        </select>
        <input type="text" class="builder-input inp-ref" placeholder="Ref" value="\${pax.ref}" data-idx="\${idx}" data-field="ref">
        \${paxList.length > 1 ? \`<button class="btn-del-pax" onclick="deletePaxRow(\${idx})" title="Remove Passenger">&times;</button>\` : ''}
      \`;
      container.appendChild(row);
    });
    document.getElementById('btnAddPax').style.display = paxList.length >= 9 ? 'none' : 'flex';
    updateOutputs();
  }
  function updateOutputs() {
    let nameCmds = [];
    let docsCmds = [];
    let inftCmds = [];
    paxList.forEach((pax) => {
      const last = (pax.last || 'LASTNAME').trim().toUpperCase();
      const first = (pax.first || 'FIRSTNAME').trim().toUpperCase();
      const dob = (pax.dob || '30JAN62').trim().toUpperCase();
      const pType = pax.type;
      const gender = pax.gender;
      const ref = (pax.ref || '1.1').trim();
      let nameCmd = '-' + last + '/' + first;
      if (pType === 'CNN') nameCmd += '*P-C07';
      else if (pType === 'INF') nameCmd = '-I/' + last + '/' + first + '*DOB' + dob;
      else if (pType === 'INS') nameCmd += '*P-INS';
      nameCmds.push(nameCmd);
      const docsFirst = first.replace(/\\s*(MR|MRS|MS|MSTR|MISS)$/i, '').trim();
      const docsCmd = '3DOCS/DB/' + dob + '/' + gender + '/' + last + '/' + docsFirst + '-' + ref;
      docsCmds.push(docsCmd);
      if (pType === 'INF' || gender.includes('I')) {
        const inftCmd = '3INFT/' + last + '/' + docsFirst + '/' + dob + '-' + ref;
        inftCmds.push(inftCmd);
      }
    });
    document.getElementById('outCmdName').textContent = nameCmds.join('\\n');
    document.getElementById('outCmdDocs').textContent = docsCmds.join('\\n');
    const inftRow = document.getElementById('outInftRow');
    if (inftCmds.length > 0) {
      inftRow.style.display = 'flex';
      document.getElementById('outCmdInft').textContent = inftCmds.join('\\n');
    } else {
      inftRow.style.display = 'none';
    }
  }
  document.getElementById('paxContainer').addEventListener('input', function(e) {
    const idx = e.target.getAttribute('data-idx');
    const field = e.target.getAttribute('data-field');
    if (idx !== null && field) {
      paxList[idx][field] = e.target.value;
      updateOutputs();
    }
  });
  document.getElementById('paxContainer').addEventListener('change', function(e) {
    const idx = e.target.getAttribute('data-idx');
    const field = e.target.getAttribute('data-field');
    if (idx !== null && field) {
      paxList[idx][field] = e.target.value;
      updateOutputs();
    }
  });
  addPaxRow({ last: 'HASSAN', first: 'HANY', dob: '30JAN62', type: 'ADT', gender: 'M', ref: '1.1' });
  document.getElementById('guideSearch').addEventListener('input', function() {
    const q = this.value.toLowerCase().trim();
    const cards = document.querySelectorAll('#stepsList .step-card');
    cards.forEach(card => {
      const hay = (card.getAttribute('data-search') + ' ' + card.innerText).toLowerCase();
      card.style.display = (hay.includes(q) ? 'block' : 'none');
    });
  });
<\/script>
</body>
</html>`;
const IA_VIP_HTML = IA_VIP_HTML_BASE.replace('</head>', "<script>document.addEventListener('DOMContentLoaded',function(){try{var L=window.IA_LEAD||{};var p=document.getElementById('pax');if(p&&!p.value&&L.client)p.value=L.client;}catch(e){}});<\/script>" + '</head>');

};
// TBC Assistant — runs the tool on the page with the same helpers it had
// in Tampermonkey (saved settings, styles, tabs, copy), provided by the
// extension instead.
(() => {
  if (window.__tbcxLoaded) return;
  window.__tbcxLoaded = true;
  const D = document;
  const send = (type, obj) => D.dispatchEvent(new CustomEvent('tbcx:' + type, { detail: JSON.stringify(obj) }));
  const cache = new Map();           // key -> saved text (JSON)
  const listeners = new Map();       // id -> { k, fn }
  const watched = new Map();         // key -> number of listeners
  const pending = new Map();         // rpc id -> callback
  const tabs = new Map();            // tab id -> handle
  const menus = new Map();           // menu id -> fn
  let seq = 1;
  const parse = (s) => { try { return JSON.parse(s); } catch (e) { return undefined; } };
  const later = (fn) => Promise.resolve().then(fn);
  function rpc(op, args, cb) {
    const id = cb ? 'r' + (seq++) : 0;
    if (cb) pending.set(id, cb);
    send('rpc', { id, op, args });
  }
  D.addEventListener('tbcx:rpc-res', (e) => {
    const m = parse(e.detail); if (!m) return;
    const cb = pending.get(m.id); if (!cb) return;
    pending.delete(m.id);
    try { cb(m.res); } catch (err) { console.error(err); }
  });
  function fire(k, oldS, newS, remote) {
    if (!watched.get(k)) return;
    const o = oldS === undefined ? undefined : parse(oldS);
    const n = newS === undefined ? undefined : parse(newS);
    for (const l of Array.from(listeners.values())) {
      if (l.k !== k) continue;
      later(() => { try { l.fn(k, o, n, remote); } catch (err) { console.error('[TBC Assistant]', err); } });
    }
  }
  D.addEventListener('tbcx:changed', (e) => {
    const m = parse(e.detail); if (!m) return;
    const old = cache.get(m.k);
    const nv = m.v === null ? undefined : m.v;
    if (old === nv) return; // our own write coming back
    if (nv === undefined) cache.delete(m.k); else cache.set(m.k, nv);
    fire(m.k, old, nv, true);
  });

  const GM_getValue = (k, d) => { const s = cache.get(k); if (s === undefined) return d; const v = parse(s); return v === undefined ? d : v; };
  const GM_setValue = (k, v) => {
    if (v === undefined) { GM_deleteValue(k); return; }
    const s = JSON.stringify(v);
    const old = cache.get(k);
    if (old === s) return;
    cache.set(k, s);
    send('set', { k, v: s });
    fire(k, old, s, false);
  };
  const GM_deleteValue = (k) => {
    const old = cache.get(k);
    if (old === undefined) return;
    cache.delete(k);
    send('set', { k, v: null });
    fire(k, old, undefined, false);
  };
  const GM_listValues = () => Array.from(cache.keys());
  const GM_addValueChangeListener = (k, fn) => {
    const id = seq++;
    listeners.set(id, { k, fn });
    watched.set(k, (watched.get(k) || 0) + 1);
    return id;
  };
  const GM_removeValueChangeListener = (id) => {
    const l = listeners.get(id); if (!l) return;
    listeners.delete(id);
    watched.set(l.k, Math.max(0, (watched.get(l.k) || 1) - 1));
  };
  let styleSeq = 1;
  const GM_addStyle = (css) => {
    const id = 's' + (styleSeq++) + '-' + Math.random().toString(36).slice(2, 8);
    send('style', { id, css: String(css) });
    let el = D.querySelector('style[data-tbcx-style="' + id + '"]');
    if (!el) { el = D.createElement('style'); el.textContent = String(css); (D.head || D.documentElement).appendChild(el); }
    return el;
  };
  const GM_setClipboard = (text) => {
    const t = String(text == null ? '' : text);
    rpc('copy', { text: t });
    // Also try right here, so the text is ready even before the extension answers.
    try { if (navigator.clipboard && D.hasFocus()) navigator.clipboard.writeText(t).catch(() => {}); } catch (e) { /* the extension copies it */ }
  };
  const GM_openInTab = (url, opts) => {
    const o = typeof opts === 'boolean' ? { active: !opts } : (opts || {});
    const h = { closed: false, onclose: null, _id: null, _closeAsked: false,
      close() { if (h.closed) return; if (h._id == null) { h._closeAsked = true; return; } rpc('close', { tabId: h._id }); } };
    let abs = url; try { abs = new URL(url, location.href).href; } catch (e) { /* as given */ }
    rpc('open', { url: abs, active: !!o.active, insert: o.insert !== false, setParent: !!o.setParent }, (res) => {
      if (!res || res.tabId == null) { h.closed = true; return; }
      h._id = res.tabId; tabs.set(res.tabId, h);
      if (h._closeAsked) h.close();
    });
    return h;
  };
  D.addEventListener('tbcx:tabclosed', (e) => {
    const m = parse(e.detail); if (!m) return;
    const h = tabs.get(m.tabId); if (!h) return;
    tabs.delete(m.tabId); h.closed = true;
    if (typeof h.onclose === 'function') { try { h.onclose(); } catch (err) { /* ignore */ } }
  });
  const GM_xmlhttpRequest = (d) => {
    let aborted = false;
    rpc('xhr', { method: d.method || 'GET', url: d.url, headers: d.headers || {}, data: d.data == null ? null : String(d.data) }, (res) => {
      if (aborted) return;
      if (!res || res.error) { if (d.onerror) d.onerror(res || { error: 'failed' }); return; }
      const r = Object.assign({ readyState: 4 }, res);
      if (d.onload) d.onload(r);
      if (d.onloadend) d.onloadend(r);
    });
    return { abort() { aborted = true; } };
  };
  const GM_registerMenuCommand = (caption, fn) => {
    const id = 'm' + (seq++);
    menus.set(id, fn);
    if (window.top === window) rpc('menu-add', { id, caption: String(caption) });
    return id;
  };
  const GM_unregisterMenuCommand = (id) => { menus.delete(id); if (window.top === window) rpc('menu-remove', { id }); };
  D.addEventListener('tbcx:menu-run', (e) => {
    const m = parse(e.detail); if (!m) return;
    const fn = menus.get(m.id);
    if (fn) { try { fn(); } catch (err) { console.error(err); } }
  });
  const GM_info = { script: Object.assign({}, window.__tbcxMeta), scriptHandler: 'TBC Assistant extension', version: window.__tbcxMeta.version };
  try { delete window.__tbcxMeta; } catch (e) { /* ignore */ }

  D.addEventListener('tbcx:init', (e) => {
    const m = parse(e.detail); if (!m || !m.data) return;
    Object.keys(m.data).forEach((k) => { const v = m.data[k]; if (typeof v === 'string') cache.set(k, v); });
    const run = window.__tbcxRun; try { delete window.__tbcxRun; } catch (err) { window.__tbcxRun = undefined; }
    if (typeof run !== 'function') return;
    try {
      run(GM_getValue, GM_setValue, GM_deleteValue, GM_listValues, GM_addValueChangeListener, GM_removeValueChangeListener,
        GM_addStyle, GM_setClipboard, GM_openInTab, GM_xmlhttpRequest, GM_registerMenuCommand, GM_unregisterMenuCommand, GM_info, window);
    } catch (err) { console.error('[TBC Assistant]', err); }
  }, { once: true });
  send('hello', {});
})();
